//�Xara Ltd
if(typeof(loc)=="undefined"||loc==""){var loc="";if(document.body&&document.body.innerHTML){var tt=document.body.innerHTML;var ml=tt.match(/["']([^'"]*)dimpletab.js["']/i);if(ml && ml.length > 1) loc=ml[1];}}

var bd=0
document.write("<style type=\"text/css\">");
document.write("\n<!--\n");
var tr="filter:alpha(opacity=94);-moz-opacity:0.94;";if(IE5) tr="";
document.write(".dimpletab_menu {"+tr+"z-index:999;border-color:#000000;border-style:solid;border-width:"+bd+"px 0px "+bd+"px 0px;background-color:#99ccff;position:absolute;left:0px;top:0px;visibility:hidden;}");
document.write(".dimpletab_plain, a.dimpletab_plain:link, a.dimpletab_plain:visited{text-align:left;background-color:#99ccff;color:#15428b;text-decoration:none;border-color:#000000;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:8pt;font-family:Tahoma, Verdana, Arial, sans-serif;font-weight:bold;}");
document.write("a.dimpletab_plain:hover, a.dimpletab_plain:active{background-color:#15428b;color:#ffffff;text-decoration:none;border-color:#000000;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:8pt;font-family:Tahoma, Verdana, Arial, sans-serif;font-weight:bold;}");
document.write("\n-->\n");
document.write("</style>");

var fc=0xffffff;
var bc=0x15428b;
if(typeof(frames)=="undefined"){var frames=4;if(frames>0)animate();}

startMainMenu("",0,0,1,0,0)
mainMenuItem("dimpletab_b1",".gif",25,156,"javascript:;","","Home",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b2",".gif",25,156,"javascript:;","","File",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b3",".gif",25,156,"javascript:;","","Basic Setup",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b4",".gif",25,156,"javascript:;","","Employee Information",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b5",".gif",25,156,"javascript:;","","Data",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b6",".gif",25,156,"javascript:;","","Leave",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b7",".gif",25,156,"javascript:;","","Reports",1,2,"dimpletab_plain");
mainMenuItem("dimpletab_b8",".gif",25,156,"javascript:;","","Utility",1,2,"dimpletab_plain");
endMainMenu("",0,0);

//startSubmenu("dimpletab_b8","dimpletab_menu",111);
//submenuItem("Create User","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Change Password","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("User permission","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b8");

//startSubmenu("dimpletab_b7","dimpletab_menu",127);
//submenuItem("Daily Report","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Job Card","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Monthly Attendance","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Monthly Late","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Monthly Absent","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Menu Text","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b7");

//startSubmenu("dimpletab_b6","dimpletab_menu",104);
//submenuItem("Leave Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Leave Apply","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Leave Approved","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Leave Transfer","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b6");

//startSubmenu("dimpletab_b5","dimpletab_menu",97);
//submenuItem("Data Collection","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Data Process","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b5");

//startSubmenu("dimpletab_b4","dimpletab_menu",113);
//submenuItem("Information Entry","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Information List","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Disable","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Enable","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b4");

//startSubmenu("dimpletab_b3","dimpletab_menu",135);
//submenuItem("Company Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Department Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Section Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Designation Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Shift Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Menual Entry","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("OSD Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Weekly Holiday Setup","javascript:;","","dimpletab_plain");
//submenuItem("---","javascript:;","","dimpletab_plain");
//submenuItem("Govt. Holiday Setup","javascript:;","","dimpletab_plain");
//submenuItem("&copy;Xara","http://www.xara.com/products/MenuMaker/mmtrialmenu.asp","","dimpletab_plain");
//endSubmenu("dimpletab_b3");

startSubmenu("dimpletab_b8","dimpletab_menu",113);
submenuItem("Create User","Default.aspx?Page=CreateUser","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Change Password","javascript:;","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Role Creation","Default.aspx?Page=RoleCreation","","dimpletab_plain");
submenuItem("Permission Assign","Default.aspx?Page=FormManagement","","dimpletab_plain");
endSubmenu("dimpletab_b8");

startSubmenu("dimpletab_b7","dimpletab_menu",122);
submenuItem("Daily Report","Default.aspx?Page=DailyAttendanceViewer","","dimpletab_plain");
submenuItem("---","Default.aspx?Page=JobCard","","dimpletab_plain");
submenuItem("Job Card","javascript:;","","dimpletab_plain");
submenuItem("---","Default.aspx?Page=MonthlyReport","","dimpletab_plain");
submenuItem("Monthly Report","Default.aspx?Page=MonthlyReport","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Employee Info","Default.aspx?Page=EmployeeInformationReport","","dimpletab_plain");
submenuItem("New Employee Info","Default.aspx?Page=NewEmployeeInformation","","dimpletab_plain");
submenuItem("Resign Employee Info","Default.aspx?Page=ResignEmployeeInformation","","dimpletab_plain");
submenuItem("Leave Info","Default.aspx?Page=LeaveInformationReport","","dimpletab_plain");
submenuItem("Leave Balance Info","Default.aspx?Page=LeaveBalanceReport","","dimpletab_plain");
endSubmenu("dimpletab_b7");

startSubmenu("dimpletab_b6","dimpletab_menu",102);
submenuItem("Leave Setup","Default.aspx?Page=LeaveConfiguration","","dimpletab_plain");
submenuItem("Leave Leave Type Setup","Default.aspx?Page=LeaveTypeInfo","","dimpletab_plain");
submenuItem("Leave Apply","Default.aspx?Page=LeaveInformationEntry","","dimpletab_plain");
submenuItem("Leave Approved","Default.aspx?Page=LeaveApprove","","dimpletab_plain");
submenuItem("Leave Status","Default.aspx?Page=LeaveStatus","","dimpletab_plain");
submenuItem("Leave Transfer","Default.aspx?Page=LeaveTransfer","","dimpletab_plain");

submenuItem("Leave Approved","Default.aspx?Page=LeaveApprove","","dimpletab_plain");
endSubmenu("dimpletab_b6");

startSubmenu("dimpletab_b5","dimpletab_menu",93);
submenuItem("Data Collection","Default.aspx?Page=TextDataCollect","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Data Process","Default.aspx?Page=DailyProcess","","dimpletab_plain");
endSubmenu("dimpletab_b5");

startSubmenu("dimpletab_b4","dimpletab_menu",107);
submenuItem("Information Entry","Default.aspx?Page=Employee","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Information List","Default.aspx?Page=EmployeeBrouser","","dimpletab_plain");
submenuItem("---","Default.aspx?Page=Enable","","dimpletab_plain");
submenuItem("Enable","Default.aspx?Page=Enable","","dimpletab_plain");
endSubmenu("dimpletab_b4");

startSubmenu("dimpletab_b3","dimpletab_menu",129);
submenuItem("Company Setup","Default.aspx?Page=CompanyInfo","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Department Setup","Default.aspx?Page=DepartmentInfo","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Section Setup","Default.aspx?Page=SectionInfo","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Designation Setup","Default.aspx?Page=DesignationForm","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Shift Setup","Default.aspx?Page=Shift","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Menual Entry","javascript:;","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("OSD Setup","Default.aspx?Page=OSDForm","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Weekly Holiday Setup","Default.aspx?Page=WeeklyHoliday","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Govt. Holiday Setup","Default.aspx?Page=GovtHolidayForm","","dimpletab_plain");
endSubmenu("dimpletab_b3");

startSubmenu("dimpletab_b2","dimpletab_menu",62);
submenuItem("LogOff","javascript:;","","dimpletab_plain");
submenuItem("---","javascript:;","","dimpletab_plain");
submenuItem("Exit","javascript:;","","dimpletab_plain");
endSubmenu("dimpletab_b2");

loc="";
