
function EditCheckEffect(hidEditCheckedIDS,editChkID,deleteChkID)
{
         var hidobj = document.getElementById(hidEditCheckedIDS);    
         var values = hidobj.value.split(",");
         for (i = 0;  i < values.length;  i++)
         {
           var tempEditID = values[i];
           var tempobj = document.getElementById(values[i]);
           if(tempEditID!=editChkID)
            {
             tempobj.checked =false;
            }
         }
         var delobj =  document.getElementById(deleteChkID);
         delobj.checked =false;
}
    
     function NotificationDoubleClick(iValueH) 
     {
        window.location = "Default.aspx?Page=LeaveApprove&&TesingId="+iValueH+"";
     }
    function DeleteCheckEffect(deleteChkID,editChkID)
    {  
      //alert("Delete Clicked");
        var delobj = document.getElementById(deleteChkID);
        var editobj = document.getElementById(editChkID);
        editobj.checked = false;
    }
     function disp_confirm()
     {    
        var r = confirm("Are you sure you want to delete?");
        return r;
     }
    
     function SelectAll(id) 
     {
       var frm = document.forms[0];
       for (i=0;i<frm.elements.length;i++) 
       {
           if (frm.elements[i].type == "checkbox") 
           {
               frm.elements[i].checked = document.getElementById(id).checked;
           }
        }
      } 