﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Role;

public partial class login : System.Web.UI.Page
{
    RoleData obj_RoleData;
    SqlCommand cmd = new SqlCommand();
    SqlConnection con;
    ArrayList arrUsername = new ArrayList();
    ArrayList arrUserNumber = new ArrayList();
    ArrayList arrFormName = new ArrayList();
    ArrayList arrFormDescription = new ArrayList();

    protected void Page_Load(object sender, EventArgs e)
    {
        userNameTextBox.Focus();
    }

    private void CheckingPermission()
    {
        ArrayList UserPermissionFunction = new ArrayList();
        ArrayList User_Number = new ArrayList();
        string logStr = "select User_Number from tblUser  where UserId='" + userNameTextBox.Text + "' ";
        DataSet dsUser = new DataSet();
        dsUser = ClsCommon.GetAdhocResult(logStr);

        foreach (DataRow dRow in dsUser.Tables[0].Rows)
        {
            UserPermissionFunction.Add(dRow);
        }
        foreach (Object objRow in UserPermissionFunction)
        {
            User_Number.Add(((DataRow)objRow)["User_Number"].ToString());
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string logStr = "select * from tblUser  where UserId='" + userNameTextBox.Text.Trim() + "' and UserPassword='" + passwordTextBox.Text + "'";

        bool log;
        log = ClsCommon.ItemCheck(logStr);
        if (!log)
        {
            invalidLogin.Visible = true;
            invalidLogin.Text = "Please type valid username & Password ";
            userNameTextBox.Text = "";
            passwordTextBox.Text = "";
            userNameTextBox.Focus();
        }
        else
        {
            FunctionaUserRole(userNameTextBox.Text.Trim());
            Session["LogIn"] = "LogIn";
            Session["Username"] = userNameTextBox.Text.Trim();
            Response.Redirect("Welcomepage.aspx");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        userNameTextBox.Text = "";
        passwordTextBox.Text = "";
        userNameTextBox.Focus();
    }

    private void FunctionaUserRole(string userid)
    {
        obj_RoleData = new RoleData();
        con = obj_RoleData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "Select dbo.tblFunction.FormConstant,dbo.tblFunction.Function_Desc,dbo.tblUser.UserId,dbo.tblUser.User_number From tblFunction inner join tlbRole on dbo.tblFunction.Role_Number=dbo.tlbRole.Role_Number inner join tblUser on dbo.tlbRole.User_Name = dbo.tblUser.UserId where tblUser.UserId='" + userid.Trim() + "' order by FormConstant";
        SqlDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            arrUsername.Add(Convert.ToString(reader["UserId"]));
            arrUserNumber.Add(Convert.ToInt32(reader["User_number"]));
            arrFormName.Add(Convert.ToString(reader["FormConstant"]));
            arrFormDescription.Add(Convert.ToString(reader["Function_Desc"]));
        }
        Session["FormConstant"] = arrFormName;
        Session["FunctionDesc"] = arrFormDescription;
    }
}
