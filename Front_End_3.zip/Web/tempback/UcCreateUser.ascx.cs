﻿using System;
using System.Collections;
using System.Configuration;

using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Data;

public partial class PageControls_UcCreateUser : System.Web.UI.UserControl
{
    private User _obj;

    ProcessUserSelect pus = new ProcessUserSelect();
    DataTable dt = new DataTable();
    public void GridUserShow()
    {
        string strSearchUser = "select User_Number,UserId,UserPassword,UserType from tblUser";
        DataSet dsUser = new DataSet();
        dsUser = ClsCommon.GetAdhocResult(strSearchUser);
        gvwUser.DataSource = dsUser;
        gvwUser.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["LogIn"] != null)
            {
                btnSave.Enabled = true;
                btnFresh.Enabled = true;
                btnClose.Enabled = true;
                btnUpdate.Enabled = false;
                GridUserShow();
            }
            else
                Response.Redirect("login.aspx");
        }
    }
    protected void btnDelChkUser_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "D"))
            {
                foreach (GridViewRow gr in gvwUser.Rows)
                {
                    CheckBox del = (CheckBox)gr.FindControl("userDeleteCheckBox");
                    if (del.Checked)
                    {
                        HiddenField HidUser_Number = (HiddenField)gr.FindControl("HidDelUser_Number");
                        Session["HidDelUser_Number"] = Convert.ToInt16(HidUser_Number.Value);
                        UserDelete();
                        userLabel.Text = "Data deleted successfully";
                        GridUserShow();
                    }
                }
            }
            else
            {
                userLabel.Visible = true;
                userLabel.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEditChkUser_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "U"))
            {
                foreach (GridViewRow gr in gvwUser.Rows)
                {
                    CheckBox _edit = (CheckBox)gr.FindControl("userEditCheckBox");
                    if (_edit.Checked)
                    {
                        HiddenField HidUser_Number = (HiddenField)gr.FindControl("HidUser_Number");
                        HiddenField HidUser_Id = (HiddenField)gr.FindControl("HidUserId");
                        HiddenField HidUserPass = (HiddenField)gr.FindControl("HidUserPass");


                        UserNameTextBox.Text = HidUser_Id.Value;
                        passtxt.Text = HidUserPass.Value;
                        Session["HidUser_Number"] = Convert.ToInt16(HidUser_Number.Value);
                        headerLabel.Text = "Update User ";
                    }

                }

                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
            }
            else
            {
                userLabel.Visible = true;
                userLabel.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    public void Refresh()
    {
        UserNameTextBox.Text = "";
        passtxt.Text = "";
        ConPassTextBox.Text = "";
        GridUserShow();
        btnSave.Enabled = true;


    }
    public void AddUser()
    {
        _obj = new User();
        try
        {
            _obj.UName = UserNameTextBox.Text;
            _obj.UPassword = passtxt.Text;

            _obj.UType = "";

            ProcessUserInsert pui = new ProcessUserInsert();
            pui.PUser = _obj;
            pui.invoke();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void UserDelete()
    {
        User _objectUser = new User();

        try
        {

            _objectUser.UserNo = Convert.ToInt16(Session["HidDelUser_Number"].ToString());
            // _obj.UserNo = Convert.ToInt16(Session["HidDelUser_Number"].ToString());
            ProcessUserDelete pud = new ProcessUserDelete();
            pud.Ur = _objectUser;
            pud.invoke();
        }
        catch (Exception e)
        {
            e.Message.ToString();
        }
    }
    public void UpdateUser()
    {

        User _objUpUser = new User();
        try
        {
            // receive the drop down list value(userPassword)
            // _objUpUser.UAccept = srhDropDownList.SelectedItem.Value.ToString();
            _objUpUser.UserNo = Convert.ToInt16(Session["HidUser_Number"].ToString());
            _objUpUser.UName = UserNameTextBox.Text;
            _objUpUser.UPassword = passtxt.Text;
            _objUpUser.UType = "";

            ProcessUserUpdate puu = new ProcessUserUpdate();
            puu.userUp = _objUpUser;
            puu.invoke();
        }
        catch (Exception e)
        {
            e.Message.ToString();
        }
    }
    protected void ReloadAll()
    {

        foreach (GridViewRow oGrid in gvwUser.Rows)
        {

            CheckBox oCheckbox = (CheckBox)oGrid.FindControl("userEditCheckBox");

            if (oCheckbox.Checked)
            {
            }
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            ReloadAll();
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpd_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            string strUser = "select * from tblUser where UserId='" + UserNameTextBox.Text + "'";
            if (UserNameTextBox.Text.Trim().Equals("") || passtxt.Text.Trim().Equals(""))
                userLabel.Text = "Please fills the required fields";
            else
            {
                UpdateUser();
                userLabel.Text = "Data updated successfully";
            }
            GridUserShow();
            Refresh();
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
      
    }
    protected void UserNameTextBox_TextChanged(object sender, EventArgs e)
    {
    }

    protected void btnUserSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int userIndex = 0;
            userIndex = ddlSearchUser.SelectedIndex;
            DataSet dsUser = new DataSet();
            if (userIndex == 0)
            {
                string strUser = "select * from tblUser where UserId='" + searchUserTextBox.Text + "'";
                dsUser = ClsCommon.GetAdhocResult(strUser);
                gvwUser.DataSource = dsUser;
                gvwUser.DataBind();
            }
            else
            {
                string strUser = "select * from tblUser where User_Number='" + searchUserTextBox.Text + "'";
                userIndex = ddlSearchUser.SelectedIndex;
                dsUser = ClsCommon.GetAdhocResult(strUser);
                gvwUser.DataSource = dsUser;
                gvwUser.DataBind();
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void gvwUser_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("userEditCheckBox");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("userDeleteCheckBox");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

    protected void btnFresh_Click(object sender, EventArgs e)
    {
        Refresh();
        GridUserShow();
        userLabel.Text = "";
        headerLabel.Text = "";
    }
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "C"))
            {
                string strUser = "select * from tblUser where UserId='" + UserNameTextBox.Text + "'";
                bool user;
                user = ClsCommon.ItemCheck(strUser);
                if (UserNameTextBox.Text.Trim().Equals("") || passtxt.Text.Trim().Equals(""))
                    userLabel.Text = "Please fills the required fields";
                else if (user)
                {
                    userLabel.Visible = true;
                    userLabel.Text = "Data already existed";
                }
                else
                {
                    AddUser();
                    userLabel.Visible = true;
                    userLabel.Text = "Data saved successfully";
                }
                Refresh();
                GridUserShow();
            }
            else
            {
                userLabel.Visible = true;
                userLabel.Text = "Unable to process request";
            }
        }
    }
}
