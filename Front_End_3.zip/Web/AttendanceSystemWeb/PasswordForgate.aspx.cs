﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Role;
using AttendanceSystem.Dal.Report;
using GAVarificationService;
using System.Text;
using System.Management;
using System.IO;
using System.Text;
using System.Security;
using System.Security.Cryptography;
using System.Net;
using System.Net.Mail;

public partial class PasswordForgate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //String StrPath = Server.MapPath("~\\images\\");
            //imgContent.ImageUrl = new CUtility().PictureUpload(StrPath);
        }
    }
    private String GetPasswordFromUserId()
    {
        String EncryptPassword = "";
        String OriginalPassword = "";
        String Email = "";
        String Sql = "Select UserPassword,Email from tblUser where UserId = '" + txtUserId.Text.Trim() + "'";
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            EncryptPassword = reader["UserPassword"].ToString();
            Email = reader["Email"].ToString();
        }
        if (EncryptPassword != "" && Email == userNameTextBox.Text.Trim())
        {
            OriginalPassword = new CUtility().Decrypt(EncryptPassword);
        }
        return OriginalPassword;
    }
    private Int32 MialSending()
    {
        Int32 RntValue = 0;
        if (GetPasswordFromUserId() != "")
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(userNameTextBox.Text.Trim().ToString());
            //mail.To.Add("bablu12_kuet@yahoo.com");
            mail.From = new MailAddress("info@ga-limited.com");
            mail.Subject = "General Automation Password Recovery";
            String Body = "<table><tr><td>User Name:</td><td>" + txtUserId.Text.Trim() + " </td>";
            Body = Body + "</tr> <tr><td>Passwodr:</td><td>" + GetPasswordFromUserId() + "</td></tr></table>";
            mail.Body = Body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
            //smtp.Host = "smtp.gmail.com,587"; 
            smtp.Credentials = new System.Net.NetworkCredential
                 ("ga.system@ga-limited.com", "system123");
            //Or your Smtp Email ID and Password
            smtp.EnableSsl = true;
            smtp.Send(mail);
            RntValue = 1;
        }
        return RntValue;
    }
    protected void btnPassword_Click(object sender, EventArgs e)
    {
        if (txtUserId.Text != "" && userNameTextBox.Text != "")
        {
            if (MialSending() == 1)
            {
                lblPassword.Visible = true;
                lblPassword.ForeColor = System.Drawing.Color.Green;
                lblPassword.Text = "Password Has Been Sent To Your E-mail.";
            }
            else
            {
                lblPassword.Visible = true;
                lblPassword.ForeColor = System.Drawing.Color.Red;
                lblPassword.Text = "User Id or E-mail Id Not Valid.";
            }
        }
        else
        {
            lblPassword.Visible = true;
            lblPassword.ForeColor = System.Drawing.Color.Red;
            lblPassword.Text = "User Id or E-mail Id Required.";
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
}
