﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Role;
using AttendanceSystem.Dal.Report;
using GAVarificationService;
using System.Text;
using System.Management;
using System.IO;
using System.Text;
using System.Security;
using System.Security.Cryptography;

public partial class login : System.Web.UI.Page
{
    #region Declaration

    RoleData obj_RoleData;
    SqlCommand cmd = new SqlCommand();
    SqlConnection con;
    ArrayList arrUsername = new ArrayList();
    ArrayList arrUserNumber = new ArrayList();
    ArrayList arrFormName = new ArrayList();
    ArrayList arrFormDescription = new ArrayList();
    DateTime serverdate = DateTime.Now.Date;
    string decDateString = "";
    int newEntry = int.MinValue;
    ReportData objReportData = new ReportData();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            userNameTextBox.Focus();
            //String StrPath = Server.MapPath("~\\images\\");
            //imgContent.ImageUrl = new CUtility().PictureUpload(StrPath);
            DeleteExpiredUser();
        }
    }

    #endregion

    #region Private Methods
     
    private void DeleteExpiredUser()
    {
        try
        {
            String Sql = "ExpiredUserDelete";
            con = new SqlConnection();
            cmd = new SqlCommand();
            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;
            cmd.Parameters.Add("@CurrnetDate", DateTime.Now);
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private Int32 UserAvailable(String UserId)
    {
        Int32 rntPassword = 0;
        try
        {
            String Sql = "select count(*) UserAvail from tblUser where UserId = '" + UserId + "'";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Sql;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                rntPassword = int.Parse(reader["UserAvail"].ToString());
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        return rntPassword;
    }
    private void CheckingPermission()
    {
        ArrayList UserPermissionFunction = new ArrayList();
        ArrayList User_Number = new ArrayList();
        string logStr = "select User_Number from tblUser  where UserId='" + userNameTextBox.Text + "' ";
        DataSet dsUser = new DataSet();
        dsUser = ClsCommon.GetAdhocResult(logStr);

        foreach (DataRow dRow in dsUser.Tables[0].Rows)
        {
            UserPermissionFunction.Add(dRow);
        }
        foreach (Object objRow in UserPermissionFunction)
        {
            User_Number.Add(((DataRow)objRow)["User_Number"].ToString());
        }
    }
    public String GetPassword(string UserId)
    {
        String rntPassword = "";
        String Sql = "select UserPassword from tblUser where UserId = '" + UserId + "'";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            rntPassword = reader["UserPassword"].ToString();
        }
        return rntPassword;
    }
    private void FunctionaUserRole(string userid)
    {
        obj_RoleData = new RoleData();
        con = obj_RoleData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
       //cmd.CommandText = "Select dbo.tblFunction.FormConstant,dbo.tblFunction.Function_Desc,dbo.tblUser.UserId,dbo.tblUser.Username,tblEmployee.EmpName,dbo.tblUser.User_number,dbo.tblUser.UserType,Role_Name From tblFunction inner join tlbRole on dbo.tblFunction.Role_Number=dbo.tlbRole.Role_Number inner join tblUser on dbo.tlbRole.User_Name = dbo.tblUser.UserId inner join tblEmployee on tblUser.UserName=tblEmployee.Emp_Number where tblUser.UserId='" + userid.Trim() + "' and Function_Desc <>'----' order by FormConstant";
        cmd.CommandText = "Select dbo.tblFunction.FormConstant,dbo.tblFunction.Function_Desc,dbo.tblUser.UserId,dbo.tblUser.Username,tblEmployee.EmpName,dbo.tblUser.User_number,dbo.tblUser.UserType,Role_Name From tblFunction inner join tlbRole on dbo.tblFunction.Role_Number=dbo.tlbRole.Role_Number inner join tblUser on dbo.tlbRole.Role_Number = dbo.tblUser.Role_Number inner join tblEmployee on tblUser.UserName=tblEmployee.Emp_Number where tblUser.UserId='" + userid.Trim() + "' and Function_Desc <>'----' order by FormConstant";
        SqlDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            arrUsername.Add(Convert.ToString(reader["UserId"]));
            arrUserNumber.Add(Convert.ToInt32(reader["User_number"]));
            arrFormName.Add(Convert.ToString(reader["FormConstant"]));
            arrFormDescription.Add(Convert.ToString(reader["Function_Desc"]));
            
            Session["UserType"] = reader["UserType"].ToString();
            Session["User_Number"] = reader["Username"].ToString();
            Session["UserId"] = reader["UserId"];
            Session["Role_Name"] = reader["Role_Name"];
            Session["tmpEmp_Number"] = reader["Username"];// For Other Employee
            Session["tmpDept_Head"] = reader["Role_Name"];// For Showing Data for Dept Head
            Session["EmpName"] = reader["EmpName"];
            string var = Session["tmpDept_Head"].ToString();
            string var2 = Session["Role_Name"].ToString();
        }
        if (arrFormName.Count > 0)
        {
            Session["FormConstant"] = arrFormName;
            Session["FunctionDesc"] = arrFormDescription;
        }
    }
    public bool AbaleToLogin()
    {

        try
        {
            string strServerDate = " select getdate() as  servdate ";
            string GetData;
            DataSet ds = ClsCommon.GetAdhocResult(strServerDate);

            serverdate = DateTime.Parse(ds.Tables[0].Rows[0]["servdate"].ToString());
            string strSQl = " select * from tblAccessControl where CompId='" + ConfigurationSettings.AppSettings["APPLICATIONID"].ToString() + "' ";

            GetData = GetString(serverdate.ToString("dd/MM/yyyy"));

            DataSet dsResult = ClsCommon.GetAdhocResult(strSQl);

            if (dsResult.Tables[0].Rows.Count > 0)
            {
                newEntry = 2;

                string encDateString = dsResult.Tables[0].Rows[0]["ExpDate"].ToString();//"<;:@<::A:";
                if (encDateString == "")
                {
                    return false;
                }

                decDateString = DeCryptData(encDateString);

                string decAcctualstr = decDateString.Substring(0, decDateString.Length - 1);

                DateTime dtDate = new DateTime(int.Parse(decAcctualstr.Substring(4, 4)), int.Parse(decAcctualstr.Substring(2, 2)), int.Parse(decAcctualstr.Substring(0, 2)));

                if (serverdate <= dtDate)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                newEntry = 1;
                return false;

            }
        }
        catch (Exception er)
        {
            return false;
        }
    }
    public bool IsTempared(string DBstr, string servicestr)
    {
        if (DBstr == servicestr)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public bool GetActiveDateFromService(string MyCompId, DateTime serverdate)
    {
        string decServiceStr = "";
        string sqlUpdate = "";
        bool retval = false;
        GAVarificationService.VerificationServiceClient oVarify = new VerificationServiceClient("BasicHttpBinding_IVerificationService", "http://192.168.0.1/GALService/GVerify.svc/basic");

        decServiceStr = oVarify.GetData(MyCompId, serverdate);
        string[] GivenValues = decServiceStr.Split(',');

        if (newEntry == 1)
        {
            sqlUpdate = " insert into tblAccessControl(CompId,ExpDate) values('" + MyCompId + "','" + GivenValues[1].ToString() + "') ";

        }

        if (newEntry == 2)
        {
            sqlUpdate = " update tblAccessControl set ExpDate='" + GivenValues[1].ToString() + "' where CompId='" + MyCompId + "' ";

        }

        int returnedrecord = ClsCommon.ExecuteAdhocQuery(sqlUpdate);

        if (returnedrecord > 0)
        {
            retval = true;
        }

        return retval;
    }
    public static string GetString(string DT)
    {
        string str;
        int len = 0;
        len = DT.Length;
        string[] strArray = new String[20];
        strArray = DT.Split('/');
        str = strArray[0] + strArray[1] + strArray[2];
        return str;
    }
    public static string GenerateID(string str)
    {
        double b_k, b_p, b_6, b_7, b_x, b_remndr, b_12thdgt, b_Check;
        b_k = 11;
        b_7 = 7;
        b_6 = 6;
        b_x = 0;

        for (b_p = 2; b_p < b_7; b_p++)
        {
            b_x = b_x + b_p * (Convert.ToDouble(str));
            b_k = b_k - 1;
        }
        for (b_p = 2; b_p < b_6; b_p++)
        {
            b_x = b_x + b_p * Convert.ToDouble(str);
            b_k = b_k - 1;
        }
        b_remndr = b_x % 11;
        if (b_remndr == 1)
            b_12thdgt = 1;
        else if (b_remndr == 0)
            b_12thdgt = 0;
        else
            b_12thdgt = 11 - b_remndr;
        b_Check = b_12thdgt;


        return str + b_Check.ToString();

    }
    public static string DeCryptData(string Data)
    {
        string Encrypt;
        int CharStr;
        int i;
        Encrypt = "";
        for (i = 0; i < Data.Length; i++)
        {
            char[] df = Data.Substring(i, 1).ToCharArray();
            CharStr = Convert.ToInt16(df[0]) - 10;
            Encrypt = Encrypt + Convert.ToChar(CharStr);
        }
        return Encrypt;
    }
    public string DegenerateID(string encrID)
    {
        return encrID.Substring((encrID.Length - 1), 1);
    }
    public string HasInstallationID()
    {
        string sInstallID = "";

        string strServerDate = " select * from  tblAccessControl ";
        string GetData;
        DataSet ds = ClsCommon.GetAdhocResult(strServerDate);
        DataTable dt = ds.Tables[0];
        //CompId
        string sCompId = dt.Rows[0]["CompId"].ToString().Trim();
        sInstallID = dt.Rows[0]["InstallID"].ToString().Trim();

        return sInstallID;
    }
    protected bool CallInstallation()
    {
        bool result = false;
        try
        {
            GAVarificationService.VerificationServiceClient oVarify = new VerificationServiceClient("BasicHttpBinding_IVerificationService", "http://192.168.0.1/GALService/GVerify.svc/basic");

            string sApplicationID = ConfigurationSettings.AppSettings["APPLICATIONID"].ToString();

            string stReturn = "";

            stReturn = oVarify.GetCompanyPermission(sApplicationID);

            if (stReturn != "")
            {
                PutValueInDB(sApplicationID, stReturn);
            }
            else
            {
                string serialnumber = GetHardDriveSerialnumber();
                string stReturn2 = oVarify.PutMySession(sApplicationID, serialnumber, DateTime.Now.ToString("dd/MMM/yyyy"));
            }


            //PutMySession(sApplicationID, serialnumber, DateTime.Now.ToString());

            result = true;
        }
        catch (Exception e)
        {
            result = false;

        }

        return result;
    }
    protected string GetHardDriveSerialnumber()
    {
        ManagementObjectSearcher oManagement = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
        string serialnumber = "";

        foreach (ManagementObject wmi_HD in oManagement.Get())
        {
            if (wmi_HD["Model"] != null)
            {
                serialnumber = wmi_HD["Model"].ToString();

            }
        }


        //ManagementScope managementScope = new ManagementScope(@"\root\cimv2");
        //managementScope.Options.Impersonation = ImpersonationLevel.Impersonate;
        //ManagementObjectSearcher searcher = new ManagementObjectSearcher(managementScope, new ObjectQuery("SELECT * FROM Win32_DiskDrive WHERE InterfaceType=\"IDE\" or InterfaceType=\"SCSI\""));
        //foreach (ManagementObject disk in searcher.Get())
        //{
        //    if (disk["PNPDeviceID"] != null)
        //    {
        //        string pnpDeviceID = disk["PNPDeviceID"].ToString();
        //        string[] split = pnpDeviceID.Split('\\');

        //        byte[] bytes = GetHexStringBytes(split[2]);
        //        string serial = this.ReverseSerialNumber(Encoding.UTF8.GetString(bytes));


        //    }
        //}

        return serialnumber;
    }
    private string ReverseSerialNumber(string serialNumber)
    {
        serialNumber = serialNumber.Trim();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < serialNumber.Length; i += 2)
        {
            sb.Append(serialNumber[i + 1].ToString() + serialNumber[i].ToString());
        }
        serialNumber = sb.ToString();
        sb = null;
        return serialNumber;
    }
    public static Byte[] GetHexStringBytes(string hex)
    {
        try
        {
            if (hex.Contains(String.Empty))
            {
                hex = hex.Replace(" ", String.Empty);
            }
            if (hex.Length % 2 == 1)
            {
                hex = "0" + hex;
            }
            int size = hex.Length / 2;
            Byte[] bytes = new Byte[size];
            for (int i = 0; i < size; i++)
            {
                bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            }
            return bytes;
        }
        catch
        {
            return new byte[] { };
        }
    }
    public bool PutValueInDB(string ApplicationID, string strValue)
    {
        bool succes = false;
        try
        {
            //DBGateWay oGateWay = new DBGateWay();
            //using (oSqlConnection = oGateWay.OpenConnection())
            //{
            //    oSqlConnection.Open();

            string SQl = " update  [dbo].[tblAccessControl] set InstallID='" + strValue.Trim() + "'  where CompId='" + ApplicationID.Trim() + "' ";

            //SQl = SQl + " INSERT INTO [dbo].[tbl_Company_Activation]  ";
            //SQl = SQl + " ( [CompId],[HardSerialNumber],[RequestTime],[Createdate])  ";
            //SQl = SQl + " VALUES ( '" + ApplicationID.Trim() + "','" + MySerialValue.Trim() + "','" + DateTime.Parse(ServerRequestTime).ToString("dd/MMM/yyyy") + "','" + DateTime.Now.Date.ToString("dd/MMM/yyyy") + "' ) ";

            ClsCommon.ExecuteAdhocQuery(SQl);

            succes = true;
            //    SqlCommand command = new SqlCommand(SQl, oSqlConnection);
            //    command.CommandType = CommandType.Text;
            //    command.ExecuteNonQuery();

            //}
        }
        catch (Exception e)
        {
            succes = false;
            // throw;
        }
        return succes;
    }
    private Int32 UserStillValideORNot(String UserId)
    {
        Int32 rntvalue = 0;
        String rntDate = "";
        String Today = DateTime.Now.ToString();
        DateTime rntDateTime;
        DateTime TodatDateTime;

        try
        {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();

            String Sql = "select isnull(ValidDate,'') as ValidDate from tblUser where UserId = '" + UserId + "'";

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Sql;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                rntDate = reader["ValidDate"].ToString();
            }
            rntDateTime = DateTime.Parse(rntDate);
            TodatDateTime = DateTime.Parse(Today);

            if (DateTime.Compare(rntDateTime, TodatDateTime) >= 0)
                rntvalue = 1;
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }


        return rntvalue;
    }

    #endregion

    #region Button Handlers

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        String PasswordEncrypt = "";
        String PasswordByUserId = "";
        String PasswordDecrypt = "";
        //string p = "DER/G7/pTH4YqnJDUQ2LxA==";
        //string a;
        //a = new CUtility().Decrypt(p);


        if (UserAvailable(userNameTextBox.Text.Trim().ToString()) == 1)
        {
            if (UserStillValideORNot(userNameTextBox.Text.Trim().ToString()) == 1)
            {
                PasswordByUserId = GetPassword(userNameTextBox.Text.Trim().ToString());
                PasswordEncrypt = new CUtility().Encrypt(passwordTextBox.Text.Trim());
                PasswordDecrypt = new CUtility().Decrypt(PasswordEncrypt);

                if (PasswordByUserId != PasswordEncrypt)
                {
                    invalidLogin.Visible = true;
                    invalidLogin.ForeColor = System.Drawing.Color.Red;
                    invalidLogin.Text = "Please Type Valid Username & Password ";
                    userNameTextBox.Text = "";
                    passwordTextBox.Text = "";
                    userNameTextBox.Focus();
                }
                else
                {
                    FunctionaUserRole(userNameTextBox.Text.Trim());
                    Session["LogIn"] = "LogIn";
                    Session["Username"] = userNameTextBox.Text.Trim();
                    System.Web.Security.FormsAuthentication.RedirectFromLoginPage(userNameTextBox.Text.Trim(), false);
                }
            }
            else
            {
                invalidLogin.Visible = true;
                invalidLogin.ForeColor = System.Drawing.Color.Red;
                invalidLogin.Text = "You Are Not Valid User ";
            }
        }
        else
        {
            invalidLogin.Visible = true;
            invalidLogin.ForeColor = System.Drawing.Color.Red;
            invalidLogin.Text = "User Not Created";
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        userNameTextBox.Text = "";
        passwordTextBox.Text = "";
        userNameTextBox.Focus();
    }
    protected void btnVarify_Click(object sender, EventArgs e)
    {
        if (HasInstallationID() == "")
        {
            if (CallInstallation())
            {
                //invalidLogin.Text = " Request sent to sarver.";
            }
            else
            {
                invalidLogin.Text = " Unable to sent request to server.";

            }
        }
        else
        {
            invalidLogin.Text = " N D G";
        }
    }

    #endregion
}
