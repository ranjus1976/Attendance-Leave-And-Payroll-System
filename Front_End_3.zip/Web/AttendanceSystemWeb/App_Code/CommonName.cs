﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;


/// <summary>
/// Summary description for CommonName
/// </summary>
///
public class CommonName
{
    #region Variables

    String option, option1;
    ArrayList OptionArralist = new ArrayList();
    ReportData objReportData = new ReportData();
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();

    #endregion

    #region Common Message

    public String AlreadyExistMessage = "already exist";
    public String SavedMessage = "Data saved successful.";
    public String SelectMessage = "Please select!";
    public String UpdateMessage = "Data updated successful.";
    public String UnableProcess = "Unable to process request";
    public String DeleteMessage = "Data deleted successful.";
    public String IDRequired = "Id required.";
    public String NameRequired = "Name required.";
    public String IdorNameRequired = "id or name required.";
    public String AddressRequired = "Address required.";
    public String SearchItem = "Enter search item.";
    public String InvalidSearchItem = "Invalid search item";
    public String NotEnoughPermission = "You do not have enough permission";
    public String DateMessageforError = "From date must be less than to date!";
    public String PrevousProcess = "You should process the previous date first!";
    public String ProcessDateRequired = "Please enter process date.";
    public String SeasonNameRequired = "Please select season name";

    #endregion

    #region Common Methods

    public CommonName()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public String EmployeeName(String SelectedEmpId)
    {
        String Sql = "Select EmpName from tblEmployee where empId = '" + SelectedEmpId + "'";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String EmpName = Convert.ToString(cmd.ExecuteScalar());
        con.Close();
        return EmpName;
    }
    public String StartDate(String SelectedEmpId)
    {
        String Sql = "select convert(varchar, AdjSatrtDate,103) as AdjSatrtDate from tbl_BikeLoanSetup where empId = '" + SelectedEmpId + "'";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String BkLnStartDate = Convert.ToString(cmd.ExecuteScalar());
        con.Close();
        return BkLnStartDate;
    }
    public String BikeLnEndDate(String SelectedEmpId)
    {
        String Sql = "select convert(varchar, AdjEndDate,103) from tbl_BikeLoanSetup where empId = '" + SelectedEmpId + "'";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String LnEndDate = Convert.ToString(cmd.ExecuteScalar());
        return LnEndDate;
    }
    public String EmpLnEndDate(String SelectedEmpId)
    {
        String Sql = "select convert(varchar, ELoanEndDate,103) from tbl_EmpLoanSetUp where empId= '" + SelectedEmpId + "' and ELLog=1";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String LnEndDate = Convert.ToString(cmd.ExecuteScalar());
        return LnEndDate;
    }


    //Updated By Sanjoy
    public String EmpLnStartDate(String SelectedEmpId)
    {
        String Sql = "select convert(varchar, ELoanSrtDate,103) from tbl_EmpLoanSetUp where empId= '" + SelectedEmpId + "' and ELLog=1";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String LnEndDate = Convert.ToString(cmd.ExecuteScalar());
        return LnEndDate;
    }

    public void EmployeeTolTip(DropDownList ddlList, string selecValue, Label lblEmpName)
    {
        foreach (ListItem item in ddlList.Items)
        {
            if (item.Value.ToString() == selecValue)
            {
                String EmployeeNameSelect = EmployeeName(item.Text.ToString());
                //item.Attributes.Add("title", EmployeeNameSelect);
                lblEmpName.Visible = true;
                lblEmpName.Text = EmployeeNameSelect;
                break;
            }
        }
    }
    public ArrayList GetOption(String rdnbtnCommon, DropDownList ddlCommon)
    {
        if (rdnbtnCommon == "ALL")
        {
            option = "1";
            option1 = "1";
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        else if (rdnbtnCommon == "Dept")
        {
            option = "dbo.tblDepartment.DeptName";
            option1 = ddlCommon.SelectedItem.ToString();
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        else if (rdnbtnCommon == "Sect")
        {
            option = "dbo.tblSection.SectName";
            option1 = ddlCommon.SelectedItem.ToString();
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        else
        {
            option = "dbo.tblEmployee.EmpId ";
            option1 = ddlCommon.SelectedItem.Text.ToString();
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        return OptionArralist;
    }
    public ArrayList GetOption1(String rdnbtnCommon, DropDownList ddlCommon)
    {
        if (rdnbtnCommon == "ALL")
        {
            option = "1";
            option1 = "1";
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        else if (rdnbtnCommon == "Dept")
        {
            option = "dbo.tbl_PaySlip.Department";
            option1 = ddlCommon.SelectedItem.ToString();
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }

        else
        {
            option = "dbo.tbl_PaySlip.EmpId";
            option1 = ddlCommon.SelectedItem.Text.ToString();
            OptionArralist.Add(option);
            OptionArralist.Add(option1);
        }
        return OptionArralist;
    }

    public void LabelMessageandColor(Label lblGetHere, String DisplayingMessage, System.Drawing.Color ColorHere)
    {
        lblGetHere.Visible = true;
        lblGetHere.ForeColor = ColorHere;
        lblGetHere.Text = DisplayingMessage;
    }
    public void LabelReset(Label lblGetHere)
    {
        lblGetHere.Visible = false;
        lblGetHere.Text = "";
    }
    public HtmlAnchor InitialHyperLinkControl(HtmlAnchor htmlcntrl)
    {
        htmlcntrl.HRef = ConfigurationManager.AppSettings[htmlcntrl.ID];
        
        htmlcntrl.Attributes.Remove("class");
        htmlcntrl.Attributes.Add("class", "permissionShow");

        return htmlcntrl;
    }
    public bool PermissionReturn(String formName, String strName, String strPermission)
    {
        bool rtnValue = false;
        if (formName == strName && strPermission.Contains("R"))
            rtnValue = true;

        return rtnValue;
    }
    public Int32 DatetimeCompare(String strFromDate, String strToDate)
    {
        DateTime FromDate;
        DateTime ToDate;
        Int32 rtnValue = 0;

        if (strFromDate != "" && strToDate != "")
        {
            FromDate = Convert.ToDateTime(strFromDate);
            ToDate = Convert.ToDateTime(strToDate);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                rtnValue = 1;
        }
        return rtnValue;
    }
    public string MonthId(string monthname)
    {
        switch (monthname)
        {
            case "Jan":
                return "1";
                break;
            case "Feb":
                return "2";
                break;
            case "Mar":
                return "3";
                break;
            case "Apr":
                return "4";
                break;
            case "May":
                return "5";
                break;
            case "Jun":
                return "6";
                break;
            case "Jul":
                return "7";
                break;
            case "Aug":
                return "8";
                break;
            case "Sep":
                return "9";
                break;
            case "Oct":
                return "10";
                break;
            case "Nov":
                return "11";
                break;
            case "Dec":
                return "12";
                break;
            default:
                return "0";
                break;
        }

    }
    public void Addmonth(DropDownList drplist)
    {
        drplist.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        items.Add(new ListItem("Jan", "1"));
        items.Add(new ListItem("Feb", "2"));
        items.Add(new ListItem("Mar", "3"));
        items.Add(new ListItem("Apr", "4"));
        items.Add(new ListItem("May", "5"));
        items.Add(new ListItem("Jun", "6"));
        items.Add(new ListItem("Jul", "7"));
        items.Add(new ListItem("Aug", "8"));
        items.Add(new ListItem("Sep", "9"));
        items.Add(new ListItem("Oct", "10"));
        items.Add(new ListItem("Nov", "11"));
        items.Add(new ListItem("Dec", "12"));

        //items.Sort(delegate(ListItem item1, ListItem item2) { return item1.Text.CompareTo(item2.Text); });

        drplist.Items.AddRange(items.ToArray());

    }

    public string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }
    #endregion
}
