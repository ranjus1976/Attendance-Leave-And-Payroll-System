using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace GAL.Components
{
	/// <summary>
	/// Summary description for ReportUtils.
	/// </summary>
	public class ReportUtils
	{
		public ReportUtils()
		{
		}
//		public static ArrayList getMonths()
//		{
//			ArrayList al = new ArrayList();
//			al.Add("Select a Month");
//			al.Add("January");
//			al.Add("February");
//			al.Add("March");
//			al.Add("April");
//			al.Add("May");
//			al.Add("June");
//			al.Add("July");
//			al.Add("August");
//			al.Add("September");
//			al.Add("October");
//			al.Add("November");
//			al.Add("December");
//			return al;
//		}
		public static ArrayList getQuarter()
		{
			ArrayList al = new ArrayList();
			al.Add("Select a Quarter");
			al.Add("1st Qtr");
			al.Add("2nd Qtr");
			al.Add("3rd Qtr");
			al.Add("4th Qtr");
			return al;
		}

		public ReportDocument prepareReport() 
		{ 
			ReportDocument crReportDocument = new ReportDocument();
			crReportDocument.Load(System.Web.HttpContext.Current.Session["Report"].ToString(),CrystalDecisions.Shared.OpenReportMethod.OpenReportByTempCopy); 
			// ------ parameter initializing starts here
			
			string strRpt = System.Web.HttpContext.Current.Session["Report"].ToString().ToLower();
			strRpt= strRpt.Substring(strRpt.LastIndexOf("\\")+1,strRpt.Length-strRpt.LastIndexOf("\\")-5);
			switch (strRpt)
			{
				
				case "crtrialbalance" :
				{
					crReportDocument.SetParameterValue("Duration",System.Web.HttpContext.Current.Session["Duration"]) ;
					break;
				}

                case "cremployeeinfo":
				{
                    crReportDocument.SetParameterValue("EmpID", System.Web.HttpContext.Current.Session["EmpID"]);
					break;
				}

				
				case "salescustwise" :
				{
					crReportDocument.SetParameterValue("custID",System.Web.HttpContext.Current.Session["custID"]);
					crReportDocument.SetParameterValue("fromDate",System.Web.HttpContext.Current.Session["fromDate"]);
					crReportDocument.SetParameterValue("toDate",System.Web.HttpContext.Current.Session["toDate"]);
					crReportDocument.SetParameterValue("title",System.Web.HttpContext.Current.Session["title"]);
					break;
				}
				case "salesjournal" :
				{
					crReportDocument.SetParameterValue("fromDate",System.Web.HttpContext.Current.Session["fromDate"]);
					crReportDocument.SetParameterValue("toDate",System.Web.HttpContext.Current.Session["toDate"]);
					crReportDocument.SetParameterValue("title",System.Web.HttpContext.Current.Session["title"]);
					break;
				}
				case "salesproduct" :
				{
					crReportDocument.SetParameterValue("prodCat",System.Web.HttpContext.Current.Session["prodCat"]);
					crReportDocument.SetParameterValue("fromDate",System.Web.HttpContext.Current.Session["fromDate"]);
					crReportDocument.SetParameterValue("toDate",System.Web.HttpContext.Current.Session["toDate"]);
					crReportDocument.SetParameterValue("title",System.Web.HttpContext.Current.Session["title"]);
					break;
				}

                case "Department":
                {

                    crReportDocument.SetParameterValue("CompId", System.Web.HttpContext.Current.Session["CompId"]);
                    break;
                }

                case "Company":
                {
                    //crReportDocument.SetParameterValue();
                    break;
                }

                case "crdailyattendance":
                {
                    if (System.Web.HttpContext.Current.Session["CompareDate"] != null)
                    {
                       // crReportDocument.SetParameterValue("Date1", System.Web.HttpContext.Current.Session["PunchDate"]);
                        crReportDocument.RecordSelectionFormula = System.Web.HttpContext.Current.Session["CompareDate"].ToString().Trim();

                    }
                    break;
                }
                case "rptdailyactivities":
                {
                    if (System.Web.HttpContext.Current.Session["CompareDate"] != null)
                    {
                         crReportDocument.SetParameterValue("Date1", System.Web.HttpContext.Current.Session["PunchDate"]);
                        //crReportDocument.RecordSelectionFormula = System.Web.HttpContext.Current.Session["CompareDate"].ToString().Trim();
                         
                    }
                    break;
                }

                case "DailyActivities":
                {
                    //crReportDocument.SetParameterValue("EmpId", System.Web.HttpContext.Current.Session["EmpId"]);
                    crReportDocument.SetParameterValue("CompId", System.Web.HttpContext.Current.Session["CompId"]);
                    crReportDocument.SetParameterValue("EmpED", System.Web.HttpContext.Current.Session["EmpED"]);
                    crReportDocument.SetParameterValue("Date1", System.Web.HttpContext.Current.Session["PunchDate"]);
                    //crReportDocument.SetParameterValue("toDate", System.Web.HttpContext.Current.Session["toDate"]);
                    crReportDocument.SetParameterValue("title", System.Web.HttpContext.Current.Session["title"]);
                    break;
                }
                case "rptjobcard":
                {
                    crReportDocument.SetParameterValue("@FromDate", System.Web.HttpContext.Current.Session["FromDate"]);
                    crReportDocument.SetParameterValue("@ToDate", System.Web.HttpContext.Current.Session["ToDate"]);
                    break;
                }

				default : break;
			}
			// ------ parameter initializing ends here

			// ------ database logon for crystal report starts here ------------
			Sections crSections; 
			ReportDocument crSubreportDocument; 
			SubreportObject crSubreportObject;
			ReportObjects crReportObjects; 
			ConnectionInfo crConnectionInfo; 
			CrystalDecisions.CrystalReports.Engine.Database crDatabase;
			//Database crDatabase; 
			CrystalDecisions.CrystalReports.Engine.Tables crTables;
			//Tables crTables; 
			TableLogOnInfo crTableLogOnInfo; 
//			crReportDocument = new ReportDocument(); 
//			crReportDocument.Load(System.Web.HttpContext.Current.Session["Report"].ToString(),CrystalDecisions.Shared.OpenReportMethod.OpenReportByTempCopy); 
			crDatabase = crReportDocument.Database; 
			crTables = crDatabase.Tables; 
			

			//DBConn dc = new DBConn(ConfigurationSettings.AppSettings["ProjectName"].ToString());
			crConnectionInfo = new ConnectionInfo();
            crConnectionInfo.ServerName = ".";//dc.serverName; 
            crConnectionInfo.DatabaseName = "WebAttendance";//dc.databaseName;
//			crConnectionInfo.ServerName = "DENMServer/ViggoERP" ;
//			crConnectionInfo.DatabaseName = "xyz" ;

            crConnectionInfo.UserID = "sa";//dc.userID; 
            crConnectionInfo.Password = "";// dc.password; 
			foreach (CrystalDecisions.CrystalReports.Engine.Table aTable in crTables) 
			{ 
				//s = aTable.Location.ToString();	// existing location,
				
				crTableLogOnInfo = aTable.LogOnInfo; 
				crTableLogOnInfo.ConnectionInfo = crConnectionInfo; 
				aTable.ApplyLogOnInfo(crTableLogOnInfo); 
				
						//change the Database name to pick data from different database.

                aTable.Location = "WebAttendance" + ".dbo." + aTable.Location.Substring(aTable.Location.LastIndexOf(".") + 1);
								
			} 
			
			// THIS STUFF HERE IS FOR REPORTS HAVING SUBREPORTS 
			// set the sections object to the current report's section 
			crSections = crReportDocument.ReportDefinition.Sections; 
			// loop through all the sections to find all the report objects 
			foreach (Section crSection in crSections) 
			{ 
				crReportObjects = crSection.ReportObjects; 
				//loop through all the report objects in there to find all subreports 
				foreach (ReportObject crReportObject in crReportObjects) 
				{ 
					if (crReportObject.Kind == ReportObjectKind.SubreportObject) 
					{ 
						crSubreportObject = (SubreportObject) crReportObject; 
						//open the subreport object and logon as for the general report 
						crSubreportDocument = crSubreportObject.OpenSubreport(crSubreportObject.SubreportName); 
						crDatabase = crSubreportDocument.Database; 
						crTables = crDatabase.Tables; 
						foreach (CrystalDecisions.CrystalReports.Engine.Table aTable in crTables) 
						{
							crTableLogOnInfo = aTable.LogOnInfo; 
							crTableLogOnInfo.ConnectionInfo = crConnectionInfo; 
							aTable.ApplyLogOnInfo(crTableLogOnInfo);
                            aTable.Location = "WebAttendance" + ".dbo." + aTable.Location.Substring(aTable.Location.LastIndexOf(".") + 1);
						} 
					} 
				} 
			} 
			// ------ database logon for crystal report ends here ------------
			/// finally return the Report-Document object 
			return crReportDocument; 
		}

	}
}
