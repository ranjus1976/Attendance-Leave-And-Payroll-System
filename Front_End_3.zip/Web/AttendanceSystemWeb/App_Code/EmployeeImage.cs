﻿using System;
using System.Web;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.IO;

/// <summary>
/// Summary description for EmployeeImage
/// </summary>
public class EmployeeImage
{
    public EmployeeImage()
    {
      
    } 

    public static void LoadImageEmp(DropDownList ddlEmpID, HtmlTable tblImageEmp, Image ImageEmp)
    {
        if (ddlEmpID.SelectedValue != "NA")
        {
            if (ddlEmpID.SelectedValue != "")
            {
                if (ddlEmpID.SelectedItem.Text != "All")
                {
                DataSet ds = new DataSet();
                string[] v = ddlEmpID.SelectedValue.Split(',');
                ds = ClsCommon.GetAdhocResult("select e.EmpFileName from tblEmployee e where e.Emp_Number='" + v[0].ToString() + "'");
                string ImgFileName = ds.Tables[0].Rows[0][0].ToString().Trim();
                if (ImgFileName != "")
                {
                    string[] fileEntries = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/TextFile/"), ImgFileName);
                    if (fileEntries.Length != 0)
                    {
                        foreach (string filename in fileEntries)
                        {
                            string name = Path.GetFileName(filename);
                            if (ImgFileName == name)
                            {
                                tblImageEmp.Visible = true;
                                ImageEmp.ImageUrl = "~/TextFile/" + ImgFileName;
                            }
                            else
                            {
                                tblImageEmp.Visible = false;
                                //ImageEmp.ImageUrl = "~/images/None.bmp";
                            }
                        }
                    }
                    else
                        tblImageEmp.Visible = false;
                    // ImageEmp.ImageUrl = "~/images/None.bmp";
                }
                else
                    tblImageEmp.Visible = false;
                //ImageEmp.ImageUrl = "~/images/None.bmp";
            }
            else
                tblImageEmp.Visible = false;
            // ImageEmp.ImageUrl = "~/images/None.bmp";
        }
        else
            tblImageEmp.Visible = false;
        // ImageEmp.ImageUrl = "~/images/None.bmp";
        }
        else
            tblImageEmp.Visible = false;
    }


    public static void LoadImageEmp(HtmlTable tblImageEmp, Image ImageEmp, object EmpId)
    {
        DataSet ds = new DataSet();
        ds = ClsCommon.GetAdhocResult("select e.EmpFileName from tblEmployee e where e.Emp_Number='" + EmpId + "'");
        string ImgFileName = ds.Tables[0].Rows[0][0].ToString().Trim();
        if (ImgFileName != "")
        {
            string[] fileEntries = Directory.GetFiles(System.Web.HttpContext.Current.Server.MapPath("~/TextFile/"), ImgFileName);
            if (fileEntries.Length != 0)
            {
                foreach (string filename in fileEntries)
                {
                    string name = Path.GetFileName(filename);
                    if (ImgFileName == name)
                    {
                        tblImageEmp.Visible = true;
                        ImageEmp.ImageUrl = "~/TextFile/" + ImgFileName;
                    }
                    else
                    {
                        tblImageEmp.Visible = false;
                        //ImageEmp.ImageUrl = "~/images/None.bmp";
                    }
                }
            }
            else
                tblImageEmp.Visible = false;
            // ImageEmp.ImageUrl = "~/images/None.bmp";
        }
        else
            tblImageEmp.Visible = false;
        //ImageEmp.ImageUrl = "~/images/None.bm
    }
}
