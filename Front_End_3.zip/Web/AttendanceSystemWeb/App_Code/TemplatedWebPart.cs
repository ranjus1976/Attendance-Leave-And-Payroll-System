﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;



public class TemplatedWebPart : System.Web.UI.WebControls.WebParts.WebPart
{
    //string with UI code to be added to the page
    protected string templateHTML = string.Empty;

    //Control IDs, the template must use these ID's
    private string searchButtonID = "searchImgBtn";
    private string allTextID = "allTxt";
    //controls that will be found from the template
    protected TextBox allTxt = null;
    protected ImageButton searchBtn = null;

    public TemplatedWebPart()
    {
    }

    protected override void CreateChildControls()
    {
        if (templateHTML != string.Empty)
        {
            try
            {
                //create a control that has been parsed by asp.net
                Control template = Page.ParseControl(templateHTML);
                //add it to the page
                this.Controls.Add(template);
                //search for the known controls
                allTxt = template.FindControl(allTextID) as TextBox;
                searchBtn = template.FindControl(searchButtonID) as ImageButton;
                //hook up any events
                if (searchBtn != null)
                {
                    searchBtn.Click += new ImageClickEventHandler(btnSearch_Click);
                }

            }
            catch (Exception err)
            {
                this.Controls.Add(
                    new LiteralControl(string.Format("Error applying template: {0}", err.Message))
                    );
            }
        }
        else
        {
            this.Controls.Add(new LiteralControl("Please enter a template in the toolpart settings"));
        }

        base.CreateChildControls();
    }

    void btnSearch_Click(object sender, ImageClickEventArgs e)
    {
        //if the template included the textbox, show its results
        if (allTxt != null)
        {
            this.Controls.Add(new LiteralControl("Searched On: " + allTxt.Text));
        }
    }

    /*
     Use the below for sharepoint: 
    [System.Web.UI.WebControls.WebParts.WebBrowsable(true),
    System.Web.UI.WebControls.WebParts.WebDisplayName("Layout Template"),
    System.Web.UI.WebControls.WebParts.WebDescription("Template that is used for layout"),
    System.Web.UI.WebControls.WebParts.Personalizable(
    System.Web.UI.WebControls.WebParts.PersonalizationScope.Shared),
    System.ComponentModel.Category("Template Settings"),
    System.ComponentModel.DefaultValue("")
    ]*/

    [WebBrowsable]
    [Personalizable]
    public string TemplateHTML
    {
        get { return templateHTML; }

        set { templateHTML = value; }
    }

}


