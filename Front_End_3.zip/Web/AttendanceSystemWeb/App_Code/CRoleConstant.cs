﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for CRoleConstant
/// </summary>
public static class CRoleConstant
{
    public enum SecurityConstant
    {
        COMPANYSETUP,
        DEPARTMENTSETUP,
        SECTIONSETUP,
        DESIGNATIONSETUP,
        SHIFTSETUP,
        OSDSETUP,
        COMPANYMANUALENTRY,
        WEEKLYHOLIDAY,
        GOVTHOLIDAY,
        REMARKS,
        CONFIRMATIONDATE,
        EMPLOYEEINFORMATION,
        EMPLOYEEINFORMATIONLIST,
        EMPLOYEEENABLEDISABLE,
        EMPLOYEEIDCONVERTER,
        DATACOLLECION,
        DATAPROCESS,
        DAILYREPORT,
        MONTHLYREPORT,
        JOBCARD,
        EMPLOYEEINFOREPORT,
        CREATEUSER,
        CHANGEPASSWORD,
        ROLECREAION,
        FORMASSIGN,
        LEAVEAPPROVE,
        LEAVECONFIG,
        LEAVESTATUS,
        LEAVEENTRY,
        LEAVETYPESETUP,
        LEAVETRANSFER,
        USERMANAGEMENT,
        NEWEMPLOYEEINFO,
        RESIGNEMPLOYEEINFO,
        LEAVEINFORMATIONREPOR,
        LEAVEBALANCEREPOR,
        ACTIONTAKEN,
        OVERNIGHTDUTY,
        ANYUNREST,
        DATABASEBACKUP,
        SALARYSLABSETUP,
        SALARYBREAKUP,
        MBBILAdJADJUSTMENTENTRY,
        EMPWISECBF,
        EMPWISECBFSTART,
        CMPLOANINTRATE,
        BIKEENTRYDETSIL,
        BIKELOANSETUP,
        BIKELOANADJ,
        EMPLOANSETUP,
        LOANADJENTRY,
        SALARYDRAW,
        SALARYPROCESS,
        SALARYADJ,
        CBFDETAILS,
        MOBILEBILLREPORT,
        BIKELOANREPORT,
        EMPLOANREPORT,
        BONUSPROCESS,
        LEAVEPERMISSION,
        PROJECTBONUS,
        CONTREMPSAL,
        PROJECTSETUP,
        BONUSREPORT,
        PROJECTBONUSREPORT,
        INSBONUS,
        INSBONUSREPORT,
        FINSETUP
    }
}
