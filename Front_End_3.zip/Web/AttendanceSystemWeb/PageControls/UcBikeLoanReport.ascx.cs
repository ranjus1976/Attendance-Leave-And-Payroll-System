﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;


public partial class PageControls_UcBikeLoanReport : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKELOANREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    RadoBtnBikeCurntLoanEmp.Checked = true;
                    RadoBtnBikeCurntLoanEmp.Enabled = true;
                    RadioBtnBikeCplLoan.Checked = false;
                    loadEmployee();
                    String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtBxStrtDat.Text = ReportDateShow;
                    txtBxEndDat.Text = ReportDateShow;

                    Session["NotReadPermission"] = null;

                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
      
    }

    public void loadEmployee()
    {
        try
        {
            string strSQL = "select  b.EmpId,e.EmpName,e. Emp_Number from tbl_BikeLoanSetup as b inner join tblEmployee as e on b.EmpId=e.EmpId  where b.ValidLog='1'";
            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
       


        if (drpEmpId.SelectedIndex == 0)
        {
            lblEmpname.Text = string.Empty;
            txtbikLnStrDat.Text = string.Empty;
            txtBkLnEndDat.Text = string.Empty;

        }
        else 
        {
            objCommonName = new CommonName();
            lblEmpname.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
            txtbikLnStrDat.Text = objCommonName.StartDate(drpEmpId.SelectedItem.Text);
            txtBkLnEndDat.Text = objCommonName.BikeLnEndDate(drpEmpId.SelectedItem.Text);
            EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        
        
        }

    }
    protected void btnReport_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (checkfield())
            {
                try
                {
                    
                    Session["ReportName"] = "rptBikeLoan.rpt";
                    Session["TableName"] = "dsBikeLoan";
                    Session["CompanyName"] = "General Automation Limited";
                    string startDate = txtBxStrtDat.Text;
                    string endDate = txtBxEndDat.Text;
                    Session["StartMonthNo"] = startDate.Substring(3, 2);
                    Session["StartYear"] = startDate.Substring(6, 4);
                    Session["EndMonthNo"] = endDate.Substring(3, 2);
                    Session["Endyear"] = endDate.Substring(6, 4);
                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_Bike_Loan";


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, "Please Select Employee", System.Drawing.Color.Red);
            
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private bool checkfield()
    {
        bool rvt = true;
        if (drpEmpId.SelectedItem.Text == "Select")
        {
            rvt = false;
        }
        return rvt;
    
    }
    private ArrayList GetOption()
    {
        try
        {
            if (RadoBtnBikeCurntLoanEmp.Checked)
            {
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
                OptionArralist.Add("CrntLn");
               
            }
            else
            {
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
                OptionArralist.Add("CmplLn");
              
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void RadoBtnBikeCurntLoanEmp_CheckedChanged1(object sender, EventArgs e)
    {
        
        RadoBtnBikeCurntLoanEmp.Checked = true;
        RadioBtnBikeCplLoan.Checked = false;
        loadEmployee();
        lblEmpname.Text = string.Empty;
        txtbikLnStrDat.Text = string.Empty;
        txtBkLnEndDat.Text = string.Empty;
      
    }
    protected void RadioBtnBikeCplLoan_CheckedChanged1(object sender, EventArgs e)
    {
        RadioBtnBikeCplLoan.Checked = true;
        RadoBtnBikeCurntLoanEmp.Checked = false;
        LoadBikeCompleteLoan();
        lblEmpname.Text = string.Empty;
        txtbikLnStrDat.Text = string.Empty;
        txtBkLnEndDat.Text = string.Empty;
       
       
    }
    public void LoadBikeCompleteLoan()
    {
        try
        {
            string strSQL = "select  b.EmpId,e.EmpName,e. Emp_Number from tbl_BikeLoanSetup as b inner join tblEmployee as e on b.EmpId=e.EmpId where b.ValidLog='0'";
            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
}
