﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.BLL.Salary;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;

public partial class PageControls_UcSalaryAdjustment : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadCompany();
            loadEmployee();
            LoadYear();
            objCommonName.Addmonth(DrpListMonth);
            chkAdd.Checked = false;
            ChkDeduct.Checked = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            chkContr.Checked = false;
            /*LoadLoanCritiria();
            showGridView();
            TextBoxLAmtDue.ReadOnly = true;
            //TextBoxNoOfInstment.ReadOnly = true;
            //TextBoxInstallmentAmount.ReadOnly = true;
            BikeLoad();
            BikeSelect();*/
        }
    }
    private void LoadYear()
    {
        drpYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpYear.DataSource = li;
        drpYear.Items.AddRange(items.ToArray());
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    
    protected void mbSalAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbSalAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbSalAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void mbSalAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbSalAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        drpCmp.SelectedItem.Text = "Select";
        drpEmpId.SelectedItem.Text="Select";
        EmpNameTxtBox.Text = "";
        DrpListMonth.SelectedItem.Text = "Select";
        drpYear.SelectedItem.Text = "Select";
        TextBoxGross.Text = "";
        TextBoxAdj.Text = "";
        TextBoxRemark.Text = "";
        chkAdd.Checked = false;
        ChkDeduct.Checked = false;
        btnUpdate.Enabled = false;
        btnSave.Enabled = true;
        drpEmpId.Enabled = false;
        drpYear.Enabled = false;
        DrpListMonth.Enabled = false;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddSalaryAdj();
        objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        drpEmpId.Enabled = true;
        drpYear.Enabled = true;
        DrpListMonth.Enabled = true;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYADJ.ToString(), "C"))
            {
                if (Validate())
                {
                   if(!CheckExists())
                   {
                       action = "save";
                       AddSalaryAdj();
                       objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.SavedMessage.ToString(),System.Drawing.Color.Green);
                       showGridView();
                       action = "";
                   }
                   else
                   {
                       objCommonName.LabelMessageandColor(labelSalAdj,"Data " +objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
                   }


                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private bool CheckExists()
    {
        bool exists;
        string strSql;
        if(chkAdd.Checked)
        {
            strSql = "SELECT EmpId FROM tbl_Salary_Adjust where AddAmount<>0 and DeductAmount=0 and Month='"+DrpListMonth.SelectedItem.Text+"' and Year='"+drpYear.SelectedItem.Text+"' and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        }
        else
        {
            strSql = "SELECT EmpId FROM tbl_Salary_Adjust where AddAmount=0 and DeductAmount<>0 and Month='" + DrpListMonth.SelectedItem.Text + "' and Year='" + drpYear.SelectedItem.Text + "' and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        }
        

        exists=ClsCommon.ItemCheck(strSql);
        return exists;
    }

    private bool Validate()
    {
        bool retval = true;
        if (drpEmpId.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelSalAdj, "Select Employee", System.Drawing.Color.Red);
        }
        
        if (DrpListMonth.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelSalAdj, "Select Month", System.Drawing.Color.Red);
        }
        if (drpYear.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelSalAdj, "Select Year", System.Drawing.Color.Red);
        }
        if (chkAdd.Checked==false && ChkDeduct.Checked==false)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelSalAdj, "Select Add or Deduct", System.Drawing.Color.Red);
        }
        return retval;
    }

    private void AddSalaryAdj()
    {
        SalaryAdj objSalaryAdj=new SalaryAdj();
        objSalaryAdj.EmpId = drpEmpId.SelectedItem.Text;
        objSalaryAdj.Month = DrpListMonth.SelectedItem.Text;
        objSalaryAdj.Year = drpYear.SelectedItem.Text;
        objSalaryAdj.AdjAmount = int.Parse(TextBoxAdj.Text);
        objSalaryAdj.Remark = TextBoxRemark.Text;
        int Log = 0;
        if(chkAdd.Checked)
        {
            Log = 0;
        }
        if (ChkDeduct.Checked)
        {
            Log = 1;
        }
        objSalaryAdj.Log = Log;
        objSalaryAdj.Action = action;
        ProcessSalaryAdjInsert objProcessSalaryAdjInsert = new ProcessSalaryAdjInsert();
        objProcessSalaryAdjInsert.SalaryAdjIntrate = objSalaryAdj;
        objProcessSalaryAdjInsert.invoke();
    }

    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        string searchStr = "SELECT EmpId,Month,Year,AddAmount,DeductAmount,Remark FROM tbl_Salary_Adjust where Year='" + txtSearch.Text.Trim() + "'";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbSalAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbSalAdGridView.DataBind();
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        EmpNameTxtBox.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        string strSQL = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
        DataSet Gross = new DataSet();
        Gross = ClsCommon.GetAdhocResult(strSQL);
        if (Gross.Tables[0].Rows.Count != 0)
        {
            TextBoxGross.Text = Gross.Tables[0].Rows[0][0].ToString();
        }
        showGridView();
    }
    private void showGridView()
    {
        string searchStr = "SELECT EmpId,Month,Year,AddAmount,DeductAmount,Remark FROM tbl_Salary_Adjust where EmpId='"+drpEmpId.SelectedItem.ToString()+"'";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbSalAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbSalAdGridView.DataBind();
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYADJ.ToString(), "U"))
            {
                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in mbSalAdGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int add = int.Parse(gvrow.Cells[3].Text);
                int deduct = int.Parse(gvrow.Cells[4].Text);
                DrpListMonth.SelectedItem.Text = gvrow.Cells[1].Text;
                drpYear.SelectedItem.Text = gvrow.Cells[2].Text;
                if (add==0)
                {
                    chkAdd.Checked = false;
                    ChkDeduct.Checked = true;
                    TextBoxAdj.Text = deduct.ToString();
                }
                if (deduct == 0)
                {
                    chkAdd.Checked = true;
                    ChkDeduct.Checked = false;
                    TextBoxAdj.Text = add.ToString();
                }
                TextBoxRemark.Text = gvrow.Cells[5].Text;
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }

 

    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            action = "delete";
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYADJ.ToString(), "D"))
            {
                foreach (GridViewRow oRow in mbSalAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        SalaryAdj objSalaryAdj = new SalaryAdj();
                        objSalaryAdj.EmpId = drpEmpId.SelectedItem.Text;
                        objSalaryAdj.Month = mbSalAdGridView.Rows[i].Cells[1].Text;
                        objSalaryAdj.Year = mbSalAdGridView.Rows[i].Cells[2].Text;
                        objSalaryAdj.AdjAmount = 0;
                        if(mbSalAdGridView.Rows[i].Cells[3].Text=="0")
                        {
                            objSalaryAdj.Log = 0;
                        }
                        else
                        {
                            objSalaryAdj.Log = 1;
                        }
                        objSalaryAdj.Remark = "";
                        objSalaryAdj.Action = action;
                        ProcessSalaryAdjInsert objProcessSalaryAdjInsert = new ProcessSalaryAdjInsert();
                        objProcessSalaryAdjInsert.SalaryAdjIntrate = objSalaryAdj;
                        objProcessSalaryAdjInsert.invoke();
                    }
                    i++;
                }
                action = "";
                showGridView();
                objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelSalAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void chkAdd_CheckedChanged(object sender, EventArgs e)
    {
        if(chkAdd.Checked)
        {
            ChkDeduct.Checked = false;
        }
    }
    protected void ChkDeduct_CheckedChanged(object sender, EventArgs e)
    {
        if(ChkDeduct.Checked)
        {
            chkAdd.Checked = false;
        }
    }
    protected void chkContr_CheckedChanged(object sender, EventArgs e)
    {
        if(chkContr.Checked==true)
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number  where EmpED = 1 and Comp_Number=1 and EmpStatus='Contructual' order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));
            chkAdd.Checked = true;
            ChkDeduct.Checked = false;
            chkAdd.Enabled = false;
            ChkDeduct.Enabled = false;
        }
        else
        {
            loadEmployee();
            chkAdd.Checked = false;
            ChkDeduct.Checked = false;
            chkAdd.Enabled = true;
            ChkDeduct.Enabled = true;
        }
    }
}
