﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.BLL.CBF;

public partial class PageControls_UcEmpWiseCBFSatrt : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    private string action = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            loadCompany();
            loadEmployee();
            LoadYear();
            showGridView();
            objCommonName.Addmonth(drpCBFMonth);

        }
    }

    private void LoadYear()
    {
        drpCBFYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year=System.DateTime.Now.Year;
        int lastyear=(year+1);
        ListItem[] li=new ListItem[15];
        for(int i=7;i>0;i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
        lastyear--;
        }
        drpCBFYear.DataSource = li;
        drpCBFYear.Items.AddRange(items.ToArray());
    }

    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        drpCmp.SelectedIndex = 0;
        drpEmpId.SelectedIndex = 0;
        drpCBFMonth.SelectedIndex = 0;
        drpCBFYear.SelectedIndex = 0;
        TextBoxEmpName.Text = "";
        labelEmpCBFStar.Text = "";

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddEmpWiseCBFStart();
        objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        drpEmpId.Enabled = true;

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBFSTART.ToString(), "C"))
            {
                if (Validate())
                {
                    string sqlquery = "select EmpId from tbl_Emp_CBF_Start_Month where EmpID='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ShowLog=1 and CbfLog=1";
                    SqlConnection con = new SqlConnection();
                    SqlCommand cmd = new SqlCommand();
                    ReportData objReportData = new ReportData();
                    con = objReportData.GetDBConn();
                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = sqlquery;
                    string Employee = Convert.ToString(cmd.ExecuteScalar());
                    if (Employee == "")
                    {
                        action = "save";
                        AddEmpWiseCBFStart();
                        objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.SavedMessage.ToString(),
                                                           System.Drawing.Color.Green);
                        showGridView();
                        action = "";
                    }
                    else
                    {
                        objCommonName.LabelMessageandColor(labelEmpCBFStar, drpEmpId.SelectedItem.Text + objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
                    }

                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName..ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddEmpWiseCBFStart()
    {
        EmpWiseCBFStart objEmpWiseCBFStart=new EmpWiseCBFStart();
        objEmpWiseCBFStart.EmpId = drpEmpId.SelectedItem.Text;
        objEmpWiseCBFStart.EmpName = TextBoxEmpName.Text;
        objEmpWiseCBFStart.MonthName = drpCBFMonth.SelectedItem.Text;
        objEmpWiseCBFStart.YearName = drpCBFYear.SelectedItem.Text;
        objEmpWiseCBFStart.CbfLog = 1;
        objEmpWiseCBFStart.Action = action;
        ProcessEmpCBFStartInsert objProcessEmpCBFStartInsert = new ProcessEmpCBFStartInsert();
        objProcessEmpCBFStartInsert.EmpCBFStart = objEmpWiseCBFStart;
        objProcessEmpCBFStartInsert.invoke();

    }

    private bool Validate()
    {
        bool retval = true;
        if(drpEmpId.SelectedIndex==0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpCBFStar, "Select Employee Id", System.Drawing.Color.Red);
        }
        else if(drpCBFMonth.SelectedIndex==0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpCBFStar, "Select Month", System.Drawing.Color.Red);
        }
        else if(drpCBFYear.SelectedIndex==0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpCBFStar, "Select Year", System.Drawing.Color.Red);
        }
        return retval;
    }

    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            string EmpId = txtSearch.Text;
            Search(EmpId);
        }
        else
            Response.Redirect("login.aspx");

    }

    private void Search(string empId)
    {
        string searchStr = "SELECT EmpId,EmpName,MonthName,YearName from tbl_Emp_CBF_Start_Month where EmpId='" +empId+ "'" ;
        DataSet dsMonthDeduct = new DataSet();
        hidEditCheckedIDS.Value = "";
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grvEmpCbfStart.DataSource = dsMonthDeduct.Tables[0];
        grvEmpCbfStart.DataBind();
    }


    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
        
        Clear();
    }
    private void showGridView()
    {
        string searchStr = "SELECT C.EmpId,C.EmpName,C.MonthName,C.YearName from tbl_Emp_CBF_Start_Month C inner join tblEmployee E on  C.EmpId=E.EmpId where CbfLog=1 and ShowLog=1 and E.EmpStatus<>'Resign' order by C.EmpId ASC";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grvEmpCbfStart.DataSource = dsMonthDeduct.Tables[0];
        grvEmpCbfStart.DataBind();
    }
    private void Clear()
    {
        
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxEmpName.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
       EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
    }
    protected void grvEmpCbfStart_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvEmpCbfStart_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void grvEmpCbfStart_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }

    }
    protected void grvEmpCbfStart_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvEmpCbfStart_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBFSTART.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grvEmpCbfStart.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                        EmpWiseCBFStart objEmpWiseCBFStart=new EmpWiseCBFStart();
                        objEmpWiseCBFStart.EmpId = grvEmpCbfStart.Rows[i].Cells[0].Text;
                        ProcessEmpWiseCBFStartDelete EmpCBFD = new ProcessEmpWiseCBFStartDelete();
                        EmpCBFD.EMPCBFDStart = objEmpWiseCBFStart;
                        EmpCBFD.invoke();

                    }
                    i++;
                }
                showGridView();
                objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBFSTART.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
            {
                objCommonName.LabelMessageandColor(labelEmpCBFStar, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in grvEmpCbfStart.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadSalaryBreakUp(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }

    private void loadSalaryBreakUp(string id, int row)
    {
        string a = HiddenField1.Value;
        string strSQL = "Select EmpId,EmpName from tblEmployee where EmpId= '" + id + "'";
        DataSet dsEmp = new DataSet();
        dsEmp = ClsCommon.GetAdhocResult(strSQL);

        if (dsEmp.Tables[0].Rows.Count != 0)
        {
            drpEmpId.SelectedValue = dsEmp.Tables[0].Rows[0][1].ToString();
            drpEmpId.Enabled = false;
            TextBoxEmpName.ReadOnly = true;
            TextBoxEmpName.Text = dsEmp.Tables[0].Rows[0][1].ToString();
        }
        drpCBFMonth.SelectedItem.Text = grvEmpCbfStart.Rows[row].Cells[2].Text;
        drpCBFYear.SelectedItem.Text = grvEmpCbfStart.Rows[row].Cells[3].Text;
    }
}
