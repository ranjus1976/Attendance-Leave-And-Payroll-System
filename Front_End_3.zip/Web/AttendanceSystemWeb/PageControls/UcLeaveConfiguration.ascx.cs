﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Dal.Report;
using AttendanceSystem.BLL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.IO;


public partial class PageControls_LeaveConfiguration : System.Web.UI.UserControl
{
    CommonName objCommonName;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVECONFIG.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    PopulateCompanyList();
                    FinancialYear();
                    ddlCompanyList.SelectedIndex = 1;
                    PopulateDepartmentList();
                    EmployeeImage.LoadImageEmp(ddlEmployeelist, tblId, EmpImage);
                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Combo Load
    private void FinancialYear()
    {
        try
        {
            string strSQL = "select Opening_Date,Closing_Date,Financial_Year from  tblFinancial_Year where Running_Flag = 1";
            ClsCommon.drplistAdd(ddlYearList, strSQL, "Financial_Year", "Opening_Date", "Closing_Date");
            ddlYearList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void PopulateCompanyList()
    {
        ClsCommon.drplistAdd(ddlCompanyList, " select Comp_Number,CompName from  tblCompany ", "CompName", "Comp_Number");
        ddlCompanyList.Items.Insert(0, new ListItem("Select", "NA"));
    }
    protected void PopulateDepartmentList()
    {
        if (ddlCompanyList.SelectedItem.Value.Trim() != "NA")
        {
            ClsCommon.drplistAdd(ddlDepartmentList, " select Dept_Number,DeptName from  tblDepartment where Comp_Number='" + ddlCompanyList.SelectedItem.Value.Trim() + "' ", "DeptName", "Dept_Number");
            ddlDepartmentList.Items.Insert(0, new ListItem("All", "ALL"));
        }
    }
    protected void PopulateEmployeeList()
    {
        if (ddlDepartmentList.SelectedItem.Value.Trim() != "ALL")
        {
            ddlEmployeelist.Items.Clear();
            ClsCommon.drplistAddNew(ddlEmployeelist, " select Emp_Number,EmpId,EmpName from  tblEmployee inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number inner join tblDepartment on tblDepartment.Dept_Number = tblSection.Dept_Number where EmpED = 1 and tblDepartment.Dept_Number='" + ddlDepartmentList.SelectedItem.Value.Trim() + "' ", "EmpId", "Emp_Number");
            ddlEmployeelist.Items.Insert(0, new ListItem("All", "ALL"));
        }

    }
    #endregion

    #region Private Methods
    protected void SaveDataInDB()
    {
        LeaveBalance oLeaveBalance = PrepareObject();

        ProcessEmployeeLeaveBalance oProcessLeaveBalance = new ProcessEmployeeLeaveBalance();
        oProcessLeaveBalance.Balance = oLeaveBalance;
        oProcessLeaveBalance.invoke();
        ClearFields();
    }

    protected LeaveBalance PrepareObject()
    {
        LeaveBalance oBalance = new LeaveBalance();

        string[] arrYear = ddlYearList.SelectedItem.Text.Trim().Split('-');
        int year1 = int.Parse(arrYear[0]);
        year1 = year1 - 1;

        int year2 = int.Parse(arrYear[1]);
        year2 = year2 - 1;

        string[] arrDate = ddlYearList.SelectedValue.Split(',');

        if (ddlDepartmentList.SelectedValue.Trim() == "ALL")
        {
            oBalance.Dept = -1;
            oBalance.Sec = -1;
            oBalance.Emp = -1;
        }
        else
        {
            oBalance.Dept = Convert.ToInt32(ddlDepartmentList.SelectedValue.Trim());

            oBalance.Sec = -1;
            oBalance.Emp = -1;
            if (ddlEmployeelist.SelectedValue.Trim() == "ALL")
            {
                oBalance.Emp = -1;
            }
            else
            {
                oBalance.Emp = int.Parse(ddlEmployeelist.SelectedValue.Trim());
            }
        }

        oBalance.Comp_Name = Convert.ToInt32(ddlCompanyList.SelectedValue.Trim());
        oBalance.Leave_Year = Convert.ToString(ddlYearList.SelectedItem.Text.Trim());
        oBalance.PC = HttpContext.Current.Request.UserHostAddress.Trim();
        oBalance.tempyear1 = DateTime.Parse(arrDate[0].ToString()).ToString("dd/MMM/yyyy");
        oBalance.tempyear2 = DateTime.Parse(arrDate[1].ToString()).ToString("dd/MMM/yyyy");
        oBalance.PreviousYear = year1 + "-" + year2;

        oBalance.EntryBy = 60;
        return oBalance;
    }

    protected void ValidationCheckProcess()
    {
    }

    protected void ClearFields()
    {
        ddlCompanyList.SelectedIndex = 0;
    }

    #endregion

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVECONFIG.ToString(), "C"))
            {
                try
                {
                    if (ddlCompanyList.SelectedIndex != 0 &&
                        ddlYearList.SelectedIndex != 0
                        )
                    {
                        SaveDataInDB();
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                        lblMessage.Text = "Data processed successful.";
                    }
                    else
                    {
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = "Please select!";
                    }
                }
                catch (Exception ebtnSave)
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = ebtnSave.Message;
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void rdoSelectionList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlCompanyList_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompanyList.SelectedIndex != 0)
        {
            PopulateDepartmentList();
        }
        else
        {
            ddlDepartmentList.SelectedIndex = 0;
            ddlEmployeelist.SelectedIndex = 0;
            ddlYearList.SelectedIndex = 0;
        }
    }
    protected void ddlDepartmentList_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlEmployeelist.Items.Clear();
        PopulateEmployeeList();
    }
    protected void ddlSectionList_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlEmployeelist.Items.Clear();
        PopulateEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {

    }
    protected void ddlEmployeelist_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeelist, tblId, EmpImage);
    }
    
}
