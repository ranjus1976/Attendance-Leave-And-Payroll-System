﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;

public partial class PageControls_UcProjectBonus : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    public ProjectBonus objProjectBonus = new ProjectBonus();
    public string action = "";
    public int i = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTBONUS.ToString(), "R"))
        {
            if (Session["LogIn"] != null)
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    loadEmployee();
                    drpDept.Enabled = false;
                    drpEmpId.Enabled = false;
                    drpCmp.Enabled = false;
                    loadDepartment();
                    loadProject();
                    loadCompProject();
                    txtConfirmationDateShow.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
                    btnSave.Enabled = true;
                    btnUpdateProj.Enabled = false;
                    DrpPrjUPD.Enabled = false;

                }

            }
            else
                Response.Redirect("login.aspx");
        }
        else 
        {
            Session["NotReadPermission"] = "NotReadPermission";
            Response.Redirect("Default.aspx");
        }
    }
    private void LoadEmpGrdComp()
    {
        
        string str = "SELECT DesigName,Amount FROM tbl_ProjectBonusAmt inner join tblDesignation on Desig_Number=DesigNumber where ProjectId=" + DrpPrjUPD.SelectedValue.ToString();
        DataSet dsBonusPay = new DataSet();
        dsBonusPay = ClsCommon.GetAdhocResult(str);
        if (dsBonusPay.Tables[0].Rows.Count > 0)
        {
            grvBonus.DataSource = dsBonusPay.Tables[0];
            grvBonus.DataBind();
        }
        else 
        {
            grvBonus.DataSource = null;
            grvBonus.DataBind();
        }
    }
    private void LoadEmpGrd()
    {

        string str = "SELECT DesigName,Amount FROM tbl_ProjectBonusAmt inner join tblDesignation on Desig_Number=DesigNumber where ProjectId=" + drpProject.SelectedValue.ToString();
        DataSet dsBonusPay = new DataSet();
        dsBonusPay = ClsCommon.GetAdhocResult(str);
        if (dsBonusPay.Tables[0].Rows.Count > 0)
        {
            grvBonus.DataSource = dsBonusPay.Tables[0];
            grvBonus.DataBind();
        }
        else
        {
            grvBonus.DataSource = null;
            grvBonus.DataBind();
        }
    }
    private void loadProject()
    {
        string strSQL = "SELECT ProjectId,ProjectName FROM tbl_ProjectName where ProjectLog=1";
        ClsCommon.drplistAdd(drpProject, strSQL, "ProjectName", "ProjectId");
        drpProject.Items.Insert(0, new ListItem("Select", "NA"));

    }
    private void loadCompProject()
    {
        string strSQL = "SELECT ProjectId,ProjectName FROM tbl_ProjectName where ProjectLog=0";
        ClsCommon.drplistAdd(DrpPrjUPD, strSQL, "ProjectName", "ProjectId");
        DrpPrjUPD.Items.Insert(0, new ListItem("Select", "NA"));    
    }

    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadDepartment()
    {

        try
        {
            drpDept.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCmp.SelectedValue + " ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxEmpName.Text = "";
        TextBoxDesig.Text = "";
        TextBoxBAmount.Text = "";
       
    }
    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxEmpName.Text = "";
        TextBoxDesig.Text = "";
        TextBoxBAmount.Text = "";
        
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " and tblEmployee.Sect_Number=" + drpDept.SelectedValue.ToString() + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

            

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        TextBoxEmpName.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        TextBoxEmpName.Text = "";
        TextBoxDesig.Text = "";
        TextBoxBAmount.Text = "";
       
        string text = "";
        String Sql = "Select D.DesigName from tblDesignation D inner join tblEmployee E on E.Desig_Number=D.Desig_Number where E.EmpId ='" + drpEmpId.SelectedItem.Text + "'";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String Desig = Convert.ToString(cmd.ExecuteScalar());
        TextBoxDesig.Text = Desig;        
        String sqlAmt = "SELECT isnull(sum(Amount),0) as Amount FROM tbl_ProjectBonusAmt P inner join tblEmployee E on E.Desig_Number=P.DesigNumber where E.EmpId ='"+drpEmpId.SelectedItem.Text+"' and P.ProjectId="+drpProject.SelectedValue.ToString();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = sqlAmt;
        String Amt = Convert.ToString(cmd.ExecuteScalar());
        TextBoxBAmount.Text = Amt+" tk";
        if (TextBoxBAmount.Text == "0 tk")
        {
            TextBoxBAmount.ForeColor = System.Drawing.Color.Red;
            i = 0;
            Label1.Text = "Invalid";
            Label1.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            TextBoxBAmount.ForeColor = System.Drawing.Color.Black;
            i = 1;
            Label1.Text = "";
            Label1.ForeColor = System.Drawing.Color.Black;
        }


    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
        ClearAll();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {

    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTBONUS.ToString(), "C"))
            {
                if (isValidData())
                {
                    String Sql11 = "SELECT isnull(sum(Amount),0) as Amount FROM tbl_ProjectBonusAmt where ProjectId=" + drpProject.SelectedValue.ToString();
                    SqlConnection conn = new SqlConnection();
                    SqlCommand cmd1 = new SqlCommand();
                    ReportData objReportData1 = new ReportData();
                    conn = objReportData1.GetDBConn();
                    conn.Open();
                    cmd1.Connection = conn;
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = Sql11;
                    String Amount = Convert.ToString(cmd1.ExecuteScalar());
                    conn.Close();
                    if (Convert.ToInt32(Amount)!=0)
                    {
                        objCommonName.LabelMessageandColor(lblErrorMessage, "", System.Drawing.Color.Red);
                        action = "save";
                        foreach (var s in ListBoxEmp.Items)
                        {
                            objProjectBonus.EmpNumber = s.ToString();
                            AddData();
                            ProjectBonusAddData objProjectBonusAddData = new ProjectBonusAddData();
                            objProjectBonusAddData.ProjectBonusdata = objProjectBonus;
                            objProjectBonusAddData.InsertProjectBonus();
                        }
                        action = "";
                        objCommonName.LabelMessageandColor(lblErrorMessage, "Data Successfully Inserted", System.Drawing.Color.Green);
                        String Sql = "UPDATE tbl_ProjectName SET ProjectLog =0 WHERE ProjectId=" + drpProject.SelectedValue.ToString();
                        SqlConnection con = new SqlConnection();
                        SqlCommand cmd = new SqlCommand();
                        ReportData objReportData = new ReportData();
                        con = objReportData.GetDBConn();
                        con.Open();
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = Sql;
                        cmd.ExecuteNonQuery();
                        con.Close();
                        ClearAll();
                        
                    }
                    else
                    {
                        objCommonName.LabelMessageandColor(lblErrorMessage, "SetUp Bonus First", System.Drawing.Color.Red);
                    }
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, "Unable to process request", System.Drawing.Color.Red);
                
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddData()
    {
        
        objProjectBonus.Duration = int.Parse(TextBoxDuration.Text);
        objProjectBonus.ProjectName = drpProject.SelectedItem.Text;
        objProjectBonus.EffectiveDate = Convert.ToDateTime(txtConfirmationDateShow.Text);
        objProjectBonus.EntryBy = Session["Username"].ToString();        
        objProjectBonus.Action = action;
    }
    private bool isValidData()
    {
        bool retv = true;
       

        if (drpEmpId.SelectedItem.Text == "Select")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Employee", System.Drawing.Color.Red);
        }
       /* else if (TextBoxBAmount.Text == "")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Give Bonus Amount", System.Drawing.Color.Red);
        }*/

        else if (drpProject.SelectedItem.Text == "Select")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Give Project Name", System.Drawing.Color.Red);
        }

        return retv;
    }
    private void ClearAll()
    {
        drpDept.SelectedItem.Text = "Select";
        drpEmpId.SelectedItem.Text = "Select";
        
        lblErrorMessage.Visible = false;
        TextBoxDuration.Text = "";
        txtConfirmationDateShow.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        btnSave.Enabled=true;
        btnUpdateProj.Enabled = false;
        ListBoxEmp.Items.Clear();
        chkUpdate.Checked = false;       
        DrpPrjUPD.Enabled = false;
        drpEmpId.Enabled = false;
        grvBonus.DataSource = null;
        grvBonus.DataBind();
        TextBoxEmpName.Text = "";
        TextBoxDesig.Text = "";
        TextBoxBAmount.Text = "";
        TextBoxDuration.Text = "";
        drpProject.SelectedItem.Text = "Select";
        /*GridSalBreak.DataSource = null;
        GridSalBreak.DataBind();
        grvSalaryPay.DataSource = null;
        grvSalaryPay.DataBind();*/


    }
    protected void btnAddEmp_Click(object sender, EventArgs e)
    {
        int i = 0;
        foreach (var s in ListBoxEmp.Items)
        {
            if (drpEmpId.SelectedItem.Text == s.ToString())
            {
                i = 1;
            }
        }
        if (i == 1)
        {
            ListBoxEmp.Items.Remove(drpEmpId.SelectedItem.Text);
        }
        if (drpEmpId.SelectedItem.Text != "Select" && i==1)
        {
            ListBoxEmp.Items.Add(drpEmpId.SelectedItem.Text);
        }
    }
    protected void btnRemoveEmp_Click(object sender, EventArgs e)
    {
        if (ListBoxEmp.SelectedIndex != -1)
        {
            ListBoxEmp.Items.Remove(ListBoxEmp.SelectedItem.Text);
        }

    }
    protected void chkUpdate_CheckedChanged(object sender, EventArgs e)
    {
        if (chkUpdate.Checked)
        {
            drpProject.SelectedItem.Text = "Select";
            drpProject.Enabled = false;           
            TextBoxDuration.Enabled = false;
            drpCmp.Enabled = false;
            drpDept.Enabled = false;
            drpEmpId.Enabled = false;
            ListBoxEmp.Enabled = false;
            txtConfirmationDateShow.Enabled = false;
            DrpPrjUPD.Enabled = true; 
            btnUpdateProj.Enabled = true;
            btnSave.Enabled = false;
            btnAddEmp.Enabled = false;
            btnRemoveEmp.Enabled = false;
            loadCompProject();
        }
        else
        {
            drpProject.SelectedItem.Text = "Select";
            DrpPrjUPD.SelectedItem.Text = "Select";
            drpProject.Enabled = true;
            TextBoxDuration.Enabled = true;
            drpCmp.Enabled = true;
            drpDept.Enabled = true;
            drpEmpId.Enabled = true;
            ListBoxEmp.Enabled = true;
            txtConfirmationDateShow.Enabled = true;
            DrpPrjUPD.Enabled = false;

            btnUpdateProj.Enabled = false;
            btnSave.Enabled = true;
            btnAddEmp.Enabled = true;
            btnRemoveEmp.Enabled = true;
        }
    }
    protected void btnUpdateProj_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTBONUS.ToString(), "U"))
            {
                if (ValidData())
                {
                    
                    String Sql = "sp_ProjectBonusUpdate";
                    SqlConnection con = new SqlConnection();
                    SqlCommand cmd = new SqlCommand();
                    ReportData objReportData = new ReportData();
                    con = objReportData.GetDBConn();
                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Sql;
                    cmd.Parameters.Add("@ProjectId", DrpPrjUPD.SelectedValue.ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Data Successfully UpDated", System.Drawing.Color.Green);
                    ClearAll();
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, "Unable to process request", System.Drawing.Color.Red);

            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private bool ValidData()
    {
        bool retv = true;


        if (DrpPrjUPD.SelectedItem.Text == "Select")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Project", System.Drawing.Color.Red);
        }
        return retv;
    }
    protected void drpProject_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpProject.SelectedItem.Text != "Select")
        {
            drpEmpId.Enabled = true;
            drpDept.Enabled = true;
            drpCmp.Enabled = true;
            LoadEmpGrd();
            TextBoxEmpName.Text = "";
            TextBoxDesig.Text = "";
            TextBoxBAmount.Text = "";
            TextBoxDuration.Text = "";

        }
        else 
        {
            drpEmpId.Enabled = false;
            drpDept.Enabled = false;
            drpCmp.Enabled = false;
            TextBoxEmpName.Text = "";
            TextBoxDesig.Text = "";
            TextBoxBAmount.Text = "";
            TextBoxDuration.Text = "";
        }
    }

    protected void DrpPrjUPD_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DrpPrjUPD.SelectedItem.Text != "Select")
        {
            LoadEmpGrdComp();
        }       
    }
}
