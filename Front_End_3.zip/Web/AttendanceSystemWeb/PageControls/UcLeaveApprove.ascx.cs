﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Core;
using AttendanceSystem.Dal;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;

public partial class PageControls_LeaveApprove : System.Web.UI.UserControl
{
    String EmpId = "";
    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEAPPROVE.ToString(), "R"))
            {
                if (Request.QueryString.Count > 1)
                {
                    if (Request.QueryString[2] != null)
                        EmpId = Request.QueryString[2].ToString();
                }
                if (!IsPostBack)
                {
                    if (EmpId != "")
                        GetLeaveApplyLoag(EmpId);
                    else
                        GetLeaveApplyLoag(EmpId);
                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Methods

    private void GetLeaveApplyLoag(String EmpCode)
    {
        Int32 EmpId = int.Parse(Session["User_Number"].ToString());
        String Role = Session["Role_Name"].ToString();
        SqlCommand cmd = new SqlCommand();

        String Sql = "sp_Leave_ApplyRead";
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();

        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;

        cmd.Parameters.Add("@EmpId", EmpId);
        cmd.Parameters.Add("@UserType", Role);
        cmd.Parameters.Add("@EmpCode", EmpCode);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            grvLeaveList.DataSource = ds.Tables[0];
            grvLeaveList.DataBind();
            btnApproveOrDisApprove.Enabled = false;
            btnCancel.Enabled = true;
        }
        else
        {
            btnTable.Visible = false;
            btnGridTable.Disabled = false;
            grvLeaveList.DataSource = ds.Tables[0];
            grvLeaveList.DataBind();
            Session["NoLeave="] = "NoLeave";
            Response.Redirect("Default.aspx");
            btnCancel.Enabled = true;
        }
    }
    public void PopulateGrid(string emp_id, int leavetype, DateTime Year)
    {
        int empTempID = int.Parse(emp_id);//GetEmpID(emp_id);
        if (empTempID != int.MinValue)
        {
            LeaveApplied oApplied = new LeaveApplied();
            oApplied.Employee_Number = empTempID;
            oApplied.Leave_Type_Number = leavetype;
            oApplied.From_Date = Year;


            ProcessLeaveReadForLeaveApproval oApproval = new ProcessLeaveReadForLeaveApproval();
            oApproval.LeaveApplied = oApplied;
            oApproval.invoke();

            if (oApproval.LeaveApproveDS.Tables[0].Rows.Count > 0)
            {
                grvLeaveList.DataSource = (DataTable)oApproval.LeaveApproveDS.Tables[0];
                grvLeaveList.DataBind();

            }
            else
            {
                grvLeaveList.EmptyDataText = "Data not found!";
                grvLeaveList.DataSource = null;
                grvLeaveList.DataBind();
            }
        }
    }
    private Int32 GetUserNumber()
    {
        Int32 User_Number;
        String UserName = Convert.ToString(Session["Username"]);
        String Sql = "Select User_Number from tblUser where UserId = '" + UserName + "'";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        User_Number = Convert.ToInt32(cmd.ExecuteScalar());

        return User_Number;
    }
    public void ProcessLeaveApprove()
    {
        foreach (GridViewRow gRow in grvLeaveList.Rows)
        {
            LeaveApplied oApplied = new LeaveApplied();

            HiddenField oEMP = (HiddenField)gRow.FindControl("hidEmployeeNumber");
            HiddenField oType = (HiddenField)gRow.FindControl("hidLeaveTypeNumber");
            HiddenField oAppply = (HiddenField)gRow.FindControl("hidApplyNumber");
            TextBox txtFromDate = (TextBox)gRow.FindControl("txtFromDate");
            Label lblFromDate = (Label)gRow.FindControl("lblFromDate");
            TextBox txtToDate = (TextBox)gRow.FindControl("txtToDate");
            Label lblToDate = (Label)gRow.FindControl("lblToDate");
            TextBox oAvail = (TextBox)gRow.FindControl("txtAccepted1");
            Label lblOAvail = (Label)gRow.FindControl("txtAccepted");
            CheckBox oAccept = (CheckBox)gRow.FindControl("chkApproveOrDisApprove");
            CheckBox oRecomende = (CheckBox)gRow.FindControl("chkRecommened");
            HiddenField oDate = (HiddenField)gRow.FindControl("hidStartDate");

            if (oAccept.Checked == true || oRecomende.Checked == true)
            {
                if (oEMP != null)
                {
                    oApplied.Employee_Number = int.Parse(oEMP.Value.Trim());
                }
                if (oType != null)
                {
                    oApplied.Leave_Type_Number = int.Parse(oType.Value.Trim());
                }
                if (oAppply != null)
                {
                    oApplied.Leave_Apply_Number = int.Parse(oAppply.Value.Trim());
                }

                if (oAvail != null && oAvail.Text.Trim() != "")
                {
                    oApplied.Avail = float.Parse(oAvail.Text.Trim());
                }
                else
                {
                    oApplied.Avail = float.Parse(lblOAvail.Text.Trim());
                }
                if (txtFromDate != null && txtFromDate.Text.Trim() != "")
                {
                    oApplied.From_Date = Convert.ToDateTime(txtFromDate.Text.Trim());
                }
                else
                {
                    oApplied.From_Date = Convert.ToDateTime(lblFromDate.Text.Trim());
                }
                if (txtToDate != null && txtToDate.Text.Trim() != "")
                {
                    oApplied.To_Date = Convert.ToDateTime(txtToDate.Text.Trim());
                }
                else
                {
                    oApplied.To_Date = Convert.ToDateTime(lblToDate.Text.Trim());
                }

                if (oRecomende != null)
                {
                    if (oRecomende.Checked)
                    {
                        Int32 User_Number = GetUserNumber();
                        oApplied.RecommenedBy = User_Number;
                    }
                }
                oApplied.EntryDate = System.DateTime.Now;
                oApplied.AppRecomTag = "Approved";
                if (oAccept != null)
                {
                    if (oAccept.Checked)
                    {
                        oApplied.Approval = 1;
                        oApplied.ApprovalDes = "Approved";
                        Int32 User_Number = GetUserNumber();
                        oApplied.ApproveBy = User_Number;
                    }
                    else
                    {
                        oApplied.Approval = 0;
                    }

                    if (oDate != null)
                    {
                        oApplied.Leave_Year = DateTime.Parse(oDate.Value.Trim()).Year.ToString();
                    }
                    if (oDate == null)
                    {
                        string strSQL = "SELECT Financial_Year FROM tblFinancial_Year where Running_Flag=1";
                        DataSet FinYear = new DataSet();
                        FinYear = ClsCommon.GetAdhocResult(strSQL);
                        if (FinYear.Tables[0].Rows.Count != 0)
                        {
                            oApplied.Leave_Year = FinYear.Tables[0].Rows[0][0].ToString();
                        }
                        
                    }
                    ProcessLeaveApproveInsert oInsert = new ProcessLeaveApproveInsert();
                    oInsert.LeaveApplied = oApplied;
                    oInsert.invoke();
                }
            }
        }
    }
    public void ProcessLeaveApproveRecommed()
    {
        foreach (GridViewRow gRow in grvLeaveList.Rows)
        {
            LeaveApplied oApplied = new LeaveApplied();
            HiddenField oEMP = (HiddenField)gRow.FindControl("hidEmployeeNumber");

            HiddenField oType = (HiddenField)gRow.FindControl("hidLeaveTypeNumber");
            HiddenField oAppply = (HiddenField)gRow.FindControl("hidApplyNumber");
            TextBox txtFromDate = (TextBox)gRow.FindControl("txtFromDate");
            Label lblFromDate = (Label)gRow.FindControl("lblFromDate");
            TextBox txtToDate = (TextBox)gRow.FindControl("txtToDate");
            Label lblToDate = (Label)gRow.FindControl("lblToDate");
            TextBox oAvail = (TextBox)gRow.FindControl("txtAccepted1");
            Label lblOAvail = (Label)gRow.FindControl("txtAccepted");
            CheckBox oAccept = (CheckBox)gRow.FindControl("chkApproveOrDisApprove");
            CheckBox oRecomende = (CheckBox)gRow.FindControl("chkRecommened");
            HiddenField oDate = (HiddenField)gRow.FindControl("hidStartDate");


            if (oAccept.Checked == true || oRecomende.Checked == true)
            {
                if (oEMP != null)
                {
                    oApplied.Employee_Number = int.Parse(oEMP.Value.Trim());
                }
                if (oType != null)
                {
                    oApplied.Leave_Type_Number = int.Parse(oType.Value.Trim());
                }
                if (oAppply != null)
                {
                    oApplied.Leave_Apply_Number = int.Parse(oAppply.Value.Trim());
                }

                if (oAvail != null && oAvail.Text.Trim() != "")
                {
                    oApplied.Avail = float.Parse(oAvail.Text.Trim());
                }
                else
                {
                    oApplied.Avail = float.Parse(lblOAvail.Text.Trim());
                }
                if (txtFromDate != null && txtFromDate.Text.Trim() != "")
                {
                    oApplied.From_Date = Convert.ToDateTime(txtFromDate.Text.Trim());
                }
                else
                {
                    oApplied.From_Date = Convert.ToDateTime(lblFromDate.Text.Trim());
                }
                if (txtToDate != null && txtToDate.Text.Trim() != "")
                {
                    oApplied.To_Date = Convert.ToDateTime(txtToDate.Text.Trim());
                }
                else
                {
                    oApplied.To_Date = Convert.ToDateTime(lblToDate.Text.Trim());
                }

                if (oRecomende != null)
                {
                    if (oRecomende.Checked)
                    {
                        Int32 User_Number = GetUserNumber();
                        oApplied.RecommenedBy = User_Number;
                    }
                }
                oApplied.EntryDate = System.DateTime.Now.Date;
                oApplied.AppRecomTag = "Recommend";
                if (oAccept != null)
                {
                    if (oAccept.Checked)
                    {

                        oApplied.Approval = 1;
                        oApplied.ApprovalDes = "Approved";
                        Int32 User_Number = GetUserNumber();
                        oApplied.ApproveBy = User_Number;
                    }
                    else
                    {
                        oApplied.Approval = 0;
                    }

                    if (oDate != null)
                    {
                        oApplied.Leave_Year = DateTime.Parse(oDate.Value.Trim()).Year.ToString();
                    }

                    ProcessLeaveApproveInsert oInsert = new ProcessLeaveApproveInsert();
                    oInsert.LeaveApplied = oApplied;
                    oInsert.invoke();
                }
            }
        }
    }
    public int GetEmpID(string Emp_ID)
    {
        int givenid = int.MinValue;


        DataSet dsResult = ClsCommon.GetAdhocResult(" select Emp_Number from tblEmployee where EmpId='" + Emp_ID + "'");
        if (dsResult.Tables.Count > 0)
        {
            if (dsResult.Tables[0].Rows.Count > 0)
            {
                givenid = int.Parse(dsResult.Tables[0].Rows[0]["Emp_Number"].ToString().Trim());
            }
        }

        return givenid;
    }
    protected void firstFakeLoad()
    {
        grvLeaveList.EmptyDataText = "No data available to display.....";
        grvLeaveList.DataSource = null;
        grvLeaveList.DataBind();
    }

    #endregion

    #region  Button Handlers

    protected void grvLeaveList_DataBound(object sender, EventArgs e)
    {

    }
    protected void ddlUserList_SelectedIndexChanged(object sender, EventArgs e)
    {
        //PopulateGrid();
    }
    protected void btnDisApprove_Click(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnApproveOrDisApprove_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEAPPROVE.ToString(), "C"))
            {
                try
                {
                    ProcessLeaveApprove();
                    grvLeaveList.EditIndex = -1;
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Data saved successful.";
                    GetLeaveApplyLoag(EmpId);

                }
                catch (Exception ebtnEdit)
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = ebtnEdit.Message;
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void chkApproveOrDisApprove_CheckedChanged(object sender, EventArgs e)
    {
        btnApproveOrDisApprove.Enabled = true;
        btnCancel.Enabled = true;
    }
    protected void grvLeaveList_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grvLeaveList.EditIndex = e.NewEditIndex;
    }
    protected void grvLeaveList_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        grvLeaveList.EditIndex = -1;
    }
    protected void grvLeaveList_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grvLeaveList.EditIndex = -1;
    }
    protected void chkRecommened_CheckedChanged(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEAPPROVE.ToString(), "R"))
            {
                try
                {
                    btnApproveOrDisApprove.Enabled = false;
                    btnCancel.Enabled = true;
                    ProcessLeaveApproveRecommed();
                    grvLeaveList.EditIndex = -1;
                    GetLeaveApplyLoag(EmpId);
                }
                catch (Exception ex)
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = ex.Message;
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion
}
