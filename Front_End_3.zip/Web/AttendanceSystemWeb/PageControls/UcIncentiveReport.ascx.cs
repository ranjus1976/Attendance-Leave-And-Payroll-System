﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;

public partial class PageControls_UcIncentiveReport : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.INSBONUSREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadEmployee();
                    loadDepartment();
                    LoadYear();
                    objCommonName.Addmonth(drpMonth);
                    drpDept.Enabled = false;
                    drpEmpId.Enabled = false;
                    RadioButtonAll.Checked = true;
                    RadioButtonAll.Enabled = true;
                    RadioButtonDepartment.Checked = false;
                    rdbtnEmployee.Checked = false;
                    Session["NotReadPermission"] = null;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {

        try
        {
            drpDept.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    private void LoadYear()
    {
        drpYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpYear.DataSource = li;
        drpYear.Items.AddRange(items.ToArray());
    }
    protected void btnPaySlip_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblMessage.Text = "";
                    Session["ReportName"] = "rptIncentivePaySlip.rpt";
                    Session["TableName"] = "dsIncentiveBonusReport";
                    Session["Month"] = drpMonth.SelectedItem.Text;
                    Session["Year"] = drpYear.SelectedItem.Text;
                    Session["CompanyName"] = "General Automation Limited";
                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_Incentive_Bonus_Report";
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDatefrom"] = null;
                    Session["ToDate"] = null;
                    Session["ToDate"] = null;
                    Session["FakeValue"] = null;


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {

        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
        RadioButtonAll.Checked = true;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = false;
    }
    protected void RadioButtonDepartment_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = true;
        drpEmpId.Enabled = false;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = true;
        rdbtnEmployee.Checked = false;

        loadDepartment();
    }
    protected void rdbtnEmployee_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = true;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = true;
    }
    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        lblEmpname.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
    }
    protected void drpMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drpYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    private bool Validate()
    {
        bool retVal = true;
        if (RadioButtonAll.Checked)
        {
            retVal = true;
        }
        if (drpDept.SelectedItem.Text == "Select" && RadioButtonDepartment.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblMessage, "Select Department".ToString(), System.Drawing.Color.Red);
        }
        if (drpEmpId.SelectedItem.Text == "Select" && rdbtnEmployee.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblMessage, "Select Employee".ToString(), System.Drawing.Color.Red);
        }

        if (drpYear.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblMessage, "Select Year".ToString(), System.Drawing.Color.Red);
        }
        if (drpMonth.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblMessage, "Select Month".ToString(), System.Drawing.Color.Red);
        }
        return retVal;
    }
    protected void btnIncentiveRpt_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblMessage.Text = "";
                    Session["ReportName"] = "rptIncentiveBonus.rpt";
                    Session["TableName"] = "dsIncentiveBonusReport";
                    Session["Month"] = drpMonth.SelectedItem.Text;
                    Session["Year"] = drpYear.SelectedItem.Text;
                    Session["CompanyName"] = "General Automation Limited";
                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_Incentive_Bonus_Report";
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDatefrom"] = null;
                    Session["ToDate"] = null;
                    Session["ToDate"] = null;
                    Session["FakeValue"] = null;


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private ArrayList GetOption()
    {
        try
        {
            if (RadioButtonAll.Checked)
            {

                OptionArralist.Add("All");
                OptionArralist.Add("All");
            }

            else if (RadioButtonDepartment.Checked)
            {
                OptionArralist.Add("Dept");
                OptionArralist.Add(drpDept.SelectedItem.Text);
            }
            else
            {

                OptionArralist.Add("EMP");
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }
    protected void btnShortRpt_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblMessage.Text = "";
                    Session["ReportName"] = "rptIncentiveShortBonus.rpt";
                    Session["TableName"] = "dsIncentiveBonusReport";
                    Session["Month"] = drpMonth.SelectedItem.Text;
                    Session["Year"] = drpYear.SelectedItem.Text;
                    Session["CompanyName"] = "General Automation Limited";
                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_Incentive_Bonus_Report";
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDatefrom"] = null;
                    Session["ToDate"] = null;
                    Session["ToDate"] = null;
                    Session["FakeValue"] = null;


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
       
    }
}
