﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_UcCompanyManualEntry : System.Web.UI.UserControl
{
    #region Declaration
    private Department _dept;
    private Section _sec;
    public string name = null;
    DataTable dt;
    ArrayList dlist;
    String ReportDateShow;
    String InTimeShow;
    String OutTimeShow;
    TimeSpan ts = new TimeSpan(0, 10, 0);
    DateTime Intime = System.DateTime.Now;
    DateTime OutTime;
    CommonName objCommonName = new CommonName();
    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["LogIn"] != null)
            {
                if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYMANUALENTRY.ToString(), "R"))
                {
                    deptDropDownList.Enabled = false;
                    empIdDropDownList.Enabled = false;
                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    InTimeShow = ReportDateShow.Substring(11, 5);
                    OutTime = Intime.Add(ts);
                    OutTimeShow = Convert.ToString(OutTime);
                    OutTimeShow = OutTimeShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    fromDateTextBox.Text = ReportDateShow;
                    toDateTextBox.Text = ReportDateShow;
                    inTimeTextBox.Text = "00:00";//InTimeShow;
                    outTimeTextBox.Text = "00:00"; //OutTimeShow;
                    loadCompany();
                    EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
                    Session["NotReadPermission"] = null;

                    if (Session["ManualEdit"] != null)
                    {
                        String EmpId = Session["EmpId"].ToString();
                        String FromDate = Session["PunchDate"].ToString();
                        String ToDate = Session["PunchDate"].ToString();
                        LoadEmployeeList();
                        empIdDropDownList.Enabled = true;
                        RadioButtonEmpId.Checked = true;
                        empIdDropDownList.SelectedValue = EmpId;
                        outTimeTextBox.Text = "";
                        fromDateTextBox.Text = FromDate.Substring(0, 10);
                        toDateTextBox.Text = ToDate.Substring(0, 10);
                        inTimeTextBox.Text = Session["PunchTime"].ToString();
                    }
                }
                else
                {
                    Session["NotReadPermission"] = "NotReadPermission";
                    Response.Redirect("Default.aspx");
                }
            }
            else
                Response.Redirect("login.aspx");
        }
    }

    #endregion

    #region Combo Box Load
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
        ClsCommon.drplistAdd(drplist, strSQL, "CompName", "Comp_Number");
    }

    public void loadDepartment()
    {

        try
        {
            deptDropDownList.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_Number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
            ClsCommon.drplistAdd(deptDropDownList, strSQL, "DeptName", "Dept_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }

    protected void LoadEmployeeList()
    {
        try
        {
            empIdDropDownList.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + drplist.SelectedValue + " order by empId asc ";
            ClsCommon.drplistAddNew(empIdDropDownList, strSQL, "EmpId", "Emp_Number");

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region Private Methods
    public void AddManualEntry()
    {

        DateTime manualInTime;
        DateTime manualOutTime;
        DateTime manualFromDate;
        DateTime manualToDate;

        if (inTimeTextBox.Text == "" || inTimeTextBox.Text == string.Empty)
        {
            manualInTime = DateTime.Parse(Convert.ToDateTime("01/01/1900 00:00:00").ToString("dd/MMM/yyyy HH:mm:ss"));
        }
        else
        {
            manualInTime = DateTime.Parse(Convert.ToDateTime("01/01/1900 "+inTimeTextBox.Text).ToString("dd/MMM/yyyy HH:mm:ss"));
        }
        manualFromDate = DateTime.Parse(DateTime.Parse(fromDateTextBox.Text).ToString("dd/MMM/yyyy")); //Convert.ToDateTime();
        if (outTimeTextBox.Text == "" || outTimeTextBox.Text == string.Empty)
        {
            manualOutTime = DateTime.Parse(Convert.ToDateTime("01/01/1900 00:00:00").ToString("dd/MMM/yyyy HH:mm:ss"));
        }
        else
        {
            manualOutTime = DateTime.Parse(Convert.ToDateTime("01/01/1900 " + outTimeTextBox.Text).ToString("dd/MMM/yyyy HH:mm:ss"));
        }
        manualToDate = DateTime.Parse(DateTime.Parse(toDateTextBox.Text).ToString("dd/MMM/yyyy"));// Convert.ToDateTime(toDateTextBox.Text);

        String userName = Convert.ToString(Session["Username"]);
        if (RadioButtonEmpId.Checked == true)
        {

            name = empIdDropDownList.SelectedItem.Text.ToString();
            CompanyManualInsert cmiEmp = new CompanyManualInsert();
            cmiEmp.ManualInsert(name, manualFromDate, manualToDate, manualInTime, manualOutTime, userName);

        }
        else if (RadioButtonDepartment.Checked == true)
        {
            name = deptDropDownList.SelectedValue.ToString();
            CompanyManualInsertDept cmid = new CompanyManualInsertDept();
            cmid.ManualInsertDept(int.Parse(name), manualFromDate, manualToDate, manualInTime, manualOutTime, userName);

        }
        else
        {
            CompanyManualInsertAll cmiall = new CompanyManualInsertAll();
            cmiall.ManualInsertAll(int.Parse(drplist.SelectedValue.ToString()), manualFromDate, manualToDate, manualInTime, manualOutTime, userName);
        }

    }
    private void DataUpdateProcedure(String EmpId, DateTime PunchDate, DateTime PunchTime, String Pc, String EntryBy, DateTime PrvTime)
    {
        try
        {
            String Sql = "sp_Manual_Update";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;

            cmd.Parameters.AddWithValue("@strName", EmpId);
            cmd.Parameters.AddWithValue("@PunchDate", PunchDate);
            cmd.Parameters.AddWithValue("@PunchTime", PunchTime);
            cmd.Parameters.AddWithValue("@Entryby", EntryBy);
            cmd.Parameters.AddWithValue("@PC", Pc);
            cmd.Parameters.AddWithValue("@PriVPunchTime", PrvTime);

            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {

        }
    }
    private void UpdatemanualEntry()
    {
        DateTime manualInTime;
        DateTime manualOutTime;
        DateTime manualFromDate;
        DateTime manualToDate;
        String userName = "";
        String Pc = "";
        String EmpId = "";

        manualFromDate = DateTime.Parse(DateTime.Parse(fromDateTextBox.Text).ToString("dd/MMM/yyyy")); //Convert.ToDateTime();
        manualOutTime = DateTime.Parse(Session["PunchTime"].ToString());
        Pc = System.Net.Dns.GetHostName().ToString();
        userName = Convert.ToString(Session["Username"]);

        if (inTimeTextBox.Text == "" || inTimeTextBox.Text == string.Empty)
        {
            manualInTime = DateTime.Parse(Convert.ToDateTime("00:00:00").ToString("dd/MMM/yyyy HH:mm:ss"));
        }
        else
        {
            manualInTime = DateTime.Parse(Convert.ToDateTime(inTimeTextBox.Text).ToString("dd/MMM/yyyy HH:mm:ss"));
        }

        if (empIdDropDownList.SelectedValue.ToString() != "" && RadioButtonEmpId.Checked == true)
        {
            name = empIdDropDownList.SelectedItem.Text.ToString();
            DataUpdateProcedure(name, manualFromDate, manualInTime, Pc, userName, manualOutTime);

        }
    }
    private void and(bool p)
    {
        throw new NotImplementedException();
    }
    public void Refresh()
    {
        inTimeTextBox.Text = "";
        outTimeTextBox.Text = "";
        toDateTextBox.Text = "";
        fromDateTextBox.Text = "";
        empIdDropDownList.SelectedValue = null;
        deptDropDownList.SelectedValue = null;
        name = null;
    }
    #endregion

    #region Button Click

    protected void Button1_Click(object sender, EventArgs e)
    {
        Refresh();
    }
    protected void CloseButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Refresh();
        manualLabel.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["Login"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYMANUALENTRY.ToString(), "C"))
            {
                DateTime FromDate = Convert.ToDateTime(fromDateTextBox.Text);
                DateTime ToDate = Convert.ToDateTime(toDateTextBox.Text);

                if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                {
                    if (Session["ManualEdit"] == null)
                        AddManualEntry();
                    else
                    {
                        UpdatemanualEntry();
                        Session["ManualEdit"] = null;
                    }

                    objCommonName.LabelMessageandColor(manualLabel, objCommonName.SavedMessage, System.Drawing.Color.Green);
                    Refresh();
                }
                else
                {
                    manualLabel.Visible = true;
                    manualLabel.ForeColor = System.Drawing.Color.Red;
                    manualLabel.Text = "From date must be less than to date!";
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(manualLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnFind_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx?Page=ManulEntryEdit");
    }

    #endregion

    #region Event Handlers

    protected void deptDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = true;
        empIdDropDownList.Enabled = false;
        loadDepartment();
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = true;
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(empIdDropDownList, empIdDropDownList.SelectedValue.ToString(), lblEmployee);
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = false;
    }
    protected void empIdDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(empIdDropDownList, empIdDropDownList.SelectedValue.ToString(), lblEmployee);
        EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
    }
    protected void fromDateTextBox_TextChanged(object sender, EventArgs e)
    {
        if (objCommonName.DatetimeCompare(fromDateTextBox.Text.Trim(), toDateTextBox.Text.Trim()) == 1)
            objCommonName.LabelReset(manualLabel);
        else
            objCommonName.LabelMessageandColor(manualLabel, objCommonName.DateMessageforError, System.Drawing.Color.Red);
    }
    protected void toDateTextBox_TextChanged(object sender, EventArgs e)
    {
        if (objCommonName.DatetimeCompare(fromDateTextBox.Text.Trim(), toDateTextBox.Text.Trim()) == 1)
            objCommonName.LabelReset(manualLabel);
        else
            objCommonName.LabelMessageandColor(manualLabel, objCommonName.DateMessageforError, System.Drawing.Color.Red);
    }
    protected void drplist_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        LoadEmployeeList();        
    }

    #endregion
  
}
