﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.BLL.CBF;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.BLL.EmployeeLoan;

public partial class PageControls_ucEmployeeLoanAdj : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["ELID"] = null;
            loadEmployee();
            TextBoxDate.Text = "";//Convert.ToString(System.DateTime.Now).Substring(0, 10);

        }
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["ELID"] = "";
        Session["ELInstAmt"] = "";
        EmpNameTxtBox.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        string sql = "select isnull(sum(A.Installment),0) as Installment,isnull(sum(A.Adjustment),0) as Adjustment,isnull(Max(A.NoOfInst),0) as NoOfInst FROM tbl_EmpLoanAdj A inner join tbl_EmpLoanSetUp B on B.EmpId=A.EmpId and B.ELLog=1 where A.EmpId='" + drpEmpId.SelectedItem.Text + "' and A.InstLog=1";
        DataSet dsELoanPay = new DataSet();
        dsELoanPay = ClsCommon.GetAdhocResult(sql);
        string sql1 = "SELECT ELID,LoanAmount,Instalment FROM tbl_EmpLoanSetUp where ELLog=1 and ELoanSrtDate<=Convert(datetime,'" + System.DateTime.Now + "',103) and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        DataSet dsELSetup = new DataSet();
        dsELSetup = ClsCommon.GetAdhocResult(sql1);
        int Tinst = int.Parse(dsELoanPay.Tables[0].Rows[0][0].ToString());
        int Tother = int.Parse(dsELoanPay.Tables[0].Rows[0][1].ToString());
        int NoOfInst = int.Parse(dsELoanPay.Tables[0].Rows[0][2].ToString());
        int LoanAmt = int.Parse(dsELSetup.Tables[0].Rows[0][1].ToString());
        int InstAmt = int.Parse(dsELSetup.Tables[0].Rows[0][2].ToString());
        Session["ELID"] = int.Parse(dsELSetup.Tables[0].Rows[0][0].ToString());
        Session["ELInstAmt"] = InstAmt.ToString();
        int LoanDue = LoanAmt - Tinst - Tother;
        TextBoxLDAmt.Text = LoanDue.ToString();
        TextBoxTLAmt.Text = LoanAmt.ToString();
        lblNoOfInst.Text = "No. Of Installment: "+NoOfInst.ToString()+"   ";
        lblTAdjAmt.Text = "Total Adjust: "+Tother.ToString()+"   ";
        lblTInstPay.Text = "Total Installment: "+Tinst.ToString()+"   ";
        lblInstAmt.Text = "Installment Amount: " + InstAmt.ToString()+"   ";
        LoadGrid(drpEmpId.SelectedItem.Text,dsELSetup.Tables[0].Rows[0][0].ToString());
    }

    private void LoadGrid(string EmpId,string ELID)
    {
        string searchStr = "SELECT CONVERT(varchar(10), PayDate, 103) AS PayDate,DueLoan,Adjustment FROM tbl_EmpLoanAdj where PayType='O' and EmpId='" + EmpId + "' and InstLog=1 and ELID=" + ELID;
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbBilAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbBilAdGridView.DataBind();
    }

    public void loadEmployee()
    {

        try
        {
            string strSQL = "SELECT B.EmpId,E.EmpName,E. Emp_Number FROM tbl_EmpLoanSetUp B inner join tblEmployee E on E.EmpId= B.EmpId where ELLog=1 order by B.EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));


        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            //string strSql = "SELECT BLSID FROM tbl_BikeloanAdj where payType='O' and EmpId='"+drpEmpId.SelectedItem.Text+"' and MonthName='"+drpListMonth.SelectedItem.Text+"' and YearName='"+drpListYear.SelectedItem.Text+"'";
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LOANADJENTRY.ToString(), "C"))
            {
                if (Validate())
                {
                    string month = Convert.ToDateTime(TextBoxDate.Text).ToString("MMMM").Substring(0,3);
                    string year = Convert.ToDateTime(TextBoxDate.Text).Year.ToString();
                    string strSql = "SELECT ELID FROM tbl_EmpLoanAdj where EmpId='" + drpEmpId.SelectedItem.Text + "' and Month='" + month + "' and Year='" + year + "' and InstLog=1 and PayType='O'";
                         
                   if (!ClsCommon.ItemCheck(strSql))
                    {
                        action = "save";
                        AddBikeDetail();
                        objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                        LoadGrid(drpEmpId.SelectedItem.Text, Session["ELID"].ToString());
                        action = "";
                    }
                    else
                    {
                        labelEmpLoanAdj.Visible = true;
                        labelEmpLoanAdj.ForeColor = System.Drawing.Color.Red;
                        labelEmpLoanAdj.Text = "Entry Already EXISTS For This Month!";
                    }

                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddBikeDetail()
    {
        EmployeeLoanAdjEntry objEmployeeLoanAdjEntry = new EmployeeLoanAdjEntry();
        objEmployeeLoanAdjEntry.EmpId = drpEmpId.SelectedItem.Text;
        objEmployeeLoanAdjEntry.Adjustment = int.Parse(TextBoxAdj.Text);
        DateTime Date = Convert.ToDateTime(TextBoxDate.Text);
        objEmployeeLoanAdjEntry.PayDate = Date;
        objEmployeeLoanAdjEntry.Action = action;
        ProcessEmpLoanAdjInsert objProcessEmpLoanAdjInsert = new ProcessEmpLoanAdjInsert();
        objProcessEmpLoanAdjInsert.EmployeeLoanAdjEntryIN = objEmployeeLoanAdjEntry;
        objProcessEmpLoanAdjInsert.invoke();
    }

    private bool Validate()
    {
        bool validate = true;
        if (drpEmpId.SelectedItem.Text == "Select")
        {
            validate = false;
            objCommonName.LabelMessageandColor(labelEmpLoanAdj, "Select Employee Id", System.Drawing.Color.Red);
        }
        return validate;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddBikeDetail();
        objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        LoadGrid(drpEmpId.SelectedItem.Text, Session["ELID"].ToString());
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        TextBoxDate.Enabled = true;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Clear();
    }
    private void Clear()
    {
        drpEmpId.SelectedItem.Text = "Select";
        EmpNameTxtBox.Text = "";
        TextBoxTLAmt.Text = "";
        TextBoxAdj.Text = "";
        TextBoxDate.Text = "";
        labelEmpLoanAdj.Text = "";
        TextBoxLDAmt.Text = "";
        lblInstAmt.Text = "";
        lblNoOfInst.Text = "";
        lblTAdjAmt.Text = "";
        lblTInstPay.Text = "";
        Session["ELID"] = null;
        mbBilAdGridView.DataSource = null;
        mbBilAdGridView.DataBind();
        action = "";
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void mbBilAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void mbBilAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LOANADJENTRY.ToString(), "U"))
            {

                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in mbBilAdGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int Row = gvrow.RowIndex;
                string date = gvrow.Cells[0].Text;
                string adjamount = gvrow.Cells[2].Text;
                loadBikeDetail(date, adjamount, Row);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }

    private void loadBikeDetail(string date, string adjamount, int row)
    {
        string sql = "SELECT Adjustment,CONVERT(varchar(10), PayDate, 103) AS PayDate,DueLoan FROM tbl_EmpLoanAdj where EmpId='" + drpEmpId.SelectedItem.Text + "' and PayDate=convert(datetime,'" + date + "',103) and InstLog=1 and PayType='O'";
         DataSet dsEmp = new DataSet();
         dsEmp = ClsCommon.GetAdhocResult(sql);

            if (dsEmp.Tables[0].Rows.Count != 0)
            {
                TextBoxAdj.Text = dsEmp.Tables[0].Rows[0][0].ToString();
                TextBoxLDAmt.Text = dsEmp.Tables[0].Rows[0][2].ToString();
                TextBoxDate.Text = dsEmp.Tables[0].Rows[0][1].ToString();
                TextBoxDate.Enabled = false;
            }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            action = "Delete";
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LOANADJENTRY.ToString(), "D"))
            {
                EmployeeLoanAdjEntry objEmployeeLoanAdjEntry = new EmployeeLoanAdjEntry();
                foreach (GridViewRow oRow in mbBilAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        
                        objEmployeeLoanAdjEntry.EmpId = drpEmpId.SelectedItem.Text;
                        objEmployeeLoanAdjEntry.Adjustment = 0;
                        objEmployeeLoanAdjEntry.PayDate = Convert.ToDateTime(mbBilAdGridView.Rows[i].Cells[0].Text); 
                        objEmployeeLoanAdjEntry.Action = action;
                        ProcessEmpLoanAdjInsert objProcessEmpLoanAdjInsert = new ProcessEmpLoanAdjInsert();
                        objProcessEmpLoanAdjInsert.EmployeeLoanAdjEntryIN = objEmployeeLoanAdjEntry;
                        objProcessEmpLoanAdjInsert.invoke();

                    }
                    i++;
                }
                LoadGrid(drpEmpId.SelectedItem.Text, Session["ELID"].ToString());
                objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
                action = "";
            }
            else
                objCommonName.LabelMessageandColor(labelEmpLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }
}