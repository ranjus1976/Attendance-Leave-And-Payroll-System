﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;




public partial class PageControls_UcMbBilAdJustmentEntry : System.Web.UI.UserControl
{
    MbBBillAdj objMbBBillAdj = new MbBBillAdj();
    CommonName objCommonName = new CommonName();
    string action = "";
    string EmpId = "";
    string MonthId = "";
    private string UpDateTag;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) 
        {
            loadCompany();
            loadEmployee();
            LoadYear();
            objCommonName.Addmonth(DrpListMonth);
            txtSearch.Visible = false;
            btnSearch1.Visible = false;
            Label1.Visible = false;
        }
    }
    private void LoadYear()
    {
        drpYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpYear.DataSource = li;
        drpYear.Items.AddRange(items.ToArray());
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");
        
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        EmpNameTxtBox.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        string id = Convert.ToString(drpEmpId.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        
       
        string ReportDateShow = Convert.ToString(System.DateTime.Now);
        ReportDateShow = ReportDateShow.Substring(6, 4);

        string Empid = Convert.ToString(drpEmpId.SelectedItem.Text);


        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        String Sql = "SELECT MobileCeling FROM tbl_MbileCeling inner join tblEmpSalInfo on tbl_MbileCeling.SalId=tblEmpSalInfo.SalId where EmpId='" + drpEmpId.SelectedItem.Text + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String MobC = Convert.ToString(cmd.ExecuteScalar());
        TextBoxMobC.Text = MobC;
        HiddenField1.Value = Empid;
        showGridView(Empid);
        txtSearch.Visible = true;
        btnSearch1.Visible = true;
        
        Label1.Visible = true;

        Clear();
    }

    private void showGridView(string id)
    {
        string searchStr = "SELECT EmpId,MonthName,Year,MobileDeduct FROM tblMobileDeduct where EmpId='" + id + "' and Year='" + Convert.ToString(System.DateTime.Now).Substring(6, 4) + "' order by MonthId ASC";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbBilAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbBilAdGridView.DataBind();
    }
    private void Clear()
    {
       // throw new NotImplementedException();
    }
    //public void loadEmployee(Int32 CompId)
    //{
    //    try
    //    {
    //        string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + CompId + " order by empId asc ";
    //        ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
    //        empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
    //    }
    //    catch (Exception ex)
    //    {
    //        objCommonName.LabelMessageandColor(labelMbAdj, ex.Message.ToString(), System.Drawing.Color.Red);
    //    }
    //}

    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select EmpId,Emp_Number,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void mbBilAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
   

    protected void btnREdit_Click(object sender, EventArgs e) 
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "U"))
            {
                UpDateTag = "MbAdj";

                loadFormGrid();
               
            }
            else
            {

                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");

    }

    private void loadFormGrid()
    {
        
             foreach (GridViewRow gvrow in mbBilAdGridView.Rows)
             {
                 CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[1].Text;
                loadSalaryBreakUp(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

            }
    }

    private void loadSalaryBreakUp(string id, int row)
    {
        try
        {
            string a = HiddenField1.Value;
            string strSQL = "Select EmpId,EmpName from tblEmployee where EmpId= '" + a+ "'";
             DataSet dsEmp = new DataSet();
             dsEmp = ClsCommon.GetAdhocResult(strSQL);

             if (dsEmp.Tables[0].Rows.Count != 0)
             {
                 drpEmpId.SelectedValue = dsEmp.Tables[0].Rows[0][1].ToString();
                 drpEmpId.Enabled = false;
                 EmpNameTxtBox.ReadOnly = true;
                 EmpNameTxtBox.Text = dsEmp.Tables[0].Rows[0][1].ToString();
             }
             DrpListMonth.SelectedValue = objCommonName.MonthId(mbBilAdGridView.Rows[row].Cells[1].Text);
             drpYear.SelectedItem.Text = mbBilAdGridView.Rows[row].Cells[2].Text;
             TextBoxAdj.Text = mbBilAdGridView.Rows[row].Cells[3].Text;
            //MedicalTimeTextBox.Text = mbBilAdGridView.Rows[row].Cells[5].Text;
            //CBFTextBox.Text = mbBilAdGridView.Rows[row].Cells[6].Text;
            //txtFromDate.Text = mbBilAdGridView.Rows[row].Cells[1].Text;



        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelMbAdj, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnDel_Click(object sender, EventArgs e) 
    {
        if (Session["LogIn"] != null)
        {
            int i=0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in mbBilAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                       // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                        
                      objMbBBillAdj.EmpId =HiddenField1.Value;
                      objMbBBillAdj.MonthName = mbBilAdGridView.Rows[i].Cells[1].Text;
                      objMbBBillAdj.Year = mbBilAdGridView.Rows[i].Cells[2].Text;
                      ProcessMobBillAdjDelete MobD = new ProcessMobBillAdjDelete();
                      MobD.MobD = objMbBBillAdj;
                      MobD.invoke();
                        
                    }
                    i++;
                }
                showGridView(HiddenField1.Value);
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }
   
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            string EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
            string year = txtSearch.Text;
            Search(EmpId,year);
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void Search(string EmpId, string year)
    {

        string searchStr = "SELECT EmpId,MonthName,Year,MobileDeduct FROM tblMobileDeduct where EmpId='" + EmpId + "' and Year='" + year + "' order by MonthId ASC";
        DataSet dsMonthDeduct = new DataSet();
        hidEditCheckedIDS.Value = "";
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbBilAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbBilAdGridView.DataBind();
    
    
    }
   protected void mbBilAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

   protected void btnSave_Click(object sender, EventArgs e)
   {
       if (Session["LogIn"] != null)
       {
           if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.MBBILAdJADJUSTMENTENTRY.ToString(), "C"))
           {
               if (Validate())
               {
                   action = "save";
                   AddMobBill();
                   objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                   showGridView(EmpId);
                   action = "";

               }
           }
           else
               objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
       }
       else
           Response.Redirect("login.aspx");
   }

   private void clearall()
   {
       drpCmp.SelectedIndex = 1;
       drpEmpId.SelectedIndex = 0;
       EmpNameTxtBox.Text = "";
       DrpListMonth.SelectedIndex = 0;
       drpYear.SelectedItem.Text = "Select";
       TextBoxAdj.Text = "";
       mbBilAdGridView.DataSource = null;
       mbBilAdGridView.DataBind();
       labelMbAdj.Text = "";
       drpEmpId.Enabled = true;
       
   }

   private void AddMobBill()
   {
       try
       {
           EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
           objMbBBillAdj.EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
           objMbBBillAdj.MonthName = Convert.ToString(DrpListMonth.SelectedItem.Text);
           objMbBBillAdj.Year = drpYear.SelectedItem.Text;
           objMbBBillAdj.MobileDeduct = float.Parse(TextBoxAdj.Text);
           objMbBBillAdj.MonthId = DrpListMonth.SelectedValue;
           objMbBBillAdj.Action = action;
           objMbBBillAdj.MCelling = float.Parse(TextBoxMobC.Text);
           PorcessMobBillAdjInsert procmbbilladj = new PorcessMobBillAdjInsert();
           procmbbilladj.MbBillAdjBLL = objMbBBillAdj;
           procmbbilladj.invoke();
       }
       catch (Exception ex)
       {
           objCommonName.LabelMessageandColor(labelMbAdj, ex.Message.ToString(), System.Drawing.Color.Red);
       }


   }
   protected bool Validate()
   {
       string strSql = "SELECT EmpId,MonthName,Year,MobileDeduct FROM tblMobileDeduct where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and Year='" + Convert.ToString(System.DateTime.Now).Substring(6, 4) + "' and MonthName='" + Convert.ToString(DrpListMonth.SelectedItem.Text) + "' order by MonthId ASC";
       bool chkvalue = false;
       if (ClsCommon.ItemCheck(strSql))
       {
           objCommonName.LabelMessageandColor(labelMbAdj, "This Month Data already Exists " + objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
       
       }
       else if (drpEmpId.SelectedIndex == 0)
       {
           objCommonName.LabelMessageandColor(labelMbAdj, "Employee " + objCommonName.IDRequired.ToString(), System.Drawing.Color.Red);
       
       }
       else if (DrpListMonth.SelectedIndex == 0)
       {
           objCommonName.LabelMessageandColor(labelMbAdj, "Month " + objCommonName.NameRequired.ToString(), System.Drawing.Color.Red);
       }
       else if (drpYear.SelectedItem.Text == "Select")
       {
           objCommonName.LabelMessageandColor(labelMbAdj, "Year " + objCommonName.NameRequired.ToString(), System.Drawing.Color.Red);
       }
       else 
       {
           chkvalue = true;
       }
       return chkvalue;
   }
   protected void btnUpdate_Click(object sender, EventArgs e)
   {
       action="Update";
       AddMobBill();
       objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
       action = "";
       HiddenField1.Value = "";
       showGridView(EmpId);
       btnSave.Enabled = true;
       btnUpdate.Enabled = false;
       drpEmpId.Enabled = true;
   }
   protected void btnSearch_Click(object sender, EventArgs e)
   {
       clearall();
   }
   protected void TextBoxMBill_TextChanged(object sender, EventArgs e)
   {
       if(TextBoxMobC.Text!="" && TextBoxMBill.Text!="")
       {
           if(int.Parse(TextBoxMobC.Text) < int.Parse(TextBoxMBill.Text))
           {
               TextBoxAdj.Text = (int.Parse(TextBoxMBill.Text) - int.Parse(TextBoxMobC.Text)).ToString();
           }
           else
           {
               TextBoxAdj.Text = "0";
           }
       }
   }
}
