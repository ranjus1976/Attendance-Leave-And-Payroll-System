﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using System.IO;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class PageControls_UcTextFileCollect : System.Web.UI.UserControl
{
    private TextDataCollect _Text;

    public TextDataCollect Text
    {
        get { return _Text; }
        set { _Text = value; }
    }
    public string txtLine, txtFine, dyval, mnval, totyr, id_no, mcode, sLoc, cardid;
    public string cddy, cdmn, cdhr, hrval, cdyr2, cdyr1, yrvalf2, yrvall2, cdmm, mmval, intFileNum, cdtime;
    public string Dt1;
    public DateTime Dt2;

    protected void btnOk_Click(object sender, EventArgs e)
    {
        String strFileName = "";
        String FilePath = "";
        string[] strExt;
        Int32 CountTag = 0;

        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DATACOLLECION.ToString(), "C"))
            {
                if (FileUpload1.HasFile)
                {
                    Regex rgTime = new Regex("[0-9][0-9]:[0-9][0-9]");
                    Regex rgDate = new Regex("[0-3][0-9]/[0-1][0-9]/[0-9][0-9][0-9][0-9]");

                    strFileName = FileUpload1.FileName.Substring(FileUpload1.FileName.LastIndexOf('\\') + 1);
                    FilePath = Server.MapPath("TextFile\\" + strFileName);

                    if (File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }

                    FileUpload1.PostedFile.SaveAs(Server.MapPath("TextFile\\" + FileUpload1.FileName));
                    strFileName = FileUpload1.FileName.Substring(FileUpload1.FileName.LastIndexOf('\\') + 1);
                    FilePath = Server.MapPath("TextFile\\" + strFileName);

                    strExt = strFileName.Split('.');

                    if (strExt[1] == "csv") //if (strExt[1] == "txt")
                    {
                        try
                        {
                            StreamReader sr = new StreamReader(FilePath);
                            string input = null;
                            while ((input = sr.ReadLine()) != null)
                            {
                                string sLoc1 = input.Trim();
                                if (sLoc1.Length >= 30)
                                {
                                    sLoc = sLoc1.Substring(1, 2); //for Machine Location
                                    dyval = sLoc1.Substring(22, 2); //for day value
                                    mnval = sLoc1.Substring(20, 2); //for Month value
                                    totyr = sLoc1.Substring(16, 4); //for Year value
                                    hrval = sLoc1.Substring(25, 2); // for hour value
                                    mmval = sLoc1.Substring(27, 2); //for minute value
                                    cardid = sLoc1.Substring(5, 11); //employee cardno
                                    cdtime = hrval + ":" + mmval; //hour and minute
                                    Dt1 = dyval + "/" + mnval + "/" + totyr; //day+month+year

                                    if (rgTime.IsMatch(cdtime) && rgDate.IsMatch(Dt1))
                                    {
                                        Dt2 = Convert.ToDateTime(Dt1);
                                        AddTextData();
                                        CountTag++;
                                    }
                                }
                            }
                            sr.Close();
                            if (CountTag > 0)
                            {
                                lblErrorMeassage.Visible = true;
                                lblErrorMeassage.ForeColor = System.Drawing.Color.Green;
                                lblErrorMeassage.Text = "Data saved successful.";
                            }
                            else
                            {
                                lblErrorMeassage.Visible = true;
                                lblErrorMeassage.ForeColor = System.Drawing.Color.Red;
                                lblErrorMeassage.Text = "File does not have valid data";
                            }
                        }
                        catch (Exception ex)
                        {
                            ex.Message.ToString();
                        }
                    }
                    else
                    {
                        lblErrorMeassage.Visible = true;
                        lblErrorMeassage.ForeColor = System.Drawing.Color.Red;
                        lblErrorMeassage.Text = "Please browse a .txt file";
                    }
                }
                else
                {
                    lblErrorMeassage.Visible = true;
                    lblErrorMeassage.ForeColor = System.Drawing.Color.Red;
                    lblErrorMeassage.Text = "Please browse a file first ";
                }
            }
            else
            {
                lblErrorMeassage.Visible = true;
                lblErrorMeassage.ForeColor = System.Drawing.Color.Red;
                lblErrorMeassage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    public void AddTextData()
    {
        _Text = new TextDataCollect();
        _Text.CardId = cardid;
        _Text.PunchDate = Dt2;
        //_Text.PunchTime = Convert.ToDateTime(cdtime);
        _Text.PunchTime = cdtime;
        _Text.StNo = sLoc;
        ProcessTextDataInsert tdata = new ProcessTextDataInsert();
        tdata.DataCollect = _Text;
        tdata.invoke();

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DATACOLLECION.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    lblErrorMeassage.Visible = false;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    
}
