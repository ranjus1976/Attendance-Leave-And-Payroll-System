﻿using System;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;

public partial class PageControls_UcBikeLoanAdjment : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["BLSID"] = null;
            loadEmployee();
            txtFromDate.Text = "";// Convert.ToString(System.DateTime.Now).Substring(0, 10);
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            //LoadYear();
            //objCommonName.Addmonth(drpListMonth);
        }
    }
    
    private void loadEmployee()
    {
        try
        {
            string strSQL = "SELECT B.EmpId,E.EmpName FROM tbl_BikeLoanSetup B inner join tblEmployee E on E.EmpId= B.EmpId where ValidLog=1 order by E.EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));
            

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxEmpName.Text = drpEmpId.SelectedValue.ToString();
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        string sql = "SELECT sum(A.InstAmt),sum(A.OTherAdj) FROM tbl_BikeloanAdj A inner join tbl_BikeLoanSetup B on B.EmpId=A.EmpId and B.ValidLog=1 where A.EmpId='"+drpEmpId.SelectedItem.Text+"'";
        DataSet dsBikePay = new DataSet();
        dsBikePay = ClsCommon.GetAdhocResult(sql);
        string TInstAmt = dsBikePay.Tables[0].Rows[0][0].ToString();
        string TOTherAdj = dsBikePay.Tables[0].Rows[0][1].ToString();


        string sql1 = "SELECT LoanAmount,TotalAmtInst,BLoanAmtDue,Duration FROM tbl_BikeLoanSetup where ValidLog=1 and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        DataSet dsBike = new DataSet();
        dsBike = ClsCommon.GetAdhocResult(sql1);
        string TLoan = dsBike.Tables[0].Rows[0][0].ToString();
        string TInst = dsBike.Tables[0].Rows[0][1].ToString();
        string BLoadDue = dsBike.Tables[0].Rows[0][2].ToString();
        string NOfInst = dsBike.Tables[0].Rows[0][3].ToString();
        string YearlyIns = numberstring((int.Parse(BLoadDue) * 12 / int.Parse(NOfInst)).ToString());
        TextBoxAdjAmt.Text = YearlyIns;
        TotalAmtDue(TLoan, TInst, TInstAmt, TOTherAdj);
        TotalAdjDueAmt(TLoan, TInst, TInstAmt, TOTherAdj);
        LoadEmpLoan();
    }
    private void LoadEmpLoan()
    {
        Session["BLSID"] = null;
        string sql = "SELECT sum(A.InstAmt),sum(A.OTherAdj),Max(NoOfInst) as NoOfInst FROM tbl_BikeloanAdj A inner join tbl_BikeLoanSetup B on B.EmpId=A.EmpId and B.ValidLog=1 where A.EmpId='" + drpEmpId.SelectedItem.Text + "'";
        DataSet dsBikePay = new DataSet();
        dsBikePay = ClsCommon.GetAdhocResult(sql);
        string TInstAmt = dsBikePay.Tables[0].Rows[0][0].ToString();
        string TOTherAdj = dsBikePay.Tables[0].Rows[0][1].ToString();
        string PayInstNo = dsBikePay.Tables[0].Rows[0][2].ToString();

        string sql1 = "SELECT LoanAmount,TotalAmtInst,BLoanAmtDue,Duration,EmpInstAmt,BLSID FROM tbl_BikeLoanSetup where ValidLog=1 and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        DataSet dsBike = new DataSet();
        dsBike = ClsCommon.GetAdhocResult(sql1);
        if (dsBike.Tables[0].Rows.Count != 0)
        {
            string TLoan = dsBike.Tables[0].Rows[0][0].ToString();
            string TInst = dsBike.Tables[0].Rows[0][1].ToString();
            string BLoadDue = dsBike.Tables[0].Rows[0][2].ToString();
            string NOfInst = dsBike.Tables[0].Rows[0][3].ToString();
            string InstAmt = dsBike.Tables[0].Rows[0][4].ToString();
            Session["BLSID"] = dsBike.Tables[0].Rows[0][5].ToString();
            string YearlyIns = numberstring((int.Parse(BLoadDue)*12/int.Parse(NOfInst)).ToString());
            TextBoxAdjAmt.Text = YearlyIns;
            TotalAmtDue(TLoan, TInst, TInstAmt, TOTherAdj);
            TotalAdjDueAmt(TLoan, TInst, TInstAmt, TOTherAdj);
            lblNoOfInst.Text = "No. Of Installment: " + PayInstNo.ToString() + "   ";
            lblTAdjAmt.Text = "Total Adjust: " + TOTherAdj.ToString() + "   ";
            lblTInstPay.Text = "Total Installment: " + TInstAmt.ToString() + "   ";
            lblInstAmt.Text = "Installment Amount: " + InstAmt.ToString() + "   ";
            LoadGrid(drpEmpId.SelectedItem.Text, Session["BLSID"].ToString());
        }
        else
        {
            TextBoxTAmtDue.Text = "0";
            TextBoxTAdjDueAmt.Text = "0";
            loadEmployee();

        }
    }
    private void LoadGrid(string EmpId, string BLSID)
    {
        string searchStr = "SELECT CONVERT(varchar(10), payDate, 103) AS PayDate,LoanAmtDue,OTherAdj FROM tbl_BikeloanAdj where payType='O' and EmpId='" + EmpId + "' and InstLog=1 and BLSID=" + BLSID;
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeLnAdjmentGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeLnAdjmentGridView.DataBind();
    }
    private string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }

    private void TotalAdjDueAmt(string TLoan, string TInst, string TInstAmt, string TOTherAdj)
    {
        if (TInstAmt == "")
        {
            TInstAmt = "0";
        }
        if (TOTherAdj == "")
        {
            TOTherAdj = "0";
        }
        string TotalAmtAdjDue = (int.Parse(TLoan) - int.Parse(TInst) - int.Parse(TOTherAdj)).ToString();
        if (int.Parse(TotalAmtAdjDue)<0)
        {
            TotalAmtAdjDue = "0";
        }
        TextBoxTAdjDueAmt.Text = TotalAmtAdjDue;
    }

    private void TotalAmtDue(string TLoan, string TInst, string TInstAmt, string TOTherAdj)
    {
        if (TInstAmt == "")
        {
            TInstAmt = "0";
        }
        if (TOTherAdj == "")
        {
            TOTherAdj = "0";
        }
        string TotalDueAmt = (int.Parse(TLoan) - int.Parse(TInstAmt) - int.Parse(TOTherAdj)).ToString();
            TextBoxTAmtDue.Text = TotalDueAmt;
        
        
    }

    protected void DropDownListMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownListYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLnAdjmentGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            //string strSql = "SELECT BLSID FROM tbl_BikeloanAdj where payType='O' and EmpId='"+drpEmpId.SelectedItem.Text+"' and MonthName='"+drpListMonth.SelectedItem.Text+"' and YearName='"+drpListYear.SelectedItem.Text+"'";
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "C"))
            {
                if (Validate())
                {
                    string month = Convert.ToDateTime(txtFromDate.Text).ToString("MMMM").Substring(0, 3);
                    string year = Convert.ToDateTime(txtFromDate.Text).Year.ToString();
                    string strSql = "SELECT BLSID FROM tbl_BikeloanAdj where EmpId='" + drpEmpId.SelectedItem.Text + "' and MonthName='" + month + "' and YearName='" + year + "' and InstLog=1 and payType='O'";
                         
                   if (!ClsCommon.ItemCheck(strSql))
                   {
                            action = "save";
                            AddBikeDetail();
                            objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                            LoadEmpLoan();
                            //showGridView();
                            action = "";
                        }
                        else
                        {
                            LabelLoanAdj.Visible = true;
                            LabelLoanAdj.ForeColor = System.Drawing.Color.Red;
                            LabelLoanAdj.Text = "Entry Already EXISTS For This Month!";
                        }
                    
                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddBikeDetail()
    {
        BikeLoanAdj objBikeLoanAdj=new BikeLoanAdj();
        objBikeLoanAdj.EmpId = drpEmpId.SelectedItem.Text;
        objBikeLoanAdj.AdjAmount = int.Parse(TextBoxAdjAmt.Text);
        DateTime Date = Convert.ToDateTime(txtFromDate.Text);
        objBikeLoanAdj.Date = Date;
        objBikeLoanAdj.Action = action;
        ProcessBikeLoanAdjInsert objProcessBikeLoanAdjInsert=new ProcessBikeLoanAdjInsert();
        objProcessBikeLoanAdjInsert.BikeLoanAdjIntrate = objBikeLoanAdj;
        objProcessBikeLoanAdjInsert.invoke();
    }

    private bool Validate()
    {
        return true;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void BikeLnAdjmentGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLnAdjmentGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BikeLnAdjmentGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void BikeLnAdjmentGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "U"))
            {

                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in BikeLnAdjmentGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int Row = gvrow.RowIndex;
                string date = gvrow.Cells[0].Text;
                string adjamount = gvrow.Cells[2].Text;
                loadBikeDetail(date, adjamount, Row);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadBikeDetail(string date, string adjamount, int row)
    {
        string sql = "SELECT OTherAdj,CONVERT(varchar(10), payDate, 103) AS PayDate,(select min(LoanAmtDue) from tbl_BikeloanAdj where EmpId='1161' and InstLog=1 ) as LoanAmtDue FROM tbl_BikeloanAdj where EmpId='" + drpEmpId.SelectedItem.Text + "' and PayDate=convert(datetime,'" + date + "',103) and InstLog=1 and PayType='O'";
        DataSet dsEmp = new DataSet();
        dsEmp = ClsCommon.GetAdhocResult(sql);

        if (dsEmp.Tables[0].Rows.Count != 0)
        {
            TextBoxAdjAmt.Text = dsEmp.Tables[0].Rows[0][0].ToString();
            TextBoxTAmtDue.Text = dsEmp.Tables[0].Rows[0][2].ToString();
            txtFromDate.Text = dsEmp.Tables[0].Rows[0][1].ToString();
            TextBoxTAdjDueAmt.Text = "";
            txtFromDate.Enabled = false;
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            action = "Delete";
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "D"))
            {
                BikeLoanAdj objBikeLoanAdj = new BikeLoanAdj();
                foreach (GridViewRow oRow in BikeLnAdjmentGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");


                        
                        objBikeLoanAdj.EmpId = drpEmpId.SelectedItem.Text;
                        objBikeLoanAdj.AdjAmount = 0;
                        DateTime Date = Convert.ToDateTime(BikeLnAdjmentGridView.Rows[i].Cells[0].Text); ;
                        objBikeLoanAdj.Date = Date;
                        objBikeLoanAdj.Action = action;
                        ProcessBikeLoanAdjInsert objProcessBikeLoanAdjInsert = new ProcessBikeLoanAdjInsert();
                        objProcessBikeLoanAdjInsert.BikeLoanAdjIntrate = objBikeLoanAdj;
                        objProcessBikeLoanAdjInsert.invoke();

                    }
                    i++;
                }
                LoadGrid(drpEmpId.SelectedItem.Text, Session["BLSID"].ToString());
                objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
                action = "";
            }
            else
                objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        drpEmpId.SelectedItem.Text = "Select";
        TextBoxEmpName.Text = "";
        TextBoxTAdjDueAmt.Text = "";
        TextBoxTAmtDue.Text = "";
        TextBoxAdjAmt.Text = "";
        txtFromDate.Text = "";
        lblNoOfInst.Text = "";
        lblTAdjAmt.Text = "";
        lblTInstPay.Text = "";
        lblInstAmt.Text = "";
        LabelLoanAdj.Text = "";
        Session["BLSID"] = null;
        btnUpdate.Enabled = false;
        btnSave.Enabled = true;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddBikeDetail();
        objCommonName.LabelMessageandColor(LabelLoanAdj, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        hidEditCheckedIDS.Value = "";
        LoadGrid(drpEmpId.SelectedItem.Text, Session["BLSID"].ToString());
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        txtFromDate.Enabled = true;
    }
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {

    }
}
