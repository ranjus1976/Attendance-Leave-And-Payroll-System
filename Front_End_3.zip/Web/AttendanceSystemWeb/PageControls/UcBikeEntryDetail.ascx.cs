﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Design;
using AttendanceSystem.Core;

public partial class PageControls_UcBikeEntryDetail : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            TextBoxInsurExpDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
            TextBoxInsurIssueDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
            TextBoxPurchaseDte.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
            TextBoxOther.Text = "0";
            showGridView();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
        }
    }
    private void showGridView()
    {
        string searchStr = "SELECT BikeID,Model,Manufecturer,ManuYear,RegistrationNo,EngineNo,ChesisNo,TotalCost FROM tbl_Bike_Entry_Details where BikeLog=1 order by Model asc";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeEntryDatailGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeEntryDatailGridView.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["FinalStringBikeFileName"] == null)
        {
            GetImage();
        }
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "C"))
            {
                if (Validate())
                {
                    if (flUploadBike.HasFile || Session["FinalStringBikeFileName"] != null)
                    {
                        string strSql = "SELECT BikeID FROM tbl_Bike_Entry_Details where BikeLog=1 and EngineNo='" + TextBoxEngineNo + "' OR ChesisNo='" + TextBoxChesisNo.Text + "'";

                        if (!ClsCommon.ItemCheck(strSql))
                        {
                            action = "save";
                            AddBikeDetail();
                            objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                            showGridView();
                            action = "";
                        }
                        else
                        {
                            LabelBikeDetail.Visible = true;
                            LabelBikeDetail.ForeColor = System.Drawing.Color.Red;
                            LabelBikeDetail.Text = "Bike Already EXISTS!";
                        }
                    }
                    else
                    {

                        LabelBikeDetail.Visible = true;
                        LabelBikeDetail.ForeColor = System.Drawing.Color.Red;
                        LabelBikeDetail.Text = "Please browse a file first ";

                    }
                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddBikeDetail()
    {
        BikeDetailInfo objBikeDetail = new BikeDetailInfo();
        objBikeDetail.Model = TextBoxModel.Text;
        objBikeDetail.RegistrationNo = TextBoxRegNo.Text + "-" + TextBoxRegNo0.Text + "-" + TextBoxRegNo1.Text + "-" + TextBoxRegNo2.Text;
        objBikeDetail.EngineNo = TextBoxEngineNo.Text;
        objBikeDetail.ChesisNo = TextBoxChesisNo.Text;
        objBikeDetail.Manufecturer = TextBoxManufacturer.Text;
        objBikeDetail.ManuYear = TextBoxMYear.Text;
        objBikeDetail.PurchaseDate = TextBoxPurchaseDte.Text;
        objBikeDetail.InsuranceNo = TextBoxInsurNo.Text;
        objBikeDetail.InsurIssueDate = TextBoxInsurIssueDate.Text;
        objBikeDetail.InsurExpireDate = TextBoxInsurExpDate.Text;
        objBikeDetail.Price = int.Parse(TextBoxPrice.Text);
        objBikeDetail.InsuranceCost = int.Parse(TextBoxInsurCost.Text);
        objBikeDetail.RegCharge = int.Parse(TextBoxRegCost.Text);
        objBikeDetail.Others = int.Parse(TextBoxOther.Text);
        objBikeDetail.TotalCost = int.Parse(TextBoxTotalCost.Text);
        objBikeDetail.Narration = TextBoxNarate.Text;
        objBikeDetail.Color = TextBoxColor.Text;
        objBikeDetail.ImageLoc = Session["FinalStringBikeFileName"].ToString();
        objBikeDetail.Action = action;
        ProcessBikeDetailInfoInsert objProcessBikeDetailInfoInsert = new ProcessBikeDetailInfoInsert();
        objProcessBikeDetailInfoInsert.bikeDetailInfoIntrate = objBikeDetail;
        objProcessBikeDetailInfoInsert.invoke();

    }

    private bool Validate()
    {
        bool retval = true;
        //if (TextBoxRegNo.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeDetail, "Give RegNo", System.Drawing.Color.Red);
        //}
        //else if (TextBoxEngineNo.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeDetail, "Give EngineNo", System.Drawing.Color.Red);
        //}
        //else if (TextBoxChesisNo.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeDetail, "Give ChesisNo", System.Drawing.Color.Red);
        //}
        //else if (TextBoxManufacturer.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeDetail, "Give Manufacturer", System.Drawing.Color.Red);
        //}
        //else if (TextBoxPrice.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeDetail, "Give Price", System.Drawing.Color.Red);
        //}
        return retval;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void BikeEntryDatailGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeEntryDatailGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeEntryDatailGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BikeEntryDatailGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void BikeEntryDatailGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "U"))
            {

                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in BikeEntryDatailGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int Row = gvrow.RowIndex;
                string EnginNo = gvrow.Cells[4].Text;
                string CacisNo = gvrow.Cells[5].Text;
                loadBikeDetail(EnginNo, CacisNo, Row);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadBikeDetail(string EnginNo, string CacisNo, int row)
    {
        try
        {
            string a = HiddenField1.Value;
            string strSQL = "select * from tbl_Bike_Entry_Details where BikeLog=1 and EngineNo='" + EnginNo + "' OR ChesisNo='" + CacisNo + "'";
            DataSet dsEmp = new DataSet();
            dsEmp = ClsCommon.GetAdhocResult(strSQL);

            if (dsEmp.Tables[0].Rows.Count != 0)
            {
                TextBoxModel.Text = dsEmp.Tables[0].Rows[0][1].ToString();


                string input = dsEmp.Tables[0].Rows[0][4].ToString();
                //string[]  divides=new string[4];
                string[] divides = input.Split('-');

                for (int i = 0; i < divides.Length; i++)
                {
                    if (i == 0)
                        TextBoxRegNo.Text = divides[i].ToString();
                    else if (i == 1)
                        TextBoxRegNo.Text += "-" + divides[i].ToString();
                    else if (i == 2)
                        TextBoxRegNo0.Text = divides[i].ToString();
                    else if (i == 3)
                        TextBoxRegNo1.Text = divides[i].ToString();
                    else

                        TextBoxRegNo2.Text = divides[i].ToString();
                }

                //TextBoxRegNo0.Text = part[1];
                //TextBoxRegNo1.Text = a[2];

                TextBoxEngineNo.Text = dsEmp.Tables[0].Rows[0][5].ToString().Trim();
                TextBoxChesisNo.Text = dsEmp.Tables[0].Rows[0][6].ToString();
                TextBoxManufacturer.Text = dsEmp.Tables[0].Rows[0][2].ToString();
                TextBoxMYear.Text = dsEmp.Tables[0].Rows[0][3].ToString();
                TextBoxPurchaseDte.Text = dsEmp.Tables[0].Rows[0][9].ToString().Substring(0, 10);
                TextBoxInsurNo.Text = dsEmp.Tables[0].Rows[0][11].ToString();
                TextBoxInsurIssueDate.Text = dsEmp.Tables[0].Rows[0][12].ToString().Substring(0, 10);
                TextBoxInsurExpDate.Text = dsEmp.Tables[0].Rows[0][13].ToString().Substring(0, 10);
                TextBoxPrice.Text = dsEmp.Tables[0].Rows[0][8].ToString();
                TextBoxInsurCost.Text = dsEmp.Tables[0].Rows[0][14].ToString();
                TextBoxRegCost.Text = dsEmp.Tables[0].Rows[0][10].ToString();
                TextBoxOther.Text = dsEmp.Tables[0].Rows[0][16].ToString();
                TextBoxTotalCost.Text = dsEmp.Tables[0].Rows[0][17].ToString();
                TextBoxNarate.Text = dsEmp.Tables[0].Rows[0][7].ToString();
                TextBoxColor.Text = dsEmp.Tables[0].Rows[0][18].ToString();
                Session["FinalStringBikeFileName"] = dsEmp.Tables[0].Rows[0][15].ToString();
                PictureUpload();
                TextBoxModel.Enabled = false;
                //TextBoxRegNo.Enabled = false;
                TextBoxEngineNo.Enabled = false;
                TextBoxChesisNo.Enabled = false;
                TextBoxManufacturer.Enabled = false;
                TextBoxMYear.Enabled = false;
                TextBoxPurchaseDte.Enabled = false;
                flUploadBike.Enabled = false;
                btnFind.Enabled = false;

            }

        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelBikeDetail, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKEENTRYDETSIL.ToString(), "D"))
            {
                BikeDetailInfo objBikeDetailInfo = new BikeDetailInfo();
                foreach (GridViewRow oRow in BikeEntryDatailGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        objBikeDetailInfo.EngineNo = BikeEntryDatailGridView.Rows[i].Cells[4].Text;
                        objBikeDetailInfo.ChesisNo = BikeEntryDatailGridView.Rows[i].Cells[5].Text;
                        ProcessBikeDetailinfoDelete BikeDetailinfoD = new ProcessBikeDetailinfoDelete();
                        BikeDetailinfoD.BikeDetailInfoD = objBikeDetailInfo;
                        BikeDetailinfoD.invoke();

                    }
                    i++;
                }
                showGridView();
                objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddBikeDetail();
        objCommonName.LabelMessageandColor(LabelBikeDetail, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        TextBoxModel.Enabled = true;
        TextBoxRegNo.Enabled = true;
        TextBoxEngineNo.Enabled = true;
        TextBoxChesisNo.Enabled = true;
        TextBoxManufacturer.Enabled = true;
        TextBoxMYear.Enabled = true;
        TextBoxPurchaseDte.Enabled = true;
        flUploadBike.Enabled = true;
        LabelBikeDetail.Text = "";
        TextBoxModel.Text = "";
        TextBoxRegNo.Text = "";
        TextBoxEngineNo.Text = "";
        TextBoxChesisNo.Text = "";
        TextBoxManufacturer.Text = "";
        TextBoxMYear.Text = "";
        TextBoxPurchaseDte.Text = "";
        TextBoxInsurNo.Text = "";
        TextBoxInsurIssueDate.Text = "";
        TextBoxInsurExpDate.Text = "";
        TextBoxPrice.Text = "";
        TextBoxInsurCost.Text = "";
        TextBoxRegCost.Text = "";
        TextBoxOther.Text = "";
        TextBoxTotalCost.Text = "";
        TextBoxNarate.Text = "";
        imgContent.ImageUrl = "";
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        btnFind.Enabled = true;

    }

    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        string searchStr = "select BikeID,RegistrationNo,EngineNo,ChesisNo,Manufacturer,Price,PurchaseDate from tbl_Bike_Entry_Details where BikeID='" + txtSearch.Text + "' and BikeLog=1";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeEntryDatailGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeEntryDatailGridView.DataBind();
    }
    protected void btnFind_Click(object sender, EventArgs e)
    {
        PictureBrowse();
    }
    private void PictureBrowse()
    {
        String strFileName = "";
        string[] Extension;


        if (flUploadBike.HasFile)
        {
            strFileName = flUploadBike.FileName.Substring(flUploadBike.FileName.LastIndexOf('\\') + 1);
            Extension = strFileName.Split('.');

            if (Extension[1] == "jpg" || Extension[1] == "jpeg" || Extension[1] == "bmp")
            {
                GetImage();
                PictureUpload();
                LabelSearch.Text = "";
                LabelSearch.Visible = false;
            }
        }



        else
        {
            LabelSearch.Visible = true;
            LabelSearch.ForeColor = System.Drawing.Color.Red;
            LabelSearch.Text = "Please browse a file first ";
        }

    }
    public string GetImage()
    {
        String strFileName = "";
        String strFileNameFinal = "";
        String FilePath = "";
        String FakeName = "";
        string[] FakeName2;
        string[] FakeName3;
        string[] FakeName1;
        string[] BFileName;
        String FinalStringForeFileName = "";
        //Session["FinalStringBikeFileName"] = null;

        if (flUploadBike.HasFile)
        {
            strFileName = flUploadBike.FileName.Substring(flUploadBike.FileName.LastIndexOf('\\') + 1);
            BFileName = strFileName.Split('.');

            FakeName = DateTime.Now.ToString();
            FakeName1 = FakeName.Split(' ');
            FakeName2 = FakeName1[0].Split('/');
            FakeName3 = FakeName1[1].Split(':');
            FinalStringForeFileName = FakeName2[0] + FakeName2[1] + FakeName2[2] + FakeName3[0] + FakeName3[1] + FakeName3[2] + BFileName[0] + "." + BFileName[1];

            FilePath = Server.MapPath("TextFile\\" + FinalStringForeFileName);
            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
            }
            flUploadBike.PostedFile.SaveAs(Server.MapPath("TextFile\\" + FinalStringForeFileName));
            Session["FinalStringBikeFileName"] = FinalStringForeFileName;
        }


        else
        {
            LabelSearch.Visible = true;
            LabelSearch.ForeColor = System.Drawing.Color.Red;
            LabelSearch.Text = "Please browse a file first ";
        }

        return FinalStringForeFileName;
    }
    private void PictureUpload()
    {
        string path = "";
        String FullPath = "";

        path = Session["FinalStringBikeFileName"].ToString();
        if (path != "")
        {
            FullPath = "~/TextFile/" + path;
            imgContent.ImageUrl = FullPath;
        }
    }
    protected void TextBoxInsurCost_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxInsurCost.Text != "" && TextBoxRegCost.Text != "" && TextBoxPrice.Text != "" && TextBoxOther.Text != "")
        {
            TextBoxTotalCost.Text = (int.Parse(TextBoxInsurCost.Text) + int.Parse(TextBoxRegCost.Text) + int.Parse(TextBoxPrice.Text) + int.Parse(TextBoxOther.Text)).ToString();

        }
        else
        {
            TextBoxTotalCost.Text = "";
        }
    }
    protected void TextBoxPrice_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxInsurCost.Text != "" && TextBoxRegCost.Text != "" && TextBoxPrice.Text != "" && TextBoxOther.Text != "")
        {
            TextBoxTotalCost.Text = (int.Parse(TextBoxInsurCost.Text) + int.Parse(TextBoxRegCost.Text) + int.Parse(TextBoxPrice.Text) + int.Parse(TextBoxOther.Text)).ToString();

        }
        else
        {
            TextBoxTotalCost.Text = "";
        }
    }
    protected void TextBoxRegCost_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxInsurCost.Text != "" && TextBoxRegCost.Text != "" && TextBoxPrice.Text != "" && TextBoxOther.Text != "")
        {
            TextBoxTotalCost.Text = (int.Parse(TextBoxInsurCost.Text) + int.Parse(TextBoxRegCost.Text) + int.Parse(TextBoxPrice.Text) + int.Parse(TextBoxOther.Text)).ToString();

        }
        else
        {
            TextBoxTotalCost.Text = "";
        }
    }
    protected void TextBoxOther_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxInsurCost.Text != "" && TextBoxRegCost.Text != "" && TextBoxPrice.Text != "" && TextBoxOther.Text != "")
        {
            TextBoxTotalCost.Text = (int.Parse(TextBoxInsurCost.Text) + int.Parse(TextBoxRegCost.Text) + int.Parse(TextBoxPrice.Text) + int.Parse(TextBoxOther.Text)).ToString();

        }
        else
        {
            TextBoxTotalCost.Text = "";
        }
    }
    protected void TextBoxManufacturer_TextChanged(object sender, EventArgs e)
    {

    }
}
