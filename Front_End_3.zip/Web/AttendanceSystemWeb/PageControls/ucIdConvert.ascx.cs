﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_ucIdConvert : System.Web.UI.UserControl
{
    CommonName objCommonName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEIDCONVERTER.ToString(), "R"))
        {
            if (Session["LogIn"] != null)
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    ddlCompanyCode.SelectedIndex = 1;
                    EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblId, EmpImage);
                    Session["NotReadPermission"] = null;
                    if (ddlCompanyCode.SelectedIndex != 0)
                    {
                        LoadEmployeeList();
                        Label1.Visible = false;
                        Label1.Text = "";
                        objCommonName = new CommonName();
                        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
                    }
                    else
                    {
                        ddlEmployeeCode.SelectedIndex = 0;
                    }
                }
            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Session["NotReadPermission"] = "NotReadPermission";
            Response.Redirect("Default.aspx");
        }
    }

    #region Private methods
    private void Clear()
    {
        ddlCompanyCode.SelectedIndex = 0;
        ddlEmployeeCode.SelectedIndex = 0;
        txtNewEmployeeCode.Text = "";
    }
    
    #endregion

    #region Combo Load
    public void loadCompany()
    {

        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(ddlCompanyCode, strSQL, "CompName", "Comp_Number");
            ddlCompanyCode.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    protected void LoadEmployeeList()
    {
        try
        {
            ddlEmployeeCode.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + ddlCompanyCode.SelectedValue + " order by EmpId asc";
            ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
            ddlEmployeeCode.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Clear();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEIDCONVERTER.ToString(), "R"))
        {
            if (Session["LogIn"] != null)
            {
                if (txtNewEmployeeCode.Text.Trim() != "" && txtNewEmployeeCode.Text.Trim() != String.Empty)
                {
                    if (ddlEmployeeCode.SelectedIndex != 0 && ddlCompanyCode.SelectedIndex != 0)
                    {
                        ReportData objReportData = new ReportData();
                        SqlCommand cmd = new SqlCommand();
                        SqlConnection objReturnedConn = new SqlConnection();
                        String Sql = " update tblEmployee set EmpId='" + txtNewEmployeeCode.Text + "' where EmpId = '" + ddlEmployeeCode.SelectedItem.Text + "' ";
                        objReturnedConn = objReportData.GetDBConn();
                        objReturnedConn.Open();
                        cmd.Connection = objReturnedConn;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = Sql;
                        cmd.ExecuteNonQuery();
                        Clear();
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Green;
                        Label1.Text = "Data saved successful.";
                    }

                    else
                    {
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Red;
                        Label1.Text = "Please select!";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "New employee id required";
                }
            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to process the request!";
        }

    }
    protected void ddlCompanyCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompanyCode.SelectedIndex != 0)
        {
            LoadEmployeeList();
            Label1.Visible = false;
            Label1.Text = "";
            objCommonName = new CommonName();
            objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        }
        else
        {
            ddlEmployeeCode.SelectedIndex = 0;
        }
    }
    protected void ddlEmployeeCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblId, EmpImage);
    }
    
           
}
