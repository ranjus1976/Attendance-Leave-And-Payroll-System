﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Core;

public partial class PageControls_UcGovtHoliDayForm : System.Web.UI.UserControl
{
    String ReportDateShow = "";
    String TimeShow = "";
    protected DataSet GetHoliDayDataSource()
    {
        ProcessGovtHoliDaySelectAll processSelect = new ProcessGovtHoliDaySelectAll();
        processSelect.invoke();
        return processSelect.GovtHoliDayDS;
    }
    protected void BindGridView()
    {
        GridView1.DataSource = GetHoliDayDataSource();
        GridView1.DataBind();
        Session["GovtHoliDay"] = GetHoliDayDataSource();
    }
    private void FinancialYear()
    {
        try
        {
            string strSQL = "select Financial_Year_Number,Financial_Year from  tblFinancial_Year";
            ClsCommon.drplistAdd(ddlFinancialYear, strSQL, "Financial_Year", "Financial_Year_Number");
            ddlFinancialYear.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void ClearPage()
    {
        TextBoxGovtHoliDayName.Text = "";
        txtFromdate.Text = "";
        txtToDate.Text = "";
        ddlFinancialYear.SelectedIndex = 0;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.GOVTHOLIDAY.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    ListItem item1 = new ListItem("Holiday Name", "0");

                    ListItem item2 = new ListItem("Date", "1");

                    DDLSearchBy.Items.Add("Select");
                    DDLSearchBy.Items.Add(item1);
                    DDLSearchBy.Items.Add(item2);
                    BindGridView();

                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    TimeShow = ReportDateShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);

                    txtFromdate.Text = ReportDateShow;
                    txtToDate.Text = ReportDateShow;
                    txtFromDate1.Text = ReportDateShow;
                    txtToDate1.Text = ReportDateShow;
                    FinancialYear();
                    Session["NotReadPermission"] = null;
                }
                SetEditMode(false);
                string GHNumber = Request.QueryString["GHNumber"];
                string del = Request.QueryString["Del"];
                string GHName = Request.QueryString["GHName"];
                string EditMode = Request.QueryString["Edit"];
                if (GHNumber != null && del != null)
                {
                    HiddenGHNumber.Value = GHNumber;
                    GovtHoliDayDelete();
                    BindGridView();
                }
                if (GHNumber != null && GHName != null)
                {
                    LoadUI();
                    SetEditMode(true);
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }

    protected void btnEdit_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.GOVTHOLIDAY.ToString(), "U"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");


                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField HidGHNumber1 = (HiddenField)oRow.FindControl("HidGHNumber");
                        HiddenField HidGHName1 = (HiddenField)oRow.FindControl("HidGHName");

                        HiddenField HidFinancial_Year1 = (HiddenField)oRow.FindControl("HidFinancial_Year");
                        HiddenField HidFromDate1 = (HiddenField)oRow.FindControl("HidFromDate");
                        HiddenField HidHidToDate1 = (HiddenField)oRow.FindControl("HidToDate");
                        HiddenField Hidamount1 = (HiddenField)oRow.FindControl("Hidamount");


                        string DateFrom = Convert.ToString(HidFromDate1.Value);
                        string DateTo = Convert.ToString(HidHidToDate1.Value);
                        HiddenGHNumber.Value = HidGHNumber1.Value;
                        TextBoxGovtHoliDayName.Text = HidGHName1.Value;
                        ddlFinancialYear.SelectedItem.Text = HidFinancial_Year1.Value;
                        txtFromdate.Text = DateFrom.Substring(0, 10);
                        txtToDate.Text = DateTo.Substring(0, 10);
                    }
                }
                BtnSave.Enabled = false;
                BtnUpdate.Enabled = true;
                Label9.Visible = false;
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    protected GovtHoliday GetInfoFromUI()
    {
        GovtHoliday gHoliDay = new GovtHoliday();

        string GHNumber = HiddenGHNumber.Value;
        if (!GHNumber.Equals(""))
        {
            gHoliDay.GHNumber = Convert.ToInt32(GHNumber);
        }
         string strGHName  = TextBoxGovtHoliDayName.Text;
         string strNewGHName= strGHName.Replace("'","''");
         gHoliDay.GHName = strNewGHName;

        gHoliDay.FinYearNo = Convert.ToString(ddlFinancialYear.SelectedValue);

        gHoliDay.FromDate = Convert.ToDateTime(txtFromdate.Text);
        gHoliDay.ToDate = Convert.ToDateTime(txtToDate.Text);
        gHoliDay.EntryBy = 1;
        gHoliDay.EntryDate = DateTime.Now;
        gHoliDay.PC = System.Net.Dns.GetHostName();

        return gHoliDay;

    }

    protected void LoadUI()
    {
        string GHNumber = Request.QueryString["GHNumber"];
        GridView1.Visible = false;
        TextBoxGovtHoliDayName.Text = Request.QueryString["GHName"];
        ddlFinancialYear.Text = Request.QueryString["Fin"];
    }

    protected void GovtHoliDayDelete()
    {
        GovtHoliday gHoliDay = new GovtHoliday();
        gHoliDay.GHNumber = Convert.ToInt32(HiddenGHNumber.Value);

        ProcessGovtHoliDayDelete processDelete = new ProcessGovtHoliDayDelete();
        processDelete.GHoliday = gHoliDay;
        processDelete.invoke();
        BindGridView();
    }
    protected void GovtHoliDayAdd()
    {
        ProcessGovtHoliDayInsert processInsert = new ProcessGovtHoliDayInsert();
        processInsert.GHoliDay = GetInfoFromUI();
        processInsert.invoke();
    }

    private bool isValidData()
    {
        if ((TextBoxGovtHoliDayName.Text.Trim().Equals("")))
        {
            Label9.Visible = true;
            Label9.ForeColor = System.Drawing.Color.Red;
            Label9.Text = "Holiday name required.";
            TextBoxGovtHoliDayName.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.GOVTHOLIDAY.ToString(), "C"))
            {
                DateTime FromDate = Convert.ToDateTime(txtFromdate.Text);
                DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

                if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                {
                    if (ddlFinancialYear.SelectedIndex != 0)
                    {
                        string strSql = "SELECT dbo.tblGovt_Holiday.* FROM dbo.tblGovt_Holiday WHERE     (GHName = '" + TextBoxGovtHoliDayName.Text.Replace("'","''") + "') AND (FromDate = '" + DateTime.Parse(txtFromdate.Text).ToString("dd/MMM/yyyy") + "') AND (ToDate = '" + DateTime.Parse(txtToDate.Text).ToString("dd/MMM/yyyy") + "')";
                        if (!ClsCommon.ItemCheck(strSql))
                        {
                            if (isValidData())
                            {

                                GovtHoliDayAdd();
                                Label9.Visible = true;
                                Label9.ForeColor = System.Drawing.Color.Green;
                                Label9.Text = "Data saved successful.";
                                ClearPage();
                                BindGridView();
                            }
                        }
                        else
                        {
                            Label9.Visible = true;
                            Label9.ForeColor = System.Drawing.Color.Red;
                            Label9.Text = "Holiday already exist";
                        }
                        BindGridView();
                        BtnUpdate.Enabled = false;
                        BtnSave.Enabled = true;
                    }
                    else
                    {
                        Label9.Visible = true;
                        Label9.ForeColor = System.Drawing.Color.Red;
                        Label9.Text = "Please select financial year!";
                    }
                }
                else
                {
                    Label9.Visible = true;
                    Label9.ForeColor = System.Drawing.Color.Red;
                    Label9.Text = "From date must be less than to date!";
                }
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "Unable to process request";
            }
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindGridView();
    }
    protected void SelectHoliDay()
    {
        DateTime fromDate = System.DateTime.Now;
        DateTime toDate = System.DateTime.Now;
        if (txtFromDate1.Text != "" && txtToDate1.Text != "")
        {
            fromDate = Convert.ToDateTime(txtFromDate1.Text);
            toDate = Convert.ToDateTime(txtToDate1.Text);
        }
        DataSet ds = (DataSet)Session["GovtHoliDay"];
        DataTable tbl = ds.Tables[0];
        DataView dv = tbl.DefaultView;

        string st = "";
        if (PanelText.Visible)
        {
            st = "  GHName like '%" + txtboxHolidayName.Text + "%'";//txtboxHolidayName
        }
        else if (PanelDate.Visible)
        {
            st = "FromDate>=" + "'" + fromDate.Date.ToString() + "' and ToDate<='" + toDate.Date.ToString() + "'";
        }

        dv.RowFilter = st;
        DataTable dtzy = dv.ToTable();

        GridView1.DataSource = dtzy;

        if (dtzy.Rows.Count == 0)
        {
            GridView1.EmptyDataText = "No match found for the input.";
            GridView1.DataSource = null;
        }

        GridView1.DataBind();
    }
    protected void BtnSearch_Click1(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            SelectHoliDay();
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void btnDelete_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.GOVTHOLIDAY.ToString(), "D"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxDelete = (CheckBox)oRow.FindControl("chkDelete");

                    if (oCheckBoxDelete.Checked)
                    {
                        HiddenField HidGHNumber1 = (HiddenField)oRow.FindControl("HidGHNumber");

                        HiddenGHNumber.Value = HidGHNumber1.Value;


                        GovtHoliDayDelete();
                    }
                }
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Green;
                Label9.Text = "Data deleted successful.";
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    void SetEditMode(bool set)
    {
        BtnSave.Enabled = !set;
        BtnUpdate.Enabled = set;
    }

    protected void BtnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        //Page_Load(sender, e);
        Response.Redirect("Default.aspx?Page=GovtHoliDayForm");
        SetEditMode(false);
    }


    protected void GovtHoliDayUpdate()
    {
        ProcessGovtHoliDayUpdate update = new ProcessGovtHoliDayUpdate();
        update.Holiday = GetInfoFromUI();
        update.invoke();
    }

    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            DateTime FromDate = Convert.ToDateTime(txtFromdate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                GovtHoliDayUpdate();
                ClearPage();
                BindGridView();
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Green;
                Label9.Text = "Data updated successful.";
                BtnSave.Enabled = true;
                BtnUpdate.Enabled = false;
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void DDLSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DDLSearchBy.SelectedValue.Equals("1"))
        {
            PanelText.Visible = false;
            PanelDate.Visible = true;
        }
        else if (DDLSearchBy.SelectedValue.Equals("0"))
        {
            PanelText.Visible = true;
            PanelDate.Visible = false;
        }
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;

            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");

            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";

            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void txtFromdate_TextChanged1(object sender, EventArgs e)
    {
        if (txtFromdate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromdate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Label9.Visible = false;
                Label9.Text = "";
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "From date must be less than to date!";
            }
        }
    }
    protected void txtToDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromdate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromdate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Label9.Visible = false;
                Label9.Text = "";
            }
            else
            {
                Label9.Visible = true;
                Label9.ForeColor = System.Drawing.Color.Red;
                Label9.Text = "From date must be less than to date!";
            }
        }
    }
}
