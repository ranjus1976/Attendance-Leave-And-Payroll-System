﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_UcEnable : System.Web.UI.UserControl
{
    CommonName objCommonName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEENABLEDISABLE.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadEmpId();
                    loadCompany();
                    EmployeeImage.LoadImageEmp(drpEmpList,tblId, EmpImage);
                    objCommonName = new CommonName();
                    objCommonName.EmployeeTolTip(drpEmpList, drpEmpList.SelectedValue.ToString(), lblEmpname);
                    Session["NotReadPermission"] = null;
                }
                loadEmpId();
                EmployeeImage.LoadImageEmp(drpEmpList, tblId, EmpImage);
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEENABLEDISABLE.ToString(), "C"))
            {
                if (drpEmpList.SelectedIndex != 0)
                {

                    Employee _Emp = new Employee();
                    if (RadioButtonListEnDisable.Items[0].Selected)
                    {
                        _Emp.EmpSts = 1;
                    }
                    else
                    {
                        _Emp.EmpSts = 0;
                    }
                    _Emp.EmpNumber = Convert.ToInt32(drpEmpList.SelectedValue);
                    ProcessEmployeeEnableDisableUpdate peu = new ProcessEmployeeEnableDisableUpdate();
                    peu.EmpUp = _Emp;
                    peu.invoke();
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                    lblErrorMessage.Text = "Data saved successful.";
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    lblErrorMessage.Text = "Please select!";
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    #region Load Combo

    public void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadEmpId()
    {
        int enable;

        if (RadioButtonListEnDisable.Items[0].Selected)
        {
            enable = 0;
        }
        else
        {
            enable = 1;
        }
        try
        {
            drpEmpList.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where tblEmployee.EmpED =" + enable + " and tblCompany.Comp_Number = " + ddlCompany.SelectedValue + " order by EmpId ";
            ClsCommon.drplistAddNew(drpEmpList, strSQL, "EmpId", "Emp_Number");
            drpEmpList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }

    #endregion

    protected void RadioButtonListEnDisable_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmpId();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpEmpList, drpEmpList.SelectedValue.ToString(), lblEmpname);
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmpId();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpEmpList, drpEmpList.SelectedValue.ToString(), lblEmpname);
    }
    protected void drpEmpList_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpEmpList, drpEmpList.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(drpEmpList, tblId, EmpImage);
    }
    protected void drpEmpList_TextChanged(object sender, EventArgs e)
    {
    }
    
}
