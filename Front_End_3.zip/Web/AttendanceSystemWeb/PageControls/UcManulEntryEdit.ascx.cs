﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;

public partial class PageControls_UcManulEntryEdit : System.Web.UI.UserControl
{
    CommonName objCommonName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadCompany();
            loadEmpId();
            objCommonName = new CommonName();
           // objCommonName.EmployeeTolTip(ddlEmpId);
        }

    }

    #region Combo Load
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
        ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
    }
    protected void loadEmpId()
    {
        ddlEmpId.Items.Clear();
        string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + int.Parse(ddlCompany.SelectedValue.ToString()) + " order by empId asc ";
        ClsCommon.drplistAddNew(ddlEmpId, strSQL, "EmpId", "Emp_Number");
        ddlEmpId.Items.Insert(0, new ListItem("Select", "NA"));

    }
    private String CardId()
    {
        String Sql = "Select CardId from tblEmployee where Emp_Number = " + int.Parse(ddlEmpId.SelectedValue.ToString()) + "";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String reader = cmd.ExecuteScalar().ToString();
        return reader;
    }
    private void DataLoad(String CardId)
    {
        if (txtDate.Text != "")
        {
            String PunchDate = Convert.ToDateTime(txtDate.Text).ToString("dd/MMM/yyyy");

            String Sql = "Select CardId,PunchDate,substring(convert(varchar(20),PunchTime,120),12,5) as PunchTime from tblRaw_Data where CardId = '" + CardId + "' and PunchDate = '" + PunchDate + "' order by substring(convert(varchar(20),PunchTime,120),12,5) ";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();
            DataSet ds = new DataSet();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Sql;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                grvLeaveList.DataSource = ds;
                grvLeaveList.DataBind();
            }
            else
            {
                grvLeaveList.DataSource = ds;
                grvLeaveList.DataBind();
            }
        }
    }
    private void ManualEntryDeleteDelete(String CardId, String PunchDate, String PunchTime)
    {
        PunchDate = DateTime.Parse(PunchDate).ToString("dd/MMM/yyyy");
        try
        {
            String Sql = "sp_Manual_Delete";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;

            cmd.Parameters.AddWithValue("@cardId", CardId);
            cmd.Parameters.AddWithValue("@PunchDate", PunchDate);
            cmd.Parameters.AddWithValue("@PunchTime", PunchTime);

            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {

        }
    }
    #endregion

    #region Button

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void txtDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlEmpId.SelectedIndex != 0 && txtDate.Text != "")
        {
            Session["CardId"] = CardId();
            hdnCardId.Value = CardId();
            DataLoad(hdnCardId.Value.ToString());
        }
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            foreach (GridViewRow gr in grvLeaveList.Rows)
            {
                CheckBox _edit = (CheckBox)gr.FindControl("chkEdit");
                if (_edit.Checked)
                {
                    Label lblCardId = (Label)gr.FindControl("lblCardId");
                    Label lblPunchDate = (Label)gr.FindControl("lblPunchDate");
                    Label lblPunchTime = (Label)gr.FindControl("lblPunchTime");

                    Session["CardId"] = lblCardId.Text;
                    Session["PunchDate"] = lblPunchDate.Text;
                    Session["PunchTime"] = lblPunchTime.Text;
                    Session["EmpId"] = ddlEmpId.SelectedValue.ToString();
                    Session["ManualEdit"] = "ManulaEdit";

                    Response.Redirect("Default.aspx?Page=CompanyManualEntry");
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            foreach (GridViewRow gr in grvLeaveList.Rows)
            {
                CheckBox del = (CheckBox)gr.FindControl("chkDel");
                if (del.Checked)
                {
                    try
                    {
                        Label lblCardId = (Label)gr.FindControl("lblCardId");
                        Label lblPunchDate = (Label)gr.FindControl("lblPunchDate");
                        Label lblPunchTime = (Label)gr.FindControl("lblPunchTime");

                        ManualEntryDeleteDelete(lblCardId.Text, lblPunchDate.Text, lblPunchTime.Text);
                        DataLoad(lblCardId.Text);
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                        lblMessage.Text = "Data deleted successful.";
                    }
                    catch (Exception ex)
                    {
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = ex.Message.ToString();
                    }
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void ddlEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlEmpId.SelectedIndex != 0 && txtDate.Text != "")
        {
            Session["CardId"] = CardId();
            hdnCardId.Value = CardId();
            DataLoad(hdnCardId.Value.ToString());
        }
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmpId();
        objCommonName = new CommonName();
      //  objCommonName.EmployeeTolTip(ddlEmpId);
    }

    #endregion

    protected void grvLeaveList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hdnCardId0.Value = hdnCardId0.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hdnCardId0.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hdnCardId0.Value = hdnCardId0.Value.TrimStart(',');
        }
    }
}
