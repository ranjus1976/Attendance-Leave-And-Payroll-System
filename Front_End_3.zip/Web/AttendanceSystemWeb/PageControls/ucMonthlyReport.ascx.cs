﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.IO;

public partial class PageControls_ucMonthlyReport : System.Web.UI.UserControl
{
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.MONTHLYREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    deptDropDownList.Enabled = false;
                    empIdDropDownList.Enabled = false;
                    loadCompany();
                    EmployeeImage.LoadImageEmp(empIdDropDownList, tblId, EmpImage);
                    String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtFromDate.Text = ReportDateShow;
                    txtToDate.Text = ReportDateShow;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Combo Load

    public void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(drpCompanylist, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {
        try
        {

            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCompanylist.SelectedValue + " ";
            ClsCommon.drplistAdd(deptDropDownList, strSQL, "DeptName", "Dept_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    protected void LoadEmployeeList()
    {
        try
        {
            empIdDropDownList.Items.Clear();
            string strSQL = "select EmpId,Emp_Number from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where  EmpED = 1 and tblCompany.Comp_Number = " + drpCompanylist.SelectedValue + " and EmpEd=1 order by empId asc ";
            ClsCommon.drplistAddNew(empIdDropDownList, strSQL, "EmpId", "Emp_Number");
            empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region Private Methods

    private ArrayList GetOption()
    {
        CommonName objCommonName = new CommonName();

        if (RadioButtonAll.Checked)
        {
            OptionArralist = objCommonName.GetOption("ALL", drpCompanylist);
        }
        else if (RadioButtonDepartment.Checked)
        {
            OptionArralist = objCommonName.GetOption("Dept", deptDropDownList);
        }
        else
        {
            OptionArralist = objCommonName.GetOption("Emp", empIdDropDownList);
        }
        return OptionArralist;
    }

    #endregion

    #region Report Generation
    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["ReportName"] = "rptMonthlyPresent.rpt";
                Session["TableName"] = "dsMonthlyPresentDays";
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnMonthlyAbsent_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;
                Session["ReportName"] = "rptMonthlyAbsentDays.rpt";
                Session["TableName"] = "dsMonthlyAbsent";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnMonylyLate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["ReportName"] = "rptMonthlyLateDays.rpt";
                Session["TableName"] = "dsMonthlyLate";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnMonthlyOTHour_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;
                Session["ReportName"] = "rptMonthlyOvertime.rpt";
                Session["TableName"] = "dsMonthlyOTHour";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnAttendence_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;
                Session["ReportName"] = "rptMonthlyAttendence.rpt";
                Session["TableName"] = "dsMonthlyAttendence";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnSummary_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = txtFromDate.Text;
                Session["ToDate"] = txtToDate.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;
                Session["ReportName"] = "rptMonthlySummaryReport.rpt";
                Session["TableName"] = "dsMonthlySummary";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    #endregion

    protected void Page_Error(object sender, EventArgs e)
    {
        Exception oec = Server.GetLastError();
        String fgVariable = oec.Message + "\n" + oec.StackTrace.ToString();
        Response.Write(fgVariable);
    }
    protected override void OnError(EventArgs e)
    {
        Exception oec = Server.GetLastError();
        String fgVariable = oec.Message + "\n" + oec.StackTrace.ToString();
        Response.Write(fgVariable);

    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = false;
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = true;
        empIdDropDownList.Enabled = false;
        loadDepartment();
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = true;
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(empIdDropDownList, empIdDropDownList.SelectedValue.ToString(), lblEmpname);
    }
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                lblDateError.Visible = true;
                lblDateError.Text = "";
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.ForeColor = System.Drawing.Color.Red;
                lblDateError.Text = "From date must be less than to date!";
            }
        }

    }
    protected void txtToDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                lblDateError.Visible = true;
                lblDateError.Text = "";
            }
            else
            {
                lblDateError.Visible = true;
                lblDateError.Text = "From date must be less than to date!";
            }
        }

    }
    protected void empIdDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(empIdDropDownList, empIdDropDownList.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(empIdDropDownList, tblId, EmpImage);
    }
    protected void drpCompanylist_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(empIdDropDownList, empIdDropDownList.SelectedValue.ToString(), lblEmpname);
    }
}
