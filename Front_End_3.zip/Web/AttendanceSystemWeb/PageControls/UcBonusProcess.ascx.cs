﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;
public partial class PageControls_UcBonusProcess : System.Web.UI.UserControl
{
    public string name = null;
    DataTable dt;
    String Date = System.DateTime.Now.ToString();
    String ReportDateShow = "";
    CommonName objCommonName = new CommonName();
    Int32 CompId = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYPROCESS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    CompId = int.Parse(CompDropDownList.SelectedValue.ToString());
                    DeptList(CompId);
                    EmployeeList(CompId);
                    objCommonName.Addmonth(drpMonth);
                    RadioButtonAll.Checked = true;
                    RadioButtonComp.Checked = false;
                    RadioButtonDepartment.Checked = false;
                    RadioButtonEmpId.Checked = false;
                    CompDropDownList.Enabled = false;
                    deptDropDownList.Enabled = false;
                    empIdDropDownList.Enabled = false;
                    LoadYear();

                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }
    private void LoadYear()
    {
        drpYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpYear.DataSource = li;
        drpYear.Items.AddRange(items.ToArray());
    }
    protected void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(CompDropDownList, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    public void DeptList(Int32 CompId)
    {
        try
        {
            string strSQL = "select DeptName,Dept_Number from  tblDepartment where comp_number = " + CompId + "   order by DeptName asc";
            ClsCommon.drplistAdd(deptDropDownList, strSQL, "DeptName", "Dept_Number");
            deptDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    public void EmployeeList(Int32 CompId)
    {
        try
        {
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + CompId + " order by empId asc ";
            ClsCommon.drplistAdd(empIdDropDownList, strSQL, "EmpId", "Emp_Number");
            empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected void deptDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            CompId = int.Parse(CompDropDownList.SelectedValue.ToString());
            //DeptList(CompId);
            EmployeeList(CompId);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void empIdDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblEmpname.Text = objCommonName.EmployeeName(empIdDropDownList.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
    }
    protected void btnCancel_Click(object sender, System.EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {

        if (RadioButtonDepartment.Checked)
        {
            RadioButtonAll.Checked = false;
            RadioButtonComp.Checked = false;
            RadioButtonDepartment.Checked = true;
            RadioButtonEmpId.Checked = false;
            CompDropDownList.Enabled = false;
            deptDropDownList.Enabled = true;
            empIdDropDownList.Enabled = false;
            empIdDropDownList.SelectedItem.Text = "Select";
            lblEmpname.Text = "";
        }
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButtonEmpId.Checked)
        {
            RadioButtonAll.Checked = false;
            RadioButtonComp.Checked = false;
            RadioButtonDepartment.Checked = false;
            RadioButtonEmpId.Checked = true;
            CompDropDownList.Enabled = false;
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = true;
        }
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        if (RadioButtonAll.Checked)
        {
            RadioButtonAll.Checked = true;
            RadioButtonComp.Checked = false;
            RadioButtonDepartment.Checked = false;
            RadioButtonEmpId.Checked = false;
            CompDropDownList.Enabled = false;
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = true;
            deptDropDownList.SelectedItem.Text = "Select";
            empIdDropDownList.SelectedItem.Text = "Select";
            lblEmpname.Text = "";
        }
    }
    protected void btnProcess_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            String Sql = "sp_IncreamentCheck";
            SqlConnection con = new SqlConnection();
            ReportData objReportData = new ReportData();
            DataSet ds = new DataSet();
            con = objReportData.GetDBConn();
            con.Open();
            SqlCommand cmd = new SqlCommand(Sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;
            cmd.Parameters.AddWithValue("@PageSelect", "SalaryProcsee");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count != 0)
            {
                if (Validate())
                {
                    try
                    {
                        SalaryProcess objSalaryProcess = new SalaryProcess();
                        //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                        if (RadioButtonAll.Checked)
                        {
                            objSalaryProcess.Critaria = 1;
                            objSalaryProcess.Company = "";
                            objSalaryProcess.DeptId = "";
                            objSalaryProcess.EmployeeId = "";
                            objSalaryProcess.MonthName = drpMonth.SelectedItem.Text;
                            objSalaryProcess.Bname = TextBoxBname.Text;
                            objSalaryProcess.MontnNumber = drpMonth.SelectedValue.ToString();
                            objSalaryProcess.YearName = drpYear.SelectedItem.Text;
                            objSalaryProcess.Rate = int.Parse(TextBRate.Text);
                            objSalaryProcess.User = Session["Username"].ToString();
                        }
                        else if (RadioButtonComp.Checked)
                        {
                            objSalaryProcess.Critaria = 2;
                            objSalaryProcess.Company = CompDropDownList.SelectedValue.ToString();
                            objSalaryProcess.DeptId = "";
                            objSalaryProcess.EmployeeId = "";
                            objSalaryProcess.MonthName = drpMonth.SelectedItem.Text;
                            objSalaryProcess.Bname = TextBoxBname.Text;
                            objSalaryProcess.MontnNumber = drpMonth.SelectedValue.ToString();
                            objSalaryProcess.YearName = drpYear.SelectedItem.Text;
                            objSalaryProcess.Rate = int.Parse(TextBRate.Text);
                            objSalaryProcess.User =Session["Username"].ToString();
                        }
                        else if (RadioButtonDepartment.Checked)
                        {
                            objSalaryProcess.Critaria = 3;
                            objSalaryProcess.Company = CompDropDownList.SelectedValue.ToString();
                            objSalaryProcess.DeptId = deptDropDownList.SelectedValue.ToString();
                            objSalaryProcess.EmployeeId = "";
                            objSalaryProcess.MonthName = drpMonth.SelectedItem.Text;
                            objSalaryProcess.Bname = TextBoxBname.Text;
                            objSalaryProcess.MontnNumber = drpMonth.SelectedValue.ToString();
                            objSalaryProcess.YearName = drpYear.SelectedItem.Text;
                            objSalaryProcess.Rate = int.Parse(TextBRate.Text);
                            objSalaryProcess.User = Session["Username"].ToString();
                        }
                        else
                        {
                            objSalaryProcess.Critaria = 4;
                            objSalaryProcess.Company = CompDropDownList.SelectedValue.ToString();
                            objSalaryProcess.DeptId = deptDropDownList.SelectedValue.ToString();
                            objSalaryProcess.EmployeeId = empIdDropDownList.SelectedItem.Text;
                            objSalaryProcess.Bname = TextBoxBname.Text;
                            objSalaryProcess.MonthName = drpMonth.SelectedItem.Text;
                            objSalaryProcess.MontnNumber = drpMonth.SelectedValue.ToString();
                            objSalaryProcess.YearName = drpYear.SelectedItem.Text;
                            objSalaryProcess.Rate = int.Parse(TextBRate.Text);
                            objSalaryProcess.User = Session["Username"].ToString();
                        }
                        BonusProcessInsert eprocess = new BonusProcessInsert();
                        eprocess.SalaryProcessObj = objSalaryProcess;
                        eprocess.ProcessData();
                        if (ReturningValue.rtnValue == 1)
                        {
                            objCommonName.LabelMessageandColor(LabelSalary, "Bonus Process Succesfully Done",
                                                               System.Drawing.Color.Green);
                        }
                        else
                        {
                            objCommonName.LabelMessageandColor(LabelSalary, "An Error Occured During Process".ToString(),
                                                               System.Drawing.Color.Red);
                        }
                    }
                    catch (Exception ex)
                    {
                        objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
                    }
                }
            }
            else
            {
                Response.Redirect("Welcomepage.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private bool Validate()
    {
        bool retVal = true;
        if (RadioButtonAll.Checked)
        {
            retVal = true;
        }
        if (deptDropDownList.SelectedItem.Text == "Select" && RadioButtonDepartment.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Department".ToString(), System.Drawing.Color.Red);
        }
        if (empIdDropDownList.SelectedItem.Text == "Select" && RadioButtonEmpId.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Employee".ToString(), System.Drawing.Color.Red);
        }

        if (drpYear.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Year".ToString(), System.Drawing.Color.Red);
        }
        if (drpMonth.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Month".ToString(), System.Drawing.Color.Red);
        }
        if (TextBoxBname.Text == "")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Bonus Name".ToString(), System.Drawing.Color.Red);
        }
        return retVal;
    }

    protected void CompDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            CompId = int.Parse(CompDropDownList.SelectedValue.ToString());
            DeptList(CompId);
            EmployeeList(CompId);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void RadioButtonComp_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButtonComp.Checked)
        {
            RadioButtonAll.Checked = false;
            RadioButtonComp.Checked = true;
            RadioButtonDepartment.Checked = false;
            RadioButtonEmpId.Checked = false;
            CompDropDownList.Enabled = true;
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = false;
            deptDropDownList.SelectedItem.Text = "Select";
            empIdDropDownList.SelectedItem.Text = "Select";
            lblEmpname.Text = "";
        }
    }
}
