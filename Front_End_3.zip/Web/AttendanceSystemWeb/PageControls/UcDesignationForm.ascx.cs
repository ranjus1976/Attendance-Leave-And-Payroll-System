﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Role;
using AttendanceSystem.Dal.Report;


public partial class PageControls_DesignationForm : System.Web.UI.UserControl
{
    #region Declaration

    Int32 CompId = 0;
    CommonName objCommonName = new CommonName();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        SetEditMode(false);
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DESIGNATIONSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    ListItem itmDesigId = new ListItem("Designation ID", "0");
                    ListItem itmDesigName = new ListItem("Designation Name", "1");
                    ListItem itmGrade = new ListItem("Grade", "2");
                    ListItem itmPriority = new ListItem("Priority", "3");

                    DDLSearchBy.Items.Add("Select");
                    DDLSearchBy.Items.Add(itmDesigId);
                    DDLSearchBy.Items.Add(itmDesigName);

                    loadItem();

                    CompId = Int32.Parse(drplist.SelectedValue.ToString());
                    BindGridView(CompId);

                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    protected void deleteDesignation(string delID)
    {
        try
        {
            int ID = Convert.ToInt32(delID);
            Designation desig = new Designation();
            desig.DesigNumber = ID;
            ProcessDesignationDelete p = new ProcessDesignationDelete();
            p.Desig = desig;
            p.invoke();
            drplist.Enabled = true;
            objCommonName.LabelMessageandColor(Label5, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    void SetEditMode(bool set)
    {
        BtnUpdate.Enabled = set;
        BtnSave.Enabled = !set;
    }
    void LoadForEdit()
    {
        try
        {
            string desigNumber = Request.QueryString["Desig_Number"];
            string ID = Request.QueryString["ID"];
            Session["DesigId"] = ID;

            string desigName = Request.QueryString["Name"];
            string grade = Request.QueryString["Grade"];
            string priority = Request.QueryString["Priority"];

            TextBoxDesignationId.Text = ID;
            TextBoxDesigName.Text = desigName;
            TextBoxGrade.Text = grade;
            TextBoxPriority.Text = priority;
            hiddenDesigNumber.Value = desigNumber;
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void loadItem()
    {
        try
        {
            string strSQL = "Select Comp_Number,CompName,CompId from tblCompany ";
            ClsCommon.drplistAdd(drplist, strSQL, "CompName", "Comp_Number");
            // drplist.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void AddDesignation()
    {
        Designation designation = new Designation();
        try
        {
            string query = " select * from tblDesignation where DesigId = " + TextBoxDesignationId.Text;

            designation.Company = int.Parse(drplist.SelectedValue);
            designation.DesigId = TextBoxDesignationId.Text;
            designation.DesigName = TextBoxDesigName.Text;
            designation.Grade = TextBoxGrade.Text;

            if (TextBoxPriority.Text == "")
                designation.Priority = 0;
            else
                designation.Priority = Convert.ToInt32(TextBoxPriority.Text);

            designation.Entryby = 1;
            designation.PC = System.Net.Dns.GetHostName();
            designation.Entrydate = DateTime.Now;
            ProcessDesignationInsert pds = new ProcessDesignationInsert();
            pds.Desig = designation;
            pds.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private bool isValidData()
    {
        if ((TextBoxDesigName.Text.Trim().Equals("")) || (TextBoxDesignationId.Text.Trim().Equals("")))
        {
            objCommonName.LabelMessageandColor(Label5, "Designation " + objCommonName.IdorNameRequired, System.Drawing.Color.Red);
            TextBoxDesigName.Focus();
            TextBoxDesignationId.Focus();
            return false;
        }
        else if (TextBoxPriority.Text.Trim().Equals(""))
        {
            objCommonName.LabelMessageandColor(Label5, "Priority required.", System.Drawing.Color.Red);
            TextBoxPriority.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    protected void clearall()
    {
        //drplist.SelectedIndex = 0;
        TextBoxDesignationId.Text = "";
        TextBoxDesigName.Text = "";
        TextBoxGrade.Text = "";
        TextBoxPriority.Text = "";

    }
    protected void BindGridView(Int32 CompId)
    {
        try
        {
            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            String Sql = "sp_Designation_SelectAll";
            ReportData objReportData = new ReportData();
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            DataSet ds = new DataSet();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;
            cmd.Parameters.AddWithValue("@CompId", CompId);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["AllDesignation"] = ds;
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
                Session["AllDesignation"] = ds;
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    #endregion

    #region Methods

    private void UpdateDesig()
    {
        try
        {
            Designation desig = new Designation();
            desig.DesigNumber = Convert.ToInt32(hiddenDesigNumber.Value);
            desig.Company = int.Parse(drplist.SelectedValue);
            desig.DesigId = TextBoxDesignationId.Text;
            desig.DesigName = TextBoxDesigName.Text;
            desig.Grade = TextBoxGrade.Text;
            desig.Priority = Convert.ToInt32(TextBoxPriority.Text);
            ProcessDesignationUpdate pdgu = new ProcessDesignationUpdate();
            pdgu.Desig = desig;
            pdgu.invoke();
            objCommonName.LabelMessageandColor(Label5, objCommonName.SavedMessage, System.Drawing.Color.Green);
            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            BindGridView(CompId);
            clearall();
            drplist.Enabled = true;
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private Int32 RentValue(String DesigId)
    {
        String Sql = "";
        Int32 reader = 0;
        try
        {
            Sql = Sql + "select count(*) from tblDesignation where DesigId = '" + DesigId + "' AND Comp_number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
            SqlConnection objReturnedConn;
            SqlCommand comdd = new SqlCommand();
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            objReturnedConn.Open();
            comdd.Connection = objReturnedConn;
            comdd.CommandType = CommandType.Text;
            comdd.CommandText = Sql;
            reader = Convert.ToInt32(comdd.ExecuteScalar());
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return reader;
    }

    #endregion

    #region Button Handlers

    protected void btnEdit_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DESIGNATIONSETUP.ToString(), "U"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oChkBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
                    if (oChkBoxEdit.Checked)
                    {
                        hiddenDesigNumber.Value = ((HiddenField)oRow.FindControl("HidDesig_Number")).Value;
                        HiddenField HidenCompId = (HiddenField)oRow.FindControl("HiddenCompId");
                        HiddenField HidDesigId1 = (HiddenField)oRow.FindControl("HidDesigId");
                        HiddenField HidDesigName1 = (HiddenField)oRow.FindControl("HidDesigName");
                        HiddenField HidGrade1 = (HiddenField)oRow.FindControl("HidGrade");
                        HiddenField HidPriority1 = (HiddenField)oRow.FindControl("HidPriority");

                        drplist.SelectedValue = HidenCompId.Value;
                        TextBoxDesignationId.Text = HidDesigId1.Value;
                        Session["DesigId"] = HidDesigId1.Value;
                        TextBoxDesigName.Text = HidDesigName1.Value;
                        TextBoxGrade.Text = HidGrade1.Value;
                        TextBoxPriority.Text = HidPriority1.Value;

                        SetEditMode(true);
                        drplist.Enabled = false;
                    }
                }
                Label5.Visible = false;
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDelete_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DESIGNATIONSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oChkBoxDelete = (CheckBox)oRow.FindControl("chkDelete");

                    if (oChkBoxDelete.Checked)
                    {
                        hiddenDesigNumber.Value = ((HiddenField)oRow.FindControl("HidDesig_Number")).Value;
                        deleteDesignation(hiddenDesigNumber.Value);
                    }
                }

                CompId = Int32.Parse(drplist.SelectedValue.ToString());
                BindGridView(CompId);
                Label5.Visible = false;
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void BtnSelect_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            BindGridView(CompId);

        }
        else
            Response.Redirect("login.aspx");
    }
    protected void Delete_Click(object sender, EventArgs e)
    {
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DESIGNATIONSETUP.ToString(), "C"))
            {
                string strSql = "SELECT * FROM tblDesignation WHERE DesigId = '" + TextBoxDesignationId.Text + "' and Comp_Number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
                string strSql1 = "SELECT * FROM tblDesignation WHERE DesigName = '" + TextBoxDesigName.Text + "' and Comp_Number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
                if (!ClsCommon.ItemCheck(strSql))
                {
                    if (!ClsCommon.ItemCheck(strSql1))
                    {
                        if (isValidData())
                        {
                            AddDesignation();
                            Label5.Visible = true;
                            Label5.ForeColor = System.Drawing.Color.Green;
                            Label5.Text = "Data saved successful.";
                            clearall();
                            CompId = Int32.Parse(drplist.SelectedValue.ToString());
                            BindGridView(CompId);
                        }
                    }
                    else
                    {
                        Label5.Visible = true;
                        Label5.ForeColor = System.Drawing.Color.Red;
                        Label5.Text = "This name already exist";
                    }
                }
                else
                {
                    Label5.Visible = true;
                    Label5.ForeColor = System.Drawing.Color.Red;
                    Label5.Text = "This id already exist";
                }

                CompId = Int32.Parse(drplist.SelectedValue.ToString());
                BindGridView(CompId);
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        CompId = Int32.Parse(drplist.SelectedValue.ToString());
        GridView1.PageIndex = e.NewPageIndex;
        BindGridView(CompId);
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        String Sql = "";
        if (txtbox.Text.Trim() != "" && DDLSearchBy.SelectedIndex != 0)
        {
            try
            {
                if (DDLSearchBy.SelectedIndex == 1)
                {
                    Sql = "select * from tblDesignation where DesigId Like '%" + txtbox.Text.ToString() + "%' and Comp_Number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
                }
                else if (DDLSearchBy.SelectedIndex == 2)
                {
                    Sql = "select * from tblDesignation where DesigName like '%" + txtbox.Text.ToString() + "%' and Comp_Number = " + int.Parse(drplist.SelectedValue.ToString()) + " ";
                }
                ClsCommon.GetAdhocResult(Sql);
                DataSet ds = new DataSet();
                ds = ClsCommon.GetAdhocResult(Sql);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                    Label5.Visible = false;
                    Label5.Text = "";
                }
                else
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                    Label5.Visible = true;
                    Label5.ForeColor = System.Drawing.Color.Red;
                    Label5.Text = "Search item not found";
                }
            }
            catch (Exception ex)
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = ex.Message.ToString();
            }
        }
        else
        {
            Label5.Visible = true;
            Label5.ForeColor = System.Drawing.Color.Red;
            Label5.Text = "Enter search item.";
        }

    }
    protected void BtnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            String DesigId = TextBoxDesignationId.Text.ToString();
            String DesigId1 = Session["DesigId"].ToString();

            if (DesigId == DesigId1)
            {
                UpdateDesig();
            }
            else
            {
                if (RentValue(DesigId) == 0)
                {
                    string val = hiddenDesigNumber.Value;
                    UpdateDesig();
                }
                else
                {
                    Label5.Visible = true;
                    Label5.ForeColor = System.Drawing.Color.Red;
                    Label5.Text = "Id already used";
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void TextBoxGrade_TextChanged(object sender, EventArgs e)
    {

    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx?Page=DesignationForm");
    }
    protected void DDLSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;


            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");

            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";

            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');

        }
    }
    protected void drplist_SelectedIndexChanged(object sender, EventArgs e)
    {

        CompId = Int32.Parse(drplist.SelectedValue.ToString());
        BindGridView(CompId);

    }

    #endregion
}
