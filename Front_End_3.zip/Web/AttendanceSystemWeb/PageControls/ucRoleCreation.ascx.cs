﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;

public partial class PageControls_ucRoleCreation : System.Web.UI.UserControl
{
    Role obj_Role;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["LogIn"] != null)
            {
                ShowRole();
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;
            }
            else
                Response.Redirect("login.aspx");
        }
    }

    #region Private Methods
    protected void ShowRole()
    {
        try
        {
            ProcessRoleDataSelect obj_ProcessRoleDataSelect = new ProcessRoleDataSelect();
            obj_ProcessRoleDataSelect.invoke();
            hidEditCheckedIDS.Value = "";
            Session["RoleDS"] = obj_ProcessRoleDataSelect.RoleDS.Tables[0];
            gvwUser.DataSource = obj_ProcessRoleDataSelect.RoleDS.Tables[0];
            gvwUser.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    public void AddRole()
    {
        obj_Role = new Role();
        obj_Role.RoleName = txtRoleName.Text.Trim();
        obj_Role.AspRole = "AspRole";
        obj_Role.Mode = "Edit";
        obj_Role.User = Session["Username"].ToString(); 
        obj_Role.EntryBy = "1";
        obj_Role.EntryDate = Convert.ToDateTime(System.DateTime.Today);
        obj_Role.PC = System.Net.Dns.GetHostName().ToString();

        ProcessRoleDataInsert obj_ProcessRoleDataInsert = new ProcessRoleDataInsert();
        obj_ProcessRoleDataInsert.Role = obj_Role;
        obj_ProcessRoleDataInsert.invoke();
    }
    private bool isValidData()
    {
        if (txtRoleName.Text.Trim().Equals(""))
        {
            lblRoleCreation.Visible = true;
            lblRoleCreation.Text = "Role Name Required.";
            txtRoleName.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    public void RoleUpdate()
    {
        obj_Role = new Role();
        obj_Role.RoleNumber = Convert.ToInt32(hidEditCheckedIDS.Value);
        obj_Role.RoleName = txtRoleName.Text.Trim();
        obj_Role.AspRole = "AspRole";
        obj_Role.Mode = "Edit";
        obj_Role.User = "Bablu";
        obj_Role.EntryBy = "1";
        obj_Role.EntryDate = Convert.ToDateTime(System.DateTime.Today);
        obj_Role.PC = System.Net.Dns.GetHostName().ToString();

        ProcessRoleDataUpdate obj_ProcessRoleDataUpdate = new ProcessRoleDataUpdate();
        obj_ProcessRoleDataUpdate.Role = obj_Role;
        obj_ProcessRoleDataUpdate.invoke();
        hidEditCheckedIDS.Value = "";
        clearall();

    }
    protected void DeleteRole(string id)
    {
        obj_Role = new Role();

        obj_Role.RoleNumber = Convert.ToInt32(hidEditCheckedIDS.Value);
        ProcessRoleDataDelete obj_ProcessRoleDataDelete = new ProcessRoleDataDelete();
        obj_ProcessRoleDataDelete.Role = obj_Role;
        obj_ProcessRoleDataDelete.invoke();
        hidEditCheckedIDS.Value = "";
        ShowRole();
        
    }
    private void loadRole(string id)
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["RoleDS"];
        foreach (DataRow dr in dt.Rows)
        {
            if (dr[0].ToString() == id)
            {
                txtRoleName.Text = dr[1].ToString();
            }
        }
    }
    protected void loadFormGrid()
    {

        foreach (GridViewRow oRow in gvwUser.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("userUpdateCheckBox");

            if (oCheckBoxEdit.Checked)
            {

                HiddenField hdnRoleINumber = (HiddenField)oRow.FindControl("HidEditUser_Number");
                hidEditCheckedIDS.Value = hdnRoleINumber.Value;
                loadRole(hdnRoleINumber.Value);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }
        }
    }
    private void clearall()
    {
        txtRoleName.Text = "";
    }
    #endregion
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ROLECREAION.ToString(), "C"))
            {
                string strSql = "Select Role_Name From tlbRole Where Role_Name='" + txtRoleName.Text.Trim() + "'";
                if (!ClsCommon.ItemCheck(strSql))
                {
                    if (isValidData())
                    {
                        AddRole();
                        lblRoleCreation.Visible = true;
                        lblRoleCreation.ForeColor = System.Drawing.Color.Green;
                        lblRoleCreation.Text = "Data Saved Successful.";
                        clearall();
                        ShowRole();
                        btnSave.Enabled = true;
                        btnUpdate.Enabled = false;
                    }
                }
                else
                {
                    lblRoleCreation.Visible = true;
                    lblRoleCreation.ForeColor = System.Drawing.Color.Red;
                    lblRoleCreation.Text = "This Name Already Exist";
                }
            }
            else
            {
                lblRoleCreation.Visible = true;
                lblRoleCreation.ForeColor = System.Drawing.Color.Red;
                lblRoleCreation.Text = "Unable to Process Request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            RoleUpdate();
            lblRoleCreation.Visible = true;
            lblRoleCreation.ForeColor = System.Drawing.Color.Green;
            lblRoleCreation.Text = "Data Updated Successful.";
            clearall();
            ShowRole();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnEditChkUser_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ROLECREAION.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
            {
                lblRoleCreation.Visible = true;
                lblRoleCreation.ForeColor = System.Drawing.Color.Red;
                lblRoleCreation.Text = "Unable to Process Request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDelChkUser_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ROLECREAION.ToString(), "D"))
            {
                foreach (GridViewRow oRow in gvwUser.Rows)
                {
                    CheckBox oCheckBoxDelete = (CheckBox)oRow.FindControl("userDeleteCheckBox");

                    if (oCheckBoxDelete.Checked)
                    {

                        HiddenField hRoleId = (HiddenField)oRow.FindControl("HidDelUser_Number");

                        hidEditCheckedIDS.Value = hRoleId.Value;
                        DeleteRole(hRoleId.Value);
                    }
                }
                lblRoleCreation.Visible = true;
                lblRoleCreation.ForeColor = System.Drawing.Color.Green;
                lblRoleCreation.Text = "Data Deleted Successful.";
            }
            else
            {
                lblRoleCreation.Visible = true;
                lblRoleCreation.ForeColor = System.Drawing.Color.Red;
                lblRoleCreation.Text = "Unable to Process Request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
}
