﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.IO;

public partial class PageControls_UcEmpConfirmationDate : System.Web.UI.UserControl
{
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CONFIRMATIONDATE.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    drpDept.Enabled = false;
                    drpId.Enabled = false;
                    String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtFromDate.Text = ReportDateShow;
                    txtToDate.Text = ReportDateShow;
                    EmployeeImage.LoadImageEmp(drpId, tblId, EmpImage);
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.apsx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Combo Load

    public void loadCompany()
    {
        string strSQL = "";
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                strSQL = "Select Comp_Number, CompName from tblCOmpany ";
                ClsCommon.drplistAdd(drpCompany, strSQL, "CompName", "Comp_Number");
            }
            else
            {
                strSQL = "select TC.Comp_Number as Comp_Number,CompName ";
                strSQL = strSQL + "from tblSection TS inner join ";
                strSQL = strSQL + "tblDepartment TD on TS.Dept_Number = TD.Dept_Number inner join ";
                strSQL = strSQL + "tblCompany TC on TC.Comp_Number = TD.Comp_Number inner join ";
                strSQL = strSQL + "tblEmployee TE on TE.Sect_Number = TS.Sect_Number ";
                strSQL = strSQL + "where TE.Emp_Number = " + Convert.ToInt32(Session["User_Number"].ToString()) + "";
                ClsCommon.drplistAdd(drpCompany, strSQL, "CompName", "Comp_Number");
            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {
        try
        {
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCompany.SelectedValue + " ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void LoadEmployeeList()
    {
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + drpCompany.SelectedValue + " order by empId asc ";
                ClsCommon.drplistAddNew(drpId, strSQL, "EmpId", "Emp_Number");
                drpId.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and Emp_Number = " + Convert.ToInt32(Session["User_Number"].ToString()) + " and tblCompany.Comp_Number = " + drpCompany.SelectedValue + " order by empId asc ";
                ClsCommon.drplistAddNew(drpId, strSQL, "EmpId", "Emp_Number");
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    #endregion

    #region Private Methods

    private ArrayList GetOption()
    {
        CommonName objCommonName = new CommonName();

        if (RadioButtonAll.Checked)
        {
            OptionArralist = objCommonName.GetOption("ALL", drpCompany);
        }
        else if (RadioButtonDepartment.Checked)
        {
            OptionArralist = objCommonName.GetOption("Dept", drpDept);
        }
        else
        {
            OptionArralist = objCommonName.GetOption("Emp", drpId);
        }
        return OptionArralist;
    }

    #endregion

    #region Button Handlers

    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            // Report All Session Clear///////////////////////////////////////

            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;

            //End

            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                Session["FromDate"] = FromDate;
                Session["ToDate"] = ToDate;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["ReportName"] = "rptEmployeeConfDate.rpt";
                Session["TableName"] = "dsEmployeeNewInformation";
                Session["CompanyName"] = drpCompany.SelectedItem.Text.ToString();
                Session["Company_Number"] = drpCompany.SelectedValue;

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    #endregion

    #region Radio Button Halders

    protected void drpCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
    }
    protected void RadioButtonAll_CheckedChanged(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpId.Enabled = false;
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        drpDept.Enabled = true;
        drpId.Enabled = false;
        loadDepartment();
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpId.Enabled = true;
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
    }
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                lblMessage.Visible = false;
                lblMessage.Text = "";
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.Text = "From date must be less than to date!";
            }
        }
    }
    protected void txtToDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && txtToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                lblMessage.Visible = false;
                lblMessage.Text = "";
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.Text = "From date must be less than to date!";
            }
        }
    }
    protected void drpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(drpId, tblId, EmpImage);
    }
   
    #endregion
}
