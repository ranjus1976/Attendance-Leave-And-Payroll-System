﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Insert;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;


public partial class PageControls_UcFinantialYear : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    private string action = "";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            showGridView();
            Session["FinId"] = "0";
        }
    }
    protected void mbBilAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbBilAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }

    }
    protected void mbBilAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string strSql = "SELECT Financial_Year FROM tblFinancial_Year where Financial_Year = '" + EmpNameTxtBox .Text.Trim()+ "'";
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.FINSETUP.ToString(), "C"))
            {
                if (!ClsCommon.ItemCheck(strSql))
                {
                    action = "save";
                    Add("0");
                    objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                    showGridView();
                    action = "";

                }
                else
                    objCommonName.LabelMessageandColor(labelMbAdj,"Data "+ objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
            }
            else
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void showGridView()
    {
        string searchStr = "SELECT Financial_Year,convert(varchar,Opening_Date,103) as Opening_Date,convert(varchar,Closing_Date,103) as Closing_Date,(CASE WHEN Running_Flag=0 THEN 'False' ELSE 'True' END) as Running_Flag FROM tblFinancial_Year order by Financial_Year DESC";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        mbBilAdGridView.DataSource = dsMonthDeduct.Tables[0];
        mbBilAdGridView.DataBind();
    }

    private void Add(string id)
    {
        FinantialYear objFinantialYear = new FinantialYear();
        objFinantialYear.FinYear = EmpNameTxtBox.Text;
        objFinantialYear.OpeningDate = Convert.ToDateTime(dptFromDate.Text);
        objFinantialYear.ClosingDate = Convert.ToDateTime(dtpToDate.Text);
        if(chkActive.Checked==true)
        {
            objFinantialYear.ActiveBit = true;
        }
            else
        {
            objFinantialYear.ActiveBit = false;
        }
        objFinantialYear.Action = action;
        objFinantialYear.FinYearId = int.Parse(id);
        FinancialYearInsertData objFinancialYearInsertData=new FinancialYearInsertData();
        objFinancialYearInsertData.FinancialYear = objFinantialYear;
        objFinancialYearInsertData.AddFinancialYear();
        Session["FinId"] = "0";

    }


    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
       /* string strSQL = "Select Financial_Year_Number from tblFinancial_Year where Financial_Year= '" + EmpNameTxtBox.Text.Trim() + "'";
        DataSet ds = new DataSet();
        ds = ClsCommon.GetAdhocResult(strSQL);*/
       
            Add(Session["FinId"].ToString());
            objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UpdateMessage.ToString(),System.Drawing.Color.Green);
            action = "";
            Session["FinId"] = "0";
            showGridView();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
        
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        EmpNameTxtBox.Text = "";
        dtpToDate.Text = "";
        dptFromDate.Text = "";
        chkActive.Checked = false;
        btnUpdate.Enabled = false;
        btnSave.Enabled = true;

    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            FinantialYear objFinantialYear = new FinantialYear();
            int i = 0;
            action = "Delete";
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.FINSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in mbBilAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        objFinantialYear.FinYear = mbBilAdGridView.Rows[i].Cells[0].Text;
                        objFinantialYear.FinYearId = 0;
                        objFinantialYear.OpeningDate = System.DateTime.Now;
                        objFinantialYear.ClosingDate = System.DateTime.Now;
                        objFinantialYear.ActiveBit = false;
                        objFinantialYear.Action = action;
                        FinancialYearInsertData objFinancialYearInsertData = new FinancialYearInsertData();
                        objFinancialYearInsertData.FinancialYear = objFinantialYear;
                        objFinancialYearInsertData.AddFinancialYear();

                    }
                    i++;
                }
                showGridView();
                action = "";
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.FINSETUP.ToString(), "U"))
            {
                
                loadFormGrid();
            }
            else
            {
                objCommonName.LabelMessageandColor(labelMbAdj, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {

        foreach (GridViewRow gvrow in mbBilAdGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                loadSalaryBreakUp(i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadSalaryBreakUp(int row)
    {
        try
        {
            string strSQL = "Select Financial_Year_Number from tblFinancial_Year where Financial_Year= '" + mbBilAdGridView.Rows[row].Cells[0].Text.Trim() + "'";
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(strSQL);
            Session["FinId"] = ds.Tables[0].Rows[0][0].ToString();

            EmpNameTxtBox.Text= mbBilAdGridView.Rows[row].Cells[0].Text;
            dptFromDate.Text = mbBilAdGridView.Rows[row].Cells[1].Text;
            dtpToDate.Text = mbBilAdGridView.Rows[row].Cells[2].Text;
            if(mbBilAdGridView.Rows[row].Cells[3].Text=="True")
            {
                chkActive.Checked = true;
            }
            else
            {
                chkActive.Checked = false;
            }
            //MedicalTimeTextBox.Text = mbBilAdGridView.Rows[row].Cells[5].Text;
            //CBFTextBox.Text = mbBilAdGridView.Rows[row].Cells[6].Text;
            //txtFromDate.Text = mbBilAdGridView.Rows[row].Cells[1].Text;



        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelMbAdj, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
