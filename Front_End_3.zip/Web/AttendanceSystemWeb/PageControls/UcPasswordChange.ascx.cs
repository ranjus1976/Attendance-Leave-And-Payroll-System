﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.Dal;

public partial class PageControls_UcPasswordChange : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    #region Private Methods

    private void ReturnValue()
    {
        String CurrentLoginUserNumber = "";
        String OldPassword = "";
        String NewPassword = "";
        Int32 RntValue = 0;

        CurrentLoginUserNumber = Session["UserId"].ToString();
        OldPassword = new CUtility().Encrypt(txtOldPassword.Text.ToString());
        NewPassword = new CUtility().Encrypt(txtNewPassword.Text.ToString());


        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = StoredProcedure.Name.sp_PasswordChange.ToString(); ;

        cmd.Parameters.AddWithValue("@UserId", CurrentLoginUserNumber);
        cmd.Parameters.AddWithValue("@OldPasswod", OldPassword);
        cmd.Parameters.AddWithValue("@NewPassword", NewPassword);

        RntValue = int.Parse(cmd.ExecuteScalar().ToString());

        if (RntValue == 1)
        {
            lblPasswordChange.Visible = true;
            lblPasswordChange.ForeColor = System.Drawing.Color.Green;
            lblPasswordChange.Text = "Data saved successfull.";
        }
        else
        {
            lblPasswordChange.Visible = true;
            lblPasswordChange.ForeColor = System.Drawing.Color.Red;
            lblPasswordChange.Text = "Old pasword wrong";
        }
    }
    private bool IsValidData()
    {
        bool rtnValue = false;
        if (txtOldPassword.Text == "" || txtOldPassword.Text == String.Empty)
        {
            rtnValue = true;
        }

        if (txtNewPassword.Text == "" || txtNewPassword.Text == String.Empty)
        {
            rtnValue = true;
        }
        return rtnValue;
    }

    #endregion

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (IsValidData() != true)
        {
            ReturnValue();
        }
        else
        {
            lblPasswordChange.Visible = true;
            lblPasswordChange.ForeColor = System.Drawing.Color.Red;
            lblPasswordChange.Text = "Please give password";
        }
    }

    protected void btnFresh_Click(object sender, EventArgs e)
    {
        txtConformPassword.Text = "";
        txtNewPassword.Text = "";
        txtOldPassword.Text = "";
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
