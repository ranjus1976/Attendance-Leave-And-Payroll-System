﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Dal.Report;

public partial class PageControls_ucProjectSetUp : System.Web.UI.UserControl
{
    ProjectBAmount objProjectBAmount = new ProjectBAmount();
    CommonName objCommonName = new CommonName();
    string action="";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (!IsPostBack)
            {
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;                
                DrpProject.Enabled = false;
                btnUpdateProj.Enabled = false;
                btnDelete.Enabled = false;
                LoadProject();
                loadCompany();
                loadDepartment();
            }

        }
        else
            Response.Redirect("login.aspx");
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadDepartment()
    {

        try
        {
            drpDept.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCmp.SelectedValue + " ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    private void LoadGrid()
    {
        string sql = "select A.EmpId,A.EmpName,B.DesigName from tblEmployee A inner join tblDesignation B on B.Desig_Number=A.Desig_Number where A.EmpED=1 and A.EmpStatus<>'Resigned'";
        DataSet Desig = new DataSet();
        Desig = ClsCommon.GetAdhocResult(sql);
        ProjectGridView.DataSource = Desig.Tables[0];
        ProjectGridView.DataBind();
    
    }
    private void LoadProject()
    {
        string strSQL = "SELECT ProjectId,ProjectName FROM tbl_ProjectName where ProjectLog=1";
        ClsCommon.drplistAdd(DrpProject, strSQL, "ProjectName", "ProjectId");
        DrpProject.Items.Insert(0, new ListItem("Select", "NA"));
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTSETUP.ToString(), "C"))
            {
                if (isValidData())
                {
                    String Sql = "sp_Project_Add";
                    SqlConnection con = new SqlConnection();
                    ReportData objReportData = new ReportData();
                    DataSet ds = new DataSet();
                    con = objReportData.GetDBConn();
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Sql, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Sql;
                    cmd.Parameters.AddWithValue("@ProjectName", TextBoxPName.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    action="Save";
                    foreach (GridViewRow oRow in ProjectGridView.Rows)
                    {
                        TextBox oTxtBoxEdit = (TextBox)oRow.FindControl("TxtAmt");

                        if (oTxtBoxEdit.Text != "0")
                        {
                            objProjectBAmount.ProjectName = TextBoxPName.Text;
                            objProjectBAmount.DesigName = oRow.Cells[0].Text;
                            objProjectBAmount.Amount = int.Parse(oTxtBoxEdit.Text);
                            objProjectBAmount.Action=action;
                            ProjectBAmountInsertData objProjectBAmountInsertData = new ProjectBAmountInsertData();
                            objProjectBAmountInsertData.ProjectBAmountdata = objProjectBAmount;
                            objProjectBAmountInsertData.InsertProjectBAmount();

                        }

                    }
                    action="";
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Data Successfully Inserted", System.Drawing.Color.Green);
                    ClearAll();
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, "Unable to process request", System.Drawing.Color.Red);

            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private bool isValidData()
    {
        bool retv = true;
        if (TextBoxPName.Text == "")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Give Project Name", System.Drawing.Color.Red);
        }

        return retv;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTSETUP.ToString(), "U"))
            {
                String Sql = "DELETE FROM tbl_ProjectBonusAmt WHERE ProjectId=" + DrpProject.SelectedValue.ToString();
                SqlConnection con = new SqlConnection();
                ReportData objReportData = new ReportData();
                DataSet ds = new DataSet();
                con = objReportData.GetDBConn();
                con.Open();
                SqlCommand cmd = new SqlCommand(Sql, con);
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = Sql;
                cmd.ExecuteNonQuery();
                con.Close();
                if (true)
                {
                    action = "Update";

                    foreach (GridViewRow oRow in ProjectGridView.Rows)
                    {
                        TextBox oTxtBoxEdit = (TextBox)oRow.FindControl("TxtAmt");

                        if (oTxtBoxEdit.Text != "0")
                        {
                            objProjectBAmount.ProjectName = DrpProject.SelectedItem.Text;
                            objProjectBAmount.DesigName = oRow.Cells[0].Text;
                            objProjectBAmount.Amount = int.Parse(oTxtBoxEdit.Text);
                            objProjectBAmount.Action = action;
                            ProjectBAmountInsertData objProjectBAmountInsertData = new ProjectBAmountInsertData();
                            objProjectBAmountInsertData.ProjectBAmountdata = objProjectBAmount;
                            objProjectBAmountInsertData.InsertProjectBAmount();

                        }

                    }
                    action = "";
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Data Successfully Updated", System.Drawing.Color.Green);
                    ClearAll();
                }
            }
        }
        else
         {
            objCommonName.LabelMessageandColor(lblErrorMessage, "Unable to process request", System.Drawing.Color.Red);
         }      
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
        ClearAll();
    }
    private void ClearAll()
    {
        chkUpdate.Checked = false;
        TextBoxPName.Text = "";
        DrpProject.SelectedItem.Text = "Select";
        LoadGrid();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        btnUpdateProj.Enabled = false;
        btnDelete.Enabled = false;
    
    
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {

    }
    protected void ProjectGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ProjectGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void ProjectGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ProjectGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void ProjectGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void TextBoxPName_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxPName.Text != "")
        {
           /* SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            con.Open();*/
           /* String Sql = "Select ProjectName from tbl_ProjectName  ProjectName Like '%" + TextBoxPName.Text + "%'";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            ReportData objReportData = new ReportData();
            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Sql;
            String project = Convert.ToString(cmd.ExecuteScalar());

            con.Close();*/






            /*SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from projects_record where (company like '%@text%') and (status=@status)";


            cmd.Connection = con;
            cmd.Parameters.Add("@text", SqlDbType.VarChar, 50).Value = TextBox9.Text;


            string s = "Pending";
            cmd.Parameters.Add("@status", SqlDbType.VarChar, 50).Value = s;



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();*/
        }
    }
    protected void btnUpdateProj_Click(object sender, EventArgs e)
    {
        if (DrpProject.SelectedItem.Text != "Select")
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, "", System.Drawing.Color.Red);
            LoadGridUpdate();
            btnUpdate.Enabled = true;
            btnSave.Enabled = false;
            TextBoxPName.Enabled = false;
            DrpProject.Enabled = false;
        }
        else
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Project Name", System.Drawing.Color.Red);
        }
       
    }
    private void LoadGridUpdate()
    {
        String Sql = "SELECT D.DesigName,isnull(P.Amount,0) as Amount FROM tblDesignation D Left join tbl_ProjectBonusAmt P on P.DesigNumber=D.Desig_Number and P.ProjectId=" + DrpProject.SelectedValue.ToString();
        DataSet dsPB = new DataSet();
        dsPB = ClsCommon.GetAdhocResult(Sql);
        ProjectGridView.DataSource = dsPB.Tables[0];
        ProjectGridView.DataBind();
      int i = 0;
        foreach (DataRow row in dsPB.Tables[0].Rows)
        {
            TextBox oTxtBoxEdit = (TextBox)ProjectGridView.Rows[i].FindControl("TxtAmt");

            if (Convert.ToString(row["Amount"]) != "0")
            {
                oTxtBoxEdit.Text = Convert.ToString(row["Amount"]);
            }
            else
            {
               oTxtBoxEdit.Text = "0";
            }
            i++;
        }
    }
    protected void chkUpdate_CheckedChanged(object sender, EventArgs e)
    {
        if (chkUpdate.Checked)
        {
            DrpProject.SelectedItem.Text = "Select";
            DrpProject.Enabled = true;
            btnUpdateProj.Enabled = true;
            btnDelete.Enabled = true;
        }
        else
        {
            DrpProject.SelectedItem.Text = "Select";
            DrpProject.Enabled = false;
            btnUpdateProj.Enabled = false;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            btnDelete.Enabled = false;
            TextBoxPName.Enabled = true;
            LoadGrid();
        }
    }
   
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTSETUP.ToString(), "D"))
            {
               
                if (Check())
                {
                    action = "Delete";

                  
                            objProjectBAmount.ProjectName = DrpProject.SelectedItem.Text;
                            objProjectBAmount.DesigName = "";
                            objProjectBAmount.Amount = 0;
                            objProjectBAmount.Action = action;
                            ProjectBAmountInsertData objProjectBAmountInsertData = new ProjectBAmountInsertData();
                            objProjectBAmountInsertData.ProjectBAmountdata = objProjectBAmount;
                            objProjectBAmountInsertData.InsertProjectBAmount();

                    action = "";
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Data Successfully Deleted", System.Drawing.Color.Green);
                    ClearAll();
                }
            }
        }
        else
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, "Unable to process request", System.Drawing.Color.Red);
        }
    }

    private bool Check()
    {
        bool rtv = true;
        if (DrpProject.SelectedItem.Text == "Select")
        {
            rtv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Project Name", System.Drawing.Color.Red);
        }
        return rtv;
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadGrid();
    }
}