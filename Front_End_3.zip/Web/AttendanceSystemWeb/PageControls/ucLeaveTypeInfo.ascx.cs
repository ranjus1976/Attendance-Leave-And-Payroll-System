﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;

public partial class PageControls_ucLeaveTypeInfo : System.Web.UI.UserControl
{
    LeaveType objLeaveType = new LeaveType();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETYPESETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    LeaveTypeList();
                }
                btnUpdate.Enabled = false;
                btnSave.Enabled = true;
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }

    #region Private Methods

    protected void LeaveTypeList()
    {
        try
        {
            ProcessLeaveTypeSelect objProcessLeaveTypeSelect = new ProcessLeaveTypeSelect();
            objProcessLeaveTypeSelect.invoke();
            Session["LeaveTypeDS"] = objProcessLeaveTypeSelect.LeaveTypeDS.Tables[0];
            grdDepartment.DataSource = objProcessLeaveTypeSelect.LeaveTypeDS.Tables[0];
            grdDepartment.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    private bool isValidData()
    {
        if ((txtLeaveName.Text.Trim().Equals("")) || (txtBalance.Text.Trim().Equals("")))
        {
            Label1.Visible = true;
            Label1.Text = "Department ID or Name Rerquired.";
            txtLeaveName.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    public void AddLeaveType()
    {
        objLeaveType = new LeaveType();
        objLeaveType.LeaveName = txtLeaveName.Text.Trim();
        objLeaveType.LeaveBalance = Convert.ToInt32(txtBalance.Text.Trim());
        objLeaveType.IsRequired = Convert.ToBoolean(chkCarryForward.Checked);
        objLeaveType.IsFSpecific = Convert.ToBoolean(chkFSpecific.Checked);
        objLeaveType.IsPaid = Convert.ToBoolean(chkPaid.Checked);
        objLeaveType.EntryBy = "1";
        objLeaveType.PC = System.Net.Dns.GetHostName().ToString();
        objLeaveType.EntryDate = System.DateTime.Now;

        ProcessLeaveTypeInsert objProcessLeaveTypeInsert = new ProcessLeaveTypeInsert();
        objProcessLeaveTypeInsert.LeaveType = objLeaveType;
        objProcessLeaveTypeInsert.invoke();
    }
    protected void UpdateLeaveType()
    {
        objLeaveType = new LeaveType();
        objLeaveType.LeaveTypeNumber = int.Parse(hdnUpdateLeaveTypeId.Value);
        objLeaveType.LeaveName = txtLeaveName.Text.Trim();
        objLeaveType.LeaveBalance = Convert.ToInt32(txtBalance.Text.Trim());
        objLeaveType.IsRequired = Convert.ToBoolean(chkCarryForward.Checked);
        objLeaveType.IsFSpecific = Convert.ToBoolean(chkFSpecific.Checked);
        objLeaveType.IsPaid = Convert.ToBoolean(chkPaid.Checked);
        objLeaveType.EntryBy = "1";
        objLeaveType.PC = System.Net.Dns.GetHostName().ToString();
        objLeaveType.EntryDate = System.DateTime.Now;

        ProcessLeaveTypeUpdate objProcessLeaveTypeUpdate = new ProcessLeaveTypeUpdate();
        objProcessLeaveTypeUpdate.LeaveType = objLeaveType;
        objProcessLeaveTypeUpdate.invoke();
        hdnUpdateLeaveTypeId.Value = "";
    }
    protected void deleteLeaveType(string delID)
    {
        objLeaveType.LeaveTypeNumber = Convert.ToInt32(delID);
        ProcessLeaveTypeDelete objProcessLeaveTypeDelete = new ProcessLeaveTypeDelete();
        objProcessLeaveTypeDelete.LeaveType = objLeaveType;
        objProcessLeaveTypeDelete.invoke();
        hdnUpdateLeaveTypeId.Value = "";
        LeaveTypeList();
        Label1.Visible = true;
        Label1.ForeColor = System.Drawing.Color.Green;
        Label1.Text = "Data Deleted Successful.";
    }
    private void loadDepartment(string id)
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["LeaveTypeDS"];
        foreach (DataRow dr in dt.Rows)
        {
            if (dr[0].ToString() == id)
            {
                txtLeaveName.Text = dr[1].ToString();
                txtBalance.Text = dr[2].ToString();
                chkCarryForward.Checked = Convert.ToBoolean(dr[3]);
                chkFSpecific.Checked = Convert.ToBoolean(dr[7]);
                chkPaid.Checked = Convert.ToBoolean(dr[9]);
            }
        }
    }
    protected void loadFormGrid()
    {
        foreach (GridViewRow oRow in grdDepartment.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");

            if (oCheckBoxEdit.Checked)
            {
                HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hdnLeaveTypeId");
                hdnUpdateLeaveTypeId.Value = hDeptId1.Value;
                loadDepartment(hDeptId1.Value);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }
        }
    }
    protected void SearchLeaveType()
    {
        string Searchquery;
        if (ddlSearch.SelectedIndex == 0)
        {
            Label1.Visible = true;
            Label1.Text = "Enter Search Item.";
        }
        else if (ddlSearch.SelectedIndex == 1)
        {
            Searchquery = "Select * From tblLeave_Type Where Leave_Name='" + txtSearch.Text + "'";
            ClsCommon.GetAdhocResult(Searchquery);
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(Searchquery);
            hdnUpdateLeaveTypeId.Value = "";
            grdDepartment.DataSource = ds;
            grdDepartment.DataBind();
            Label1.Visible = false;
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Invalid Search Item";
        }

    }
    private void clearall()
    {
        txtLeaveName.Text = "";
        txtBalance.Text = "";
        txtSearch.Text = "";
        chkCarryForward.Checked = false;
        chkFSpecific.Checked = false;
    }
    #endregion

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETYPESETUP.ToString(), "C"))
            {
                string strSql = "Select Leave_Name From tblLeave_Type Where Leave_Name='" + txtLeaveName.Text.Trim() + "'";
                if (!ClsCommon.ItemCheck(strSql))
                {
                    if (isValidData())
                    {
                        AddLeaveType();
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Green;
                        Label1.Text = "Data saved successful.";
                        clearall();
                        LeaveTypeList();
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "This id already exist";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process the request";
            }

        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        UpdateLeaveType();
        Label1.Visible = true;
        Label1.ForeColor = System.Drawing.Color.Green;
        Label1.Text = "Data updated successful.";
        clearall();
        LeaveTypeList();

    }
    protected void Cancel_Click(object sender, EventArgs e)
    {
        clearall();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            SearchLeaveType();
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETYPESETUP.ToString(), "U"))
        {
            if (Session["LogIn"] != null)
            {
                loadFormGrid();
            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to process the request";
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETYPESETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grdDepartment.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hdnLeaveTypeId");
                        hdnUpdateLeaveTypeId.Value = hDeptId1.Value;
                        deleteLeaveType(hDeptId1.Value);
                    }
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process the request";
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
    protected void grdDepartment_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdDepartment.PageIndex = e.NewPageIndex;
        LeaveTypeList();
    }
    protected void grdDepartment_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hdnUpdateLeaveTypeChek.Value = hdnUpdateLeaveTypeChek.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hdnUpdateLeaveTypeChek.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hdnUpdateLeaveTypeChek.Value = hdnUpdateLeaveTypeChek.Value.TrimStart(',');
        }
    }
}
