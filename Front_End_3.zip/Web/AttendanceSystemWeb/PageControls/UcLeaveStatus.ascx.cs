﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Report;
using AttendanceSystem.BLL;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Collections;


public partial class PageControls_LeaveStatus : System.Web.UI.UserControl
{
    LeaveBalance oBalnce = new LeaveBalance();
    SqlCommand cmd = new SqlCommand();
    ReportData obj_ReportData = new ReportData();
    SqlConnection con = new SqlConnection();
    CommonName objCommonName;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVESTATUS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    tblIdMaster.Visible = false;
                    LoadEmployeeList();
                    FinancialYear();
                    objCommonName = new CommonName();
                   // objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname); 
                     if (Session["Role_Name"].ToString() == "User")
                     {
                         DataSet ds = new DataSet();
                         ds = ClsCommon.GetAdhocResult("select EmpId from tblEmployee where Emp_Number='" + Session["User_Number"].ToString() + "'");
                         ddlEmployeeCode.SelectedItem.Text = ds.Tables[0].Rows[0][0].ToString().Trim();
                         EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
                         objCommonName.EmployeeTolTip(ddlEmployeeCode, Session["tmpEmp_Number"].ToString(), lblEmpname);
                     }
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private void LeaveStatusLoad()
    {
        if (ddlYearList.SelectedIndex != 0)
        {
            string tempID = GetEmpID(ddlEmployeeCode.SelectedItem.Text.Trim());
            if (tempID != "")
            {
                hidEmpID.Value = tempID;
                string[] values = tempID.Split(',');

                if (Session["UserType"].ToString() != "ADMIN" && Session["UserType"].ToString() != "SUPERADMIN")
                {
                    //ReadLeaveDataForEmployee(int.Parse(Session["User_Number"].ToString()));
                    ReadLeaveDataForEmployee(int.Parse(values[0]));
                }
                else
                {
                    if (ddlEmployeeCode.SelectedIndex != 0)
                    {
                        ReadLeaveDataForEmployee(int.Parse(values[0].ToString()));
                    }
                    else
                    {
                        lblMessage.Visible = true;
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = "Please enter a valid code";
                    }
                }
            }
            lblMessage.Text = "";
            lblMessage.Visible = false;
        }
        else
        {
            lblMessage.Visible = true;
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "Please select financial year or employee id!";
        }
    }
    private void FinancialYear()
    {
        try
        {
            string strSQL = "select year(Opening_Date) as Opening_Date,Financial_Year from  tblFinancial_Year";
            ClsCommon.drplistAdd(ddlYearList, strSQL, "Financial_Year", "Opening_Date");
            ddlYearList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void LoadEmployeeList()
    {
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee where EmpED = 1 order by empId asc";
                ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
                ddlEmployeeCode.Items.Insert(0, new ListItem("Select", "NA"));
            }
            if (Session["Role_Name"].ToString() == "DeptHead")
            {
                //ddlEmployeeCode.DataSource = null;
                //string strSQL = "select distinct e.EmpId,e.Emp_Number,e.EmpName, d.Comp_Number"
                //                + " from tblEmployee e,tblDepartment d,tlbRole r,tblSection s"
                //                + " where r.Role_Name='" + Session["Role_Name"].ToString() + "' and"
                //                + " d.DeptName=(select d.DeptName from tblDepartment d, tblSection s, tblEmployee e"
                //                + " where e.Sect_Number=s.Sect_Number and d.Dept_Number=s.Dept_Number and e.Emp_Number='" + Session["User_Number"].ToString() + "')"
                //                +" and d.Comp_Number=(select c.Comp_Number from tblDepartment d, tblCompany c, tblSection s, tblEmployee e"
                //                +
                //                " where e.Sect_Number=s.Sect_Number and d.Dept_Number=s.Dept_Number and e.Emp_Number='97'"
                //                + " and d.Comp_Number=c.Comp_Number )"
                //                + " and s.Dept_Number=d.Dept_Number and e.Sect_Number=s.Sect_Number and EmpED = 1"
                //                + " order by e.empId asc";

                string strSQL = "select distinct e.EmpId,e.Emp_Number,e.EmpName"
                                + " from tblEmployee e,tblDepartment d,tlbRole r,tblSection s"
                                + " where r.Role_Name='" + Session["Role_Name"].ToString() + "'"
                                + " and d.DeptName=(select d.DeptName from tblDepartment d, tblSection s, tblEmployee e"
                                + " where e.Sect_Number=s.Sect_Number and"
                                + " d.Dept_Number=s.Dept_Number and"
                                + " e.Emp_Number='" + Session["User_Number"].ToString() + "')"
                                + " and s.Dept_Number=d.Dept_Number and e.Sect_Number=s.Sect_Number and EmpED = 1 order by e.empId asc";

                ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
                ddlEmployeeCode.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee where EmpED = 1 and Emp_Number = " + Convert.ToInt32(Session["User_Number"].ToString()) + " order by empId asc ";
                ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void ReadLeaveDataForEmployee(int empTempID)
    {
        if (empTempID != int.MinValue)
        {
            LeaveBalance oLeaveBalance = new LeaveBalance();
            oLeaveBalance.Employee_Number = empTempID;
            oLeaveBalance.Leave_Year = ddlYearList.SelectedItem.Text.Trim();
            ProcessEmployeeLeaveStatusRead oReadStatus = new ProcessEmployeeLeaveStatusRead();
            oReadStatus.LeaveBalance = oLeaveBalance;
            oReadStatus.invoke();
            DataTable dtBalance = (DataTable)oReadStatus.LeaveBalanceDS.Tables[0];

            if (dtBalance.Rows.Count > 0)
            {
                grvLeaveList.DataSource = dtBalance;
                grvLeaveList.DataBind();
            }
            if (dtBalance.Rows.Count == 0)
            {
                grvLeaveList.DataSource = null;
                grvLeaveList.DataBind();
            }
        }
    }
    public string GetEmpID(string empID)
    {
        string _values = "";

        DataSet dsResult = ClsCommon.GetAdhocResult(" select Emp_Number,EmpName from tblEmployee where EmpId='" + empID.Trim() + "'");
        if (dsResult.Tables.Count > 0)
        {
            if (dsResult.Tables[0].Rows.Count > 0)
            {
                //givenid = int.Parse(dsResult.Tables[0].Rows[0]["Emp_Number"].ToString().Trim());
                _values = _values + dsResult.Tables[0].Rows[0]["Emp_Number"].ToString().Trim() + "," + dsResult.Tables[0].Rows[0]["EmpName"].ToString().Trim();
            }
        }

        return _values;
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVESTATUS.ToString(), "C"))
        {
            try
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = " Data updated successful.";
                ClearAllFields();

            }
            catch (Exception ebtnEdit)
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = ebtnEdit.ToString();
            }
        }
        else
        {
            lblMessage.Visible = true;
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "Unable to process request";
        }
    }
    protected void ddlEmplIst_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ReadLeaveDataForEmployee();
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
    }
    public void ShowReport()
    {
        DataTable dt = new DataTable("person");
        dt.Columns.Add("name", typeof(string));

        for (int x = 0; x < 5; x++)
        {
            DataRow drNew = dt.NewRow();
            drNew["name"] = x.ToString();
            dt.Rows.Add(drNew);
        }
        DataSet dsdt = new DataSet();
        dsdt.Tables.Add(dt);
        Session["give"] = dsdt;
        Response.Redirect("GReportItem.aspx");
    }
    public void ClearAllFields()
    {
        ddlYearList.SelectedIndex = 0;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void ddlEmployeeCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        if (ddlEmployeeCode.SelectedIndex != 0)
        {
            LeaveStatusLoad();
        }
        if (ddlEmployeeCode.SelectedIndex == 0)
        {
            grvLeaveList.DataSource = null;
            grvLeaveList.DataBind();
        }
        EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
    }

    protected void btnApproveList_Click(object sender, EventArgs e)
    {
        Int32 Employee_Number = 0;
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        String Sql = "sp_ApproveListWithDate";

        if (Session["UserType"].ToString() != "ADMIN" || Session["UserType"].ToString() != "SUPERADMIN")
        {
            Employee_Number = int.Parse(Session["User_Number"].ToString());
        }
        else
        {
            string[] strValues = ddlEmployeeCode.SelectedItem.Value.Split(',');
            Employee_Number = int.Parse(strValues[0].ToString());
        }

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
    }
    protected void ddlYearList_SelectedIndexChanged(object sender, EventArgs e)
    {
        LeaveStatusLoad();
     //   LoadEmpImage();
    }
}
