﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Data.Sql;
using System.Data.ProviderBase;

public partial class PageControls_UcDatabaseBackup : System.Web.UI.UserControl
{
    #region Declaration

    CommonName objCommonName = new CommonName();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DATABASEBACKUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    HideMessage1.Visible = false;
                    HideMessage2.Visible = false;
                }
            }
            else
                Response.Redirect("Default.aspx");
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Button Handlers

    protected void btnOk_Click(object sender, EventArgs e)
    {
        try
        {
            DatabaseBackup _DatabaseBackup = new DatabaseBackup();

            String FilePath = "";
            String FileName = "";
            FileName = "Web.bak";
            FilePath = Server.MapPath("DataBack\\" + FileName);
            FileInfo objFileInfo = new FileInfo(FilePath);
            if (objFileInfo.Exists)
            {
                objFileInfo.Delete();
            }
            _DatabaseBackup.Path = FilePath;
            ProcessDatabaseBackupInsert objProcessDatabaseBackupInsert = new ProcessDatabaseBackupInsert();
            objProcessDatabaseBackupInsert.DatabaseBackup = _DatabaseBackup;
            objProcessDatabaseBackupInsert.invoke();

            HideMessage1.Visible = true;
            HideMessage2.Visible = true;
            objCommonName.LabelMessageandColor(lblErrorMeassage, "Data backed up successfull", System.Drawing.Color.Green);
            DownloadDatabaseBak.Visible = true;
            DownloadDatabaseBak.NavigateUrl = "~/DataBack/Web.bak";
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMeassage, ex.Message.ToString(), System.Drawing.Color.Green);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    #endregion
}
