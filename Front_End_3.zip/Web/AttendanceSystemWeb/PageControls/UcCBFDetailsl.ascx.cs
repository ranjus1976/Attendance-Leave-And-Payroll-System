﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;

public partial class PageControls_UcCBFDetailsl : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CBFDETAILS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    loadEmployee();
                    loadDepartment();
                    LoadYear();
                    objCommonName.Addmonth(drpSalaryMonth);
                    drpDept.Enabled = false;
                    drpEmpId.Enabled = false;
                    drpCmp.Enabled = false;
                    RadioButtonAll.Checked = true;
                    RadioButtonAll.Enabled = true;
                    RadioButtonCmpWise.Checked = false;
                    RadioButtonDepartment.Checked = false;
                    rdbtnEmployee.Checked = false;
                
                    Session["NotReadPermission"] = null;
                  
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }


    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {

        try
        {
            drpDept.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCmp.SelectedValue + " ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }

    private void LoadYear()
    {
        drpSalaryYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpSalaryYear.DataSource = li;
        drpSalaryYear.Items.AddRange(items.ToArray());
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        loadEmployee();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpEmpId, drpEmpId.SelectedValue.ToString(), lblEmpname);
        Clear();
    }
    private void Clear()
    {

    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
        drpCmp.Enabled = false;
        //EmpImage.Visible = false;
        RadioButtonAll.Checked = true;
        RadioButtonCmpWise.Checked = false;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = false;
        lblEmpname.Text = string.Empty;
        drpEmpId.SelectedIndex = 0;
        drpDept.SelectedIndex = 0;

    }
    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
    }
    protected void RadioButtonDepartment_CheckedChanged1(object sender, EventArgs e)
    {
        //EmpImage.Visible = false;
        drpDept.Enabled = true;
        drpEmpId.Enabled = false;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = true;
        rdbtnEmployee.Checked = false;
        drpEmpId.SelectedIndex = 0;
        lblEmpname.Text = string.Empty;
        loadDepartment();
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        lblEmpname.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        //lblEmpname.Text = objCommonName.EmployeeName(empIdDropDownList.SelectedItem.Text);
       // EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
      
    }
    protected void rdbtnEmployee_CheckedChanged1(object sender, EventArgs e)
    {


        //if (EmpImage.ImageUrl != null)
        //{
        //    EmpImage.ImageUrl = null;
        //}
        drpDept.Enabled = false;
        drpEmpId.Enabled = true;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = true;
        drpDept.SelectedIndex = 0;
    }
    protected void drpSalaryMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drpSalaryYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void FullYearChkBx_CheckedChanged(object sender, EventArgs e)
    {


        if (FullYearChkBx.Checked)
        {
            drpSalaryMonth.Enabled = false;
            SumRptChkBx.Checked = false;
        }
        else
        {
            drpSalaryMonth.Enabled = true;
        }
      
    }
    protected void SumRptChkBx_CheckedChanged(object sender, EventArgs e)
    {
        
        FullYearChkBx.Checked = false;
        
    }
    protected void btnReport_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
         
            if(ChkValidate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblErrorMessage.Text = "";
                    Session["ReportName"] = "rptCBFDetail.rpt";
                    Session["TableName"] = "dsCBFDetail";
                    Session["CompanyName"] = drpCmp.SelectedItem.Text;
                    Session["Month"] = drpSalaryMonth.SelectedItem.Text;
                    Session["Year"] = drpSalaryYear.SelectedItem.Text;
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDateto"] = null;

                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_CBFDetail";


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
            {
               
            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private bool ChkValidate()
    {
        bool rtv=true;
        if(FullYearChkBx.Checked)
        {
            if(drpSalaryYear.SelectedItem.Text=="Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(lblErrorMessage, "Select Year", System.Drawing.Color.Red);
            }
        }
        else
        {
            if (drpSalaryMonth.SelectedItem.Text == "Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(lblErrorMessage, "Select Month", System.Drawing.Color.Red);
            }
            else if(drpSalaryYear.SelectedItem.Text == "Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(lblErrorMessage, "Select Year", System.Drawing.Color.Red);
            }
        }
        if(RadioButtonDepartment.Checked)
        {
            if (drpDept.SelectedItem.Text == "Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(lblErrorMessage, "Select Department", System.Drawing.Color.Red);
            }
        }
       if(rdbtnEmployee.Checked)
       {
           if (drpEmpId.SelectedItem.Text == "Select")
           {
               rtv = false;
               objCommonName.LabelMessageandColor(lblErrorMessage, "Select Employee", System.Drawing.Color.Red);
           }
       }
        return rtv;
    }

    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }



    private ArrayList GetOption()
    {
        try
        {
            if (RadioButtonAll.Checked && FullYearChkBx.Checked)
            {

                OptionArralist.Add("All");
                OptionArralist.Add("FullYear");
            }


            else if (RadioButtonCmpWise.Checked && FullYearChkBx.Checked)
            {

                OptionArralist.Add("FullYearCmp");
                OptionArralist.Add(drpCmp.SelectedItem.Text);
            }

            else if (RadioButtonDepartment.Checked && FullYearChkBx.Checked)
            {

                OptionArralist.Add("FullYearDept");
                OptionArralist.Add(drpDept.SelectedItem.Text);
            }
            else if (rdbtnEmployee.Checked && FullYearChkBx.Checked)
            {

                OptionArralist.Add("FullYearEmp");
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
            }

          else  if (RadioButtonAll.Checked)
            {

                OptionArralist.Add("All");
                OptionArralist.Add("All");
            }
            else if (RadioButtonCmpWise.Checked)
            {

                OptionArralist.Add("COM");
                OptionArralist.Add(drpCmp.SelectedItem.Text);
            }
            else if (RadioButtonDepartment.Checked)
            {

                OptionArralist.Add("ComDept");
                OptionArralist.Add(drpDept.SelectedItem.Text);
            }
            else
            {

                OptionArralist.Add("EMP");
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }
    protected void RadioButtonCmpWise_CheckedChanged1(object sender, EventArgs e)
    {

        //EmpImage.Visible = false; 
        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
        drpCmp.Enabled = true;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = false;
        drpDept.SelectedIndex = 0;
    }
}
