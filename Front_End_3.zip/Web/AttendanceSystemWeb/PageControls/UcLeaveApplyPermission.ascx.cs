﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;
public partial class PageControls_UcLeaveApplyPermission : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();

    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            loadEmployee();
            LoadGrid();
        }
    }
    public void LoadGrid()
    {
        string searchStr = "SELECT E.EmpId,E.EmpName  FROM tbl_LeavePermission B inner join tblEmployee E on E.Emp_Number=B.Emp_Number where B.LeaveApproveTag=1  order by E.EmpId ASC";
        DataSet DSLeavePermission = new DataSet();
        DSLeavePermission = ClsCommon.GetAdhocResult(searchStr);
        mbBilAdGridView.DataSource = DSLeavePermission.Tables[0];
        mbBilAdGridView.DataBind();
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1  order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void mbBilAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void mbBilAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        EmpNameTxtBox.Text = drpEmpId.SelectedValue.ToString();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEPERMISSION.ToString(), "C"))
            {
                if (Session["UserType"].ToString() == "SUPERADMIN")
                {
                    if (Validate())
                    {
                        int isSuccess=LeaveAdd();
                        if (isSuccess>0)
                        {
                            objCommonName.LabelMessageandColor(labelLP, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                        }
                        else
                        {
                            objCommonName.LabelMessageandColor(labelLP, "Error Occured", System.Drawing.Color.Red);
                        }
                        LoadGrid();
                        
                    }
                }
                else
                {
                    objCommonName.LabelMessageandColor(labelLP, "You Dont have Permission", System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(labelLP, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected bool Validate()
    {
        string strSql = "SELECT E.EmpId  FROM tbl_LeavePermission B inner join tblEmployee E on E.Emp_Number=B.Emp_Number where B.LeaveApproveTag=1  and E.EmpId='"+drpEmpId.SelectedItem.Text+"'";
        bool chkvalue = false;
        if (ClsCommon.ItemCheck(strSql))
        {
            objCommonName.LabelMessageandColor(labelLP, "This Data already Exists " + objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);

        }
        else if (drpEmpId.SelectedItem.Text == "Select")
        {
            objCommonName.LabelMessageandColor(labelLP, "Employee " + objCommonName.IDRequired.ToString(), System.Drawing.Color.Red);

        }
        else
        {
            chkvalue = true;
        }
        return chkvalue;
    }
    protected int LeaveAdd()
    {
        int rtv = 0;
        String Sql = "sp_LeavePermission";
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();
        con = objReportData.GetDBConn();
        con.Open();
        SqlCommand cmd = new SqlCommand(Sql, con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@EmpId", drpEmpId.SelectedItem.Text);
        rtv=cmd.ExecuteNonQuery();
        con.Close();
        return rtv;
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        drpEmpId.SelectedItem.Text = "Select";
        EmpNameTxtBox.Text = "";
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEPERMISSION.ToString(), "D"))
            {
                foreach (GridViewRow oRow in mbBilAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        int rtv = 0;
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                        String Sql = "sp_LeavePermission_Delete";
                        SqlConnection con = new SqlConnection();
                        ReportData objReportData = new ReportData();
                        DataSet ds = new DataSet();
                        con = objReportData.GetDBConn();
                        con.Open();
                        SqlCommand cmd = new SqlCommand(Sql, con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = Sql;
                        cmd.Parameters.AddWithValue("@EmpId", mbBilAdGridView.Rows[i].Cells[0].Text);
                        rtv = cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    i++;
                }
                LoadGrid(); 
                objCommonName.LabelMessageandColor(labelLP, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelLP, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }
}
