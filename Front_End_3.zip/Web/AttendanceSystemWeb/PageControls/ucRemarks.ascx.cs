﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.Net;
using System.IO;

public partial class PageControls_ucRemarks : System.Web.UI.UserControl
{
    #region Declarations

    CommonName objCommonName;
    Remarks objRemarks = new Remarks();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.REMARKS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
                    LoadEmployeeList();
                    BindGrid();
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }

    #endregion

    #region Private methods

    protected void BindGrid()
    {
        String Sql = "sp_Remarks_Select";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@CompId", int.Parse(ddlCompanyCode.SelectedValue.ToString()));

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    private void DeleteRemarks(Int32 DeleteId)
    {
        objRemarks = new Remarks();

        try
        {
            objRemarks.RemarksId = DeleteId;

            ProcessRemarksDeleteDate objProcessRemarksDeleteDate = new ProcessRemarksDeleteDate();
            objProcessRemarksDeleteDate.Remarks = this.objRemarks;
            objProcessRemarksDeleteDate.invoke();

            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Green;
            Label1.Text = "Data deleted successful.";

            BindGrid();
            ClearData();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private void RemarksAdd()
    {
        objRemarks = new Remarks();

        try
        {
            objRemarks.EmpId = int.Parse(ddlEmployeeCode.SelectedValue.ToString());
            objRemarks.Remarks1 = txtNewEmployeeCode.Text.Trim().ToString();
            objRemarks.RemarksDate = DateTime.Parse(txtFromDate.Text.Trim().ToString());
            objRemarks.PC = Dns.GetHostName();
            objRemarks.EntryBy = 0;
            objRemarks.EntryDate = DateTime.Now.Date;

            ProcessRemarksInsertData objProcessRemarksInsertData = new ProcessRemarksInsertData();
            objProcessRemarksInsertData.Remarks = this.objRemarks;
            objProcessRemarksInsertData.invoke();

            ClearData();
            BindGrid();

            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Green;
            Label1.Text = "Data saved successful.";
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private void RemarksUpdate()
    {
        objRemarks = new Remarks();

        try
        {
            objRemarks.RemarksId = int.Parse(Session["RemarksId"].ToString());
            objRemarks.EmpId = int.Parse(ddlEmployeeCode.SelectedValue.ToString());
            objRemarks.Remarks1 = txtNewEmployeeCode.Text.Trim().ToString();
            objRemarks.RemarksDate = DateTime.Parse(txtFromDate.Text.Trim().ToString());
            objRemarks.PC = Dns.GetHostName();
            objRemarks.EntryBy = 0;
            objRemarks.EntryDate = DateTime.Now.Date;

            ProcessRemarksUpdateData objProcessRemarksUpdateData = new ProcessRemarksUpdateData();
            objProcessRemarksUpdateData.Remarks = this.objRemarks;
            objProcessRemarksUpdateData.invoke();

            ClearData();
            BindGrid();

            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Green;
            Label1.Text = "Data updated successful.";
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private void ClearData()
    {
        txtFromDate.Text = "";
        ddlEmployeeCode.SelectedIndex = 0;
        txtNewEmployeeCode.Text = "";
        ddlCompanyCode.SelectedIndex = 0;
        btnSave.Enabled = true;
        BtnUpdate.Enabled = false;
    }
    #endregion

    #region Combo Load
    public void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(ddlCompanyCode, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void LoadEmployeeList()
    {
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
                strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
                strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
                strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(ddlCompanyCode.SelectedValue.ToString()) + " order by EmpId";

                ddlEmployeeCode.Items.Clear();
                ClsCommon.drplistAdd(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
                ddlEmployeeCode.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                ddlEmployeeCode.Items.Clear();
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and Emp_Number = " + Convert.ToInt32(Session["User_Number"].ToString()) + " and tblCompany.Comp_Number = " + ddlCompanyCode.SelectedValue + " order by empId asc ";
                ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region Button Handlers

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.REMARKS.ToString(), "C"))
        {
            if (Session["LogIn"] != null)
            {
                if (ddlEmployeeCode.SelectedIndex != 0)
                {
                    RemarksAdd();
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "Please select!";
                }
            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to process the request!";
        }
    }
    protected void ddlCompanyCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        BindGrid();

    }
    protected void ddlEmployeeCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.REMARKS.ToString(), "D"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxDelete = (CheckBox)oRow.FindControl("chkDelete");

                    if (oCheckBoxDelete.Checked)
                    {
                        HiddenField deleteHndId = (HiddenField)oRow.FindControl("HidOSD_Number");

                        DeleteRemarks(int.Parse(deleteHndId.Value.ToString()));
                    }
                }
                BindGrid();
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.REMARKS.ToString(), "U"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField HidEmpId1 = (HiddenField)oRow.FindControl("HidEmpId");
                        HiddenField HidOSD_Number1 = (HiddenField)oRow.FindControl("HidOSD_Number");
                        HiddenField HidFromDate1 = (HiddenField)oRow.FindControl("HidToDate");
                        HiddenField HidEmpName1 = (HiddenField)oRow.FindControl("HidEmpName");
                        HiddenField HidLocatio = (HiddenField)oRow.FindControl("HidLocation");
                        HiddenField HidCompnay = (HiddenField)oRow.FindControl("HiddenField1");

                        Session["RemarksId"] = HidOSD_Number1.Value.ToString();
                        string FromDate = HidFromDate1.Value;

                        ddlCompanyCode.SelectedValue = HidCompnay.Value;
                        ddlEmployeeCode.SelectedValue = HidEmpId1.Value;
                        txtFromDate.Text = FromDate.Substring(0, 10).Trim();
                        txtNewEmployeeCode.Text = HidLocatio.Value;
                    }
                }
                btnSave.Enabled = false;
                BtnUpdate.Enabled = true;
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            RemarksUpdate();
        }
        else
            Response.Redirect("login.aspx");
    }
  
    #endregion

}
