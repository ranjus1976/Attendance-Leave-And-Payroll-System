﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Select;
using AttendanceSystem.Dal.Report;
using System.Collections.Specialized;
using System.Data.SqlClient;


public partial class PageControls_WeeklyHoliDay1 : System.Web.UI.UserControl
{
    #region Declarations

    Int32 CompId = 0;
    CommonName objCommonName = new CommonName();
    SqlCommand cmd = new SqlCommand();
    ReportData objReportData = new ReportData();
    SqlConnection conn = new SqlConnection();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.WEEKLYHOLIDAY.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    CompanySelect();
                    LoadCheckBox();
                    BindGridView();
                    CompanyNameList.SelectedIndex = 1;
                    Departmentlist(int.Parse(CompanyNameList.SelectedValue.ToString()));
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    private void LoadCheckBox()
    {
       
        ArrayList daysOfWeek = new ArrayList();
        string[] nameOfDays = { "FRI", "SAT", "SUN", "MON", "TUE", "WED", "THS" };
        HolidayCheckBoxList.Items.Add(new ListItem("FRI", "Friday"));
        HolidayCheckBoxList.Items.Add(new ListItem("SAT", "Saturday"));
        HolidayCheckBoxList.Items.Add(new ListItem("SUN", "Sunday"));
        HolidayCheckBoxList.Items.Add(new ListItem("MON", "Monday"));
        HolidayCheckBoxList.Items.Add(new ListItem("TUE", "Tuesday"));
        HolidayCheckBoxList.Items.Add(new ListItem("WED", "Wednesday"));
        HolidayCheckBoxList.Items.Add(new ListItem("THS", "Thursday"));
        HolidayCheckBoxList.Items[0].Selected = false;

        HolidayCheckBoxList.DataBind();
        ListItemCollection dfa = new ListItemCollection();
    }
    private void CompanySelect()
    {
        ProcessCompanySelect pcs = new ProcessCompanySelect();
        pcs.invoke();
        Session["DS"] = pcs.CompanyDS.Tables[0];
        DataTable dt = (DataTable)Session["DS"];

        string[] str = { "All Department"};
        DepartmentSelectDropDownList.DataSource = str;
        DepartmentSelectDropDownList.DataBind();

        ArrayList oList = new ArrayList();

        Company com = new Company();
        com.CompName = "All Company";
        com.CompNo = 0;
        oList.Add(com);
        foreach (DataRow dr in dt.Rows)
        {
            Company oCompany = new Company();
            oCompany.CompName = dr["CompName"].ToString().Trim();
            oCompany.CompNo = Convert.ToInt32(dr["Comp_Number"].ToString().Trim());
            oList.Add(oCompany);

        }

        CompanyNameList.DataSource = oList;
        CompanyNameList.DataTextField = "CompName";
        CompanyNameList.DataValueField = "CompNo";
        CompanyNameList.DataBind();
    }
    protected ListItemCollection GetSelectedIndices(CheckBoxList cbl)
    {
        ListItemCollection oSele = new ListItemCollection();
        foreach (ListItem item in cbl.Items)
        {
            if (item.Selected)
                oSele.Add(item);
        }
        return oSele;
    }
    private void save()
    {
        Int32 CompId = Int32.Parse(CompanyNameList.SelectedValue.ToString());
        
        
        Int32 DeptId = Int32.Parse(DepartmentSelectDropDownList.SelectedValue.ToString());
        //Int32 EmpId = Int32.Parse(ddlEmployee.SelectedValue.ToString());
        try
        {
            String sql = "";

            if (DepartmentSelectDropDownList.SelectedIndex == 0)
                sql = "Delete from dbo.tblWeekly_Holiday where tblWeekly_Holiday.Comp_Number = " + CompId + " and tblWeekly_Holiday.Dept_Number = " + -1 + " and Emp_Number = " + -1 + " ";
            else if (DepartmentSelectDropDownList.SelectedIndex != 0)
                sql = "Delete from dbo.tblWeekly_Holiday where tblWeekly_Holiday.Comp_Number = " + CompId + " and tblWeekly_Holiday.Dept_Number = " + DeptId + " ";
            //else if (ddlEmployee.SelectedIndex != 0)
            //    sql = "Delete from dbo.tblWeekly_Holiday where tblWeekly_Holiday.Comp_Number = " + CompId + " and tblWeekly_Holiday.Dept_Number =  " + DeptId + " and Emp_Number = " + EmpId + " ";

            conn = objReportData.GetDBConn();
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        catch (Exception ex)
        {
            lblErrorMessage.Visible = true;
            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            lblErrorMessage.Text = ex.Message.ToString();
        }
        WeeklyHoliDay1 holiDay = new WeeklyHoliDay1();
        for (int i = 0; i < HolidayCheckBoxList.Items.Count; i++)
        {
            if (HolidayCheckBoxList.Items[i].Selected)
            {
                holiDay.CompNumber = CompanyNameList.SelectedValue;
                holiDay.DeptNumber = DepartmentSelectDropDownList.SelectedValue;
                //holiDay.EmpNumber = int.Parse(ddlEmployee.SelectedValue.ToString());
                holiDay.WHName = HolidayCheckBoxList.Items[i].Value;
                holiDay.CheckHoliDay = true;
                holiDay.EntryBy = 1;
                holiDay.EntryDate = DateTime.Now;
                holiDay.PC = System.Net.Dns.GetHostName();

                ProcessWeeklyHoliDayInsert1 pwhi = new ProcessWeeklyHoliDayInsert1();
                pwhi.HoliDay = holiDay;
                pwhi.invoke();
            }
        }
        lblErrorMessage.Visible = true;
        lblErrorMessage.ForeColor = System.Drawing.Color.Green;
        lblErrorMessage.Text = "Data saved successful.";
        //BindGridView();
    }
    private void CheckBoxCheck()
    {
        Int32 Count = 0;

        for (int i = 0; i < HolidayCheckBoxList.Items.Count; i++)
        {
            if (HolidayCheckBoxList.Items[i].Selected)
                Count = Count + 1;

            if (Count <= 2)
            {
                lblErrorMessage.Visible = false;
                lblErrorMessage.Text = "";
            }
            else
            {
                HolidayCheckBoxList.Items[i].Selected = false;
                lblErrorMessage.Visible = false;
                lblErrorMessage.Text = "";
            }
        }
    }
    protected void BtnSave_Click1(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.WEEKLYHOLIDAY.ToString(), "C"))
            {
                if (CompanyNameList.SelectedIndex != 0)
                {
                    save();
                    BindGridView();
                    LoadCheckBoxClear();
                }
                else
                {
                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    lblErrorMessage.Text = "Please select company!";
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private void LoadCheckBoxClear()
    {
        foreach (ListItem item in HolidayCheckBoxList.Items)
        {
            //check anything out here
            if (item.Selected)
                item.Selected = false;
        }
       
    }

    public void BindGridView()
    {
        AttendanceSystem.Core.WeeklyHoliDay1 Hday = new AttendanceSystem.Core.WeeklyHoliDay1();
        DataSet dsWeeklyHoliDay;
        ProcessWeeklyHoliDaySelect1 pwhs = new ProcessWeeklyHoliDaySelect1();
        pwhs.invoke();
        dsWeeklyHoliDay = pwhs.HoliDayDS;
        Session["CompanyWiseHoliDay"] = dsWeeklyHoliDay;
        GridViewWeeklyHoliday.DataSource = dsWeeklyHoliDay.Tables[0];
        GridViewWeeklyHoliday.DataBind();
    }
    public int[] GetHoliDayPattern(int encDay)
    {
        int[] arr = new int[7];
        int i = 0;
        while (encDay != 0)
        {
            arr[i++] = encDay % 10;
            encDay /= 10;
        }
        return arr;
    }
    public DataTable GetDataTable()
    {
        DataSet ds = (DataSet)Session["CompanyWiseHoliDay"];
        DataTable dt = ds.Tables[0];

        DataTable tbl = new DataTable();

        string companyNum = "1";
        string deptNum = "0";

        companyNum = CompanyNameList.SelectedValue;
        deptNum = DepartmentSelectDropDownList.SelectedValue;
        // Selects holidays for all departments of all Companies
        if (companyNum.Equals("0"))//deptNum.Equals("All Department")
        {
            return dt;
        }
        DataRow[] dr;
        // Selects holidays for all Departments of a specific Company 
        if (deptNum.Equals("0"))
        {
            dr = dt.Select("Comp_Number=" + companyNum);
        }
        // Selects holidays for a specific department of a specific Company
        else
        {
            dr = dt.Select("Comp_Number=" + companyNum +
            " and Dept_Number=" +
            deptNum);//Dept_Number
        }

        int encDay = 0;

        DataColumn col;
        foreach (DataColumn c in dt.Columns)
        {
            col = new DataColumn(c.ColumnName, c.DataType);
            tbl.Columns.Add(col);
        }
        string[] rowValue = new string[dt.Columns.Count];

        if (dr.Length > 0)
        {
            encDay = Convert.ToInt32(dr[0].ItemArray[2].ToString());//dr[0].ItemArray["Holiday"]
            if (dr.Length == 1)
            {
                SetDays(HolidayCheckBoxList, GetHoliDayPattern(encDay));
            }
            int i = 0;
            foreach (DataRow row in dr)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    rowValue[j] = dr[i].ItemArray[j].ToString();
                }
                tbl.Rows.Add(rowValue);
                i++;
            }
            BtnSave.Enabled = false;
        }
        else
        {
            DataRow r = tbl.NewRow();
            int emptyNumber = 0;
            string emptyString = "No data provided yet!!!";
            //ResetDays(SaveButton.Visible = 
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                //rowValue[j] = dr[i].ItemArray[j].ToString();
                string st = dt.Columns[j].DataType.ToString();

                if (dt.Columns[j].DataType == typeof(int))
                {
                    r[j] = emptyNumber;
                }
                else if (dt.Columns[j].DataType == typeof(string))
                {
                    r[j] = emptyString;
                }
            }
            BtnSave.Enabled = true;
            tbl.Rows.Add(r);
        }

        return tbl;


    }
    protected void SetSelected(CheckBoxList cbl, string givenValue)
    {
        ListItemCollection oSele = new ListItemCollection();

        // ArrayList selectedItems = new ArrayList();
        foreach (ListItem item in cbl.Items)
        {
            if (item.Value.Trim() == givenValue.Trim())
            {
                // selectedItems.Add(item.Value);
                //oSele.Add(item);
                item.Selected = true;
                break;
            }
        }
    }
    protected void SetDays(CheckBoxList cbl, int[] day)
    {
        int i = 0;
        foreach (ListItem item in cbl.Items)
        {
            if (day[i] == 1)
            {
                item.Selected = true;
            }
            i++;
        }
    }
    protected void ResetDays(Int32 CompanyNum, Int32 DepartmentNum)
    {
        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        SqlConnection objReturnedConn;
        ArrayList obj_ArrayList = new ArrayList();
        WeeklyHoliDaySelectCheck obj_WeeklyHoliDaySelectCheck = new WeeklyHoliDaySelectCheck();

        objReturnedConn = obj_WeeklyHoliDaySelectCheck.GetDBConn();
        ds.Tables.Add(new DataTable("tblWeekly_Holiday"));
        objReturnedConn.Open();
        cmd.Connection = objReturnedConn;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = obj_WeeklyHoliDaySelectCheck.ProcedureName();

        cmd.Parameters.AddWithValue("@Comp_Number", CompanyNum);
        cmd.Parameters.AddWithValue("@Dept_Number", DepartmentNum);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds.Tables[0]);

        foreach (DataRow dRow in ds.Tables[0].Rows)
        {
            obj_ArrayList.Add(dRow);
        }
        for (int i = 0; i < obj_ArrayList.Count; i++)
        {
        }
    }
    //protected void loadEmpId()
    //{
    //    try
    //    {
    //        ddlEmployee.Items.Clear();
    //        string strSQL = "select EmpId,Emp_Number,EmpName from tblEmployee inner join tblSection on tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number where EmpED = 1 and tblDepartment.Dept_Number = " + int.Parse(DepartmentSelectDropDownList.SelectedValue.ToString()) + " order by empId asc ";
    //        ClsCommon.drplistAddNew(ddlEmployee, strSQL, "EmpId", "Emp_Number");
    //        ddlEmployee.Items.Insert(0, new ListItem("Select", "NA"));
    //    }
    //    catch (Exception ex)
    //    {
    //        objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
    //    }
    //}
    protected void Departmentlist(Int32 CompId)
    {
        if (CompanyNameList.SelectedIndex != 0)
        {
            try
            {
                ReportData objReportData = new ReportData();
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                DataSet ds = new DataSet();
                con = objReportData.GetDBConn();
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Department_Select";
                cmd.Parameters.AddWithValue("@CompId", CompId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                DataTable dt = ds.Tables[0];
                Session["DepartmentDS"] = ds.Tables[0];
                ArrayList arrList = new ArrayList();
                bool firstTime = true;

                if (firstTime)
                {
                    Department dept = new Department();
                    dept.DeptName = "All";
                    dept.DeptNo = 0;
                    arrList.Add(dept);
                    firstTime = false;
                }
                foreach (DataRow dr in dt.Rows)
                {
                    string str = dr["Comp_Number"].ToString().Trim();

                    if (dr["Comp_Number"].ToString().Trim().Equals(CompanyNameList.SelectedItem.Value.Trim()))
                    {

                        Department oDepartment = new Department();
                        oDepartment.DeptName = dr["DeptName"].ToString();
                        oDepartment.DeptNo = Convert.ToInt32(dr["Dept_Number"].ToString());
                        arrList.Add(oDepartment);
                    }
                }
                DepartmentSelectDropDownList.DataSource = arrList;
                DepartmentSelectDropDownList.DataTextField = "DeptName";
                DepartmentSelectDropDownList.DataValueField = "DeptNo";
                DepartmentSelectDropDownList.DataBind();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }

    #endregion

    #region Button and Event haldlers

    protected void CompanyNameList_SelectedIndexChanged1(object sender, EventArgs e)
    {
        if (CompanyNameList.SelectedIndex != 0)
        {
            CompId = Int32.Parse(CompanyNameList.SelectedValue.ToString());
            Departmentlist(CompId);
        }
        else
        {
            GridViewWeeklyHoliday.DataSource = null;
            GridViewWeeklyHoliday.DataBind();
        }
    }
    protected void GridViewWeeklyHoliday_SelectedIndexChanged(object sender, EventArgs e)
    {
        IOrderedDictionary objs = GridViewWeeklyHoliday.SelectedDataKey.Values;
        string value = "";
        object o;
        IDictionaryEnumerator oDic = objs.GetEnumerator();
        while (oDic.MoveNext())
        {
            o = oDic.Value;
            value = o.ToString();
        }
    }
    protected void BtnSelect_Click(object sender, EventArgs e)
    {
        try
        {
            int MasterId = 0;

            WeeklyHoliDay1 holiDay = new WeeklyHoliDay1();
            BindGridView();
            int y = MasterId;
            this.Session["MasterId"] = MasterId;
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void DepartmentSelectDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        Int32 DepartmentSelect = Convert.ToInt32(DepartmentSelectDropDownList.SelectedValue);
        Int32 CompanySelect = Convert.ToInt32(CompanyNameList.SelectedValue);
        ResetDays(CompanySelect, DepartmentSelect);
        //loadEmpId();
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        CompanyNameList.SelectedIndex = 0;
        DepartmentSelectDropDownList.SelectedIndex = 0;
        GridViewWeeklyHoliday.DataSource = null;
        GridViewWeeklyHoliday.DataBind();

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow oRow in GridViewWeeklyHoliday.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

            if (oCheckBoxEdit.Checked)
            {
                HiddenField HidWhiname = (HiddenField)oRow.FindControl("HidWHName");
                ReportData objReportData = new ReportData();
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                String SQL = "Delete from tblWeekly_Holiday where WHName = '" + HidWhiname.Value + "'";
                con = objReportData.GetDBConn();
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = SQL;
                cmd.ExecuteNonQuery();
                con.Close();
                BindGridView();
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                lblErrorMessage.Text = "Data deleted successful.";
            }
        }
    }
    protected void HolidayCheckBoxList_SelectedIndexChanged(object sender, EventArgs e)
    {
        CheckBoxCheck();
    }
    //protected void ddlEmployee_SelectedIndexChanged(object sender, EventArgs e)
    //{

    //}

    #endregion
}
