﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;

public partial class PageControls_UcBikeLoanSetup : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadCompany();
            loadEmployee();
            LoadLoanCritiria();
            showGridView();
            TextBoxLAmtDue.ReadOnly = true;
            //TextBoxNoOfInstment.ReadOnly = true;
            //TextBoxInstallmentAmount.ReadOnly = true;
            BikeLoad();
            BikeSelect();
        }
    }
    private void BikeSelect()
    {
        string searchStr = "SELECT Model,RegistrationNo,EngineNo,ChesisNo,TotalCost FROM tbl_Bike_Entry_Details where BikeLog=1 and ChesisNo not in(select BRegNo from tbl_BikeLoanSetup where ValidLog=1)";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grvEmpCbfStart.DataSource = dsMonthDeduct.Tables[0];
        grvEmpCbfStart.DataBind();
    }







    protected void chkEditBM_CheckedChanged(object sender, EventArgs e)
    {
        int i = 0;
        foreach (GridViewRow oRow in grvEmpCbfStart.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEditBM");

            if (oCheckBoxEdit.Checked)
            {
                // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                TextBoxBikeName.Text = grvEmpCbfStart.Rows[i].Cells[0].Text;
                // TextBoxRegNo.Text = grvEmpCbfStart.Rows[i].Cells[3].Text;
                TextBoxEngin.Text = grvEmpCbfStart.Rows[i].Cells[1].Text;
                TextBoxCachis.Text = grvEmpCbfStart.Rows[i].Cells[2].Text;
                TextBoxBTotalCost.Text = grvEmpCbfStart.Rows[i].Cells[4].Text;
                string input = grvEmpCbfStart.Rows[i].Cells[3].Text;
                string[] divides = input.Split('-');

                for (int j = 0; j < divides.Length; j++)
                {
                    if (j == 0)
                        TextBoxRegNo.Text = divides[j].ToString();
                    else if (j == 1)
                        TextBoxRegNo.Text += "-" + divides[j].ToString();
                    else if (j == 2)
                        TextBoxreg1.Text = divides[j].ToString();
                    else if (j == 3)
                        TextBoxReg2.Text = divides[j].ToString();
                    else

                        TextBoxReg3.Text = divides[j].ToString();
                }



                oCheckBoxEdit.Checked = false;
            }
            i++;
        }
        // grvEmpCbfStart.Visible = false;
    }
    private void BikeLoad()
    {
        /*string strSQL = "Select Model, BikeID from tbl_Bike_Entry_Details where BikeLog=1 order by BikeID";
        drpBkike.Items.Clear();
        ClsCommon.drplistAdd(drpBkike, strSQL, "Model", "BikeID");
        drpBkike.Items.Insert(0, new ListItem("Select", "NA"));*/
    }



    private void LoadLoanCritiria()
    {
        string strSQL = "Select LoanType, LoanType from tblCompLIntRate order by LoanType";
        drpLnCriteriya.Items.Clear();
        ClsCommon.drplistAdd(drpLnCriteriya, strSQL, "LoanType", "LoanType");
        drpLnCriteriya.Items.Insert(0, new ListItem("Select", "NA"));

    }

    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and EmpId not in(select EmpId from tbl_BikeLoanSetup where ValidLog=1)and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        EmpNameTxtBox.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
    }
    protected void DropDownListLnCriteriya_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKELOANSETUP.ToString(), "C"))
            {
                if (Validate())
                {
                    string strSql = "Select BLSID From tbl_BikeLoanSetup Where ValidLog=1 and EmpId='" + drpEmpId.SelectedItem.Text + "'";

                    if (!ClsCommon.ItemCheck(strSql))
                    {

                        action = "save";
                        AddBikeLoanSetup();
                        objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                        showGridView();
                        action = "";
                    }
                    else
                    {
                        LabelBikeLoanSetup.Visible = true;
                        LabelBikeLoanSetup.ForeColor = System.Drawing.Color.Red;
                        LabelBikeLoanSetup.Text = "This id already exist";
                    }

                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");


    }

    private void showGridView()
    {
        string searchStr = "SELECT EmpId,BRegNo,BTotalValue,Duration,EmpParticipation,LoanAmount,EmpInstAmt,TotalAmtInst,BLoanAmtDue,CONVERT(varchar(10),AdjSatrtDate,103) as AdjSatrtDate,CONVERT(varchar(10),AdjEndDate,103) as AdjEndDate FROM tbl_BikeLoanSetup where ValidLog=1";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeLnSetupGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeLnSetupGridView.DataBind();
    }

    private void AddBikeLoanSetup()
    {
        BikeLoanSetup objBikeLoanSetup = new BikeLoanSetup();
        objBikeLoanSetup.CompId = drpCmp.SelectedItem.Text;
        objBikeLoanSetup.EmpId = drpEmpId.SelectedItem.Text;
        objBikeLoanSetup.BRegNo = TextBoxCachis.Text;
        objBikeLoanSetup.BTotalValue = int.Parse(TextBoxBTotalCost.Text);
        objBikeLoanSetup.BLoanType = drpLnCriteriya.SelectedItem.Text;
        objBikeLoanSetup.Duration = int.Parse(drpLnCriteriya.SelectedItem.Text.ToString());
        objBikeLoanSetup.Interest = int.Parse(TextBoxLInterest.Text);
        objBikeLoanSetup.EmpParticipation = int.Parse(TextBoxEmpPerti.Text);
        objBikeLoanSetup.LoanAmount = int.Parse(TextBoxLamount.Text);
        objBikeLoanSetup.EmpInstAmt = int.Parse(TextBoxEmpInsAmp.Text);
        objBikeLoanSetup.TotalAmtInst = int.Parse(TextBoxTInsAmp.Text);
        objBikeLoanSetup.BLoanAmtDue = int.Parse(TextBoxLAmtDue.Text);
        objBikeLoanSetup.AdjSatrtDate = txtFromDate.Text;
        objBikeLoanSetup.AdjEndDate = TextBoxAdjEndDate.Text;
        objBikeLoanSetup.Action = action;
        ProcessBikeLoanSetupInsert objProcessBikeLoanSetupInsert = new ProcessBikeLoanSetupInsert();
        objProcessBikeLoanSetupInsert.BikeLoanSetupInsert = objBikeLoanSetup;
        objProcessBikeLoanSetupInsert.invoke();
    }

    private bool Validate()
    {
        bool retval = true;
        if (drpCmp.SelectedIndex < 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Select Company", System.Drawing.Color.Red);
        }
        else if (drpEmpId.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Select Employee", System.Drawing.Color.Red);
        }
        /*else if (drpBkike.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Select Bike", System.Drawing.Color.Red);
        }*/
        else if (TextBoxBikeName.Text == "" || TextBoxEngin.Text == "" || TextBoxCachis.Text == "" || TextBoxBTotalCost.Text == "")
        {
            retval = false;
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Select Bike", System.Drawing.Color.Red);
        }
        else if (drpLnCriteriya.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Select Criteriya", System.Drawing.Color.Red);
        }
        //else if (TextBoxTotalAmount.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Give Total Amount", System.Drawing.Color.Red);
        //}
        //else if (TextBoxAdvanceAmount.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Give Advance Amount", System.Drawing.Color.Red);
        //}
        //else if (TextBoxLoanAmount.Text == "")
        //{
        //    retval = false;
        //    objCommonName.LabelMessageandColor(LabelBikeLoanSetup, "Give Loan Amount", System.Drawing.Color.Red);
        //}
        return retval;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void BikeLnSetupGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLnSetupGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLnSetupGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BikeLnSetupGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void BikeLnSetupGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.BIKELOANSETUP.ToString(), "U"))
            {
                HiddenField1.Value = drpCmp.SelectedItem.Text;
                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in BikeLnSetupGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadBikeLoanInt(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadBikeLoanInt(string id, int row)
    {
        try
        {

            string strSQL = "SELECT CompId,EmpId,BRegNo,BTotalValue,BLoanType,Duration,Interest,EmpParticipation,LoanAmount,EmpInstAmt,TotalAmtInst,BLoanAmtDue,Convert(Varchar(10),AdjSatrtDate,103) as AdjSatrtDate,Convert(Varchar(10),AdjEndDate,103) as AdjEndDate FROM tbl_BikeLoanSetup where ValidLog=1 and EmpId='" + id + "'";
            DataSet dsBLSetup = new DataSet();
            dsBLSetup = ClsCommon.GetAdhocResult(strSQL);


            String Sql = "Select Model,RegistrationNo,EngineNo,ChesisNo,TotalCost from tbl_Bike_Entry_Details where BikeLog=1 and ChesisNo='" + dsBLSetup.Tables[0].Rows[0][2].ToString() + "'";
            DataSet dsBLSetupSelect = new DataSet();
            dsBLSetupSelect = ClsCommon.GetAdhocResult(Sql);

            ReportData objReportData = new ReportData();
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = Sql;
            String BikeModel = Convert.ToString(cmd.ExecuteScalar());

            if (dsBLSetup.Tables[0].Rows.Count != 0)
            {
                drpCmp.SelectedItem.Text = dsBLSetup.Tables[0].Rows[0][0].ToString();
                drpEmpId.SelectedItem.Text = dsBLSetup.Tables[0].Rows[0][1].ToString();
                EmpNameTxtBox.Text = objCommonName.EmployeeName(dsBLSetup.Tables[0].Rows[0][1].ToString());

                TextBoxBikeName.Text = dsBLSetupSelect.Tables[0].Rows[0][0].ToString();
                TextBoxRegNo.Text = dsBLSetupSelect.Tables[0].Rows[0][1].ToString();
                TextBoxEngin.Text = dsBLSetupSelect.Tables[0].Rows[0][2].ToString();
                TextBoxCachis.Text = dsBLSetupSelect.Tables[0].Rows[0][3].ToString();
                TextBoxBTotalCost.Text = dsBLSetupSelect.Tables[0].Rows[0][4].ToString();
                TextBoxBTotalCost.Text = dsBLSetup.Tables[0].Rows[0][3].ToString();
                drpLnCriteriya.SelectedItem.Text = dsBLSetup.Tables[0].Rows[0][4].ToString();
                //TextLoanNo.Text = dsBLSetup.Tables[0].Rows[0][5].ToString();
                TextBoxLInterest.Text = dsBLSetup.Tables[0].Rows[0][6].ToString();
                TextBoxEmpPerti.Text = dsBLSetup.Tables[0].Rows[0][7].ToString();
                TextBoxLamount.Text = dsBLSetup.Tables[0].Rows[0][8].ToString();
                TextBoxEmpInsAmp.Text = dsBLSetup.Tables[0].Rows[0][9].ToString();
                TextBoxTInsAmp.Text = dsBLSetup.Tables[0].Rows[0][10].ToString();
                TextBoxLAmtDue.Text = dsBLSetup.Tables[0].Rows[0][11].ToString();
                txtFromDate.Text = dsBLSetup.Tables[0].Rows[0][12].ToString();
                TextBoxAdjEndDate.Text = dsBLSetup.Tables[0].Rows[0][13].ToString();
            }



        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelBikeLoanSetup, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CMPLOANINTRATE.ToString(), "D"))
            {
                BikeLoanSetup objBikeLoanSetup = new BikeLoanSetup();
                foreach (GridViewRow oRow in BikeLnSetupGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        objBikeLoanSetup.EmpId = BikeLnSetupGridView.Rows[i].Cells[0].Text;
                        ProcessBikeLoanSetupDelete BikeLoanSetupD = new ProcessBikeLoanSetupDelete();
                        BikeLoanSetupD.BikeLoanSetupD = objBikeLoanSetup;
                        BikeLoanSetupD.invoke();

                    }
                    i++;
                }
                showGridView();
                objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
    }
    protected void drpLnCriteriya_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strSQL = "Select Duration,IntRate from tblCompLIntRate where bikeInstLog=1 and LoanType='" +
                        drpLnCriteriya.SelectedItem.Text + "'";// " OR ChesisNo='" + CacisNo + "'";
        DataSet dsLoanCritaria = new DataSet();
        dsLoanCritaria = ClsCommon.GetAdhocResult(strSQL);

        if (dsLoanCritaria.Tables[0].Rows.Count != 0)
        {
            //TextLoanNo.Text = dsLoanCritaria.Tables[0].Rows[0][0].ToString();
            TextBoxLInterest.Text = dsLoanCritaria.Tables[0].Rows[0][1].ToString();
        }
    }
    protected void TextBoxLoanAmount_TextChanged(object sender, EventArgs e)
    {
        if (drpLnCriteriya.SelectedItem.Text != "Select" && TextBoxEmpInsAmp.Text != "")
        {
            TextBoxTInsAmp.Text = (int.Parse(drpLnCriteriya.SelectedItem.Text) * int.Parse(TextBoxEmpInsAmp.Text)).ToString();

        }
        else
        {
            TextBoxTInsAmp.Text = "";
        }
        if (TextBoxLamount.Text != "" && TextBoxTInsAmp.Text != "")
        {
            TextBoxLAmtDue.Text = (int.Parse(TextBoxLamount.Text) - int.Parse(TextBoxTInsAmp.Text)).ToString();

        }
        else
        {
            TextBoxLAmtDue.Text = "";
        }
    }
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && drpLnCriteriya.SelectedItem.Text != "Select")
        {
            string a = drpLnCriteriya.SelectedItem.Text;
            string YearCount = (int.Parse(a) / 12).ToString();
            DateTime selectedDate = DateTime.Parse(txtFromDate.Text);
            //selectedDate = selectedDate.AddYears(int.Parse(YearCount));
            selectedDate = selectedDate.AddMonths(int.Parse(a) - 1);
            //selectedDate = selectedDate.AddMonths(-1);
            TextBoxAdjEndDate.Text = selectedDate.ToString("dd/MM/yyyy");
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddBikeLoanSetup();
        objCommonName.LabelMessageandColor(LabelBikeLoanSetup, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        drpCmp.SelectedIndex = 0;
        drpEmpId.SelectedItem.Text = "Select";
        EmpNameTxtBox.Text = "";
        TextBoxBikeName.Text = "";
        TextBoxRegNo.Text = "";
        TextBoxEngin.Text = "";
        TextBoxCachis.Text = "";
        TextBoxBTotalCost.Text = "";
        drpLnCriteriya.SelectedItem.Text = "Select";
        //TextLoanNo.Text = "";
        TextBoxLInterest.Text = "";
        TextBoxEmpPerti.Text = "";
        TextBoxLamount.Text = "";
        TextBoxEmpInsAmp.Text = "";
        TextBoxTInsAmp.Text = "";
        TextBoxLAmtDue.Text = "";
        txtFromDate.Text = "";
        TextBoxAdjEndDate.Text = "";
        LabelBikeLoanSetup.Text = "";
    }
    protected void drpBkike_SelectedIndexChanged(object sender, EventArgs e)
    {

        //string strSQL = "Select TotalCost,ChesisNo,Model, BikeID from tbl_Bike_Entry_Details where BikeLog=1 and Model='" +
        //                drpBkike.SelectedItem.Text + "'";// " OR ChesisNo='" + CacisNo + "'";
        //DataSet dsBike = new DataSet();
        //dsBike = ClsCommon.GetAdhocResult(strSQL);

        //if (dsBike.Tables[0].Rows.Count != 0)
        //{
        //    TextBoxBTotalCost.Text = dsBike.Tables[0].Rows[0][0].ToString();
        //    TextBoxCachId.Text = dsBike.Tables[0].Rows[0][1].ToString();
        //}

    }
    protected void TextBoxAdjEndDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBoxEmpPerti_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxBTotalCost.Text != "" && TextBoxEmpPerti.Text != "")
        {
            TextBoxLamount.Text = (int.Parse(TextBoxBTotalCost.Text) - int.Parse(TextBoxEmpPerti.Text)).ToString();

        }
        else
        {
            TextBoxLamount.Text = "";
        }
    }
    protected void TextBoxBTotalCost_TextChanged(object sender, EventArgs e)
    {
        TextBoxEmpPerti.Focus();
    }
}
