﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;

public partial class PageControls_UcProjectBonus : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.PROJECTBONUSREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    RadioBtnCmplProject.Checked = true;
                    RadioBtnCmplProject.Enabled = true;
                    RadioBtnInCmplProject.Checked = false;
                    LoadCompleteProjectName();
                    Session["NotReadPermission"] = null;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }


    public void LoadCompleteProjectName()
    {

        try
        {
            drpPrjName.Items.Clear();
            string strSQL = "select ProjectName,ProjectId from tbl_ProjectName where ProjectLog=0 ";
            ClsCommon.drplistAdd(drpPrjName, strSQL, "ProjectName", "ProjectId ");
            drpPrjName.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    protected void drpPrjName_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnPaySlip_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblMessage.Text = "";
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDateto"] = null;
                    Session["ReportName"] = "rptProjectBonusPaySlip.rpt";
                    Session["TableName"] = "dsProjectBonus";
                    Session["ProjectName"] = drpPrjName.SelectedItem.Text;
                    Session["CompanyName"] = "General Automation Limited";
                    Session["reportstorage"] = "sp_Project_Bonus_PaySlip";
                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {

    }
    protected void btnBonus_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblMessage.Text = "";
                    Session["lnStartDatefrom"] = null;
                    Session["lnStartDateto"] = null;
                    Session["ReportName"] = "rptProjectBonusReport.rpt";
                    Session["TableName"] = "dsProjectBonus";
                    Session["ProjectName"] = drpPrjName.SelectedItem.Text;
                    Session["CompanyName"] = "General Automation Limited";
                    Session["reportstorage"] = "sp_Project_Bonus_Report";
                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private bool Validate()
    {
        bool retVal = true;

        if (drpPrjName.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblMessage, "Select Project Name".ToString(), System.Drawing.Color.Red);
        }
        
        return retVal;
    }
      protected void RadioBtnCmplProject_CheckedChanged1(object sender, EventArgs e)
    {
        RadioBtnCmplProject.Checked = true;
        RadioBtnInCmplProject.Checked = false;
        btnBonus.Visible = true;
        btnPaySlip.Visible = true;
        LoadCompleteProjectName();
    }
      protected void RadioBtnInCmplProject_CheckedChanged1(object sender, EventArgs e)
      {
          RadioBtnInCmplProject.Checked = true;
          RadioBtnCmplProject.Checked = false;
          btnBonus.Visible = false;
          btnPaySlip.Visible = false;
          LoadInCopmpleteProject();
          
      }

      public void LoadInCopmpleteProject()
      {

          try
          {
              drpPrjName.Items.Clear();
              string strSQL = "select ProjectName,ProjectId from tbl_ProjectName where ProjectLog=1 ";
              ClsCommon.drplistAdd(drpPrjName, strSQL, "ProjectName", "ProjectId ");
              drpPrjName.Items.Insert(0, new ListItem("Select", "NA"));
          }
          catch (Exception ex)
          {
              ex.Message.ToString();

          }

      }
}
