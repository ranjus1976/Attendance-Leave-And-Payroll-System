﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;

public partial class PageControls_UcShift : System.Web.UI.UserControl
{
    ProcessShiftSelect pss = new ProcessShiftSelect();
    private Shift _shft;
    String ReportDateShow;
    String TimeShow;


    #region AddShift
    public void AddShift()
    {
        _shft = new Shift();

        try
        {
            _shft.SeasonId = Convert.ToInt32(drpSeason.SelectedItem.Value);
            _shft.Shift_Number = Convert.ToInt32(drpShiftName.SelectedItem.Value);
            _shft.ShiftLate = Convert.ToDateTime("01/01/1900 " + shiftLateTextBox.Text);
            _shft.ShiftInTime = Convert.ToDateTime("01/01/1900 " + shiftInTextBox.Text);
            _shft.ShiftOutTime = Convert.ToDateTime("01/01/1900 " + shiftOutTextBox.Text);
            _shft.BreakTime = Convert.ToDateTime("01/01/1900 " + shiftLunchTimeTextBox.Text);

            _shft.PC = System.Net.Dns.GetHostName().ToString();
            _shft.EntryBy = 7;
            if (shiftRamInTextBox.Text.Trim().Equals(""))
                _shft.ShiftRamInTime = Convert.ToDateTime("01/01/1900 " + "09:30:00");
            else
                _shft.ShiftRamInTime = Convert.ToDateTime("01/01/1900 " + shiftRamInTextBox.Text);
            if (shiftRamLateTextBox.Text.Trim().Equals(""))
                _shft.ShiftRamLateTime = Convert.ToDateTime("01/01/1900 " + "09:31:00");
            else
                _shft.ShiftRamLateTime = Convert.ToDateTime("01/01/1900 " + shiftRamLateTextBox.Text);
            if (shiftRamTimeOutTextBox.Text.Trim().Equals(""))
                _shft.ShiftRamTimeOut = Convert.ToDateTime("01/01/1900 " + "17:00:00");
            else
                _shft.ShiftRamTimeOut = Convert.ToDateTime("01/01/1900 " + shiftRamTimeOutTextBox.Text);


            ProcessShiftInsert proc = new ProcessShiftInsert();
            proc.Shft = _shft;
            proc.invoke();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    #region clear
    public void ReFresh()
    {
        drpSeason.SelectedIndex = 0;
        drpShiftName.SelectedIndex = 0;
        searchShiftTextBox.Text = "Type your text";
        shiftInTextBox.Text = "";
        shiftOutTextBox.Text = "";
        shiftLateTextBox.Text = "";
        shiftLunchTimeTextBox.Text = "";

        shiftRamInTextBox.Text = "";

        shiftRamLateTextBox.Text = "";
        shiftRamTimeOutTextBox.Text = "";
        btnSave.Enabled = true;

    }

    protected void Clear_Click1(object sender, EventArgs e)
    {
        ReFresh();
        GridShiftShow();
    }
    #endregion

    protected void Save_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission("ShiftSetup", "C"))
            {
                AddShift();
                ReFresh();
                GridShiftShow();
                shiftLabel.Text = "Data Saved Successfully";
            }
            else
            {
                shiftLabel.Visible = true;
                shiftLabel.Text = "Unable to Process Request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    #endregion
    public void GridShiftShow()
    {
        string strSearch = "select ShiftId,tbl_ShiftNameSettings.Shift_Number,tbl_Season_Setup.SeasonId,SeasonTypeName,ShiftName,substring(convert(varchar(15),ShiftIn,24),0,6)as ShiftIn,substring(convert(varchar(15),ShiftOut,24),0,6) as ShiftOut,substring(convert(varchar(15),ShiftLate,24),0,6)as ShiftLate,substring(convert(varchar(15),R_In,24),0,6)as R_In ,substring(convert(varchar(15),R_Out,24),0,6)as R_Out , substring(convert(varchar(15),R_Late,24),0,6)as R_Late ,substring(convert(varchar(15),BrTime,24),0,6) as BrTime from tblShift inner join tbl_ShiftNameSettings On tblShift.Shift_Number=tbl_ShiftNameSettings.Shift_Number inner join tbl_Season_Setup On tblShift.SeasonId=tbl_Season_Setup .SeasonId";
        DataSet dsShift = new DataSet();
        dsShift = ClsCommon.GetAdhocResult(strSearch);
        gvwShift.DataSource = dsShift.Tables[0];
        gvwShift.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SHIFTSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    HideRamadan.Visible = false;
                    btnSave.Enabled = true;
                    btnFresh.Enabled = true;
                    btnEdit.Enabled = true;
                    btnEdit.Enabled = false;
                    shiftLabel.Visible = false;
                    LoadSeason();
                    LoadShiftName();

                    GridShiftShow();

                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    TimeShow = "00:00";// ReportDateShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);

                    shiftInTextBox.Text = TimeShow;
                    shiftOutTextBox.Text = TimeShow;
                    shiftLateTextBox.Text = TimeShow;
                    shiftLunchTimeTextBox.Text = TimeShow;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void btnDeleteChk_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SHIFTSETUP.ToString(), "D"))
            {
                foreach (GridViewRow gr in gvwShift.Rows)
                {
                    CheckBox del = (CheckBox)gr.FindControl("shiftDeleteCheckBox");
                    if (del.Checked)
                    {
                        HiddenField HidShift_Number = (HiddenField)gr.FindControl("HidShiftId");
                        Session["HidShiftId"] = Convert.ToInt16(HidShift_Number.Value);
                        ShiftDelete();
                        shiftLabel.Visible = true;
                        shiftLabel.ForeColor = System.Drawing.Color.Green;
                        shiftLabel.Text = "Data deleted successful.";
                        GridShiftShow();
                    }
                }
            }
            else
            {
                shiftLabel.Visible = true;
                shiftLabel.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEditChk_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SHIFTSETUP.ToString(), "U"))
            {
                foreach (GridViewRow gr in gvwShift.Rows)
                {
                    CheckBox chb = (CheckBox)gr.FindControl("shiftEditCheckBox");

                    if (chb.Checked)
                    {
                        HiddenField HidShiftId = (HiddenField)gr.FindControl("HidShiftId");
                        HiddenField HidSeasonId = (HiddenField)gr.FindControl("HidSeasonId");
                        HiddenField HidShift_Number = (HiddenField)gr.FindControl("HidShift_Number");
                        HiddenField HidShiftName = (HiddenField)gr.FindControl("HidShiftName");
                        HiddenField HidShiftIn = (HiddenField)gr.FindControl("HidShiftIn");
                        HiddenField HidShiftLate = (HiddenField)gr.FindControl("HidShiftLate");
                        HiddenField HidShiftOut = (HiddenField)gr.FindControl("HidShiftOut");
                        HiddenField HidRamadanShiftIn = (HiddenField)gr.FindControl("HidRamadanShiftIn");
                        HiddenField HidRamadanShiftLate = (HiddenField)gr.FindControl("HidRamadanShiftLate");
                        HiddenField HidRamadanShiftOut = (HiddenField)gr.FindControl("HidRamadanShiftOut");

                        HiddenField HidBrTime = (HiddenField)gr.FindControl("HidBrTime");

                        Session["ShiftNumber"] = Convert.ToInt16(HidShiftId.Value);
                        string shiftIn = HidShiftIn.Value;
                        string shiftLate = HidShiftLate.Value;
                        string shiftOut = HidShiftOut.Value;
                        string shiftlunch = HidBrTime.Value;
                        drpSeason.SelectedValue = HidSeasonId.Value;
                        drpShiftName.SelectedValue = HidShift_Number.Value;
                        shiftInTextBox.Text = shiftIn;
                        shiftLateTextBox.Text = shiftLate;
                        shiftOutTextBox.Text = shiftOut;
                        shiftLunchTimeTextBox.Text = shiftlunch;
                        shiftRamInTextBox.Text = Convert.ToString(HidRamadanShiftIn.Value);
                        shiftRamTimeOutTextBox.Text = Convert.ToString(HidRamadanShiftOut.Value);
                        shiftRamLateTextBox.Text = Convert.ToString(HidRamadanShiftLate.Value);
                    }
                }
                btnSave.Enabled = false;
                btnEdit.Enabled = true;
            }
            else
            {
                shiftLabel.Visible = true;
                shiftLabel.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    public void ShiftUpdtae()
    {
        _shft = new Shift();
        _shft.ShiftId = Convert.ToInt16(Session["ShiftNumber"].ToString());
        _shft.SeasonId = Convert.ToInt32(drpSeason.SelectedValue);
        _shft.Shift_Number = Convert.ToInt32(drpShiftName.SelectedValue);
        _shft.ShiftLate = Convert.ToDateTime("01/01/1900 " + shiftLateTextBox.Text);
        _shft.ShiftInTime = Convert.ToDateTime("01/01/1900 " + shiftInTextBox.Text);
        _shft.ShiftOutTime = Convert.ToDateTime("01/01/1900 " + shiftOutTextBox.Text);
        _shft.PC = System.Net.Dns.GetHostName().ToString();
        _shft.BreakTime = Convert.ToDateTime("01/01/1900 " + shiftLunchTimeTextBox.Text);

        if (shiftRamInTextBox.Text.Trim().Equals(""))
            _shft.ShiftRamInTime = Convert.ToDateTime("01/01/1900 " + "09:00:00");
        else
            _shft.ShiftRamInTime = Convert.ToDateTime("01/01/1900 " + shiftRamInTextBox.Text);
        if (shiftRamLateTextBox.Text.Trim().Equals(""))
            _shft.ShiftRamLateTime = Convert.ToDateTime("01/01/1900 " + "09:30:00");
        else
            _shft.ShiftRamLateTime = Convert.ToDateTime("01/01/1900 " + shiftRamLateTextBox.Text);
        if (shiftRamTimeOutTextBox.Text.Trim().Equals(""))
            _shft.ShiftRamTimeOut = Convert.ToDateTime("01/01/1900 " + "09:30:00");
        else
            _shft.ShiftRamTimeOut = Convert.ToDateTime("01/01/1900 " + shiftRamTimeOutTextBox.Text);


        ProcessShiftUpdate psu = new ProcessShiftUpdate();
        psu.OBShift = this._shft;
        psu.invoke();

    }
    #region Combo Load
    protected void LoadSeason()
    {
        string strSQL = "Select SeasonId, SeasonTypeName from tbl_Season_Setup ";
        ClsCommon.drplistAdd(drpSeason, strSQL, "SeasonTypeName", "SeasonId");
        drpSeason.Items.Insert(0, new ListItem("Select", "NA"));

    }
    protected void LoadShiftName()
    {
        string strSQL = "Select Shift_Number,ShiftName from tbl_ShiftNameSettings ";
        ClsCommon.drplistAdd(drpShiftName, strSQL, "ShiftName", "Shift_Number");
        drpShiftName.Items.Insert(0, new ListItem("Select", "NA"));

    }

    #endregion
    public void ShiftDelete()
    {
        _shft = new Shift();
        //_shft.ShiftId = Convert.ToInt16(shiftIdTextBox.Text);
        _shft.ShiftId = Convert.ToInt16(Session["HidShiftId"].ToString());

        ProcessShiftDelete psd = new ProcessShiftDelete();
        psd.Sht = this._shft;
        psd.invoke();
    }
    protected void Delete_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            ShiftDelete();
            ReFresh();
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void CLose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            //string strSearch = "select ShiftName from tblShift where ShiftName='" + shiftNameTextBox.Text + "'";
            //if (shiftNameTextBox.Text.Trim().Equals("") || shiftLateTextBox.Text.Trim().Equals("") || shiftInTextBox.Text.Trim().Equals(""))
            //{
            //    shiftLabel.Visible = true;
            //    shiftLabel.ForeColor = System.Drawing.Color.Red;
            //    shiftLabel.Text = "Please fill the required fields.";
            //}
            //else
            //{
                ShiftUpdtae();
                shiftLabel.Visible = true;
                shiftLabel.ForeColor = System.Drawing.Color.Green;
                shiftLabel.Text = "Data updated successful.";
            //}
            GridShiftShow();
            ReFresh();
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            ShiftDelete();
            ReFresh();
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
     if (Session["LogIn"] != null)
      {
            //bool shift;
            //string strSearch = "select ShiftName from tblShift where ShiftName='" + shiftNameTextBox.Text + "'";
            //shift = ClsCommon.ItemCheck(strSearch);

        if(drpSeason.SelectedIndex==0) //(drpSection.Text.Trim().Equals(""))
        {
            shiftLabel.Visible = true;
            shiftLabel.Text = "Season name required.";
            drpSeason.Focus();
        }
        else if (drpShiftName.SelectedIndex == 0)
        {
            shiftLabel.Visible = true;
            shiftLabel.Text = "Shift name required.";
            drpShiftName.Focus();
        }


        else
        {
            AddShift();
            shiftLabel.Visible = true;
            shiftLabel.ForeColor = System.Drawing.Color.Green;
            shiftLabel.Text = "Data saved successful.";
        }
        GridShiftShow();
        ReFresh();
    }
     else
       Response.Redirect("login.aspx");
 }
    protected void btnreFresh_Click(object sender, EventArgs e)
    {
        ReFresh();
        shiftLabel.Visible = false;
        shiftLabel.Text = "";
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    { }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (searchShiftTextBox.Text != "")
            {
                DataSet ds = new DataSet();
                /*
                if (searchOp == 0)
                {
                    string shiftQuery = " select Shift_Number,ShiftName,ShiftIn,ShiftOut,ShiftLate,BrTime from tblShift where Shift_Number= " + searchShiftTextBox.Text + " ";
                    DataSet ds = new DataSet();
                    ds = ClsCommon.GetAdhocResult(shiftQuery);
                    gvwShift.DataSource = ds;
                    gvwShift.DataBind();
                }
                 * */
                if (ddlSearchId.SelectedIndex == 0)
                {
                    try
                    {
                        string shiftQuery = " select Shift_Number,ShiftName,substring(convert(varchar(15),ShiftIn,24),0,6)as ShiftIn,substring(convert(varchar(15),ShiftOut,24),0,6) as ShiftOut,substring(convert(varchar(15),ShiftLate,24),0,6)as ShiftLate, substring(convert(varchar(15),R_In,24),0,6)as R_In , substring(convert(varchar(15),R_Out,24),0,6)as R_Out , substring(convert(varchar(15),R_Late,24),0,6)as R_Late ,substring(convert(varchar(15),BrTime,24),0,6) as BrTime from tblShift where  ShiftName like '" + searchShiftTextBox.Text + "%' ";
                        ds = ClsCommon.GetAdhocResult(shiftQuery);

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            gvwShift.DataSource = ds;
                            gvwShift.DataBind();
                            shiftLabel.Visible = false;
                            shiftLabel.Text = "";
                        }
                        else
                        {
                            gvwShift.DataSource = ds;
                            gvwShift.DataBind();
                            shiftLabel.Visible = true;
                            shiftLabel.ForeColor = System.Drawing.Color.Red;
                            shiftLabel.Text = "Search item not found";
                        }
                    }
                    catch (Exception ex)
                    {
                        shiftLabel.Visible = true;
                        shiftLabel.ForeColor = System.Drawing.Color.Red;
                        shiftLabel.Text = ex.Message.ToString();
                    }

                }
                else
                {
                    gvwShift.DataSource = ds;
                    gvwShift.DataBind();
                    shiftLabel.Visible = true;
                    shiftLabel.ForeColor = System.Drawing.Color.Red;
                    shiftLabel.Text = "Search item not found";
                }
            }
            else
            {
                shiftLabel.Visible = true;
                shiftLabel.ForeColor = System.Drawing.Color.Red;
                shiftLabel.Text = "Enter search item.";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void ddlSearchId_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void gvwShift_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("shiftEditCheckBox");
            hidEditCheckedIDS123.Value = hidEditCheckedIDS123.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("shiftDeleteCheckBox");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS123.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS123.Value = hidEditCheckedIDS123.Value.TrimStart(',');
        }
    }
    protected void btnSave0_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            HideRamadan.Visible = true;
        }
        else
            Response.Redirect("login.aspx");
    }
}
