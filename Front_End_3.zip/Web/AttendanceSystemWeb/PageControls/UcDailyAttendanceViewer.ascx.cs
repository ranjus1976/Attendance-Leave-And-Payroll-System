﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_UcDailyAttendanceViewer : System.Web.UI.UserControl
{
    #region  Declaration

    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DAILYREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    drpDept.Enabled = false;
                    drpEmpId.Enabled = false;
                    String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtReportDate.Text = ReportDateShow;
                    Session["NotReadPermission"] = null;
                    EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Combo Load

    protected void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(drplist, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadDepartment()
    {
        try
        {
            drpEmpId.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drplist.SelectedValue + "  ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadEmpId()
    {
        try
        {
            drpEmpId.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + drplist.SelectedValue + " order by empId asc ";
            ClsCommon.drplistAddNew(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    #endregion

    #region Private Methods

    private ArrayList GetOption()
    {
        try
        {
            if (RadioButtonAll.Checked)
            {
                OptionArralist = objCommonName.GetOption("ALL", drplist);
            }
            else if (RadioButtonDepartment.Checked)
            {
                OptionArralist = objCommonName.GetOption("Dept", drpDept);
            }
            else
            {
                OptionArralist = objCommonName.GetOption("Emp", drpEmpId);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }

    #endregion

    #region Report

    protected void btnAttendence_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear

                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyAttendance.rpt";
                Session["TableName"] = "dsDailyAttendence";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Daily_Attendence";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnLate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear

                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyLate.rpt";
                Session["TableName"] = "dsDailyLate";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Daily_Late";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnPresent_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear


                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyPresent.rpt";
                Session["TableName"] = "dsDailyPresent";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Daily_Present";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnAbsent_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear

                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyAbsent.rpt";
                Session["TableName"] = "dsDailyAbsent";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Daily_Absent";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnMissPunch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear


                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyMissOut.rpt";
                Session["TableName"] = "dsDailyMissOut";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Daily_Misspunch";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnSummary_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear


                ArrayList ArralistOption = new ArrayList();
                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailySummary.rpt";
                Session["TableName"] = "dsDailySummary";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                string option, option1;

                if (RadioButtonAll.Checked)
                {
                    option = "1";
                    option1 = "1";
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }
                else if (RadioButtonDepartment.Checked)
                {
                    option = "dbo.tblDepartment.DeptName";
                    option1 = drpDept.SelectedItem.ToString();
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }

                else
                {
                    option = "dbo.tblEmployee.EmpId";
                    option1 = drpEmpId.SelectedValue.ToString();
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }

                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Employee_Daily_Summary";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnMovement_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                Session["ToDate"] = null;
                Session["FromDate"] = null;
                Session["FinancialYear"] = null;
                Session["Date"] = null;
                // End Session Clear


                ArrayList ArralistOption = new ArrayList();
                Session["Date"] = txtReportDate.Text;
                Session["ReportName"] = "rptDailyMovement.rpt";
                Session["TableName"] = "dsDailyMovement";
                Session["CompanyName"] = drplist.SelectedItem.Text;
                Session["Company_Number"] = drplist.SelectedValue;
                string option, option1;

                if (RadioButtonAll.Checked)
                {
                    option = "1";
                    option1 = "1";
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }
                else if (RadioButtonDepartment.Checked)
                {
                    option = "dbo.tblDepartment.DeptName";
                    option1 = drpDept.SelectedItem.ToString();
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }

                else
                {
                    option = "dbo.tblEmployee.EmpId";
                    option1 = drpEmpId.SelectedValue.ToString();
                    ArralistOption.Add(option);
                    ArralistOption.Add(option1);
                }

                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Employee_Daily_Movement";

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    #endregion

    #region Radio Button

    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            drpDept.Enabled = true;
            drpEmpId.Enabled = false;
            loadDepartment();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            drpDept.Enabled = false;
            drpEmpId.Enabled = true;
            loadEmpId();
            objCommonName = new CommonName();
            objCommonName.EmployeeTolTip(drpEmpId, drpEmpId.SelectedValue.ToString(), lblEmpname);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    #endregion

    #region Button Handles

    protected void btnShow_Click(object sender, EventArgs e)
    {
        Session["Report"] = Server.MapPath("~\\Reports\\rptDailyActivities.rpt");
        Response.Redirect("~/Reports/FrmReportContainer.aspx");
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            //EmployeeTolTip();
            objCommonName = new CommonName();
            objCommonName.EmployeeTolTip(drpEmpId, drpEmpId.SelectedValue.ToString(), lblEmpname);
            EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void drplist_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            loadDepartment();
            loadEmpId();            
            objCommonName = new CommonName();
            objCommonName.EmployeeTolTip(drpEmpId, drpEmpId.SelectedValue.ToString(), lblEmpname);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void drpCompany_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
  
    #endregion
}
