﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;


public partial class PageControls_OSDFormTest : System.Web.UI.UserControl
{
    String ReportDateShow;
    String TimeShow;
    CommonName objCommonName;
    Int32 CompId = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OSDSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    ListItem item1 = new ListItem("Select", "0");
                    ListItem item2 = new ListItem("Employee Name", "1");
                    ListItem item3 = new ListItem("Date", "2");
                    DDLSearchBy.Items.Add(item1);
                    DDLSearchBy.Items.Add(item2);
                    DDLSearchBy.Items.Add(item3);
                    PanelDate.Visible = false;
                    loadCompany();
                    loadEmployee();
                    EmployeeImage.LoadImageEmp(DDLEmpName, tblIdMaster, EmpImage);
                    CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                    BindGrid(CompId);
                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    TimeShow = ReportDateShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtFromDate.Text = ReportDateShow;
                    txtToDate.Text = ReportDateShow;
                    objCommonName = new CommonName();
                    objCommonName.EmployeeTolTip(DDLEmpName, DDLEmpName.SelectedValue.ToString(), lblEmpname);
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void BindGrid(Int32 CompId)
    {
        //ProcessOSDSelectAll processOSD = new ProcessOSDSelectAll();
        //processOSD.invoke();
        String Sql = "sp_OSD_SelectAllCOmpanyWise";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@Comp_Number", int.Parse(ddlCompany.SelectedValue.ToString()));

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        Session["AllOSD"] = ds;
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void DeleteOSD(string OSD_Number)
    {
        OSD osdData = new OSD();
        osdData.OSDNumber = Convert.ToInt32(OSD_Number);

        ProcessOSDDelete osdprocess = new ProcessOSDDelete();
        osdprocess.OsdData = osdData;
        osdprocess.invoke();

    }
    protected void btnDelete_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OSDSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxDelete = (CheckBox)oRow.FindControl("chkDelete");

                    if (oCheckBoxDelete.Checked)
                    {
                        HiddenFieldOSDNumber = (HiddenField)oRow.FindControl("HidOSD_Number");

                        DeleteOSD(HiddenFieldOSDNumber.Value);
                    }
                }
                CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                BindGrid(CompId);
                Label5.Visible = false;
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEdit_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OSDSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in GridView1.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");

                    if (oCheckBoxEdit.Checked)
                    {
                        loadEmployee();
                        HiddenField HidEmpId1 = (HiddenField)oRow.FindControl("HidEmpId");
                        HiddenField HidOSD_Number1 = (HiddenField)oRow.FindControl("HidOSD_Number");
                        HiddenField HidFromDate1 = (HiddenField)oRow.FindControl("HidFromDate");
                        HiddenField HidToDate1 = (HiddenField)oRow.FindControl("HidToDate");
                        HiddenField HidEmpName1 = (HiddenField)oRow.FindControl("HidEmpName");
                        HiddenField HidLocatio = (HiddenField)oRow.FindControl("HidLocation");

                        string FromDate = HidFromDate1.Value;
                        string ToDate = HidToDate1.Value;
                        DDLEmpName.SelectedItem.Text = HidEmpId1.Value;
                        DDLEmpName.Enabled = false;
                        ddlCompany.Enabled = false;
                        txtFromDate.Text = FromDate.Substring(0, 10).Trim();
                        txtToDate.Text = ToDate.Substring(0, 10).Trim();
                        txtLocation.Text = HidLocatio.Value;
                        HiddenFieldOSDNumber.Value = HidOSD_Number1.Value;
                    }
                }
                BtnSave.Enabled = false;
                BtnUpdate.Enabled = true;
                Label5.Visible = false;
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    public void loadEmployee()
    {
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
                strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
                strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
                strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(ddlCompany.SelectedValue.ToString()) + " order by EmpId";

                DDLEmpName.Items.Clear();
                ClsCommon.drplistAdd(DDLEmpName, strSQL, "EmpId", "Emp_Number");
                DDLEmpName.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                DDLEmpName.Items.Clear();
                string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and Emp_Number = " + Convert.ToInt32(Session["User_Number"].ToString()) + " and tblCompany.Comp_Number = " + ddlCompany.SelectedValue + " order by empId asc ";
                ClsCommon.drplistAddNew(DDLEmpName, strSQL, "EmpId", "Emp_Number");
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
        // ddlCompany.Items.Insert(0, new ListItem("Select", "NA"));
    }

    protected void LoadForEdit()
    {
        HiddenFieldOSDNumber.Value = Request.QueryString["OSDNumber"];
        string FDate = Request.QueryString["FromDate"];
        string TData = Request.QueryString["TODate"];
        DateTime d = DateTime.Parse(FDate);
    }
    protected void AddOSD()
    {
        OSD osdData = new OSD();

        osdData.EmpNumber = Convert.ToInt32(DDLEmpName.SelectedValue);
        osdData.FromDate = Convert.ToDateTime(txtFromDate.Text);
        osdData.ToDate = Convert.ToDateTime(txtToDate.Text);
        osdData.EntryBy = 1;
        osdData.EntryDate = DateTime.Now;
        osdData.PC = System.Net.Dns.GetHostName();
        osdData.Location = txtLocation.Text;

        ProcessOSDInsert posdInsert = new ProcessOSDInsert();
        posdInsert.OSDBLL = osdData;
        posdInsert.invoke();

    }
    private bool isValidData()
    {
        if (DDLEmpName.SelectedItem.Text.ToString() == "Select")
        {
            Label5.Visible = true;
            Label5.ForeColor = System.Drawing.Color.Red;
            Label5.Text = "Employee id and name required.";
            return false;
        }
        else
        {
            return true;
        }
    }

    private void ClearData()
    {
        txtFromDate.Text = "";
        txtToDate.Text = "";
        DDLEmpName.SelectedIndex = 0;
        txtLocation.Text = "";
        ddlCompany.SelectedIndex = 0;
    }

    private bool FromDateToDate(DateTime FromDate, DateTime ToDate)
    {
        bool retnvalue = false;
        Int32 Count = 0;
        ArrayList FromDateArr = new ArrayList();
        ArrayList ToDateArr = new ArrayList();
        Int32 Employee_Number = 0;

        if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
        {
            string[] strValues = DDLEmpName.SelectedItem.Value.Split(',');
            Employee_Number = int.Parse(strValues[0].ToString());
        }
        else
        {
            Employee_Number = int.Parse(Session["User_Number"].ToString());
        }
        String Sql = "Select FromDate,ToDate from tblOSD_Setup where Emp_Number = " + Employee_Number + "";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == false)
        {
            retnvalue = true;
        }
        else
        {
            while (reader.Read())
            {
                FromDateArr.Add(reader[0]);
                ToDateArr.Add(reader[1]);
            }
            for (int i = 0; i < FromDateArr.Count; i++)
            {
                DateTime TempFromDate = Convert.ToDateTime(FromDateArr[i]);
                DateTime TemToDate = Convert.ToDateTime(ToDateArr[i]);

                if ((TempFromDate > FromDate && TempFromDate > ToDate)
                    || (FromDate > TemToDate && ToDate > TemToDate))
                {
                    Count++;
                }
                else
                {
                    retnvalue = false;
                }
            }
            if (Count == FromDateArr.Count)
            {
                retnvalue = true;
            }
        }
        return retnvalue;
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OSDSETUP.ToString(), "C"))
            {
                DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
                DateTime ToDate = Convert.ToDateTime(txtToDate.Text);
                if (DDLEmpName.SelectedIndex != 0)
                {
                    if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                    {
                        if (isValidData())
                        {
                            //string strSql = "SELECT dbo.tblOSD_Setup.* FROM dbo.tblOSD_Setup WHERE     Emp_Number = " + Convert.ToInt32(DDLEmpName.SelectedValue) + " AND FromDate = '" + DateTime.Parse(txtFromDate.Text).ToString("dd/MMM/yyyy") + "' AND ToDate ='" + DateTime.Parse(txtToDate.Text).ToString("dd/MMM/yyyy") + "'";
                            //string strSql = "SELECT dbo.tblOSD_Setup.* FROM dbo.tblOSD_Setup WHERE Emp_Number = " + Convert.ToInt32(DDLEmpName.SelectedValue) + " AND FromDate = '" + DateTime.Parse(txtFromDate.Text).ToString("dd/MMM/yyyy") + "' AND ToDate ='" + DateTime.Parse(txtToDate.Text).ToString("dd/MMM/yyyy") + "'";

                            //if (!ClsCommon.ItemCheck(strSql))

                            bool value = Convert.ToBoolean(FromDateToDate(FromDate, ToDate));
                            if (value == true)
                            {
                                AddOSD();
                                Label5.Visible = true;
                                Label5.ForeColor = System.Drawing.Color.Green;
                                Label5.Text = "Data saved successful.";
                                CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                                BindGrid(CompId);
                                ClearData();
                                ddlCompany.Enabled = true;
                                DDLEmpName.Enabled = true;
                            }
                            else
                            {
                                Label5.Visible = true;
                                Label5.ForeColor = System.Drawing.Color.Red;
                                Label5.Text = "OSD already setup in this date.";
                            }
                        }
                    }
                    else
                    {
                        Label5.Visible = true;
                        Label5.ForeColor = System.Drawing.Color.Red;
                        Label5.Text = "From date must be less than to date!";
                    }
                }
                else
                {
                    Label5.Visible = true;
                    Label5.ForeColor = System.Drawing.Color.Red;
                    Label5.Text = "Please select!";
                }
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        ddlCompany.Enabled = true;
        DDLEmpName.Enabled = true;
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        CompId = int.Parse(ddlCompany.SelectedValue.ToString());
        BindGrid(CompId);
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void DDLEmpID_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void DDLEmpName_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(DDLEmpName, DDLEmpName.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(DDLEmpName, tblIdMaster, EmpImage);
    }
    protected void BtnSelect_Click(object sender, EventArgs e)
    {

    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            DataSet ds = (DataSet)Session["AllOSD"];
            DataView dv = ds.Tables[0].DefaultView;
            string filterDate = "FromDate>='" + txtSearchFromDate.Text + "' and ToDate<='" + txtSearchToDate.Text + "' ";
            string filterEmpId = " EmpName='" + txtboxEmpId.Text.Trim() + "' ";

            if (PanelDate.Visible)
            {
                DateTime FromDate = Convert.ToDateTime(txtSearchFromDate.Text);
                DateTime ToDate = Convert.ToDateTime(txtSearchToDate.Text);

                if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                {
                    dv.RowFilter = filterDate;
                }
                else
                {
                    Label5.Visible = true;
                    Label5.Text = "From date must be less than to date!";
                }
            }
            else if (PanelText.Visible)
            {
                dv.RowFilter = filterEmpId;
            }
            DataTable tbl = dv.ToTable();
            int x = 0;
            x = tbl.Rows.Count;

            GridView1.DataSource = tbl;
            if (x == 0)
            {
                GridView1.EmptyDataText = "No data found";
                GridView1.DataSource = null;
            }
            GridView1.DataBind();
        }
        else
            Response.Redirect("login.aspx");
    }

    protected void BtnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void DDLSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (DDLSearchBy.SelectedValue.Equals("2"))
        {
            PanelText.Visible = false;
            PanelDate.Visible = true;

            ReportDateShow = Convert.ToString(System.DateTime.Now);
            TimeShow = ReportDateShow.Substring(11, 5);
            ReportDateShow = ReportDateShow.Substring(0, 10);
            txtSearchFromDate.Text = ReportDateShow;
            txtSearchToDate.Text = ReportDateShow;
        }
        else if (DDLSearchBy.SelectedValue.Equals("1"))
        {
            PanelText.Visible = true;
            PanelDate.Visible = false;
        }
        else if (DDLSearchBy.SelectedValue.Equals("0"))
        {
            PanelText.Visible = true;
            PanelDate.Visible = false;
        }
    }
    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            DateTime FromDate = Convert.ToDateTime(txtFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(txtToDate.Text);

            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                OSD osdData = new OSD();
                osdData.OSDNumber = Convert.ToInt32(HiddenFieldOSDNumber.Value);
                osdData.FromDate = Convert.ToDateTime(txtFromDate.Text);
                osdData.ToDate = Convert.ToDateTime(txtToDate.Text);
                osdData.Location = txtLocation.Text;
                ProcessOSDUpdate pUpdate = new ProcessOSDUpdate();
                pUpdate.OsdData = osdData;
                pUpdate.invoke();
                ClearData();
                BtnSave.Enabled = true;
                ddlCompany.Enabled = true;
                DDLEmpName.Enabled = true;
                CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                BindGrid(CompId);
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Green;
                Label5.Text = "Data updated successful.";
            }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "From date must be less than to date!";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;

            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");

            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";

            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');

        }
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
        CompId = int.Parse(ddlCompany.SelectedValue.ToString());
        BindGrid(CompId);
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(DDLEmpName, DDLEmpName.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(DDLEmpName, tblIdMaster, EmpImage);
    }
  
}
