﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using GAL.Components;
using CrystalDecisions.CrystalReports.Engine;

public partial class PageControls_UcReportContainer : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ShowReport();
    }

    private void ShowReport()
    {
        ReportUtils ru = new ReportUtils();

        try
        {
            ReportDocument oRpt = new ReportDocument();
            crvRpt.ReportSource = ru.prepareReport();
        }
        catch (Exception ex)
        {
        }
        finally
        {
            ru = null;
        }
    }
    protected void crvRpt_Init(object sender, EventArgs e)
    {

    }
}
