﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_UcDailyProcess : System.Web.UI.UserControl
{
    #region Declarations
    public string name = null;
    DataTable dt;
    String Date = System.DateTime.Now.ToString();
    String ReportDateShow = "";
    CommonName objCommonName = new CommonName();
    Int32 CompId = 0;

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DATAPROCESS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    LoadSeason();
                    CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                    DeptList(CompId);
                    EmployeeList(CompId);
                    LoadPageMail();
                    EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
        LoadLastProcessDate();
    }

    #endregion

    #region Combo Box

    protected void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void DeptList(Int32 CompId)
    {
        try
        {
            string strSQL = "select DeptName,Dept_Number from  tblDepartment where comp_number = " + CompId + "   order by DeptName asc";
            ClsCommon.drplistAdd(deptDropDownList, strSQL, "DeptName", "Dept_Number");
            deptDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void EmployeeList(Int32 CompId)
    {
        try
        {
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + CompId + " order by empId asc ";
            ClsCommon.drplistAdd(empIdDropDownList, strSQL, "EmpId", "Emp_Number");
            empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected void LoadSeason()
    {
        string strSQL = "Select SeasonId, SeasonTypeName from tbl_Season_Setup ";
        ClsCommon.drplistAdd(drpSeason, strSQL, "SeasonTypeName", "SeasonId");
        drpSeason.Items.Insert(0, new ListItem("Select", "NA"));
    }

    #endregion

    #region Private Methods

    private void LoadLastProcessDate()
    {
        try
        {
            string strLastDateQuery = "select max(PrDate) as Max_Date from tblPrDate";
            DataSet dsDate = new DataSet();
            dsDate = ClsCommon.GetAdhocResult(strLastDateQuery);
            dt = (DataTable)dsDate.Tables[0];
            string str = "";
            foreach (DataRow dr in dt.Rows)
            {
                str = (Convert.ToDateTime(dr["Max_Date"])).ToString();
            }
            lastProcessDateTextBox.Text = str.Substring(0, 10);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void LoadPageMail()
    {
        try
        {
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = false;
            fromDateTextBox.Text = Date.Substring(0, 9);
            toDateTextBox.Text = Date.Substring(0, 9);
            ReportDateShow = Convert.ToString(System.DateTime.Now);
            ReportDateShow = ReportDateShow.Substring(0, 10);
            fromDateTextBox.Text = ReportDateShow;
            toDateTextBox.Text = ReportDateShow;
            Session["NotReadPermission"] = null;
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void clearall()
    {
        drpSeason.SelectedIndex = 0;
    }
    public void AddManualEntry()
    {
        DateTime FromDate;
        DateTime ToDate;
        string SeasonName = "";

        try
        {
            CompId = int.Parse(ddlCompany.SelectedValue.ToString());

            FromDate = DateTime.Parse(DateTime.Parse(fromDateTextBox.Text.Trim()).ToString("dd/MMM/yyyy")); //Convert.ToDateTime(fromDateTextBox.Text);
            ToDate = DateTime.Parse(DateTime.Parse(toDateTextBox.Text.Trim()).ToString("dd/MMM/yyyy")); // Convert.ToDateTime(toDateTextBox.Text);
            SeasonName = drpSeason.SelectedItem.Text;
            Boolean Ramadan = Convert.ToBoolean(chkRamadan.Checked);
            Boolean AnyUnrest = Convert.ToBoolean(chkUnrest.Checked);

            if (RadioButtonEmpId.Checked)
            {
                name = empIdDropDownList.SelectedValue.ToString();
                ProcessInsertData eprocess = new ProcessInsertData();
                eprocess.ProcessData(FromDate, ToDate, 3, name,SeasonName, Ramadan, AnyUnrest, CompId);
            }
            else if (RadioButtonDepartment.Checked)
            {
                ProcessInsertData eprocess = new ProcessInsertData();
                eprocess.ProcessData(FromDate, ToDate, 2, deptDropDownList.SelectedValue.ToString(),SeasonName,Ramadan, AnyUnrest, CompId);
            }
            else
            {
                ProcessInsertData eprocess = new ProcessInsertData();
                eprocess.ProcessData(FromDate, ToDate, 1, "1", SeasonName, Ramadan, AnyUnrest, CompId);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    public void Refresh()
    {
    }

    #endregion

    #region Button Click

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                AddManualEntry();
                objCommonName.LabelMessageandColor(Label1, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                Refresh();
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnProcess_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            String Sql = "sp_Emp_SevenDays";
            SqlConnection con = new SqlConnection();
            ReportData objReportData = new ReportData();
            DataSet ds = new DataSet();
            con = objReportData.GetDBConn();
            con.Open();
            SqlCommand cmd = new SqlCommand(Sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PageSelect", "DataProcess");
            cmd.CommandText = Sql;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            
            
            if (ds.Tables[0].Rows.Count==0)
            {

                if (((_Default) this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DATAPROCESS.ToString(),
                                                               "C"))
                {
                    try
                    {
                        DateTime FromDate = Convert.ToDateTime(fromDateTextBox.Text);
                        DateTime ToDate = Convert.ToDateTime(toDateTextBox.Text);

                        DateTime LastProcessDateCheck = Convert.ToDateTime(lastProcessDateTextBox.Text);
                        TimeSpan tsCheck = new TimeSpan(1, 0, 0, 0);

                        LastProcessDateCheck = LastProcessDateCheck.Add(tsCheck);

                        if (DateTime.Compare(LastProcessDateCheck, FromDate) == 0 ||
                            DateTime.Compare(LastProcessDateCheck, FromDate) > 0)
                        {
                            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                            {
                                if (fromDateTextBox.Text.Equals(""))
                                {
                                    objCommonName.LabelMessageandColor(Label1, objCommonName.ProcessDateRequired,
                                                                       System.Drawing.Color.Red);
                                    fromDateTextBox.Focus();
                                    return;
                                }
                                else if (toDateTextBox.Text.Equals(""))
                                {
                                    objCommonName.LabelMessageandColor(Label1, objCommonName.ProcessDateRequired,
                                                                       System.Drawing.Color.Red);
                                    toDateTextBox.Focus();
                                    return;
                                }
                                else if (drpSeason.SelectedIndex == 0)
                                {
                                    objCommonName.LabelMessageandColor(Label1, objCommonName.SeasonNameRequired,
                                                                       System.Drawing.Color.Red);
                                }
                                else
                                {
                                    AddManualEntry();
                                    clearall();
                                    if (ReturningValue.rtnValue == 1)
                                    {
                                        objCommonName.LabelMessageandColor(Label1, objCommonName.SavedMessage.ToString(),
                                                                           System.Drawing.Color.Green);
                                        Refresh();
                                    }
                                    else
                                        objCommonName.LabelMessageandColor(Label1,
                                                                           ReturningValue.rtnErrorMessage.ToString(),
                                                                           System.Drawing.Color.Red);

                                }
                            }
                            else
                                objCommonName.LabelMessageandColor(Label1, objCommonName.DateMessageforError,
                                                                   System.Drawing.Color.Red);
                        }
                        else
                            objCommonName.LabelMessageandColor(Label1, objCommonName.PrevousProcess,
                                                               System.Drawing.Color.Red);
                    }
                    catch (Exception ex)
                    {
                        objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
                    }
                }
                else
                    objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
            else
            {
                Response.Redirect("Welcomepage.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

    }

    #endregion

    #region Event Handlers

    protected void deptDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = true;
        empIdDropDownList.Enabled = false;
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = true;
        objCommonName = new CommonName();
        //objCommonName.EmployeeTolTip(empIdDropDownList);         
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        deptDropDownList.Enabled = false;
        empIdDropDownList.Enabled = false;
    }
    protected void empIdDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
       // objCommonName.EmployeeTolTip(empIdDropDownList);
        EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
    }
    protected void fromDateTextBox_TextChanged(object sender, EventArgs e)
    {
        if (objCommonName.DatetimeCompare(fromDateTextBox.Text.Trim(), toDateTextBox.Text.Trim()) == 1)
            objCommonName.LabelReset(Label1);
        else
            objCommonName.LabelMessageandColor(Label1, objCommonName.DateMessageforError, System.Drawing.Color.Red);
    }
    protected void toDateTextBox_TextChanged(object sender, EventArgs e)
    {
        if (objCommonName.DatetimeCompare(fromDateTextBox.Text.Trim(), toDateTextBox.Text.Trim()) == 1)
            objCommonName.LabelReset(Label1);
        else
            objCommonName.LabelMessageandColor(Label1, objCommonName.DateMessageforError, System.Drawing.Color.Red);
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            CompId = int.Parse(ddlCompany.SelectedValue.ToString());
            DeptList(CompId);
            EmployeeList(CompId);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
   
    #endregion
}
