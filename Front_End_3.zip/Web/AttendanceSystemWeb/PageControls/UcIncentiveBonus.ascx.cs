﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;

public partial class PageControls_UcIncentiveBonus : System.Web.UI.UserControl
{
    public string name = null;
    DataTable dt;
    String Date = System.DateTime.Now.ToString();
    String ReportDateShow = "";
    CommonName objCommonName = new CommonName();
    Int32 CompId = 0;
    public string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.INSBONUS.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    CompId = int.Parse(CompDropDownList.SelectedValue.ToString());
                    DeptList(CompId);
                    EmployeeList(CompId);
                    objCommonName.Addmonth(drpMonth);
                    RadioButtonComp.Checked = false;
                    RadioButtonDepartment.Checked = false;
                    RadioButtonEmpId.Checked = false;
                    CompDropDownList.Enabled = false;
                    deptDropDownList.Enabled = false;
                    empIdDropDownList.Enabled = false;
                    LoadYear();
                    chkAmt.Checked = true;
                    chkPercent.Checked = false;
                    TextBRate.Text = "0";
                    TextBRate.ReadOnly = true;
                    TextBoxGross.Text = "";
                    RadioButtonComp.Checked = true;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(CompDropDownList, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void DeptList(Int32 CompId)
    {
        try
        {
            string strSQL = "select DeptName,Dept_Number from  tblDepartment where comp_number = " + CompId + "   order by DeptName asc";
            ClsCommon.drplistAdd(deptDropDownList, strSQL, "DeptName", "Dept_Number");
            deptDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void EmployeeList(Int32 CompId)
    {
        try
        {
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + CompId + " order by empId asc ";
            ClsCommon.drplistAdd(empIdDropDownList, strSQL, "EmpId", "Emp_Number");
            empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void LoadYear()
    {
        drpYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpYear.DataSource = li;
        drpYear.Items.AddRange(items.ToArray());
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            IncentiveBonus objIncentiveBonus = new IncentiveBonus();
            int i = 0;
            action = "Delete";
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.INSBONUS.ToString(), "D"))
            {
                foreach (GridViewRow oRow in mbBilAdGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                        objIncentiveBonus.Option = "";
                        objIncentiveBonus.Log = 1;
                        objIncentiveBonus.Gross = 0;
                        objIncentiveBonus.Bonus = 0;
                        objIncentiveBonus.Date = System.DateTime.Now;
                        objIncentiveBonus.Machine = "";
                        objIncentiveBonus.MonthNumber = 0;
                        objIncentiveBonus.OptionId = Convert.ToInt16(empIdDropDownList.SelectedValue);
                        objIncentiveBonus.Month = Convert.ToString(mbBilAdGridView.Rows[i].Cells[2].Text);
                        objIncentiveBonus.Year = mbBilAdGridView.Rows[i].Cells[3].Text;
                        objIncentiveBonus.Action = action;
                        IncentiveBonusInsertData obj = new IncentiveBonusInsertData();
                        obj.IncentiveBonusdata = objIncentiveBonus;
                        obj.InsertIncentiveBonus();

                    }
                    i++;
                }
                objCommonName.LabelMessageandColor(LabelSalary, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
            {
                objCommonName.LabelMessageandColor(LabelSalary, objCommonName.UnableProcess.ToString(),
                                                   System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
        string sql = "SELECT Gross,Bonus,MonthName,Year FROM tbl_IncentiveBonus where Emp_Number=" + Convert.ToString(empIdDropDownList.SelectedValue) + " order by Year,MonthNo DESC";
        DataSet IBonus = new DataSet();
        IBonus = ClsCommon.GetAdhocResult(sql);
        mbBilAdGridView.DataSource = IBonus.Tables[0];
        mbBilAdGridView.DataBind();
        action = "";
    }
    protected void btnProcess_Click(object sender, EventArgs e)
    {
         if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.INSBONUS.ToString(), "C"))
            {
                if(Validation())
                {
                    action = "Save";
                    IncentiveBonus objIncentiveBonus=new IncentiveBonus();
                    objIncentiveBonus.Action = action;
                    if(RadioButtonComp.Checked)
                    {
                        objIncentiveBonus.Option = "1";
                        objIncentiveBonus.OptionId = Convert.ToInt32(CompDropDownList.SelectedValue);
                    }
                    if (RadioButtonDepartment.Checked)
                    {
                        objIncentiveBonus.Option = "2";
                        objIncentiveBonus.OptionId = Convert.ToInt32(deptDropDownList.SelectedValue);
                    }
                    if (RadioButtonEmpId.Checked)
                    {
                        objIncentiveBonus.Option = "3";
                        objIncentiveBonus.OptionId = Convert.ToInt32(empIdDropDownList.SelectedValue);
                    }
                    objIncentiveBonus.Gross = 0;
                    if (chkPercent.Checked) { objIncentiveBonus.Log = 1; objIncentiveBonus.Bonus = int.Parse(TextBRate.Text); }
                    if (chkAmt.Checked) { objIncentiveBonus.Log = 2; objIncentiveBonus.Bonus = int.Parse(TextBoxAmt.Text); }
                    objIncentiveBonus.Month = drpMonth.SelectedItem.Text;
                    objIncentiveBonus.Year = drpYear.SelectedItem.Text;
                    objIncentiveBonus.MonthNumber = int.Parse(drpMonth.SelectedValue);
                    objIncentiveBonus.Date = System.DateTime.Now;
                    objIncentiveBonus.Machine = Convert.ToString(Session["EmpName"]);
                    IncentiveBonusInsertData obj = new IncentiveBonusInsertData();
                    obj.IncentiveBonusdata = objIncentiveBonus;
                    obj.InsertIncentiveBonus();
                    objCommonName.LabelMessageandColor(LabelSalary, objCommonName.SavedMessage, System.Drawing.Color.Green);
                    action = "";
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private bool Validation()
    {
        bool rtv = true;
        if(RadioButtonComp.Checked)
        {
            if(CompDropDownList.SelectedItem.Text=="Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(LabelSalary, "Select Company", System.Drawing.Color.Red);
            }
        }
        else if (RadioButtonDepartment.Checked)
        {
            if (deptDropDownList.SelectedItem.Text == "Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(LabelSalary, "Select Department", System.Drawing.Color.Red);
            }
        }
        else if (RadioButtonEmpId.Checked)
        {
            if (empIdDropDownList.SelectedItem.Text == "Select")
            {
                rtv = false;
                objCommonName.LabelMessageandColor(LabelSalary, "Select Employee", System.Drawing.Color.Red);
            }
        }
        else if (drpMonth.SelectedItem.Text == "Select")
        {
            rtv = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Month", System.Drawing.Color.Red);
        }
        if (drpYear.SelectedItem.Text == "Select")
        {
            rtv = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Select Year", System.Drawing.Color.Red);
        }
        else if (chkAmt.Checked && TextBoxAmt.Text=="0")
        {
            rtv = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Give Amount", System.Drawing.Color.Red);
        }
        else if (chkPercent.Checked && TextBRate.Text == "0" )
        {
            rtv = false;
            objCommonName.LabelMessageandColor(LabelSalary, "Give Amount", System.Drawing.Color.Red);
        }
        return rtv;
        
    }
    
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {

    }
    protected void CompDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            CompId = int.Parse(CompDropDownList.SelectedValue.ToString());
            DeptList(CompId);
            EmployeeList(CompId);
            
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void deptDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(CompDropDownList.SelectedValue.ToString()) + " and tblEmployee.Sect_Number=" + deptDropDownList.SelectedValue.ToString() + " order by EmpId";

            empIdDropDownList.Items.Clear();
            ClsCommon.drplistAdd(empIdDropDownList, strSQL, "EmpId", "EmpName");
            empIdDropDownList.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(LabelSalary, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void empIdDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {

        
        lblEmpname.Text = objCommonName.EmployeeName(empIdDropDownList.SelectedItem.Text); 
        EmployeeImage.LoadImageEmp(empIdDropDownList, tblIdMaster, EmpImage);
       
      
        string strSQL = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(empIdDropDownList.SelectedItem.Text) + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
        DataSet Gross = new DataSet();
        Gross = ClsCommon.GetAdhocResult(strSQL);
        if (Gross.Tables[0].Rows.Count != 0)
        {
            TextBoxGross.Text = Gross.Tables[0].Rows[0][0].ToString();
        }
        string sql = "SELECT Gross,Bonus,MonthName,Year FROM tbl_IncentiveBonus where Emp_Number=" + Convert.ToString(empIdDropDownList.SelectedValue)+ " order by Year,MonthNo DESC";
        DataSet IBonus = new DataSet();
        IBonus = ClsCommon.GetAdhocResult(sql);
        mbBilAdGridView.DataSource = IBonus.Tables[0];
        mbBilAdGridView.DataBind();
    }
    
    protected void RadioButtonComp_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButtonComp.Checked)
        {
            
            RadioButtonComp.Checked = true;
            RadioButtonDepartment.Checked = false;
            RadioButtonEmpId.Checked = false;
            CompDropDownList.Enabled = true;
            EmpImage.Visible = false;
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = false;
            deptDropDownList.SelectedItem.Text = "Select";
            empIdDropDownList.SelectedItem.Text = "Select";
            lblEmpname.Text = "";
            TextBoxGross.Text = "";
        }
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButtonDepartment.Checked)
        {
           
            RadioButtonComp.Checked = false;
            RadioButtonDepartment.Checked = true;
            RadioButtonEmpId.Checked = false;
            CompDropDownList.Enabled = false;
            deptDropDownList.Enabled = true;
            empIdDropDownList.Enabled = false;
            EmpImage.Visible = false;
            empIdDropDownList.SelectedItem.Text = "Select";
            lblEmpname.Text = "";
            TextBoxGross.Text = "";
        }
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButtonEmpId.Checked)
        {
            
            if (EmpImage.ImageUrl != null)
            {
                EmpImage.ImageUrl = null;
            }


            RadioButtonComp.Checked = false;
            RadioButtonDepartment.Checked = false;
            RadioButtonEmpId.Checked = true;
            EmpImage.Visible = true;
            CompDropDownList.Enabled = false;
            deptDropDownList.Enabled = false;
            empIdDropDownList.Enabled = true;
        }
    }
    protected void chkAmt_CheckedChanged(object sender, EventArgs e)
    {
        if(chkAmt.Checked)
        {
            chkPercent.Checked = false;
            chkAmt.Checked = true;
            TextBRate.ReadOnly = true;
            TextBoxAmt.ReadOnly = false;
            TextBRate.Text = "0";
            TextBoxAmt.Text = "0";
        }
    }

    protected void chkPercent_CheckedChanged(object sender, EventArgs e)
    {
        if(chkPercent.Checked)
        {
            chkAmt.Checked = false;
            chkPercent.Checked = true;
            TextBRate.ReadOnly = false;
            TextBoxAmt.ReadOnly = true;
            TextBRate.Text = "0";
            TextBoxAmt.Text = "0";
        }
    }
    protected void TextBRate_TextChanged(object sender, EventArgs e)
    {
        if(TextBoxGross.Text!="0" && TextBoxGross.Text!="")
        {
            float bonus = int.Parse(TextBoxGross.Text)*int.Parse(TextBRate.Text)/100;
            TextBoxAmt.Text = bonus.ToString();
        }
    }
    protected void mbBilAdGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void mbBilAdGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void mbBilAdGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void mbBilAdGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void drpMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(drpYear.SelectedItem.Text!="Select" && drpMonth.SelectedItem.Text!="Select" && empIdDropDownList.SelectedItem.Text!="Select")
        {
            string sql = "SELECT Gross,Bonus,MonthName,Year FROM tbl_IncentiveBonus where Emp_Number=" + Convert.ToString(empIdDropDownList.SelectedValue) + " and MonthName='" + drpMonth.SelectedItem.Text + "' and Year='"+drpYear.SelectedItem.Text + "' order by Year,MonthNo DESC";
            DataSet IBonus = new DataSet();
            IBonus = ClsCommon.GetAdhocResult(sql);
            mbBilAdGridView.DataSource = IBonus.Tables[0];
            mbBilAdGridView.DataBind();
        }
    }
    protected void drpYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpYear.SelectedItem.Text != "Select" && drpMonth.SelectedItem.Text != "Select" && empIdDropDownList.SelectedItem.Text != "Select")
        {
            string sql = "SELECT Gross,Bonus,MonthName,Year FROM tbl_IncentiveBonus where Emp_Number=" + Convert.ToString(empIdDropDownList.SelectedValue) + " and MonthName='" + drpMonth.SelectedItem.Text + "' and Year='" + drpYear.SelectedItem.Text + "' order by Year,MonthNo DESC";
            DataSet IBonus = new DataSet();
            IBonus = ClsCommon.GetAdhocResult(sql);
            mbBilAdGridView.DataSource = IBonus.Tables[0];
            mbBilAdGridView.DataBind();
        }
    }
}
