﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.BLL.CBF;
using AttendanceSystem.BLL.BikeLoan;
using AttendanceSystem.BLL.EmployeeLoan;
public partial class PageControls_ucEmpLoanSetup : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            
            loadEmployee();
            txtFromDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
            TextBoxEndDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
            TextBoxDuration.Text = "0";
            TextBoxPreLAmt.Text = "0";
            showGridView();
        }

    }
    private void showGridView()
    {
        string searchStr = "SELECT ELID,EmpId,LoanAmount,Duration,Instalment,Interest,CONVERT(varchar(10), ELoanSrtDate, 103) AS ELoanSrtDate,CONVERT(varchar(10), ELoanEndDate, 103) AS ELoanEndDate,ELLog FROM tbl_EmpLoanSetUp where ELLog=1 order by EmpId";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grdLoanSetup.DataSource = dsMonthDeduct.Tables[0];
        grdLoanSetup.DataBind();
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1  order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void grdLoanSetup_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdLoanSetup_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void grdLoanSetup_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void grdLoanSetup_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdLoanSetup_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOANSETUP.ToString(), "C"))
            {
                if (Validate())
                {
                    action = "save";
                    AddBikeLoanSetup();
                    objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                    showGridView();
                    action = "";

                }

                else
                {
                    //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }

            }
            else
                objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddBikeLoanSetup()
    {
        EmployeeLoanSetup objEmployeeLoanSetup = new EmployeeLoanSetup();
        objEmployeeLoanSetup.EmpId = drpEmpId.SelectedItem.Text;
        objEmployeeLoanSetup.LoanAmount = int.Parse(TextBoxTLoanAmt.Text);
        objEmployeeLoanSetup.Duration = int.Parse(TextBoxDuration.Text);
        objEmployeeLoanSetup.Instalment = int.Parse(TextBoxInst.Text);
        objEmployeeLoanSetup.ELoanSrtDate = Convert.ToDateTime(txtFromDate.Text);
        objEmployeeLoanSetup.ELoanEndDate = Convert.ToDateTime(TextBoxEndDate.Text);
        objEmployeeLoanSetup.ELLog = 1;
        objEmployeeLoanSetup.Action = action;
        ProcessEmployeeLoanInsert objProcessEmployeeLoanInsert = new ProcessEmployeeLoanInsert();
        objProcessEmployeeLoanInsert.EmployeeLoanSetupIN = objEmployeeLoanSetup;
        objProcessEmployeeLoanInsert.invoke();
    }
    private bool Validate()
    {
        bool retval = true;
        if (drpEmpId.SelectedIndex == 0)
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpLoanSetup, "Select Employee", System.Drawing.Color.Red);
         return retval;
        }
     
        else if (TextBoxDuration.Text == "0")
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpLoanSetup, "Give Duration", System.Drawing.Color.Red);
            return retval;
        }
        string searchStr = "select ELID from tbl_EmpLoanSetUp where EmpId='"+drpEmpId.SelectedItem.Text+"'and LoanTopLog=1";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grdLoanSetup.DataSource = dsMonthDeduct.Tables[0];
        if (dsMonthDeduct.Tables[0].Rows.Count != 0 && TextBoxPreLAmt.Text!="0")
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelEmpLoanSetup,drpEmpId.SelectedItem.Text+ " no permission to pop up loan", System.Drawing.Color.Red);
            return retval;
        }
        return retval;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            action = "Update";
            AddBikeLoanSetup();
            objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
            drpEmpId.Enabled = true;
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
            showGridView();
       

           
        }
        catch (Exception ex)
        {
            //objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ClearAll();
    }

    private void ClearAll()
    {
        drpEmpId.SelectedValue="NA";
        EmpNameTxtBox.Text = "";
        TextBoxEmpGross.Text = "";
        TextBoxPreLAmt.Text = "0";
        TextBoxLAmt.Text = "";
        TextBoxDuration.Text = "0";
        TextBoxInst.Text = "";
        TextBoxTLoanAmt.Text = "0";
        txtFromDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        TextBoxEndDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        labelEmpLoanSetup.Text = "";
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        string searchStr = "SELECT ELID,EmpId,LoanAmount,Duration,Instalment,Interest,CONVERT(varchar(10), ELoanSrtDate, 103) AS ELoanSrtDate,CONVERT(varchar(10), ELoanEndDate, 103) AS ELoanEndDate,ELLog FROM tbl_EmpLoanSetUp where ELLog=1 and EmpId like '%" + txtSearch.Text + "%' order by EmpId";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grdLoanSetup.DataSource = dsMonthDeduct.Tables[0];
        grdLoanSetup.DataBind();
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOANSETUP.ToString(), "U"))
            {

                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in grdLoanSetup.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadBikeLoanInt(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadBikeLoanInt(string id, int row)
    {
        try
        {

            drpEmpId.SelectedItem.Text = grdLoanSetup.Rows[row].Cells[0].Text;
            EmpNameTxtBox.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
            string strSQL1 = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
            DataSet Gross = new DataSet();
            Gross = ClsCommon.GetAdhocResult(strSQL1);
            if (Gross.Tables[0].Rows.Count != 0)
            {
                TextBoxEmpGross.Text = Gross.Tables[0].Rows[0][0].ToString();
            }
            TextBoxPreLAmt.Text = "0";
            TextBoxLAmt.Text = grdLoanSetup.Rows[row].Cells[1].Text;
            TextBoxTLoanAmt.Text = "0";
            TextBoxDuration.Text = grdLoanSetup.Rows[row].Cells[2].Text;
            TextBoxInst.Text = grdLoanSetup.Rows[row].Cells[3].Text;
            txtFromDate.Text = grdLoanSetup.Rows[row].Cells[4].Text;
            TextBoxEndDate.Text = grdLoanSetup.Rows[row].Cells[5].Text;
         }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelEmpLoanSetup, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOANSETUP.ToString(), "D"))
            {
                EmployeeLoanSetup objEmployeeLoanSetup = new EmployeeLoanSetup();
                objEmployeeLoanSetup.Action = "delete";
                objEmployeeLoanSetup.ELLog = 0;
                objEmployeeLoanSetup.ELoanEndDate=System.DateTime.Now;
                objEmployeeLoanSetup.ELoanSrtDate = System.DateTime.Now;
                foreach (GridViewRow oRow in grdLoanSetup.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                        
                        objEmployeeLoanSetup.EmpId = grdLoanSetup.Rows[i].Cells[0].Text;
                        ProcessEmployeeLoanInsert ProcessEmployeeLoanInsertD = new ProcessEmployeeLoanInsert();
                        ProcessEmployeeLoanInsertD.EmployeeLoanSetupIN = objEmployeeLoanSetup;
                        ProcessEmployeeLoanInsertD.invoke();

                    }
                    i++;
                }
                objEmployeeLoanSetup.Action = "";
                showGridView();
                objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelEmpLoanSetup, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void BikeLmintGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLmintGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BikeLmintGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void BikeLmintGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLmintGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxTLoanAmt.Text = "0";
        EmpNameTxtBox.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        string strSQL = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
        string SQLDUE = "select (isnull((select LoanAmount from tbl_EmpLoanSetUp  where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ELLog=1)-(isnull(sum(A.Installment),0) + isnull(sum(A.Adjustment),0)),0)) as DueLoan FROM tbl_EmpLoanAdj A inner join tbl_EmpLoanSetUp B on B.EmpId=A.EmpId and B.ELLog=1 where A.EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and A.InstLog=1 and A.ELID=(select ELID from tbl_EmpLoanSetUp  where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ELLog=1)";
        DataSet Gross = new DataSet();
        DataSet Due = new DataSet();
        Due = ClsCommon.GetAdhocResult(SQLDUE);
        Gross = ClsCommon.GetAdhocResult(strSQL);
        if (Gross.Tables[0].Rows.Count != 0)
        {
            TextBoxEmpGross.Text = Gross.Tables[0].Rows[0][0].ToString();
        }
        TextBoxPreLAmt.Text = Due.Tables[0].Rows[0][0].ToString(); ;
        TextBoxLAmt.Text = "";
        TextBoxDuration.Text = "0";
        TextBoxInst.Text = "";
        txtFromDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        TextBoxEndDate.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        labelEmpLoanSetup.Text = "";
    }
    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        if (txtFromDate.Text != "" && TextBoxDuration.Text!="")
        {
            int month = int.Parse(TextBoxDuration.Text);
            DateTime dtshow = new DateTime();
            dtshow=Convert.ToDateTime(txtFromDate.Text);
            TextBoxEndDate.Text = Convert.ToString(dtshow.AddMonths(month-1)).Substring(0, 10);
        }
    }
    protected void TextBoxLAmt_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxLAmt.Text != "")
        {
            TextBoxTLoanAmt.Text = (int.Parse(TextBoxLAmt.Text) + int.Parse(TextBoxPreLAmt.Text)).ToString();
        
        }
    }
    protected void TextBoxDuration_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxTLoanAmt.Text != "" && TextBoxDuration.Text!="")
        {
            if (TextBoxDuration.Text != "0")
            {
                TextBoxInst.Text = numberstring((int.Parse(TextBoxTLoanAmt.Text) / int.Parse(TextBoxDuration.Text)).ToString());
            }

        }
    }
    private string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }

}
