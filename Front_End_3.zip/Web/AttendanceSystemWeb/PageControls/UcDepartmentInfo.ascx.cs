﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;

public partial class PageControls_UcDepartmentInfo : System.Web.UI.UserControl
{
    #region Declaration

    private Department _Dept;
    Int32 CompId = 0;
    CommonName objCommonName = new CommonName();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DEPARTMENTSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    string delID = Request.QueryString["DelID"];
                    if (delID != null)
                    {
                        deleteDepartment(delID.Trim());
                    }
                    loadItem();

                    CompId = Int32.Parse(drplist.SelectedValue.ToString());
                    Departmentlist(CompId);

                    Session["NotReadPermission"] = null;
                }
                loadlist();
                Label1.Visible = false;
                btnUpdate.Enabled = false;
                btnSave.Enabled = true;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    public void AddDepartment()
    {
        try
        {
            _Dept = new Department();
            _Dept.DeptId = txtId1.Text.Trim();
            _Dept.DeptName = txtDepartment.Text.Trim();
            _Dept.Entryby = 1;
            _Dept.PC = System.Net.Dns.GetHostName().ToString();
            _Dept.CompNo = drplist.SelectedItem.Value;

            ProcessDepartmentInsert prcdept = new ProcessDepartmentInsert();
            prcdept.Dept = _Dept;
            prcdept.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void deleteDepartment(string delID)
    {
        Department DepD = new Department();
        try
        {
            DepD.DeptNo = Convert.ToInt32(delID);
            ProcessDepartmentDelete PDeptD = new ProcessDepartmentDelete();
            PDeptD.Dept = DepD;
            PDeptD.invoke();
            hidUpdateID.Value = "";
            objCommonName.LabelMessageandColor(Label1, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            Departmentlist(CompId);
            drplist.Enabled = true;
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }
    private bool isValidData()
    {
        if ((txtId1.Text.Trim().Equals("")) || (txtDepartment.Text.Trim().Equals("")))
        {
            txtId1.Focus();
            txtDepartment.Focus();
            objCommonName.LabelMessageandColor(Label1, "Department " + objCommonName.IdorNameRequired.ToString(), System.Drawing.Color.Red);
            return false;
        }
        else
        {
            return true;
        }
    }
    public void loadItem()
    {
        try
        {
            string strSQL = "Select Comp_Number,CompName,CompId from tblCompany ";
            ClsCommon.drplistAdd(drplist, strSQL, "CompName", "Comp_Number");
            //drplist.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void loadDepartment(string id, string compID)
    {
        DataTable dt = new DataTable();
        try
        {
            if (Session["DepartmentDS"] != null)
            {
                dt = (DataTable)Session["DepartmentDS"];

                foreach (DataRow dr in dt.Rows)
                {
                    if (dr[0].ToString() == id)
                    {
                        txtId1.Text = dr["DeptId"].ToString();
                        txtDepartment.Text = dr["DeptName"].ToString();
                    }
                }
                for (int x = 0; x < drplist.Items.Count; x++)
                {
                    string strValue = drplist.Items[x].Value.Trim();
                    if (strValue == compID)
                    {
                        drplist.SelectedValue = compID;
                        drplist.Enabled = false;
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void clearall()
    {
        txtId1.Text = "";
        txtDepartment.Text = "";
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
    }
    protected void Departmentlist(Int32 CompId)
    {
        try
        {
            ReportData objReportData = new ReportData();
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            DataSet ds = new DataSet();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = StoredProcedure.Name.sp_Department_Select.ToString();

            cmd.Parameters.AddWithValue("@CompId", CompId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(ds);

            Session["DepartmentDS"] = ds.Tables[0];
            grdDepartment.DataSource = ds.Tables[0];
            grdDepartment.DataBind();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);

        }

    }
    protected void UpdateDepartment()
    {
        try
        {
            _Dept = new Department();
            _Dept.DeptNo = int.Parse(hidUpdateID.Value);
            _Dept.DeptId = txtId1.Text.Trim();
            _Dept.DeptName = txtDepartment.Text.Trim();
            _Dept.Entryby = 1;
            _Dept.PC = System.Net.Dns.GetHostName().ToString();
            _Dept.CompNo = drplist.SelectedValue;

            ProcessDepartmentUpdate pcd = new ProcessDepartmentUpdate();
            pcd.Dept = _Dept;
            pcd.invoke();
            hidUpdateID.Value = "";
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void SearchDept(Int32 CompId)
    {
        string Searchquery;
        try
        {

            if (drpDept.SelectedIndex == 0)
                objCommonName.LabelMessageandColor(Label1,objCommonName.SearchItem.ToString(), System.Drawing.Color.Red);

            if (drpDept.SelectedIndex == 1)
            {
                Searchquery = "Select Dept_Number,DeptId,DeptName,Comp_Number From tblDepartment Where Comp_Number = " + CompId + " and DeptId like '%" + txtSearch.Text + "%'";
               
                DataSet ds = new DataSet();
                ds = ClsCommon.GetAdhocResult(Searchquery);
                hidEditCheckedIDS.Value = "";
                grdDepartment.DataSource = null;
                grdDepartment.DataSource = ds;
                grdDepartment.DataBind();
            }
            else if (drpDept.SelectedIndex == 2)
            {
                Searchquery = "Select Dept_Number,DeptId,DeptName,Comp_Number From tblDepartment Where Comp_Number = " + CompId + " and DeptName like '%" + txtSearch.Text + "%'";
                
                DataSet ds = new DataSet();
                ds = ClsCommon.GetAdhocResult(Searchquery);
                hidEditCheckedIDS.Value = "";
                grdDepartment.DataSource = null;
                grdDepartment.DataSource = ds;
                grdDepartment.DataBind();
            }
            else
                objCommonName.LabelMessageandColor(Label1, objCommonName.InvalidSearchItem.ToString(), System.Drawing.Color.Red);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadlist()
    {
        try
        {
            drpDept.Items.Clear();
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
            drpDept.Items.Insert(1, new ListItem("ID", "ID"));
            drpDept.Items.Insert(2, new ListItem("Name", "Name"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadFormGrid()
    {
        try
        {
            foreach (GridViewRow oRow in grdDepartment.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
                if (oCheckBoxEdit.Checked)
                {
                    HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");
                    HiddenField hComSID = (HiddenField)oRow.FindControl("hCompID");

                    hidUpdateID.Value = hDeptId1.Value;
                    loadDepartment(hDeptId1.Value, hComSID.Value);
                    btnSave.Enabled = false;
                    btnUpdate.Enabled = true;
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    #endregion

    #region Button Handlers

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DEPARTMENTSETUP.ToString(), "C"))
            {
                try
                {
                    string strSql = "Select DeptId From tblDepartment Where DeptId='" + txtId1.Text + "' and Comp_Number = " + Convert.ToInt32(drplist.SelectedValue.ToString()) + "";
                    string strSqlDeptName = "Select DeptName From tblDepartment Where DeptName='" + txtDepartment.Text + "' and Comp_Number = " + Convert.ToInt32(drplist.SelectedValue.ToString()) + "";
                    if (!ClsCommon.ItemCheck(strSql) || !ClsCommon.ItemCheck(strSqlDeptName))
                    {
                        if (!ClsCommon.ItemCheck(strSql))
                        {
                            if (!ClsCommon.ItemCheck(strSqlDeptName))
                            {
                                if (isValidData())
                                {
                                    AddDepartment();
                                    objCommonName.LabelMessageandColor(Label1, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                                    CompId = Int32.Parse(drplist.SelectedValue.ToString());
                                    Departmentlist(CompId);
                                    clearall();
                                }
                            }
                            else
                                objCommonName.LabelMessageandColor(Label1, "Name " + objCommonName.AlreadyExistMessage.ToString() , System.Drawing.Color.Red);
                        }
                        else
                            objCommonName.LabelMessageandColor(Label1, "This id " + objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
                    }
                    else
                        objCommonName.LabelMessageandColor(Label1, "This id and name " + objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void drplist_SelectedIndexChanged(object sender, EventArgs e)
    {
        CompId = Int32.Parse(drplist.SelectedValue.ToString());
        Departmentlist(CompId);

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            Departmentlist(CompId);
            clearall();
            drplist.Enabled = true;
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            UpdateDepartment();
            objCommonName.LabelMessageandColor(Label1, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
            clearall();
            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            Departmentlist(CompId);
            drplist.Enabled = true;
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            CompId = Int32.Parse(drplist.SelectedValue.ToString());
            SearchDept(CompId);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DEPARTMENTSETUP.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DEPARTMENTSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grdDepartment.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        hidUpdateID.Value = hDeptId1.Value;
                        deleteDepartment(hDeptId1.Value);
                    }
                }
            }
            else
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Button Click

    protected void grdDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void grdDepartment_PageIndexChanged(object sender, EventArgs e)
    {
    }
    protected void grdDepartment_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        CompId = Int32.Parse(drplist.SelectedValue.ToString());
        grdDepartment.PageIndex = e.NewPageIndex;
        Departmentlist(CompId);
    }
    protected void drpDeptId_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void grdDepartment_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

    #endregion
}
