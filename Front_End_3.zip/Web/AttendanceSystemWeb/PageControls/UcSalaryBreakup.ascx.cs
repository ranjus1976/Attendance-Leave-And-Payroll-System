﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_UcSalaryBreakup : System.Web.UI.UserControl
{
    private string UpDateTag = "";
    string ReportDateShow;
    string empWiseCBF = "";
    private SalaryBreakup salbreak = new SalaryBreakup();
    private string action = "";
    public DataSet SalaryBreakDS = new DataSet();
    public DataSet dsSalaryPay = new DataSet();
    CommonName objCommonName = new CommonName();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //ReportDateShow = Convert.ToString(System.DateTime.Now);
            //ReportDateShow = ReportDateShow.Substring(0, 10);
            //txtFromDate.Text = ReportDateShow;
            loadCompany();
            loadEmployee();
            BasicTextBox.ReadOnly = true;
            Session["SlabId"] = null;
            btnUpdate.Enabled = false;


        }
        //BasicTextBox.ReadOnly = true;
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and EmpStatus<>'Contractual' and Comp_Number=" + Convert.ToInt32(ddlCompany.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
        // ddlCompany.Items.Insert(0, new ListItem("Select", "NA"));
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
        Clear();
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextEmpName.Text = drpEmpId.SelectedValue.ToString();
        string id = Convert.ToString(drpEmpId.SelectedItem.Text);
        Session["EmpNameSal"] = drpEmpId.SelectedValue.ToString();
        Session["EmpIdSal"] = id;
        cbfhidden.Value = "";
        PictureUpload();
        showGridView(id);
        cbfhidden.Value = gretindividualCBF(id);

        showGridViewpay(id);
        //GrossTextBox.Text = "";
    }
    private void PictureUpload()
    {
        string path = "";
        String FullPath = "";
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        String Sql = "Select EmpFileName from tblEmployee where empId = '" + drpEmpId.SelectedItem.Text + "'";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        path = Convert.ToString(cmd.ExecuteScalar());
        if (path != "")
        {
            FullPath = "~/TextFile/" + path;
            EmpImage.ImageUrl = FullPath;
            /*Image test=;
             



            ImgEmpId.ImageUrl = FullPath;*/
        }
    }
    private string gretindividualCBF(string id)
    {
        string cbfvalue = "";
        string sqlCBF = "select Emp_Deposit_Amt from tbl_Emp_Wise_CBF_Entry where EmpID='" + id + "'";
        DataSet dsCBF = new DataSet();
        dsCBF = ClsCommon.GetAdhocResult(sqlCBF);

        if (dsCBF.Tables[0].Rows.Count != 0)
        {
            empWiseCBF = dsCBF.Tables[0].Rows[0][0].ToString();
        }
        if (empWiseCBF != "")
        {
            cbfvalue = empWiseCBF;
        }
        return cbfvalue;
    }

    private void showGridView(string id)
    {


        string searchStr = "SELECT EmpId,CONVERT(varchar(10), [ConfDate], 103) AS CDate,CONVERT(int, [Basic]) as Basic,CONVERT(int, [HouseRent]) as HouseRent,CONVERT(int, [MedicalAllow]) as MedicalAllow,CONVERT(int, [Gross]) as Gross,ISNULL(tbl_MbileCeling.MobileCeling, 0) AS MobileCeling,ConfDate FROM tblEmpSalInfo Left join tbl_MbileCeling on tbl_MbileCeling.SalId=tblEmpSalInfo.SalId where EmpId='" + id + "' order by ConfDate desc";

        SalaryBreakDS = ClsCommon.GetAdhocResult(searchStr);

        GridSalBreak.DataSource = SalaryBreakDS.Tables[0];
        GridSalBreak.DataBind();
        if (SalaryBreakDS.Tables[0].Rows.Count != 0)
        {
            string gross = numberstring((float.Parse(SalaryBreakDS.Tables[0].Rows[0]["Basic"].ToString()) +
            float.Parse(SalaryBreakDS.Tables[0].Rows[0]["HouseRent"].ToString()) +
            float.Parse(SalaryBreakDS.Tables[0].Rows[0]["MedicalAllow"].ToString())).ToString());
            GrossTextBox.Text = gross.ToString();
            BasicTextBox.Text = numberstring(SalaryBreakDS.Tables[0].Rows[0]["Basic"].ToString());
            HRentTextBox.Text = numberstring(SalaryBreakDS.Tables[0].Rows[0]["HouseRent"].ToString());
            MedicalTimeTextBox.Text = numberstring(SalaryBreakDS.Tables[0].Rows[0]["MedicalAllow"].ToString());
            CBFTextBox.Text = GetCBF(); //numberstring(SalaryBreakDS.Tables[0].Rows[0]["CBF"].ToString());
            txtFromDate.Text = SalaryBreakDS.Tables[0].Rows[0]["CDate"].ToString();
            MobCText.Text = SalaryBreakDS.Tables[0].Rows[0]["MobileCeling"].ToString();
           


        }
        else
        {
            BasicTextBox.Text = "";
            HRentTextBox.Text = "";
            MedicalTimeTextBox.Text = "";
            CBFTextBox.Text = "";
            txtFromDate.Text = "";
            GrossTextBox.Text = "";
            MobCText.Text = "0";
        }
    }
    protected string GetCBF()
    {
        string cbfvalue = "";
        string sqlCBF = "select StartingRange,ClosingRange,EmpDipositAmt from tbl_Salary_Slab order by StartingRange";
        DataSet dsCBF = new DataSet();
        dsCBF = ClsCommon.GetAdhocResult(sqlCBF);
        if (GrossTextBox.Text.ToString() != "")
        {
            string id = Convert.ToString(drpEmpId.SelectedItem.Text);
            empWiseCBF = gretindividualCBF(id);
            int gross = int.Parse(GrossTextBox.Text.ToString());
            if (empWiseCBF == "")
            {
                foreach (DataRow dtRow in dsCBF.Tables[0].Rows)
                {
                    int s = int.Parse(numberstring(dtRow["StartingRange"].ToString()));
                    int c = int.Parse(numberstring(dtRow["ClosingRange"].ToString()));
                    if (s <= gross && c >= gross)
                    {
                        empWiseCBF = dtRow["EmpDipositAmt"].ToString();
                    }
                }


            }

        }

        return numberstring(empWiseCBF);
    }
    private void showGridViewpay(string id)
    {
        string yera = Convert.ToString(System.DateTime.Now);
        yera = yera.Substring(6, 4);
        string searchStr = "select EmpId,MonthName,YearName,CONVERT(int,Basic) as Basic,CONVERT(int, HouseRent) as HouseRent, CONVERT(int, Medical) as MedicalAllow,CONVERT(int, (CBF+MobileDeduct+BloanDeduct+EloanDeduct+OtherDeduct)) as TotalDeduct,CONVERT(int,(Gross)) as Gross,CONVERT(int,NetPayable) as PaySal from tbl_PaySlip where EmpId='" + id + "' and YearName='" + yera + "' order by MonthNumberP ASC";
        dsSalaryPay = ClsCommon.GetAdhocResult(searchStr);
        grvSalaryPay.DataSource = dsSalaryPay.Tables[0];
        grvSalaryPay.DataBind();

    }
    protected void GridSalBreak_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void GridSalBreak_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void GridSalBreak_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "U"))
            {
                UpDateTag = "SalBrk";
                txtFromDate.Enabled = true;
                drpEmpId.Enabled = false;
                ddlCompany.Enabled = false;
                btnUpdate.Enabled = true;
                btnSave.Enabled = false;
                loadFormGridSalBreak();
            }
            else
            {
            }
            // objCommonName.LabelMessageandColor(Label5, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnDel_Click(object sender, EventArgs e)
    {

    }

    protected void grvSalaryPay_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvSalaryPay_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void grvSalaryPay_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        /*if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS1.Value = hidEditCheckedIDS1.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS1.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS1.Value = hidEditCheckedIDS1.Value.TrimStart(',');
        }*/
    }
    protected void grvSalaryPay_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvSalaryPay_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnREdit1_Click(object sender, EventArgs e)
    {

    }
    private void loadFormGridSalBreak()
    {

        foreach (GridViewRow gvrow in GridSalBreak.Rows)
        {

            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[1].Text;
                loadSalaryBreakUp(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }

    }
    private void loadSalaryBreakUp(string id, int row)
    {

        try
        {

            MobCText.Text = loadEmp(id);
            //.Text = dr["SalarySlabID"].ToString();
            //.Text = numberstring(dr["StartingRange"].ToString());
            GrossTextBox.Text = GridSalBreak.Rows[row].Cells[2].Text;
            BasicTextBox.Text = GridSalBreak.Rows[row].Cells[3].Text;
            HRentTextBox.Text = GridSalBreak.Rows[row].Cells[4].Text;
            MedicalTimeTextBox.Text = GridSalBreak.Rows[row].Cells[5].Text;
            CBFTextBox.Text = GetCBF();//GridSalBreak.Rows[row].Cells[6].Text;
            txtFromDate.Text = GridSalBreak.Rows[row].Cells[1].Text;
            DataSet dsSalaryId=new DataSet();
            string Sql = "select SalId from tblEmpSalInfo where EmpId='" + drpEmpId.SelectedItem.Text + "' and ConfDate=convert(datetime,'" + GridSalBreak.Rows[row].Cells[1].Text + "', 103) and Gross=" + GridSalBreak.Rows[row].Cells[2].Text;
            dsSalaryId = ClsCommon.GetAdhocResult(Sql);
            if (dsSalaryId!=null)
            {
                Session["SlabId"] = dsSalaryId.Tables[0].Rows[0][0].ToString();
            }
            else
            {
                Session["SlabId"] = null;    
            }
            



        }
        catch (Exception ex)
        {
            //objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private string loadEmp(string id)
    {
        string MobCeling = "";
        string strSQL = "Select EmpId,EmpName from tblEmployee where EmpId= '" + Session["EmpIdSal"] + "'";
        DataSet dsEmp = new DataSet();
        dsEmp = ClsCommon.GetAdhocResult(strSQL);

        if (dsEmp.Tables[0].Rows.Count != 0)
        {
            drpEmpId.SelectedValue = dsEmp.Tables[0].Rows[0][1].ToString();
            drpEmpId.Enabled = false;
            txtFromDate.ReadOnly = false;
            TextEmpName.Text = dsEmp.Tables[0].Rows[0][1].ToString();
        }
        strSQL = "SELECT MobileCeling FROM tblEmpSalInfo Left join tbl_MbileCeling on tbl_MbileCeling.SalId=tblEmpSalInfo.SalId where ConfDate=convert(datetime,'" + id + "',103) and EmpId='" + drpEmpId.SelectedItem.Text + "'";
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = strSQL;
        MobCeling = Convert.ToString(cmd.ExecuteScalar());
        if (MobCeling == "")
        {
            MobCeling = "0";
        }
        return MobCeling;
    }

    protected void btnDel1_Click(object sender, EventArgs e)
    { }
    protected void GrossTextBox_TextChanged(object sender, EventArgs e)
    {
        string cbfvalue = "";
        string sqlCBF = "select StartingRange,ClosingRange,EmpDipositAmt from tbl_Salary_Slab order by StartingRange";
        DataSet dsCBF = new DataSet();
        dsCBF = ClsCommon.GetAdhocResult(sqlCBF);
        if (GrossTextBox.Text.ToString() != "")
        {
            string id = Convert.ToString(drpEmpId.SelectedItem.Text);
            empWiseCBF = gretindividualCBF(id);
            int gross = int.Parse(GrossTextBox.Text.ToString());
            if (empWiseCBF == "")
            {
                foreach (DataRow dtRow in dsCBF.Tables[0].Rows)
                {
                    int s = int.Parse(numberstring(dtRow["StartingRange"].ToString()));
                    int c = int.Parse(numberstring(dtRow["ClosingRange"].ToString()));
                    if (s <= gross && c >= gross)
                    {
                        empWiseCBF = dtRow["EmpDipositAmt"].ToString();
                    }
                }


            }

        }


        int GrossValue = int.Parse(GrossTextBox.Text.ToString());
        int basicn = int.Parse(numberstring((int.Parse(GrossTextBox.Text) * .6).ToString())); ;
        int houserent = int.Parse(numberstring((basicn * .5).ToString()));
        int medical = GrossValue - (basicn + houserent);
        BasicTextBox.Text = basicn.ToString();
        HRentTextBox.Text = houserent.ToString();
        MedicalTimeTextBox.Text = medical.ToString();
        CBFTextBox.Text = numberstring(empWiseCBF);
    }

    private string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "C"))
            {
                string strSql = "SELECT CONVERT(varchar(10), [ConfDate], 103) AS 'ConfDate' FROM tblEmpSalInfo Left join tbl_MbileCeling on tbl_MbileCeling.SalId=tblEmpSalInfo.SalId where EmpId='" + drpEmpId.SelectedItem.Text + "' and ConfDate>GETDATE() order by ConfDate DESC";

                if (!ClsCommon.ItemCheck(strSql))
                {

                    if (GrossTextBox.Text.ToString() != null)
                    {
                        if (isValidData())
                        {
                            action = "save";
                            AddSalarySlab();
                            SalaryBreakLabel.Visible = true;
                            SalaryBreakLabel.ForeColor = System.Drawing.Color.Green;
                            SalaryBreakLabel.Text = "Data saved successful.";

                            showGridView(Session["EmpIdSal"].ToString());
                            showGridViewpay(Session["EmpIdSal"].ToString());

                            Session["EmpIdSal"] = "";
                            Session["EmpNameSal"] = "";
                            //Showdata();
                            /*CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                            BindGrid(CompId);
                            ClearData();
                            ddlCompany.Enabled = true;
                            DDLEmpName.Enabled = true;*/


                        }
                    }
                    else
                    {
                        SalaryBreakLabel.Visible = true;
                        SalaryBreakLabel.ForeColor = System.Drawing.Color.Red;
                        SalaryBreakLabel.Text = "Give Starting or Closing Rang!";
                    }
                }
                else
                {
                    objCommonName.LabelMessageandColor(SalaryBreakLabel, "Salary alreary setup for next increament", System.Drawing.Color.Red);
                }
            }
            else
            {
                SalaryBreakLabel.Visible = true;
                SalaryBreakLabel.ForeColor = System.Drawing.Color.Red;
                SalaryBreakLabel.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddSalarySlab()
    {
        Session["EmpIdSal"] = Convert.ToString(drpEmpId.SelectedItem.Text);
        Session["EmpNameSal"] = TextEmpName.Text;
        salbreak.EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
        salbreak.Gross = int.Parse(GrossTextBox.Text);
        salbreak.Basic = int.Parse(BasicTextBox.Text);
        salbreak.HouseRent = int.Parse(HRentTextBox.Text);
        salbreak.MedicalAllow = int.Parse(MedicalTimeTextBox.Text);
        if (Session["SlabId"] != null)
        {
            salbreak.CBF = int.Parse(Session["SlabId"].ToString());
        }
        salbreak.ConfDate = txtFromDate.Text;
        if (MobCText.Text != "")
        {
            salbreak.MobileCeling = int.Parse(MobCText.Text);
        }
        else
        {
            salbreak.MobileCeling = 0;
        }
        salbreak.Actiction = action;
        ProcessSalaryBreakUpInsert ProcSalBr = new ProcessSalaryBreakUpInsert();
        ProcSalBr.salarybreakup = salbreak;
        ProcSalBr.invoke();


    }
    private bool isValidData()
    {
        bool retv = true;
        DateTime FromDate = Convert.ToDateTime(txtFromDate.Text.Trim());
        double t = (System.DateTime.Now.Date - FromDate.Date).TotalDays;

        if (GrossTextBox.Text == "")
        {
            retv = false;
            objCommonName.LabelMessageandColor(SalaryBreakLabel, "Give Gross", System.Drawing.Color.Red);
        }
        else if (MobCText.Text == "")
        {
            retv = false;
            objCommonName.LabelMessageandColor(SalaryBreakLabel, "Give Mobile Celling", System.Drawing.Color.Red);
        }
        
        else if (t >= 40 && Session["UserType"].ToString() == "SUPERADMIN")
        {
           
            retv = false;
             objCommonName.LabelMessageandColor(SalaryBreakLabel, "Give Correct Date", System.Drawing.Color.Red);
            //if ((System.DateTime.Now).ToString().Substring(0, 10) == txtFromDate.Text.Trim())
            //{
            //    retv = true;
            //    SalaryBreakLabel.Text = "";
            //}
             if (Session["ViolateRule"]!=null)
           {
               if (Session["ViolateRule"].ToString() == "Violate Rule")
               {
                   retv = true;
                   objCommonName.LabelMessageandColor(SalaryBreakLabel, "", System.Drawing.Color.Red);
               }
           }
        }
        
        return retv;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "U"))
        { 
            try
            {
                if (isValidData())
                {
                    action = "Update";
                    AddSalarySlab();
                    objCommonName.LabelMessageandColor(SalaryBreakLabel, objCommonName.UpdateMessage.ToString(),
                                                       System.Drawing.Color.Green);
                    //clearall();
                    //CompId = Int32.Parse(drplist.SelectedValue.ToString());
                    //Departmentlist(CompId);
                    txtFromDate.Enabled = true;
                    drpEmpId.Enabled = true;
                    ddlCompany.Enabled = true;
                    btnUpdate.Enabled = false;
                    btnSave.Enabled = true;
                    showGridView(Session["EmpIdSal"].ToString());
                    showGridViewpay(Session["EmpIdSal"].ToString());
                    Session["SlabId"] = null;
                    Session["EmpIdSal"] = "";
                    Session["EmpNameSal"] = "";
                }
                else
                {
                    
                }
            }
            catch (Exception ex)
            {
                //objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
        {
            objCommonName.LabelMessageandColor(SalaryBreakLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();

    }

    private void Clear()
    {
        BasicTextBox.Text = "";
        HRentTextBox.Text = "";
        MedicalTimeTextBox.Text = "";
        CBFTextBox.Text = "";
        txtFromDate.Text = "";
        GrossTextBox.Text = "";
        drpEmpId.SelectedValue = "NA";
        txtFromDate.Text = "";
        TextEmpName.Text = "";
        GridSalBreak.DataSource = null;
        GridSalBreak.DataBind();
        grvSalaryPay.DataSource = null;
        grvSalaryPay.DataBind();
        SalaryBreakLabel.Text = "";
        MobCText.Text = "";
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}