﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Design;
using AttendanceSystem.Core;

public partial class PageControls_UcEmployee : System.Web.UI.UserControl
{
    String ReportDateShow = "";
    String TimeShow = "";
    private Employee _Emp;
    public Employee Emp
    {
        get { return _Emp; }
        set { _Emp = value; }
    }
    private string imageUrl = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATION.ToString(), "R"))
        {
            if (Session["LogIn"] != null)
            {
                if (!IsPostBack)
                {
                    clearall();
                    loadCompany();
                    loadDepartment();
                    loadShift();
                    loadDesignation();
                    InitialDataShow();
                    txtEmpId.ReadOnly = true;

                    if (Session["empId"] != null)
                    {
                        string id = Session["empId"].ToString();
                        LoadEmployee(id);
                        ShowData();
                        btnUpdate.Enabled = true;
                        btnSave.Enabled = false;
                    }
                    else
                    {
                        clearall();
                        Session["NotReadPermission"] = null;
                        btnUpdate.Enabled = false;
                       // txtEmpId.ReadOnly = false;
                        btnSave.Enabled = true;
                    }
                }                
            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Session["NotReadPermission"] = "NotReadPermission";
            Response.Redirect("Default.aspx");
        }
    }

    #region Private Methods

    private Int32 SelectSectionasPerDepartment()
    {
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        String Sql = "Select Sect_Number from tblDepartment inner join tblSection on tblDepartment.Dept_number = tblSection.Dept_Number where tblDepartment.Dept_Number = " + drpSection.SelectedValue + " ";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        Int32 SectNumber = Convert.ToInt32(cmd.ExecuteScalar());
        return SectNumber;
    }
    private void InitialDataShow()
    {
        ReportDateShow = Convert.ToString(System.DateTime.Now);
        TimeShow = ReportDateShow.Substring(11, 5);
        ReportDateShow = ReportDateShow.Substring(0, 10);
        txtJoiningDate.Text = ReportDateShow;
        txtDateOfBirth.Text = ReportDateShow;
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany ";
        ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
        //ddlCompany.Items.Insert(0, new ListItem("Select", "NA"));
    }
    public string GetImage()
    {
        String strFileName = "";
        String strFileNameFinal = "";
        String FilePath = "";
        String FakeName = "";
        string[] FakeName2;
        string[] FakeName3;
        string[] FakeName1;
        string[] BFileName;
        String FinalStringForeFileName = "";
        //Session["FinalStringForeFileName"] = null;

        if (flUploadEmployee.HasFile)
        {
            strFileName = flUploadEmployee.FileName.Substring(flUploadEmployee.FileName.LastIndexOf('\\') + 1);
            BFileName = strFileName.Split('.');

            FakeName = DateTime.Now.ToString();
            FakeName1 = FakeName.Split(' ');
            FakeName2 = FakeName1[0].Split('/');
            FakeName3 = FakeName1[1].Split(':');
            FinalStringForeFileName = FakeName2[0] + FakeName2[1] + FakeName2[2] + FakeName3[0] + FakeName3[1] + FakeName3[2] + BFileName[0] + "." + BFileName[1];

            FilePath = Server.MapPath("TextFile\\" + FinalStringForeFileName);
            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
            }
            flUploadEmployee.PostedFile.SaveAs(Server.MapPath("TextFile\\" + FinalStringForeFileName));
            Session["FinalStringForeFileName"] = FinalStringForeFileName;
        }
        else if (f1UploadDocumentory.HasFile)
        {
            strFileName = f1UploadDocumentory.FileName.Substring(f1UploadDocumentory.FileName.LastIndexOf('\\') + 1);
            strFileNameFinal = strFileName.Replace(' ', '_');
            BFileName = strFileNameFinal.Split('.');

            FakeName = DateTime.Now.ToString();
            FakeName1 = FakeName.Split(' ');
            FakeName2 = FakeName1[0].Split('/');
            FakeName3 = FakeName1[1].Split(':');
            FinalStringForeFileName = FakeName2[0] + FakeName2[1] + FakeName2[2] + FakeName3[0] + FakeName3[1] + FakeName3[2] + BFileName[0] + "." + BFileName[1];

            FilePath = Server.MapPath("TextFile\\" + FinalStringForeFileName);
            if (File.Exists(FilePath))
            {
                File.Delete(FilePath);
            }
            f1UploadDocumentory.PostedFile.SaveAs(Server.MapPath("TextFile\\" + FinalStringForeFileName));
            Session["FinalStringForDocumentoryFileName"] = FinalStringForeFileName;
        }

        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please browse a file first ";
        }

        return FinalStringForeFileName;
    }
    public void AddEmployee()
    {
        _Emp = new Employee();
        _Emp.EmpId = txtEmpId.Text.Trim();
        _Emp.CardId = txtCardId.Text.Trim();
        _Emp.EmpName = txtEmpName.Text.Trim();
        _Emp.EmpFName = txtFName.Text.Trim();
        _Emp.EmpMName = txtMName.Text.Trim();
        _Emp.PerAddress = txtperAdd.Text.Trim();
        _Emp.PreAddress = txtpreAdd.Text.Trim();
        _Emp.Tel = txtTel.Text.Trim();
        _Emp.EmergencyContact = txtEmargencyContact.Text.Trim();
        _Emp.MarSts = drpMaritial.Text.Trim();
        _Emp.Religion = txtReligion.Text.Trim();
        _Emp.BloodGroup = txtBlood.Text.Trim();
        _Emp.OT = drpOT.Text.Trim();
        _Emp.HusWifeName = txtSposeName.Text.Trim();
        _Emp.EmpStatus = drpEmpStatus.SelectedValue.ToString();
        if (drpSection.Text != "NA")
        {
            _Emp.Sect_Number = System.Convert.ToInt32(SelectSectionasPerDepartment());
        }
        if (drpShift.Text != "NA")
        {
            _Emp.Shift_Number = System.Convert.ToInt32(drpShift.SelectedItem.Value);
        }
        if (drpDesignation.Text != "NA")
        {
            _Emp.Desig_Number = System.Convert.ToInt32(drpDesignation.SelectedItem.Value);
        }
        _Emp.JDate = Convert.ToDateTime(txtJoiningDate.Text);
        if (txtConfirmationDate.Text == "" || txtConfirmationDate.Text == string.Empty)
        {
            _Emp.ConfDate = Convert.ToDateTime("01/01/1900");
        }
        else
        {
            if (txtConfirmationDateShow.Text != "")
            {
                _Emp.ConfDate = Convert.ToDateTime(txtConfirmationDateShow.Text);
            }
            else
            {

                Int32 ConfDate = Int32.Parse(txtConfirmationDate.Text.ToString());
                DateTime JoinDate = Convert.ToDateTime(txtJoiningDate.Text);
                _Emp.ConfDate = JoinDate.AddMonths(ConfDate);
            }
        }
        if (txtQuitDate.Text == "" || txtQuitDate.Text == string.Empty)
        {
            _Emp.QuitDate = Convert.ToDateTime("01/01/1900");
        }
        else
        {
            _Emp.QuitDate = Convert.ToDateTime(txtQuitDate.Text);
        }
        if (txtDateOfBirth.Text == "" || txtDateOfBirth.Text == string.Empty)
        {
            _Emp.BirthDate = Convert.ToDateTime("01/01/1900 00:00:00");
        }
        else
        {
            _Emp.BirthDate = Convert.ToDateTime(txtDateOfBirth.Text);
        }
        _Emp.EmpSts = 1;
        _Emp.EmpED = 1;
        if (drpSex.SelectedIndex != 0)
        {
            _Emp.MF = Convert.ToString(drpSex.SelectedValue.Trim());
            _Emp.FileName = Session["FinalStringForeFileName"].ToString();
            ProcessEmployeeInsert pe = new ProcessEmployeeInsert();
            pe.Emp = _Emp;
            pe.invoke();
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please select!";
        }

    }
    public void UpdateEmployee()
    {
        _Emp = new Employee();
        // _Emp.EmpNumber = Convert.ToInt16(Request.QueryString["id"]);
        string id = Session["empId"].ToString();
        _Emp.EmpNumber = int.Parse(id);
        _Emp.EmpId = txtEmpId.Text.Trim();
        _Emp.CardId = txtCardId.Text.Trim();
        _Emp.EmpName = txtEmpName.Text.Trim();
        _Emp.EmpFName = txtFName.Text.Trim();
        _Emp.EmpMName = txtMName.Text.Trim();
        _Emp.PerAddress = txtperAdd.Text.Trim();
        _Emp.PreAddress = txtpreAdd.Text.Trim();
        _Emp.EmergencyContact = txtEmargencyContact.Text.Trim();
        _Emp.Tel = txtTel.Text.Trim();
        _Emp.MarSts = drpMaritial.Text.Trim();
        _Emp.Religion = txtReligion.Text.Trim();
        _Emp.BloodGroup = txtBlood.Text.Trim();
        _Emp.OT = drpOT.Text.Trim();
        _Emp.HusWifeName = txtSposeName.Text.Trim();
        _Emp.Sect_Number = _Emp.Sect_Number = System.Convert.ToInt32(SelectSectionasPerDepartment());
        _Emp.Shift_Number = System.Convert.ToInt32(drpShift.SelectedItem.Value);
        _Emp.EmpStatus = drpEmpStatus.SelectedValue.ToString();
        if (drpDesignation.Text != "NA")
        {
            _Emp.Desig_Number = System.Convert.ToInt32(drpDesignation.SelectedItem.Value);
        }
        _Emp.JDate = Convert.ToDateTime(txtJoiningDate.Text);
        if (txtConfirmationDate.Text == "" && txtConfirmationDateShow.Text == string.Empty)
        {
            _Emp.ConfDate = Convert.ToDateTime("01/01/1900 00:00:00");
        }
        else
        {
            if (txtConfirmationDateShow.Text != "")
            {
                _Emp.ConfDate = Convert.ToDateTime(txtConfirmationDateShow.Text);
            }
            else
            {

                Int32 ConfDate = Int32.Parse(txtConfirmationDate.Text.ToString());
                DateTime JoinDate = Convert.ToDateTime(txtJoiningDate.Text);
                _Emp.ConfDate = JoinDate.AddMonths(ConfDate);
            }
        }
        if (txtQuitDate.Text == "" || txtQuitDate.Text == string.Empty)
        {
            _Emp.QuitDate = Convert.ToDateTime("01/01/1900 00:00:00");
        }
        else
        {
            _Emp.QuitDate = Convert.ToDateTime(txtQuitDate.Text);
        }
        if (txtDateOfBirth.Text == "" || txtDateOfBirth.Text == string.Empty)
        {
            _Emp.BirthDate = Convert.ToDateTime("01/01/1900 00:00:00");
        }
        else
        {
            _Emp.BirthDate = Convert.ToDateTime(txtDateOfBirth.Text);
        }
        if (drpSex.SelectedIndex != 0)
        {
            _Emp.MF = Convert.ToString(drpSex.SelectedValue.Trim());
            _Emp.FileName = Session["FinalStringForeFileName"].ToString();

            ProcessEmployeeUpdate peu = new ProcessEmployeeUpdate();
            peu.EmpUp = _Emp;
            peu.invoke();
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please select!";
        }
    }
    public void loadDepartment()
    {
        try
        {
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_Number = " + Int32.Parse(ddlCompany.SelectedValue.ToString()) + " order by   DeptName ";
            ClsCommon.drplistAdd(drpSection, strSQL, "DeptName", "Dept_Number");
            drpSection.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadSection()
    {
        try
        {
            string strSQL = "Select Sect_Number, SectName from tblSection inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number where comp_Number = " + Int32.Parse(ddlCompany.SelectedValue.ToString()) + " order by   SectName ";
            ClsCommon.drplistAdd(drpSection, strSQL, "SectName", "Sect_Number");
            drpSection.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadShift()
    {
        try
        {
            string strSQL = "SELECT DISTINCT tbl_ShiftNameSettings.ShiftName,tbl_ShiftNameSettings.Shift_Number FROM tblShift INNER JOIN tbl_ShiftNameSettings ON tblShift.Shift_Number = tbl_ShiftNameSettings.Shift_Number";
            ClsCommon.drplistAdd(drpShift, strSQL, "ShiftName", "Shift_Number");
            drpShift.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDesignation()
    {
        try
        {
            string strSQL = "Select Desig_Number, DesigName from tblDesignation where Comp_Number=" + int.Parse(ddlCompany.SelectedValue.ToString()) + " ";
            ClsCommon.drplistAdd(drpDesignation, strSQL, "DesigName", "Desig_Number");
            drpDesignation.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private bool isValidData()
    {
        if (txtEmpId.Text.Trim().Equals(""))
        {
            Label1.Visible = true;
            Label1.Text = "Employee id required.";
            txtEmpId.Focus();
            return false;

        }
        else if (txtEmpName.Text.Trim().Equals(""))
        {
            Label1.Visible = true;
            Label1.Text = "Employee name required.";
            txtEmpName.Focus();
            return false;
        }
        else if (drpEmpStatus.SelectedItem.Text.Trim() == "Select")
        {
            Label1.Visible = true;
            Label1.Text = "Employee Status required.";
            txtEmpName.Focus();
            return false;
        }
        else if (drpSection.Text.Trim().Equals(""))
        {
            Label1.Visible = true;
            Label1.Text = "Department name required.";
            drpSection.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    private void LoadEmployee(string id)
    {
        Session["FinalStringForeFileName"] = null;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        if (Session["EmployeeDS"]!=null)
        {
        ds = (DataSet)Session["EmployeeDS"];
        dt = ds.Tables[0];
        foreach (DataRow dr in dt.Rows)
        {
            if (dr[0].ToString() == id)
            {
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                txtEmpId.Text = dr[1].ToString().Trim();
                txtCardId.Text = dr[2].ToString().Trim();
                txtEmpName.Text = dr[3].ToString().Trim();
                txtFName.Text = dr[4].ToString().Trim();
                txtMName.Text = dr[5].ToString().Trim();
                drpEmpStatus.SelectedValue = dr["EmpStatus"].ToString().Trim();
                string a = dr["EmpStatus"].ToString().Trim();
                String JoningDate = Convert.ToString(dr[6]).Trim();
                txtJoiningDate.Text = JoningDate.Substring(0, 10);

                String ConfirmDate = Convert.ToString(dr[7]).Trim();
                if (ConfirmDate == "01/01/1900 00:00:00" || ConfirmDate == "")
                {
                    txtConfirmationDateShow.Text = "";
                }
                else
                    txtConfirmationDateShow.Text = ConfirmDate.Substring(0, 10);


                String QuitDate = Convert.ToString(dr[28]).Trim();
                if (QuitDate == "01/01/1900 00:00:00" || QuitDate == "")
                {
                    txtQuitDate.Text = "";
                }
                else
                    txtQuitDate.Text = QuitDate.Substring(0, 10);

                String DOB = Convert.ToString(dr[8]).Trim();
                if (DOB == "" || DOB == "01/01/1900 00:00:00")
                {
                    txtDateOfBirth.Text = "";
                }
                else
                    txtDateOfBirth.Text = DOB.Substring(0, 10);

                txtpreAdd.Text = dr[9].ToString().Trim();
                txtperAdd.Text = dr[10].ToString().Trim();
                txtEmargencyContact.Text = dr[11].ToString().Trim();
                txtTel.Text = dr[12].ToString().Trim();
                drpSex.Text = dr[13].ToString().Trim();
                drpMaritial.Text = dr[14].ToString().Trim();
                txtReligion.Text = dr[15].ToString().Trim();
                txtBlood.Text = dr[16].ToString().Trim();
                drpOT.Text = dr[17].ToString().Trim();
                txtSposeName.Text = dr[27].ToString().Trim();
                Session["FinalStringForeFileName"] = dr[29].ToString();
                PictureUpload();

                if (!dr.IsNull("Comp_Number"))
                {
                    loadCompany();
                    ddlCompany.SelectedValue = dr["Comp_Number"].ToString().Trim();
                }
                else
                {
                    ListItem oListItem = new ListItem("", "");
                    ddlCompany.Items.Insert(0, oListItem);
                }

                if (!dr.IsNull("Desig_Number"))
                {
                    loadDesignation();
                    drpDesignation.SelectedValue = dr[20].ToString().Trim();
                }
                else
                {
                    ListItem oListItem = new ListItem("", "");
                    drpDesignation.Items.Insert(0, oListItem);
                }

                if (!dr.IsNull("Dept_Number"))
                {
                    loadDepartment();
                    drpSection.SelectedValue = dr["Dept_Number"].ToString().Trim();
                }
                else
                {
                    ListItem oListItem = new ListItem("", "");
                    drpSection.Items.Insert(0, oListItem);
                }

                if (!dr.IsNull("Shift_Number"))
                {
                    loadShift();
                    drpShift.SelectedValue = dr[19].ToString().Trim();
                }
                else
                {
                    ListItem oListItem = new ListItem("", "");
                    drpShift.Items.Insert(0, oListItem);
                }
            }
        }
        }
    }

    protected void clearall()
    {
        txtEmpName.Text = "";
        ddlCompany.SelectedIndex = 0;
        txtEmpId.Text = "";
        txtJoiningDate.Text = "";
        txtCardId.Text = "";
        txtConfirmationDate.Text = "";
        txtConfirmationDateShow.Text = "";
        drpSection.SelectedIndex = 0;
        txtQuitDate.Text = "";
        drpShift.SelectedIndex = 0;
        drpOT.SelectedIndex = 0;
        drpDesignation.SelectedIndex = 0;
        drpSex.SelectedIndex = 0;
        txtBlood.Text = "";
        drpMaritial.SelectedIndex = 0;
        txtTel.Text = "";
        txtEmargencyContact.Text = "";
        txtSposeName.Text = "";
        txtDateOfBirth.Text = "";
        txtFName.Text = "";
        txtMName.Text = "";
        txtReligion.Text = "";
        txtperAdd.Text = "";
        txtpreAdd.Text = "";
        imgContent.ImageUrl = "";
        btnSave.Enabled = true;
        //txtEmpId.ReadOnly = false;
        btnUpdate.Enabled = false;
    }

    private void PictureBrowse()
    {
        String strFileName = "";
        string[] Extension;


        if (flUploadEmployee.HasFile)
        {
            strFileName = flUploadEmployee.FileName.Substring(flUploadEmployee.FileName.LastIndexOf('\\') + 1);
            Extension = strFileName.Split('.');

            if (Extension[1] == "jpg" || Extension[1] == "jpeg" || Extension[1] == "bmp")
            {
                GetImage();
                PictureUpload();
                Label1.Text = "";
                Label1.Visible = false;
             }
          }
          else if (f1UploadDocumentory.HasFile)
          {
                strFileName = f1UploadDocumentory.FileName.Substring(f1UploadDocumentory.FileName.LastIndexOf('\\') + 1);
                Extension = strFileName.Split('.');
                if (Extension[1] == "jpg" || Extension[1] == "jpeg" || Extension[1] == "bmp" || Extension[1] == "pdf" || Extension[1] == "png" || Extension[1] == "doc" || Extension[1] == "docx" || Extension[1] == "xls" || Extension[1] == " " || Extension[1] != " ")
                {
                    GetImage();
                    //PictureUpload();
                    Label1.Text = "";
                    Label1.Visible = false;
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "Only .jpg, .jpeg and .bmp Ffile are allowed.";
                }
            }

          
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please browse a file first ";
        }

    }
    private void PictureUpload()
    {
        string path = "";
        String FullPath = "";

        path = Session["FinalStringForeFileName"].ToString();
        if (path != "")
        {
            FullPath = "~/TextFile/" + path;
            imgContent.ImageUrl = FullPath;
        }
    }

    #endregion

    #region Button Hnadlers

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["FinalStringForeFileName"] == null)
        {
            GetImage();
        }
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATION.ToString(), "R"))
            {
                string strSql = "Select EmpId From tblEmployee Where EmpId='" + txtEmpId.Text + "'";

                if (!ClsCommon.ItemCheck(strSql))
                {
                    if (isValidData())
                    {
                        if (drpSex.SelectedIndex != 0)
                        {
                            if (flUploadEmployee.HasFile || Session["FinalStringForeFileName"] != null)
                            {
                                try
                                {
                                    AddEmployee();
                                    Label1.Visible = true;
                                    Label1.ForeColor = System.Drawing.Color.Green;
                                    Label1.Text = "Data saved successful.";
                                    clearall();
                                }
                                catch (Exception ex)
                                {
                                    Label1.Visible = true;
                                    Label1.ForeColor = System.Drawing.Color.Red;
                                    Label1.Text = ex.Message.ToString();
                                }
                            }
                            else
                            {
                                Label1.Visible = true;
                                Label1.ForeColor = System.Drawing.Color.Red;
                                Label1.Text = "Please browse a file first ";
                            }
                        }
                        else
                        {
                            Label1.Visible = true;
                            Label1.ForeColor = System.Drawing.Color.Red;
                            Label1.Text = "Please select!";
                        }
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "This id already exist";
                }
            }
            else
                Response.Redirect("Default.aspx");
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["empId"] = null;
        Response.Redirect("Default.aspx");
    }
    protected void txtEmpName_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Session["empId"] = null;
        clearall();
        Label1.Visible = false;

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                UpdateEmployee();
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Green;
                Label1.Text = "Data updated successful.";
                clearall();
                btnUpdate.Enabled = false;
                //txtEmpId.ReadOnly = false;
                btnSave.Enabled = true;
            }
            catch (Exception ex)
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = ex.Message.ToString();
                btnUpdate.Enabled = true;
                //txtEmpId.ReadOnly = false;
                btnSave.Enabled =false;
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void drpEmpList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnFind_Click(object sender, EventArgs e)
    {
        PictureBrowse();
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        loadShift();
        loadDesignation();
    }
    protected void txtConfirmationDate_TextChanged(object sender, EventArgs e)
    {
        if (txtConfirmationDate.Text != "" && txtJoiningDate.Text != "")
        {
            Int32 ConfDate = Int32.Parse(txtConfirmationDate.Text.ToString());
            DateTime JoinDate = Convert.ToDateTime(txtJoiningDate.Text);
            txtConfirmationDateShow.Text = JoinDate.AddMonths(ConfDate).ToString("dd/MM/yyyy");
        }
    }
    protected void txtJoiningDate_TextChanged(object sender, EventArgs e)
    {
        if (txtConfirmationDate.Text != "" && txtJoiningDate.Text != "")
        {
            Int32 ConfDate = Int32.Parse(txtConfirmationDate.Text.ToString());
            DateTime JoinDate = Convert.ToDateTime(txtJoiningDate.Text);
            txtConfirmationDateShow.Text = JoinDate.AddMonths(ConfDate).ToString("dd/MM/yyyy");
        }
    }
    #endregion
  
/// <summary>
/// Documentory Load
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>

    protected void grdDocumentory_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            //CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            //hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;


            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");

            //editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "')";

            //hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');

        }
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATIONLIST.ToString(), "D"))
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                ((Button)e.Row.FindControl("btnDel")).Attributes.Add("onclick", "javascript:DeleteAll('" + ((Button)e.Row.FindControl("btnDel")) + "')");
            }
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           
            ImageUrl = "TextFile/";//+ imageUrl;
            ImageTitle = "Title Image";
            LinkButton objLinkBtn = (LinkButton)e.Row.FindControl("lkButton");
            objLinkBtn.Attributes.Add("onclick", "javascript:popImage('" + ImageUrl + DataBinder.Eval(e.Row.DataItem, "EmpDocumentoryListFileName") + "','" + ImageTitle.Trim() + "')");


        }


    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATIONLIST.ToString(), "D"))
        {
            foreach (GridViewRow oRow in grdDocumentory.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                if (oCheckBoxEdit.Checked)
                {

                    HiddenField hCompId1 = (HiddenField)oRow.FindControl("hCompID");

                    hidUpdateID.Value = hCompId1.Value;

                    //if (EventTarget == "TRUE")
                    //{
                        deleteDocumentory(hCompId1.Value);
                    //}
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to Process Request";
        }
    }

    protected void grdDocumentory_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void btnUploadDocumentory_Click(object sender, EventArgs e)
    {
        PictureBrowse();

        if (isValidataDoc())
        {
            if (Session["FinalStringForDocumentoryFileName"] != null)
            {
           
                Documentory _Doc = new Documentory();
                _Doc.EmpCode = txtEmpId.Text.Trim();
                _Doc.EmpDocumentoryList = Session["FinalStringForDocumentoryFileName"].ToString();
                ProcessDocumentoryInsert pd = new ProcessDocumentoryInsert();
                pd.Doc = _Doc;
                pd.invoke();
                ShowData();
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Please Select!";
            }
            //ShowData();
        }

        // ShowData();
    }

    private bool isValidataDoc()
    {
        if (txtEmpId.Text.Trim().Equals(""))
        {
            Label1.Visible = true;
            Label1.Text = "Employee ID Required.";
            //Response.Write("Company Name Required.");
            txtEmpId.Focus();
            return false;

        }
        else
        {
            return true;
        }
    }

    private void ShowData()
    {
        Documentory _Doc = new Documentory();
        _Doc.EmpCode = txtEmpId.Text.Trim();
        ProcessDocumentorySelect pds = new ProcessDocumentorySelect();
        pds.Doc = _Doc;
        pds.invoke();
        //Session["EmployeeDS"] = pes.EmployeeDS.Tables[0];
        //grdEmployee.DataSource = pes.EmployeeDS.Tables[0];
        //grdEmployee.DataBind();
        Session["DocomentoryDS"] = pds.DocumentoryDS.Tables[0];
        grdDocumentory.DataSource = pds.DocumentoryDS.Tables[0];
        grdDocumentory.DataBind();
    }


    string ImageUrl = "";
    string ImageTitle = "";
    protected void LinkButton_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow oRow in grdDocumentory.Rows)
        {
          
            ImageUrl = "";
            ImageTitle = "";
            imageUrl = ((LinkButton)sender).CommandArgument; // this will return your command Arugument.
            ImageUrl = "TextFile/" + imageUrl;
            ImageTitle = "Title Image";


            /*
             string imgPdfCheck = ((LinkButton)sender).CommandArgument.ToString();
             string[] imgpdf = imgPdfCheck.Split('.');
             string pdf = "pdf";
             if (pdf == imgpdf[1])
             {
                 Response.ContentType = "Application/pdf";

                 string FilePath = MapPath("PdfFile/banglade.pdf");
                
                // Response.WriteFile(FilePath);
                 Response.End();
             }*/


            //LinkButton objLinkBtn = (LinkButton)oRow.FindControl("lkButton");
            //string clId = objLinkBtn.ClientID.ToString();
            //objLinkBtn.Attributes.Add("onclick", "javascript:popImage('" + ImageUrl.Trim() + "','" + ImageTitle.Trim() + "')");

        }


    }

    protected void deleteDocumentory(string delID)
    {
        Documentory DocD = new Documentory();
        DocD.DocNo = Convert.ToInt32(delID);
        // Employee EmpD = new Employee();

        // EmpD.EmpNumber = Convert.ToInt32(delID);
        ProcessDocumentoryDelete pDocD = new ProcessDocumentoryDelete();
        pDocD.Doc = DocD;
        pDocD.invoke();
        hidUpdateID.Value = "";
        ShowData();
    }



    protected void drpSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpSection.SelectedItem.Text != "Select")
        {
            string pretext = "";
            string postext = "";
            if (drpSection.SelectedItem.Text.Trim() == "Management".Trim()) { pretext = "MGT"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Administration".Trim()) { pretext = "ADM"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Marketing & Sales".Trim()) { pretext = "MKT"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Engineering".Trim()) { pretext = "ENG"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Software".Trim()) { pretext = "SFT"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Finance & Accounts".Trim()) { pretext = "ACC"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Refrigeration".Trim()) { pretext = "REF"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Inventory".Trim()) { pretext = "INV"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Graphics".Trim()) { pretext = "GRP"; }
            else if (drpSection.SelectedItem.Text.Trim() == "Contractual".Trim()) { pretext = "CNT"; }
            string sql = "SELECT ISNULL(Max(EmpId),0) AS EmpId FROM tblEmployee WHERE EmpId LIKE '" + pretext + "%'";
            SqlConnection con = new SqlConnection();
            ReportData objReportData = new ReportData();
            DataSet ds = new DataSet();
            con = objReportData.GetDBConn();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sql;
            String EmpIdCountStr = Convert.ToString(cmd.ExecuteScalar());
            string number;
            if (EmpIdCountStr != "0")
            {
                number = EmpIdCountStr.Substring(3, 4);
            }
            else
            {
                number = "0000";
            }
            int EmpIdCount = int.Parse(number);
            if (EmpIdCount == 0)
            {
                postext = "0001";
            }
            else
            {
                EmpIdCount = EmpIdCount + 1;
                postext = EmpIdCount.ToString();
                if (postext.Length == 1)
                {
                    postext = "000" + postext;
                }
                else if (postext.Length == 2)
                {
                    postext = "00" + postext;
                }
                else if (postext.Length == 3)
                {
                    postext = "0" + postext;
                }
                else
                {
                    postext = postext;
                }
            }
            txtEmpId.Text = pretext + postext;

        }
        else
        {
            txtEmpId.Text = "";
        }
    }
}
