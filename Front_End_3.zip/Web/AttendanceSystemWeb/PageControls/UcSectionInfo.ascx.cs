﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using AttendanceSystem.Core;
using AttendanceSystem.BLL;

public partial class PageControls_UcSectionInfo : System.Web.UI.UserControl
{
    private Section _Sect;

    public void AddSection()
    {
        _Sect = new Section();
        _Sect.SectId = txtSectId.Text.Trim();
        _Sect.SectName = txtSection.Text.Trim();
        _Sect.DeptNo = drpdlist.SelectedItem.Value;
        _Sect.Entryby = 1;
        _Sect.PC = System.Net.Dns.GetHostName().ToString();

        ProcessSectionInsert prcsect = new ProcessSectionInsert();
        prcsect.Sect = _Sect;
        prcsect.invoke();
    }
    protected void deleteSection(string delID)
    {
        string strSql = "Select Sect_Number From tblEmployee Where Sect_Number='" + delID + "'";
        if (!ClsCommon.ItemCheck(strSql))
        {
            Section SectD = new Section();

            SectD.SectNo = Convert.ToInt32(delID);
            ProcessDepartmentDelete PDeptD = new ProcessDepartmentDelete();
            ProcessSectionDelete PSectD = new ProcessSectionDelete();
            PSectD.Sect = SectD;
            PSectD.invoke();
            Sectionlist();
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "You must delete employee first.";
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SECTIONSETUP.ToString(), "C"))
            {
                string strSql = "Select SectId From tblSection Where SectId='" + txtSectId.Text.Trim() + "'";
                string strSqlSectionName = "Select SectName From tblSection Where SectName='" + txtSection.Text.Trim() + "'";

                if (!ClsCommon.ItemCheck(strSql) || !ClsCommon.ItemCheck(strSqlSectionName))
                {
                    if (!ClsCommon.ItemCheck(strSql))
                    {
                        if (!ClsCommon.ItemCheck(strSqlSectionName))
                        {
                            if (isValidData())
                            {
                                AddSection();
                                Label1.Visible = true;
                                Label1.ForeColor = System.Drawing.Color.Green;
                                Label1.Text = "Data saved successful.";
                                clearall();
                                Sectionlist();
                            }
                        }
                        else
                        {
                            Label1.Visible = true;
                            Label1.ForeColor = System.Drawing.Color.Red;
                            Label1.Text = "This name already exist";
                        }
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Red;
                        Label1.Text = "This id already exist";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "This id and name already exist";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private bool isValidData()
    {
        if ((txtSectId.Text.Trim().Equals("")) || (txtSection.Text.Trim().Equals("")))
        {
            Label1.Visible = true;
            Label1.Text = "Section id or name required.";
            txtSection.Focus();
            txtSectId.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    public void loadItem()
    {
        try
        {
            ProcessDepartmentSelect pcs = new ProcessDepartmentSelect();
            pcs.invoke();
            Session["DepartmentDS"] = pcs.DepartmentDS;
            drpdlist.DataSource = pcs.DepartmentDS;
            drpdlist.DataValueField = "Dept_Number";
            drpdlist.DataTextField = "DeptName";
            drpdlist.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    public void loadComanyName()
    {
        try
        {
            ProcessCompanySelect pcs = new ProcessCompanySelect();
            pcs.invoke();
            drpCompany.DataSource = pcs.CompanyDS;
            drpCompany.DataValueField = "Comp_Number";
            drpCompany.DataTextField = "CompName";
            drpCompany.DataBind();
            drpCompany.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    private void loadSection(string id)
    {
        DataTable dt = new DataTable();
        dt = (DataTable)Session["SectionDS"];

        foreach (DataRow dr in dt.Rows)
        {
            if (dr[0].ToString() == id)
            {
                txtSectId.Text = dr[1].ToString();
                txtSection.Text = dr[2].ToString();
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            UpdateSection();
            Label1.Visible = true;
            Label1.Text = "Data updated successful.";
            clearall();
            Sectionlist();
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            Sectionlist();
            clearall();
            Label1.Visible = false;
            Label1.Text = "";
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void clearall()
    {
        txtSectId.Text = "";
        txtSection.Text = "";
        //drpCompany.Items.Clear();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
    }
    protected void Sectionlist()
    {
        try
        {
            ProcessSectionSelect pcs = new ProcessSectionSelect();
            pcs.invoke();
            Session["SectionDS"] = pcs.SectionDS.Tables[0];
            grdslist.DataSource = pcs.SectionDS.Tables[0];
            grdslist.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SECTIONSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    Label1.Visible = false;
                    btnUpdate.Enabled = false;
                    btnSave.Enabled = true;
                    loadItem();
                    loadComanyName();
                    //Sectionlist();
                    if (Request.QueryString["Command"] != null && Request.QueryString["id"] != null)
                    {
                        loadSection(Request.Params["id"].ToString());
                        btnUpdate.Enabled = true;
                        btnSave.Enabled = false;

                    }

                    string delID = Request.QueryString["DelID"];
                    if (delID != null)
                    {
                        deleteSection(delID.Trim());
                    }
                    Sectionlist();
                }
                loadlist();
                Label1.Visible = false;
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void grdslist_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdslist.PageIndex = e.NewPageIndex;
        Sectionlist();
    }
    public void UpdateSection()
    {
        _Sect = new Section();
        _Sect.SectNo = int.Parse(hidUpdateID.Value);
        _Sect.SectId = txtSectId.Text.Trim();
        _Sect.SectName = txtSection.Text.Trim();
        _Sect.DeptNo = drpdlist.SelectedItem.Value;
        _Sect.Entryby = 1;
        _Sect.PC = System.Net.Dns.GetHostName().ToString();

        ProcessSectionUpdate psu = new ProcessSectionUpdate();
        psu.Sect = this._Sect;
        psu.invoke();

    }
    protected void drpCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpCompany.SelectedIndex != 0)
        {
            FilterDipertment(Convert.ToInt16(drpCompany.SelectedItem.Value));
        }
        else
        {
            FilterDipertment(0);
        }
    }
    private void FilterDipertment(int companyID)
    {
        DataView dv = new DataView();
        dv = ((DataSet)Session["DepartmentDS"]).Tables[0].DefaultView;
        dv.RowFilter = " Comp_Number=" + companyID;

        drpdlist.DataSource = dv;
        drpdlist.DataValueField = "Dept_Number";
        drpdlist.DataTextField = "DeptName";
        drpdlist.DataBind();
        drpdlist.Items.Insert(0, new ListItem("Select", "NA"));
    }
    protected void grdslist_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void grdslist_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtSectId_TextChanged(object sender, EventArgs e)
    {

    }
    protected void drpSect_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        SearchSect();
    }
    protected void SearchSect()
    {
        string Searchquery;
        if (drpSect.SelectedIndex == 0)
        {
            Label1.Visible = true;
            Label1.Text = "Enter Search Item.";
        }
        if (drpSect.SelectedIndex == 1)
        {
            Searchquery = "Select Sect_Number,SectId,SectName From tblSection Where SectId='" + txtSearch.Text + "'";
            ClsCommon.GetAdhocResult(Searchquery);
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(Searchquery);
            hidEditCheckedIDS.Value = "";
            grdslist.DataSource = ds;
            grdslist.DataBind();


        }
        else if (drpSect.SelectedIndex == 2)
        {
            Searchquery = "Select Sect_Number,SectId,SectName From tblSection Where SectName like'" + txtSearch.Text + "%'";
            ClsCommon.GetAdhocResult(Searchquery);
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(Searchquery);
            hidEditCheckedIDS.Value = "";
            grdslist.DataSource = ds;
            grdslist.DataBind();


        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Invalid search item";
        }

    }
    protected void loadlist()
    {
        try
        {
            drpSect.Items.Clear();
            drpSect.Items.Insert(0, new ListItem("Select", "NA"));
            drpSect.Items.Insert(1, new ListItem("ID", "ID"));
            drpSect.Items.Insert(2, new ListItem("Name", "Name"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    protected void grdslist_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;


            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");

            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";

            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');

        }
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SECTIONSETUP.ToString(), "U"))
        {
            loadFormGrid();
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to process request";
        }
    }
    protected void loadFormGrid()
    {
        foreach (GridViewRow oRow in grdslist.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");

            if (oCheckBoxEdit.Checked)
            {
                HiddenField hSectId1 = (HiddenField)oRow.FindControl("hSectID");
                hidUpdateID.Value = hSectId1.Value;
                loadSection(hSectId1.Value);
                btnUpdate.Enabled = true;
                btnSave.Enabled = false;
                break;
            }
        }

    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SECTIONSETUP.ToString(), "U"))
        {
            foreach (GridViewRow oRow in grdslist.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                if (oCheckBoxEdit.Checked)
                {

                    HiddenField hSectId1 = (HiddenField)oRow.FindControl("hSectID");

                    hidUpdateID.Value = hSectId1.Value;
                    deleteSection(hSectId1.Value);
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Green;
                    Label1.Text = "Data deleted successful.";
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Unable to process request";
        }
    }
}
