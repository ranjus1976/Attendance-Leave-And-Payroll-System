﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;

public partial class PageControls_UcEmpPrsnlLoanReport : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOANREPORT.ToString(), "R"))
            {
               
                if (!IsPostBack)
                {
                    RadoBtnCurntLoanEmp.Checked = true;
                    RadoBtnCurntLoanEmp.Enabled = true;
                    RadioBtnCmplLoan.Checked = false;
                    loadEmployee();                           
                    String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtBxStrtDat.Text = ReportDateShow;
                    txtBxEndDat.Text = ReportDateShow;
                    GridSalBreak.DataSource = null;
                    GridSalBreak.DataBind();
                    btnReport.Enabled = true;
                    Session["NotReadPermission"] = null;

                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "select  l .EmpId,e.EmpName,e. Emp_Number from tbl_EmpLoanSetUp as l inner join tblEmployee as e on l.EmpId=e.EmpId where ELLog=1 order by e.EmpId";
            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void LoadCompleteLoanEmployee()
    {
        try
        {
            string strSQL = "select  distinct l .EmpId,e.EmpName,e. Emp_Number from tbl_EmpLoanSetUp as l inner join tblEmployee as e on l.EmpId=e.EmpId where ELLog=0 ";
            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void btnReport_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if(drpEmpId.SelectedItem.Text!="Select")
            {
            try
            {
                //Session["FakeValue"] = "EmpLoan";
                Session["ReportName"] = "rptEmpLoanReport.rpt";
                Session["TableName"] = "dsEmpLoanReport";
                Session["CompanyName"] = "General Automation Limited";
                string startDate = txtBxStrtDat.Text;
                string endDate = txtBxEndDat.Text;
                Session["lnStartDatefrom"] = startDate;
                Session["lnStartDateto"] = endDate;
                Session["StartMonthNo"] = startDate.Substring(3, 2);
                Session["StartYear"] = startDate.Substring(6, 4);
                Session["EndMonthNo"] = endDate.Substring(3, 2);
                Session["Endyear"] = endDate.Substring(6, 4);
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["reportstorage"] = "sp_Emp_Loan_Report";
                Session["ToDate"] = null; 
                Session["FromDate"] = null;
                Session["FakeValue"] = null;


                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                        "window.open('" + strPath +
                                                        "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                        true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, "Select Employee", System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private ArrayList GetOption()
    {
        try
        {
            {

                OptionArralist.Add(drpEmpId.SelectedItem.Text);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        lblEmpname.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        txtEmpLnStrDat.Text = objCommonName.EmpLnStartDate(drpEmpId.SelectedItem.Text);
        txtEmpLnEndDat.Text = objCommonName.EmpLnEndDate(drpEmpId.SelectedItem.Text);
        if(RadioBtnCmplLoan.Checked==true && drpEmpId.SelectedItem.Text!="Select")
        {
            string sql ="SELECT LoanAmount,Duration,Instalment,convert(varchar(20),ELoanSrtDate,103) as StartDate ,convert(varchar(20),ELoanEndDate,103) as EndDate FROM tbl_EmpLoanSetUp where EmpId='"+drpEmpId.SelectedItem.Text+"' and ELLog=0";
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(sql);
            hidEditCheckedIDS.Value = "";
            GridSalBreak.DataSource = null;
            GridSalBreak.DataSource = ds;
            GridSalBreak.DataBind();
        }
        else
        {
            GridSalBreak.DataSource = null;
            GridSalBreak.DataBind();
        }
    }
    protected void RadoBtnCurntLoanEmp_CheckedChanged1(object sender, EventArgs e)
    {

        RadoBtnCurntLoanEmp.Checked = true;
        RadioBtnCmplLoan.Checked = false;
        loadEmployee();
        if (RadioBtnCmplLoan.Checked)
        {
            btnReport.Enabled = true;
        }

    }
    protected void RadioBtnCmplLoan_CheckedChanged1(object sender, EventArgs e)
    {
        
        RadioBtnCmplLoan.Checked = true;
        RadoBtnCurntLoanEmp.Checked = false;
        LoadCompleteLoanEmployee();
        if(RadioBtnCmplLoan.Checked)
        {
            btnReport.Enabled = false;
        }
  
    }
    protected void GridSalBreak_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void GridSalBreak_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void GridSalBreak_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnDel_Click(object sender, EventArgs e)
    { }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
              

                loadFormGrid();

           

        }
        else
            Response.Redirect("login.aspx");

    }

    private void loadFormGrid()
    {

        foreach (GridViewRow gvrow in GridSalBreak.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[1].Text;
                loadSalaryBreakUp(id, i);
              
                break;
            }

        }
    }
    private void loadSalaryBreakUp(string id, int row)
    {
        try
        {
            


            //Session["FakeValue"] = "EmpLoan";
            Session["ReportName"] = "rptEmpLoanReport.rpt";
            Session["TableName"] = "dsEmpLoanReport";
            Session["CompanyName"] = "General Automation Limited";
            string startDate = txtBxStrtDat.Text;
            string endDate = txtBxEndDat.Text;
            Session["lnStartDatefrom"] = GridSalBreak.Rows[row].Cells[3].Text;
            Session["lnStartDateto"] = GridSalBreak.Rows[row].Cells[4].Text;
            Session["StartMonthNo"] = GridSalBreak.Rows[row].Cells[3].Text.Substring(3, 2);
            Session["StartYear"] = GridSalBreak.Rows[row].Cells[3].Text.Substring(6, 4);
            Session["EndMonthNo"] = GridSalBreak.Rows[row].Cells[4].Text.Substring(3, 2);
            Session["Endyear"] = GridSalBreak.Rows[row].Cells[4].Text.Substring(6, 4);
            ArralistOption = GetOption();
            Session["option"] = ArralistOption[0];
            Session["reportstorage"] = "sp_Emp_Comp_Loan_Report";
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FakeValue"] = null;


            string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                    "window.open('" + strPath +
                                                    "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                    true);



        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(EmpLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
}
