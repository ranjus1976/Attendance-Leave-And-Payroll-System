﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Report;
using CheckBox = System.Web.UI.WebControls.CheckBox;


public partial class PageControls_SalarySlabEntry : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    public SalarySlab salarySlab = new SalarySlab();
    public string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!this.IsPostBack)
        {
           
            Showdata();
            //TextBoxCompPayableAmt.Attributes.Add("readonly", "readonly");
            action = "save";
            Label5.Visible = false;
            BtnUpdate.Enabled = false;
            BtnSave.Enabled = true;
        }
    }


    public void Showdata()
    {
        try
        {
            if (true)//["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                SqlCommand cmd = new SqlCommand();
                DataSet ds = new DataSet();
                SqlConnection objReturnedConn;
                ReportData obj_ReportData = new ReportData();

                objReturnedConn = obj_ReportData.GetDBConn();
                objReturnedConn.Open();
                cmd.Connection = objReturnedConn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Salary_Slab_Select";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                Session["SalarySlabDS"] = "";
                Session["SalarySlabDS"] = ds.Tables[0];
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                this.EmptyGridFix(GridView1);
                
                
                //string maxSalbId;
                //if (ds.Tables[0].Rows.Count == 0)
                //{
                //    maxSalbId = "S0000000";
                //}
                //else
                //{
                //    int rowcount = ds.Tables[0].Rows.Count;
                //    maxSalbId = ds.Tables[0].Rows[rowcount - 1][1].ToString(); ;
                //    string[] s1 = maxSalbId.Split('S');
                //    string s2 = s1[1];
                //    string temp = "S";
                //    s2 = (int.Parse(s2) + 1).ToString();
                //    for (int i = 1; i < maxSalbId.Length - s2.Length; i++)
                //    {
                //        temp += "0";
                //    }
                //    maxSalbId = temp + s2;
                //}
                TextBoxSalarySlabId.Text = "0000";
                /**********Next slab id ends***********************/
                TextBoxCompPerticipationPercentage.Text = 30.ToString();
            }
           
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    private string salaryslabib()
    {
        string maxSalbId="0000";
        //DataTable dt=new DataTable();
        //dt = (DataTable) Session["SalarySlabDS"];
        //if (dt.Rows.Count == 0)
        //{
        //    maxSalbId = "S0000000";
        //}
        //else
        //{
        //    int rowcount = dt.Rows.Count;
        //    maxSalbId = dt.Rows[rowcount - 1][1].ToString(); ;
        //    string[] s1 = maxSalbId.Split('S');
        //    string s2 = s1[1];
        //    string temp = "S";
        //    s2 = (int.Parse(s2) + 1).ToString();
        //    for (int i = 1; i < maxSalbId.Length - s2.Length; i++)
        //    {
        //        temp += "0";
        //    }
        //    maxSalbId = temp + s2;
        //}
        return maxSalbId;
    }

    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYSLABSETUP.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
                objCommonName.LabelMessageandColor(Label5, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
   protected void  btnRDelete_Clik(object sender, EventArgs e)
   {
       if (Session["LogIn"] != null)
       {
           if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.DEPARTMENTSETUP.ToString(), "D"))
           {
               foreach (GridViewRow oRow in GridView1.Rows)
               {
                   CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDelete");

                   if (oCheckBoxEdit.Checked)
                   {
                       HiddenField slabid = (HiddenField)oRow.FindControl("HidSalarySlabID");
                       string id = slabid.Value;
                       deleteSalarySlab(id);
                   }
               }
           }
           else
               objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
       }
       else
           Response.Redirect("login.aspx");
   }

    private void deleteSalarySlab(string id)
    {
        salarySlab.SalarySlabID = id;
        ProcessSalarySlabDelete SlabD=new ProcessSalarySlabDelete();
        SlabD.slab = this.salarySlab;
        SlabD.invoke();
        objCommonName.LabelMessageandColor(Label5, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
        Showdata();
    }

    private void loadFormGrid()
    {
        foreach (GridViewRow oRow in GridView1.Rows)
        {
            CheckBox oCheckBoxEdit = new CheckBox();
            oCheckBoxEdit= (CheckBox)oRow.FindControl("chkEdit");
            if (oCheckBoxEdit.Checked)
            {
                HiddenField slabid = (HiddenField)oRow.FindControl("HidSalarySlabID");
                string id = slabid.Value;
                loadSalarySlab(id);
                BtnSave.Enabled = false;
                BtnUpdate.Enabled = true;
                break;
           }
        }
    }
    private void loadSalarySlab(string id)
    {
        DataTable dt = new DataTable();
        try
        {
            if (Session["SalarySlabDS"] != null)
            {
                dt = (DataTable)Session["SalarySlabDS"];

                foreach (DataRow dr in dt.Rows)
                {
                    if (dr[0].ToString() == id)
                    {
                        TextBoxSalarySlabId.Text = dr["ID"].ToString();
                        TextBoxStartingRange.Text = numberstring(dr["StartingRange"].ToString());
                        TextBoxClosingRange.Text = numberstring(dr["ClosingRange"].ToString());
                        TextBoxEmpDepositAmt.Text = numberstring(dr["EmpDipositAmt"].ToString());
                        TextBoxCompPerticipationPercentage.Text = dr["CompPerticipationRatio"].ToString();
                        TextBoxCompPayableAmt.Text = numberstring(dr["CompPayableAmount"].ToString());
                    }
                }
                
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected void EmptyGridFix(GridView grdView)
    {
        if (grdView.Rows.Count == 0 &&
        grdView.DataSource != null)
        {
            DataTable dt = null;

            // need to clone sources otherwise
            // it will be indirectly adding to 
            // the original source

            if (grdView.DataSource is DataSet)
            {
                dt = ((DataSet)grdView.DataSource).Tables[0].Clone();
            }
            else if (grdView.DataSource is DataTable)
            {
                dt = ((DataTable)grdView.DataSource).Clone();
            }

            if (dt == null)
            {
                return;
            }

            dt.Rows.Add(dt.NewRow()); // add empty row
            grdView.DataSource = dt;
            grdView.DataBind();

            // hide row
            grdView.Rows[0].Visible = false;
            grdView.Rows[0].Controls.Clear();
        }


        if (grdView.Rows.Count == 1 && grdView.DataSource == null)
        {
            bool bIsGridEmpty = true;

            // check first row that all cells empty
            for (int i = 0; i < grdView.Rows[0].Cells.Count; i++)
            {
                if (grdView.Rows[0].Cells[i].Text != string.Empty)
                {
                    bIsGridEmpty = false;
                }
            }
            // hide row
            if (bIsGridEmpty)
            {
                grdView.Rows[0].Visible = false;
                grdView.Rows[0].Controls.Clear();
            }
        }

    }

    protected void BtnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            action = "update";
            UpdateSalarySlab();
            objCommonName.LabelMessageandColor(Label5, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
            Showdata();
            ClearAll();
            
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void ClearAll()
    {
        TextBoxSalarySlabId.Text = salaryslabib();
        TextBoxStartingRange.Text = "";
        TextBoxClosingRange.Text = "";
        TextBoxEmpDepositAmt.Text = "";
        TextBoxCompPerticipationPercentage.Text = "30";
        TextBoxCompPayableAmt.Text = "";
        BtnSave.Enabled = true;
        BtnUpdate.Enabled = false;
    }
    private void UpdateSalarySlab()
    {
        salarySlab.SalarySlabID = TextBoxSalarySlabId.Text.Trim().ToString();
        salarySlab.StartingRange = int.Parse(numberstring(TextBoxStartingRange.Text.ToString()));
        salarySlab.ClosingRange = int.Parse(numberstring(TextBoxClosingRange.Text.ToString()));
        salarySlab.EmpDipositAmt = int.Parse(numberstring(TextBoxEmpDepositAmt.Text.ToString()));
        salarySlab.CompPerticipationRatio = float.Parse(TextBoxCompPerticipationPercentage.Text.ToString());
        salarySlab.CompPayableAmount = int.Parse(numberstring(TextBoxCompPayableAmt.Text.ToString()));
        salarySlab.Action = action;
        ProcessSalarySlabInsert ProcSalarySlab = new ProcessSalarySlabInsert();
        ProcSalarySlab.salarySlab = salarySlab;
        ProcSalarySlab.invoke();
    }
    private string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {

       
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OSDSETUP.ToString(), "C"))
           {

                    
                if ( TextBoxStartingRange.Text.ToString()!= null|| TextBoxClosingRange.Text.ToString()!=null)
                    {
                        if (isValidData())
                        {
                            string strSql =
                                "SELECT * FROM dbo.tbl_Salary_Slab WHERE     StartingRange = " +
                                Convert.ToInt32(TextBoxStartingRange.Text.ToString()) + " AND ClosingRange = " +
                                Convert.ToInt32(TextBoxClosingRange.Text.ToString());
                            

                            if (!ClsCommon.ItemCheck(strSql))
                            {
                                AddSalarySlab();
                                Label5.Visible = true;
                                Label5.ForeColor = System.Drawing.Color.Green;
                                Label5.Text = "Data saved successful.";
                                Showdata();
                                /*CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                                BindGrid(CompId);
                                ClearData();
                                ddlCompany.Enabled = true;
                                DDLEmpName.Enabled = true;*/
                                
                            }
                            else
                            {
                                Label5.Visible = true;
                                Label5.ForeColor = System.Drawing.Color.Red;
                                Label5.Text = "Salary range already exists.";
                            }
                        }
                    }
                    else
                    {
                        Label5.Visible = true;
                        Label5.ForeColor = System.Drawing.Color.Red;
                        Label5.Text = "Give Starting or Closing Rang!";
                    }
               
           }
            else
            {
                Label5.Visible = true;
                Label5.ForeColor = System.Drawing.Color.Red;
                Label5.Text = "Unable to process request";
            }
        }
        else
           Response.Redirect("login.aspx");

    }

    private void AddSalarySlab()
    {
        try
        {
            action = "save";
            salarySlab.SalarySlabID = TextBoxSalarySlabId.Text.Trim().ToString();
            salarySlab.StartingRange = int.Parse(TextBoxStartingRange.Text.ToString());
            salarySlab.ClosingRange = int.Parse(TextBoxClosingRange.Text.ToString());
            salarySlab.EmpDipositAmt = int.Parse(TextBoxEmpDepositAmt.Text.ToString());
            salarySlab.CompPerticipationRatio = int.Parse(TextBoxCompPerticipationPercentage.Text.ToString());
            salarySlab.CompPayableAmount = int.Parse(TextBoxCompPayableAmt.Text.ToString());
            salarySlab.Action = action;
            ProcessSalarySlabInsert ProcSalarySlab = new ProcessSalarySlabInsert();
            ProcSalarySlab.salarySlab = salarySlab;
            ProcSalarySlab.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(Label5, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }

    private bool isValidData()
    {
        return true;
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        ClearAll();
        Showdata();
        Label5.Text = "";
    }
    protected void BtnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
   
  
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void hidEditCheckedIDS_ValueChanged(object sender, EventArgs e)
    {

    }
    protected void hiddenDesigNumber_ValueChanged(object sender, EventArgs e)
    {

    }
    protected void TextBoxEmpDepositAmt_TextChanged(object sender, EventArgs e)
    {
        TextBoxCompPayableAmt.Text = (Convert.ToInt64(TextBoxEmpDepositAmt.Text.ToString()) * Convert.ToInt64(TextBoxCompPerticipationPercentage.Text.ToString()) / 100).ToString();
    }
    protected void TextBoxCompPerticipationPercentage_TextChanged(object sender, EventArgs e)
    {
        if (Convert.ToInt64(TextBoxCompPerticipationPercentage.Text.ToString()) > 100)
        {
            TextBoxCompPayableAmt.Text = "";
        }
        else
        {
            TextBoxCompPayableAmt.Text =
                (Convert.ToInt64(TextBoxEmpDepositAmt.Text.ToString())*
                 Convert.ToInt64(TextBoxCompPerticipationPercentage.Text.ToString())/100).ToString();
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

}
