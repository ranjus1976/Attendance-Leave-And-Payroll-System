﻿using System;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Data;

public partial class PageControls_UCUserPermission : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UserLoad();
            UserFormLoad();
        }
    }

    #region Private Methods
    private void UserLoad()
    {
        ArrayList UserPermission = new ArrayList();
        ArrayList User_Number = new ArrayList();
        ArrayList User_Id = new ArrayList();
        string strSearchUser = "select User_Number,UserId from tblUser";
        DataSet dsUser = new DataSet();
        dsUser = ClsCommon.GetAdhocResult(strSearchUser);
        foreach (DataRow dRow in dsUser.Tables[0].Rows)
        {
            UserPermission.Add(dRow);
        }
        foreach (Object objRow in UserPermission)
        {
            User_Number.Add(((DataRow)objRow)["User_Number"].ToString());
            User_Id.Add(((DataRow)objRow)["UserId"].ToString());
        }
        for (int i = 0; i < User_Id.Count; i++)
        {
            RadioButtonListUserPermission.Items.Add(new ListItem(Convert.ToString(User_Id[i]), Convert.ToString(User_Number[i])));
        }
    }
    private void UserFormLoad()
    {
        CheckBoxListUserpermission.Items.Add(new ListItem("UcCompanyInfo.ascx", "1"));
        CheckBoxListUserpermission.Items.Add(new ListItem("UcDailyProcess.ascx", "2"));
    }

    public void AddUserPermission()
    {
        UserPermission obj_UserPermission = new UserPermission();
        try
        {
            for (int i = 0; i < CheckBoxListUserpermission.Items.Count; i++)
            {
                if (CheckBoxListUserpermission.Items[i].Selected == true)
                {
                    obj_UserPermission.User_Number = Convert.ToInt32(RadioButtonListUserPermission.SelectedValue);
                    obj_UserPermission.Function_Number = Convert.ToInt32(CheckBoxListUserpermission.Items[i].Value);
                    obj_UserPermission.Entry_By = Convert.ToInt32(1);
                    obj_UserPermission.Entry_Date = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
                    obj_UserPermission.PC = System.Net.Dns.GetHostName().ToString();
                    ProcessUserPermission obj_ProcessUserPermission = new ProcessUserPermission();
                    obj_ProcessUserPermission.UserPermission = obj_UserPermission;
                    obj_ProcessUserPermission.invoke();
                }
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    private void AddUserFunction()
    {
        UserPermission obj_UserPermission = new UserPermission();
        try
        {
            for (int i = 0; i < CheckBoxListUserpermission.Items.Count; i++)
            {
                if (CheckBoxListUserpermission.Items[i].Selected == true)
                {
                    obj_UserPermission.Function_Number = Convert.ToInt32(CheckBoxListUserpermission.Items[i].Value);
                    obj_UserPermission.Function_Description = Convert.ToString(CheckBoxListUserpermission.Items[i].Text);

                    ProcessUserPermissionFunction obj_ProcessUserPermissionFunction = new ProcessUserPermissionFunction();
                    obj_ProcessUserPermissionFunction.UserPermission = obj_UserPermission;
                    obj_ProcessUserPermissionFunction.invoke();
                }
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion


    protected void btnGivePermission_Click(object sender, EventArgs e)
    {
        AddUserPermission();
        AddUserFunction();
    }
}
