﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Select;
using System.IO;

public partial class PageControls_ucDayDeduct : System.Web.UI.UserControl
{
    #region Declarations

    String Date = System.DateTime.Now.ToString();
    TimeSpan ts;
    CommonName objCommonName = new CommonName();
    DayDeduct objDayDeduct = new DayDeduct();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ACTIONTAKEN.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    EmployeeImage.LoadImageEmp(ddlEmployeelist, tblIdMaster, EmpImage);
                    SelecData();
                    dtpToDate.Text = Date.Substring(0, 10);
                    dptFromDate.Text = Date.Substring(0, 10);
                    ts = System.DateTime.Now.Subtract(System.DateTime.Now);
                    objCommonName = new CommonName();
                    objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    protected void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCompany ";
            ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
            ddlCompany.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void SelecData()
    {
        try
        {
            ProcessDayDeductSelectData pds = new ProcessDayDeductSelectData();
            pds.invoke();
            Session["DayDeductDS"] = pds.DayDeductDS.Tables[0];
            grvLeaveList.DataSource = pds.DayDeductDS.Tables[0];
            grvLeaveList.DataBind();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void LoadEmployeeList(Int32 CompId)
    {
        try
        {
            ddlEmployeelist.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number inner join tblDepartment on tblDepartment.Dept_Number = tblSection.Dept_Number where EmpED = 1 and Comp_Number = " + CompId + " order by EmpId asc ";
            ClsCommon.drplistAddNew(ddlEmployeelist, strSQL, "EmpId", "Emp_Number");
            ddlEmployeelist.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void loadCompany(Int32 id, Int32 CompId)
    {
        try
        {
            LoadDayDeductByCompany objLoadDayDeductByCompany = new LoadDayDeductByCompany();
            SqlDataReader reader = objLoadDayDeductByCompany.DayDeductDataByCompany(id);

            while (reader.Read())
            {
                ddlCompany.SelectedValue = CompId.ToString();
                LoadEmployeeList(CompId);
                ddlEmployeelist.SelectedValue = reader[0].ToString();
                String FromDate = Convert.ToString(reader[1]);
                dptFromDate.Text = Convert.ToString(FromDate.Substring(0, 10));
                String ToDate = Convert.ToString(reader[2]);
                dtpToDate.Text = Convert.ToString(ToDate.Substring(0, 10));
                txtTotalDays.Text = Convert.ToString(reader[3]);
                txtRemarks.Text = Convert.ToString(reader[4]);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadFormGrid()
    {
        try
        {
            foreach (GridViewRow oRow in grvLeaveList.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
                if (oCheckBoxEdit.Checked)
                {
                    HiddenField hDeductId = (HiddenField)oRow.FindControl("hDeductId");
                    HiddenField hCompId = (HiddenField)oRow.FindControl("HiddenFieldCompNumber");
                    Int32 ID = Convert.ToInt32(hDeductId.Value);
                    Int32 CompId = Convert.ToInt32(hCompId.Value);
                    loadCompany(ID, CompId);
                    btnSave.Enabled = false;
                    btnUpdate.Enabled = true;
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void Clear()
    {
        ddlEmployeelist.SelectedIndex = 0;
        txtRemarks.Text = "";
        txtTotalDays.Text = "";
        dtpToDate.Text = "";
        dptFromDate.Text = "";
    }
    public void DaydeductUpdate()
    {
        Int32 hDeductId = 0;
        try
        {
            foreach (GridViewRow oRow in grvLeaveList.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
                if (oCheckBoxEdit.Checked)
                {
                    HiddenField hiddenDeductId = (HiddenField)oRow.FindControl("hDeductId");
                    hDeductId = Convert.ToInt32(hiddenDeductId.Value);
                }
            }

            Int32 EmpNumber = Convert.ToInt32(ddlEmployeelist.SelectedValue);
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);
            float TotalDays = float.Parse(txtTotalDays.Text);
            String Remarks = Convert.ToString(txtRemarks.Text);

            objDayDeduct.DayDeductId = hDeductId;
            objDayDeduct.Emp_Number = EmpNumber;
            objDayDeduct.FromDate = FromDate;
            objDayDeduct.ToDate = ToDate;
            objDayDeduct.TotalDyas = TotalDays;
            objDayDeduct.Remarks = Remarks;

            ProcessDayDeductUpdateData objProcessDayDeductUpdateData = new ProcessDayDeductUpdateData();
            objProcessDayDeductUpdateData.DayDeduct = objDayDeduct;
            objProcessDayDeductUpdateData.invoke();

            SelecData();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }
    protected void deleteDaydeduct(Int32 id)
    {
        try
        {
            objDayDeduct.DayDeductId = id;

            ProcessDayDeductDeleteData objProcessDayDeductDeleteData = new ProcessDayDeductDeleteData();
            objProcessDayDeductDeleteData.DayDeduct = objDayDeduct;
            objProcessDayDeductDeleteData.invoke();
            SelecData();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void AddDayDeduct()
    {
        try
        {
            Int32 EmpNumber = Convert.ToInt32(ddlEmployeelist.SelectedValue);
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);
            float TotalDays = float.Parse(txtTotalDays.Text);
            String Remarks = Convert.ToString(txtRemarks.Text);

            objDayDeduct.Emp_Number = EmpNumber;
            objDayDeduct.FromDate = FromDate;
            objDayDeduct.ToDate = ToDate;
            objDayDeduct.TotalDyas = TotalDays;
            objDayDeduct.Remarks = Remarks;

            ProcessDayDeductInsertData objProcessDayDeductInsertData = new ProcessDayDeductInsertData();
            objProcessDayDeductInsertData.DayDeduct = objDayDeduct;
            objProcessDayDeductInsertData.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    #endregion

    #region Button Click

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["LogIn"] != null)
            {
                if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ACTIONTAKEN.ToString(), "U"))
                {
                    DaydeductUpdate();
                    objCommonName.LabelMessageandColor(lblMessage, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
                    Clear();
                    SelecData();
                }
                else
                    objCommonName.LabelMessageandColor(lblMessage, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
            }
            else
                Response.Redirect("login.aspx");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["LogIn"] != null)
            {
                if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ACTIONTAKEN.ToString(), "C"))
                {
                    AddDayDeduct();
                    objCommonName.LabelMessageandColor(lblMessage, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                    SelecData();
                }
                else
                {
                    objCommonName.LabelMessageandColor(lblMessage, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                Response.Redirect("login.aspx");
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void HlnkEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ACTIONTAKEN.ToString(), "U"))
                loadFormGrid();
            else
                objCommonName.LabelMessageandColor(lblMessage, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void HlnkDelete_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ACTIONTAKEN.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grvLeaveList.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDelete");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hCompId1 = (HiddenField)oRow.FindControl("hDeductIddelete");
                        Int32 Id = Convert.ToInt32(hCompId1.Value);
                        deleteDaydeduct(Id);
                    }
                }
                objCommonName.LabelMessageandColor(lblMessage, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
            }
            else
                objCommonName.LabelMessageandColor(lblMessage, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Event Handlers

    protected void grvLeaveList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvLeaveList.PageIndex = e.NewPageIndex;
        SelecData();

    }
    protected void dptFromDate_TextChanged(object sender, EventArgs e)
    {
        if (dptFromDate.Text != "" && dtpToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);

            int FinalDay = 0;
            string str = "";
            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                if (DateTime.Compare(ToDate, FromDate) == 0)
                {
                    ts = ToDate.Subtract(FromDate.AddDays(-1));
                    str = ts.ToString();
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str);
                    str = string.Empty;
                    str = "";
                }
                else
                {
                    ts = ToDate.Subtract(FromDate);
                    str = ts.ToString();
                }
                if (str.Length == 10)
                {
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 11)
                {
                    str = str.Substring(0, 2);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 12)
                {
                    str = str.Substring(0, 3);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                txtTotalDays.Text = Convert.ToString(FinalDay);
                objCommonName.LabelReset(lblMessage);
            }
            else
            {
                objCommonName.LabelMessageandColor(lblMessage, objCommonName.DateMessageforError.ToString(), System.Drawing.Color.Red);
            }
        }
    }
    protected void dtpToDate_TextChanged(object sender, EventArgs e)
    {
        if (dptFromDate.Text != "" && dtpToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);
            int FinalDay = 0;
            string str = "";
            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                if (DateTime.Compare(ToDate, FromDate) == 0)
                {
                    ts = ToDate.Subtract(FromDate.AddDays(-1));
                    str = ts.ToString();
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str);
                    str = string.Empty;
                    str = "";
                }
                else
                {
                    ts = ToDate.Subtract(FromDate);
                    str = ts.ToString();
                }
                if (str.Length == 10)
                {
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 11)
                {
                    str = str.Substring(0, 2);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 12)
                {
                    str = str.Substring(0, 3);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                txtTotalDays.Text = Convert.ToString(FinalDay);
                objCommonName.LabelReset(lblMessage);
            }
            else
                objCommonName.LabelMessageandColor(lblMessage, objCommonName.DateMessageforError.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void ddlEmployeelist_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip( ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeelist, tblIdMaster, EmpImage);
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompany.SelectedIndex != 0)
        {
            LoadEmployeeList(int.Parse(ddlCompany.SelectedValue.ToString()));
            objCommonName = new CommonName();
            objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
        }
        else
            LoadEmployeeList(0);
    }
    protected void grvLeaveList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDelete");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
   
    #endregion
}
