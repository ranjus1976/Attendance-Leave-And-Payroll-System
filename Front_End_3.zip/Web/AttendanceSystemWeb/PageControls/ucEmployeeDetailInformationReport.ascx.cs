﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.IO;


public partial class PageControls_ucEmployeeInformationReportl : System.Web.UI.UserControl
{
    #region Declaration

    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName;

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFOREPORT.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    drpDept.Enabled = false;
                    drpId.Enabled = false;
                    loadCompany();
                    EmployeeImage.LoadImageEmp(drpId, tblId, EmpImage);
                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Combo Load

    public void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(drpCompanylist, strSQL, "CompName", "Comp_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {

        try
        {

            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCompanylist.SelectedValue + "";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }
    protected void LoadEmployeeList()
    {
        try
        {
            drpId.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join  tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + drpCompanylist.SelectedValue + " order by empId asc";
            ClsCommon.drplistAddNew(drpId, strSQL, "EmpId", "Emp_Number");
            drpId.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region Private Methods

    private ArrayList GetOption()
    {
        CommonName objCommonName = new CommonName();

        if (RadioButtonAll.Checked)
        {
            OptionArralist = objCommonName.GetOption("ALL", drpCompanylist);
        }
        else if (RadioButtonDepartment.Checked)
        {
            OptionArralist = objCommonName.GetOption("Dept", drpDept);
        }
       
        else
        {
            OptionArralist = objCommonName.GetOption("Emp", drpId);
        }
        return OptionArralist;
    }

    #endregion

    #region Button Handler

    protected void btnEmployeeInfo_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            // Report All Session Clear///////////////////////////////////////
            Session["ToDate"] = null;
            Session["FromDate"] = null;
            Session["FinancialYear"] = null;
            Session["Date"] = null;
            //End

            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFOREPORT.ToString(), "R"))
            {
                Session["ReportName"] = "EmployeeDetailInfo.rpt";
                Session["TableName"] = "dsEmployeeInformation";
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["CompanyName"] = drpCompanylist.SelectedItem.Text;
                Session["Company_Number"] = drpCompanylist.SelectedValue;

                //string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblErrorMessaage.Visible = true;
                lblErrorMessaage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpId.Enabled = false;
    }
    protected void RadioButtonDepartment_CheckedChanged(object sender, EventArgs e)
    {
        drpDept.Enabled = true;
        drpId.Enabled = false;
        loadDepartment();
    }
    protected void RadioButtonEmpId_CheckedChanged(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpId.Enabled = true;
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
    }
    protected void drpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(drpId, tblId, EmpImage);
    }
    protected void drpCompanylist_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpId, drpId.SelectedValue.ToString(), lblEmpname);
    }
   
    #endregion
}
