﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;

public partial class PageControls_ucEmployeeAT : System.Web.UI.UserControl
{
    CommonName objCommonName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OVERNIGHTDUTY.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    ddlCompanyCode.SelectedIndex = 1;
                    LoadEmployeeList();
                    EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
                    Session["NotReadPermission"] = null;
                    inTimeTextBox.Text = "00:00";
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Private methods
    private void Clear()
    {
        ddlCompanyCode.SelectedIndex = 0;
        ddlEmployeeCode.SelectedIndex = 0;
        txtFromDate.Text = "";
    }
    private void ONDAdd()
    {
        Int32 EmpNumber = Convert.ToInt32(ddlEmployeeCode.SelectedValue);
        String Sts = ddlEmployeeStatus.SelectedItem.Text;
        DateTime Date = Convert.ToDateTime(txtFromDate.Text);
        ReportData objReportData = new ReportData();
        SqlCommand cmd = new SqlCommand();
        SqlConnection objReturnedConn = new SqlConnection();
        String Sql = "sp_ATT";
        objReturnedConn = objReportData.GetDBConn();
        objReturnedConn.Open();
        cmd.Connection = objReturnedConn;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        DateTime manualInTime = DateTime.Parse(Convert.ToDateTime("01/01/1900 " + inTimeTextBox.Text).ToString("dd/MMM/yyyy HH:mm:ss")); ;
        cmd.Parameters.AddWithValue("@Emp_Number", EmpNumber);
        cmd.Parameters.AddWithValue("@Sts", Sts);
        cmd.Parameters.AddWithValue("@Date", Date);
        cmd.Parameters.AddWithValue("@Time", manualInTime);
        cmd.Parameters.AddWithValue("@PC",System.Net.Dns.GetHostName());
        cmd.Parameters.AddWithValue("@EntryDate", System.DateTime.Now);
        cmd.Parameters.AddWithValue("@EntryBy","USerId");

        cmd.ExecuteNonQuery();
        Clear();
        Label1.Visible = true;
        Label1.ForeColor = System.Drawing.Color.Green;
        Label1.Text = "Data saved successful.";
    }
    #endregion

    #region Combo Load
    public void loadCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number, CompName from tblCOmpany ";
            ClsCommon.drplistAdd(ddlCompanyCode, strSQL, "CompName", "Comp_Number");
            ddlCompanyCode.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void LoadEmployeeList()
    {
        try
        {
            ddlEmployeeCode.Items.Clear();
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee inner join tblSection on  tblEmployee.Sect_Number = tblSection.Sect_Number inner join tblDepartment on tblSection.Dept_Number = tblDepartment.Dept_Number inner join tblCompany on tblDepartment.Comp_Number = tblCompany.Comp_Number where EmpED = 1 and tblCompany.Comp_Number = " + Convert.ToInt32(ddlCompanyCode.SelectedValue.ToString()) + " order by EmpId asc";
            ClsCommon.drplistAddNew(ddlEmployeeCode, strSQL, "EmpId", "Emp_Number");
            ddlEmployeeCode.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.OVERNIGHTDUTY.ToString(), "C"))
            {
                if (ddlEmployeeCode.SelectedIndex != 0 && ddlCompanyCode.SelectedIndex != 0)
                {
                    if (inTimeTextBox.Text != "")
                    {
                        ONDAdd();
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Red;
                        Label1.Text = "Please Give Time!";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = "Please select!";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Clear();
    }
    protected void ddlCompanyCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadEmployeeList();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
    }
    protected void ddlEmployeeCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeCode, ddlEmployeeCode.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeeCode, tblIdMaster, EmpImage);
        
    }
   
    #endregion
}
