﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Data.SqlClient;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Dal.Report;

public partial class PageControls_ucContructualEmpSalary : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    private SalaryBreakup salbreak = new SalaryBreakup();
    string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CONTREMPSAL.ToString(), "R"))
        {
            if (Session["LogIn"] != null)
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    loadEmployee();                   
                    txtConfirmationDateShow.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
                    btnSave.Enabled = true;
                    btnUpdateProj.Enabled = false;
                    Session["SlabId"] = null;
                    loadGrid();

                }

            }
            else
                Response.Redirect("login.aspx");
        }
        else
        {
            Session["NotReadPermission"] = "NotReadPermission";
            Response.Redirect("Default.aspx");
        }


    }

    private void loadGrid()
    {
        string str = "SELECT S.EmpId,E.EmpName,convert(varchar(50),S.ConfDate,103) as ConfDate,S.Gross FROM tblEmpSalInfo S inner join tblEmployee E on E.EmpId=S.EmpId where E.EmpStatus='Contractual' and E.EmpED=1";
        DataSet dsBonusPay = new DataSet();
        dsBonusPay = ClsCommon.GetAdhocResult(str);
        if (dsBonusPay.Tables[0].Rows.Count > 0)
        {
            GridSalBreak.DataSource = dsBonusPay.Tables[0];
            GridSalBreak.DataBind();
        }
        else
        {
            GridSalBreak.DataSource = null;
            GridSalBreak.DataBind();
        }
    }

    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and EmpStatus='Contractual' and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "EmpName");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CONTREMPSAL.ToString(), "C"))
            {
                string strSql = "SELECT EmpId FROM tblEmpSalInfo where EmpId='" + drpEmpId.SelectedItem.Text+"'";

                if (!ClsCommon.ItemCheck(strSql))
                {

                    if (TextBoxSalary.Text.ToString() != null)
                    {
                        if (isValidData())
                        {
                            action = "save";
                            Session["SlabId"]=null;
                            AddSalarySlab();
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                            lblErrorMessage.Text = "Data saved successful.";
                            action = "";
                            //showGridView(Session["EmpIdSal"].ToString());
                            //showGridViewpay(Session["EmpIdSal"].ToString());

                           // Session["EmpIdSal"] = "";
                            //Session["EmpNameSal"] = "";
                            //Showdata();
                            /*CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                            BindGrid(CompId);
                            ClearData();
                            ddlCompany.Enabled = true;
                            DDLEmpName.Enabled = true;*/


                        }
                    }
                    else
                    {
                        lblErrorMessage.Visible = true;
                        lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                        lblErrorMessage.Text = "Give Starting or Closing Rang!";
                    }
                }
                else
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Salary setup is already done", System.Drawing.Color.Red);
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private void AddSalarySlab()
    {
        salbreak.EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
        salbreak.Gross = int.Parse(TextBoxSalary.Text);
        salbreak.Basic = int.Parse("0");
        salbreak.HouseRent = int.Parse("0");
        salbreak.MedicalAllow = int.Parse("0");
        if (Session["SlabId"] != null)
        {
            salbreak.CBF = int.Parse(Session["SlabId"].ToString());
        }
        else
        {
            salbreak.CBF = int.Parse("0");
        }
        salbreak.ConfDate = txtConfirmationDateShow.Text;        
        salbreak.MobileCeling = int.Parse("0"); 
        salbreak.Actiction = action;
        ContructSalaryBreakUpInsert ProcContructSalaryBreakUp = new ContructSalaryBreakUpInsert();
        ProcContructSalaryBreakUp.salbreak = salbreak;
        ProcContructSalaryBreakUp.AddAddSalaryBreak();


    }
    private bool isValidData()
    {
        bool retv = true;
        DateTime FromDate = Convert.ToDateTime(txtConfirmationDateShow.Text.Trim());

        if (TextBoxSalary.Text == "")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Give Salary", System.Drawing.Color.Red);
        }
        else if (drpEmpId.SelectedItem.Text == "Select")
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Employee", System.Drawing.Color.Red);
        }

        else if (DateTime.Compare(System.DateTime.Now.Date, FromDate.Date) > 0)
        {
            retv = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Give Correct Date", System.Drawing.Color.Red);
            //if ((System.DateTime.Now).ToString().Substring(0, 10) == txtFromDate.Text.Trim())
            //{
            //    retv = true;
            //    SalaryBreakLabel.Text = "";
            //}
        }

        return retv;
    }
    protected void btnUpdateProj_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CONTREMPSAL.ToString(), "U"))
            {
               if (TextBoxSalary.Text.ToString() != null)
                    {
                        if (isValidData())
                        {
                            action = "Update";
                            AddSalarySlab();
                            lblErrorMessage.Visible = true;
                            lblErrorMessage.ForeColor = System.Drawing.Color.Green;
                            lblErrorMessage.Text = "Data UpDated successful.";
                            Session["SlabId"] = null;
                            action = "";
                            //showGridView(Session["EmpIdSal"].ToString());
                            //showGridViewpay(Session["EmpIdSal"].ToString());

                            // Session["EmpIdSal"] = "";
                            //Session["EmpNameSal"] = "";
                            //Showdata();
                            /*CompId = int.Parse(ddlCompany.SelectedValue.ToString());
                            BindGrid(CompId);
                            ClearData();
                            ddlCompany.Enabled = true;
                            DDLEmpName.Enabled = true;*/


                        }
                   
                }
                else
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, "Salary setup is already done", System.Drawing.Color.Red);
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Unable to process request";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
        ClearAll();
    }
    private void ClearAll()
    {
        drpEmpId.SelectedItem.Text = "Select";
        TextBoxSalary0.Text = "";
        TextBoxSalary.Text = "";
        txtConfirmationDateShow.Text = Convert.ToString(System.DateTime.Now).Substring(0, 10);
        btnSave.Enabled = true;
        btnUpdateProj.Enabled = false;
        Session["SlabId"] = null;
        drpEmpId.Enabled = true;
        drpCmp.Enabled = true;
        loadGrid();

    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Session["SlabId"] = null;
        Response.Redirect("Default.aspx");
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        TextBoxSalary0.Text = objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GridSalBreak_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void GridSalBreak_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void GridSalBreak_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridSalBreak_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnDel_Click(object sender, EventArgs e)
   {
   }

    
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYBREAKUP.ToString(), "U"))
            {
                
                
                drpEmpId.Enabled = false;
                drpCmp.Enabled = false;
                loadFormGridSalBreak();
            }
            else
            {
            }
            // objCommonName.LabelMessageandColor(Label5, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }

    private void loadFormGridSalBreak()
    {
        foreach (GridViewRow gvrow in GridSalBreak.Rows)
        {

            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadSalaryBreakUp(id, i);
                btnSave.Enabled = false;
                btnUpdateProj.Enabled = true;
                break;
            }

        }
    }
    private void loadSalaryBreakUp(string id, int row)
    {

        try
        {

            
            //.Text = dr["SalarySlabID"].ToString();
            //.Text = numberstring(dr["StartingRange"].ToString());
            TextBoxSalary.Text = GridSalBreak.Rows[row].Cells[3].Text;
            txtConfirmationDateShow.Text = GridSalBreak.Rows[row].Cells[2].Text;
            drpEmpId.SelectedItem.Text = GridSalBreak.Rows[row].Cells[0].Text;
            DataSet dsSalaryId = new DataSet();
            string Sql = "select SalId from tblEmpSalInfo where EmpId='" + drpEmpId.SelectedItem.Text + "' and ConfDate=convert(datetime,'" + GridSalBreak.Rows[row].Cells[2].Text + "', 103) and Gross=" + GridSalBreak.Rows[row].Cells[3].Text;
            dsSalaryId = ClsCommon.GetAdhocResult(Sql);
            if (dsSalaryId != null)
            {
                Session["SlabId"] = dsSalaryId.Tables[0].Rows[0][0].ToString();
            }
            else
            {
                Session["SlabId"] = null;
            }




        }
        catch (Exception ex)
        {
            //objCommonName.LabelMessageandColor(Label1, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
}
