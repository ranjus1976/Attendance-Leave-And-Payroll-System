﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Role;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;


public partial class PageControls_ucFormManagement : System.Web.UI.UserControl
{
    #region Declarations

    Function obj_Function;
    RoleData obj_RoleData;
    SqlCommand cmd = new SqlCommand();
    SqlConnection con;
    static Int32 RoleId;
    ArrayList objArrayListchkSelect = new ArrayList();
    ArrayList objArrayListchkReadOnlySelect = new ArrayList();
    ArrayList objArrayListchkDeleteSelect = new ArrayList();
    ArrayList objArrayListchkUpdateSelect = new ArrayList();
    ArrayList objArrayListchkInsertSelect = new ArrayList();
    ArrayList objArrayListchkAllSelect = new ArrayList();
    ArrayList objArrayListRowNumber = new ArrayList();

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["Role_Number"] != null)
                {
                    RoleId = Convert.ToInt32(Request.QueryString["Role_Number"].Trim());
                }

                lblErrorMessage.Visible = false;
                BindForm();
                LoadFormPermissionByUserId(RoleId);
                CheckBoxUpdateAllSelect.Enabled = false;
                CheckBoxReadonlyAllSelect.Enabled = false;
                CheckBoxInsertAllSelect.Enabled = false;
                CheckBoxDeleteAllSelect.Enabled = false;
            }
            
        }
        else
            Response.Redirect("login.aspx");

    }

    #region Private Methods

    private void PermissiomChecking(String strPerm, String oFormList)
    {
        if (strPerm.Contains("R") || strPerm.Contains("C") || strPerm.Contains("U") || strPerm.Contains("D"))
        {
            for (int i = 0; i < grdForms.Rows.Count; i++)
            {
                GridViewRow objGridViewRow = grdForms.Rows[i];
                HiddenField FormConstant = (HiddenField)objGridViewRow.FindControl("hdnFormConstant");

                if (oFormList == FormConstant.Value.ToString())
                {
                    CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkSelect");
                    CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[3].FindControl("chkReadOnly");
                    CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
                    CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
                    CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

                    if (strPerm.Contains("R"))
                    {
                        chkSelect.Enabled = true;
                        chkSelect.Checked = true;
                        chkReadOnly.Checked = true;
                        chkReadOnly.Enabled = true;
                        chkInsert.Enabled = true;
                        chkUpdate.Enabled = true;
                        chkDelete.Enabled = true;
                    }
                    if (strPerm.Contains("C"))
                    {
                        chkInsert.Enabled = true;
                        chkInsert.Checked = true;
                    }
                    if (strPerm.Contains("U"))
                    {
                        chkUpdate.Enabled = true;
                        chkUpdate.Checked = true;
                    }
                    if (strPerm.Contains("D"))
                    {
                        chkDelete.Enabled = true;
                        chkDelete.Checked = true;
                    }
                }
            }
        }
    }
    private void LoadFormPermissionByUserId(Int32 roleId)
    {
        string strPerm = "";
        //string UserId = Session["UserName1"].ToString();
        SqlConnection objReturnedConn = new SqlConnection();
        SqlCommand comd = new SqlCommand();
        ReportData obj_ReportData = new ReportData();

        string Sql = "sp_FormLoadbyUser";
        objReturnedConn = obj_ReportData.GetDBConn();
        objReturnedConn.Open();
        comd.Connection = objReturnedConn;
        comd.CommandType = CommandType.StoredProcedure;
        comd.CommandText = Sql;

        comd.Parameters.AddWithValue("@roleId", roleId);

        SqlDataReader reader = comd.ExecuteReader();

        while (reader.Read())
        {
            if (reader["FormConstant"] != null && reader["Function_Desc"] != null)
            {
                String oFormList = reader["FormConstant"].ToString();
                String oFuncDesc = reader["Function_Desc"].ToString();

                if (oFuncDesc.Contains("R") || oFuncDesc.Contains("C") || oFuncDesc.Contains("U") || oFuncDesc.Contains("D"))
                {
                    if (oFormList.ToString() == "COMPANYSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DEPARTMENTSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DESIGNATIONSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "SECTIONSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "SHIFTSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "ACTIONTAKEN")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "OVERNIGHTDUTY")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "SALARYSLABSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }    

                    else if (oFormList.ToString() == "ANYUNREST")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "OSDSETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "COMPANYMANUALENTRY")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "WEEKLYHOLIDAY")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "GOVTHOLIDAY")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "REMARKS")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "EMPLOYEEINFORMATION")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }

                    else if (oFormList.ToString() == "EMPLOYEEDETAILSINFOREPORT")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                      
                    else if (oFormList.ToString() == "EMPLOYEEINFORMATIONLIST")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "EMPLOYEEENABLEDISABLE")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "EMPLOYEEIDCONVERTER")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "EMPLOYEEPROXYIDCONVERTER")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVECONFIG")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVETYPESETUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVEENTRY")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVEAPPROVE")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVESTATUS")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVETRANSFER")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DATACOLLECION")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DATAPROCESS")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DAILYREPORT")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "MONTHLYREPORT")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "JOBCARD")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "EMPLOYEEINFOREPORT")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "NEWEMPLOYEEINFO")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "RESIGNEMPLOYEEINFO")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVEINFORMATIONREPOR")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "LEAVEBALANCEREPOR")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "CREATEUSER")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    
                    else if (oFormList.ToString() == "ROLECREAION")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "CONFIRMATIONDATE")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                    else if (oFormList.ToString() == "DATABASEBACKUP")
                    {
                        strPerm = oFuncDesc.ToString();
                        PermissiomChecking(strPerm, oFormList);
                    }
                }
            }
        }
    }
    private void LoadDataTable()
    {
        DataTable dtGrid = new DataTable();
        dtGrid = (DataTable)Session["dtGridStat"];

    }
    private void BindForm()
    {
        XmlDataDocument doc = new XmlDataDocument();

        doc.DataSet.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "\\XML\\Function.xml");
        DataTable dtVal = doc.DataSet.Tables[0];

        grdForms.DataSource = dtVal;
        grdForms.DataBind();
    }
    private String CheckBoxFunction(CheckBox chkInsert, CheckBox chkUpdate, CheckBox chkDelete, CheckBox chkReadOnly)
    {
        String FunctionDescription = "";
        String insert = ConfigurationManager.AppSettings["INSER"].ToString();
        String delete = ConfigurationManager.AppSettings["DELETE"].ToString();
        String update = ConfigurationManager.AppSettings["UPDATE"].ToString();
        String readOnly = ConfigurationManager.AppSettings["READONLY"].ToString();

        if (chkInsert.Checked == true && chkUpdate.Checked == true &&
            chkDelete.Checked == true && chkReadOnly.Checked == true)
        {
            FunctionDescription = insert + update + delete + readOnly;
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == true &&
            chkDelete.Checked == true && chkReadOnly.Checked == false)
        {
            FunctionDescription = insert + update + delete + "-";
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == true &&
            chkDelete.Checked == false && chkReadOnly.Checked == true)
        {
            FunctionDescription = insert + update + "-" + readOnly;
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == false &&
            chkDelete.Checked == true && chkReadOnly.Checked == true)
        {
            FunctionDescription = insert + "-" + delete + readOnly;
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == true &&
            chkDelete.Checked == true && chkReadOnly.Checked == true)
        {
            FunctionDescription = "-" + update + delete + readOnly;
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == true &&
            chkDelete.Checked == false && chkReadOnly.Checked == false)
        {
            FunctionDescription = insert + update + "-" + "-";
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == false &&
            chkDelete.Checked == true && chkReadOnly.Checked == false)
        {
            FunctionDescription = insert + "-" + delete + "-";
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == true &&
            chkDelete.Checked == true && chkReadOnly.Checked == false)
        {
            FunctionDescription = "-" + update + delete + "-";
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == false &&
            chkDelete.Checked == false && chkReadOnly.Checked == true)
        {
            FunctionDescription = insert + "-" + "-" + readOnly;
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == true &&
            chkDelete.Checked == false && chkReadOnly.Checked == true)
        {
            FunctionDescription = "-" + update + "-" + readOnly;
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == false &&
            chkDelete.Checked == true && chkReadOnly.Checked == true)
        {
            FunctionDescription = "-" + "-" + delete + readOnly;
        }
        else if (chkInsert.Checked == true && chkUpdate.Checked == false &&
            chkDelete.Checked == false && chkReadOnly.Checked == false)
        {
            FunctionDescription = insert + "-" + "-" + "-";
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == false &&
        chkDelete.Checked == true && chkReadOnly.Checked == false)
        {
            FunctionDescription = "-" + "-" + delete + "-";
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == false &&
            chkDelete.Checked == false && chkReadOnly.Checked == true)
        {
            FunctionDescription = "-" + "-" + "-" + readOnly;
        }
        else if (chkInsert.Checked == false && chkUpdate.Checked == true &&
            chkDelete.Checked == false && chkReadOnly.Checked == false)
        {
            FunctionDescription = "-" + update + "-" + "-";
        }
        else
            FunctionDescription = "-" + "-" + "-" + "-";

        return FunctionDescription;
    }
    public void InsertFunction()
    {
        String FunctionNamevalue;
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkSelect");
            CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[3].FindControl("chkReadOnly");
            CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
            CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
            CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

            if (chkSelect != null)
            {
                Label FormName = (Label)grdForms.Rows[i].Cells[2].FindControl("lblFormName");
                HiddenField hdnFormConstant = (HiddenField)grdForms.Rows[i].Cells[1].FindControl("hdnFormConstant");
                FunctionNamevalue = CheckBoxFunction(chkInsert, chkUpdate, chkDelete, chkReadOnly);

                obj_Function.RoleNumber = RoleId;
                obj_Function.FunctioName = Convert.ToString(FormName.Text);
                obj_Function.FormConstantName = Convert.ToString(hdnFormConstant.Value);
                obj_Function.FunctionDescription = FunctionNamevalue;
                obj_Function.EntryBy = "1";
                obj_Function.EntryDate = Convert.ToString(System.DateTime.Today);
                obj_Function.PC = System.Net.Dns.GetHostName().ToString();

                ProcessFunctionDataInsert obj_ProcessFunctionDataInsert = new ProcessFunctionDataInsert();
                obj_ProcessFunctionDataInsert.Function = obj_Function;
                obj_ProcessFunctionDataInsert.invoke();
            }
        }
    }
    protected void AddFunction()
    {
        ArrayList DataList = new ArrayList();
        string Data = "";
        Int32 Role_Number = 0;
        obj_Function = new Function();
        obj_RoleData = new RoleData();
        con = obj_RoleData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "Select Function_Number,Role_Number From tblFunction Where Role_Number='" + RoleId + "'";
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            DataList.Add(Convert.ToInt32(reader["Function_Number"]));
            Role_Number = Convert.ToInt32(reader["Role_Number"]);
        }
        for (int i = 0; i < DataList.Count; i++)
        {
            Data = Convert.ToString(DataList[i]);
            if (Data != null && Data != String.Empty)
            {
                obj_Function.FunctionNumber = Convert.ToInt32(Data);
                obj_Function.RoleNumber = Convert.ToInt32(Role_Number);
                ProcessFunctionDataDelete obj_ProcessFunctionDataDelete = new ProcessFunctionDataDelete();
                obj_ProcessFunctionDataDelete.Function = obj_Function;
                obj_ProcessFunctionDataDelete.invoke();
            }
            else
                InsertFunction();
        }
        InsertFunction();
    }
    private void AllcheckBoxSelect()
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkSelect");
            CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkReadOnly");

            if (CheckBoxSelectAll.Checked == true)
            {
                chkSelect.Checked = true;
                chkReadOnly.Enabled = true;
            }
            else
            {
                chkSelect.Checked = false;
                chkReadOnly.Enabled = false;
            }

        }
    }
    private void AllReadOnlyCheckBoxSelect()
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkReadOnly");
            CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
            CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
            CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

            if (CheckBoxReadonlyAllSelect.Checked == true)
            {
                chkSelect.Checked = true;
                chkInsert.Enabled = true;
                chkDelete.Enabled = true;
                chkUpdate.Enabled = true;
            }
            else
            {
                chkSelect.Checked = false;
                chkInsert.Checked = false;
                chkDelete.Checked = false;
                chkUpdate.Checked = false;
                chkInsert.Enabled = false;
                chkDelete.Enabled = false;
                chkUpdate.Enabled = false;
            }
        }
    }
    private void AllInsertCheckBoxSelect()
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("CheckBoxInsert");

            if (CheckBoxInsertAllSelect.Checked == true)
            {
                chkSelect.Checked = true;
            }
            else
            {
                chkSelect.Checked = false;
            }
        }
    }
    private void AllUpdateCheckBoxSelect()
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("CheckBoxUpdate");
            if (CheckBoxUpdateAllSelect.Checked == true)
            {
                chkSelect.Checked = true;
            }
            else
            {
                chkSelect.Checked = false;
            }
        }
    }
    private void AllDeleteCheckBoxSelect()
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("CheckBoxDelete");
            if (CheckBoxDeleteAllSelect.Checked == true)
            {
                chkSelect.Checked = true;
            }
            else
            {
                chkSelect.Checked = false;
            }
        }
    }

    #endregion

    #region Button and Event Handlers

    protected void btnSave_Click(object sender, EventArgs e)
    {
        {
            string Sql = "declare @hasrow int,@RoleName varchar(30)";
            Sql = Sql + " select @hasrow = count(*) from tlbRole where Role_Number = " + RoleId + " and User_Name = '" + Convert.ToString(Session["Username1"]) + "' ";
            Sql = Sql + " select @RoleName = Role_Name from tlbRole where Role_Number =  " + RoleId + " ";
            Sql = Sql + " if(@hasrow = 0)";
            Sql = Sql + " BEGIN";
            Sql = Sql + "  insert into tlbRole(Role_Number, Role_Name,User_Name) values(" + RoleId + ",@RoleName,'" + Convert.ToString(Session["Username1"]) + "')";
            Sql = Sql + " END";
            SqlConnection objReturnedConn;
            SqlCommand comdd = new SqlCommand();
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            objReturnedConn.Open();
            comdd.Connection = objReturnedConn;
            comdd.CommandType = CommandType.Text;
            comdd.CommandText = Sql;
            comdd.ExecuteNonQuery();
        }
        if (Session["LogIn"] != null)
        {
            AddFunction();
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void grdForms_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
    }
    protected void chkReadOnly_CheckedChanged(object sender, EventArgs e)
    {

        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[3].FindControl("chkReadOnly");
            CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
            CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
            CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

            if (chkReadOnly.Checked == true)
            {
                chkInsert.Enabled = true;
                chkDelete.Enabled = true;
                chkUpdate.Enabled = true;
            }
            else
            {
                chkInsert.Checked = false;
                chkDelete.Checked = false;
                chkUpdate.Checked = false;
                chkInsert.Enabled = false;
                chkDelete.Enabled = false;
                chkUpdate.Enabled = false;
                CheckBoxReadonlyAllSelect.Checked = false;
            }
        }

    }
    protected void CheckBoxSelectAll_CheckedChanged(object sender, EventArgs e)
    {

        AllcheckBoxSelect();
        if (CheckBoxSelectAll.Checked == true)
        {
            CheckBoxReadonlyAllSelect.Enabled = true;
        }
        else
        {
            CheckBoxReadonlyAllSelect.Enabled = false;
            CheckBoxInsertAllSelect.Enabled = false;
            CheckBoxUpdateAllSelect.Enabled = false;
            CheckBoxDeleteAllSelect.Enabled = false;
            CheckBoxReadonlyAllSelect.Checked = false;
            CheckBoxInsertAllSelect.Checked = false;
            CheckBoxUpdateAllSelect.Checked = false;
            CheckBoxDeleteAllSelect.Checked = false;

            for (int i = 0; i < grdForms.Rows.Count; i++)
            {
                CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkReadOnly");
                CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
                CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
                CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

                chkReadOnly.Enabled = false;
                chkInsert.Enabled = false;
                chkDelete.Enabled = false;
                chkUpdate.Enabled = false;
                chkReadOnly.Checked = false;
                chkInsert.Checked = false;
                chkDelete.Checked = false;
                chkUpdate.Checked = false;
            }
        }
    }
    protected void chkSelect_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < grdForms.Rows.Count; i++)
        {
            CheckBox chkSelect = (CheckBox)grdForms.Rows[i].Cells[0].FindControl("chkSelect");
            CheckBox chkReadOnly = (CheckBox)grdForms.Rows[i].Cells[3].FindControl("chkReadOnly");
            CheckBox chkInsert = (CheckBox)grdForms.Rows[i].Cells[4].FindControl("CheckBoxInsert");
            CheckBox chkDelete = (CheckBox)grdForms.Rows[i].Cells[5].FindControl("CheckBoxDelete");
            CheckBox chkUpdate = (CheckBox)grdForms.Rows[i].Cells[6].FindControl("CheckBoxUpdate");

            if (chkSelect.Checked == true)
            {
                chkReadOnly.Enabled = true;
            }
            else
            {
                chkReadOnly.Checked = false;
                chkInsert.Checked = false;
                chkDelete.Checked = false;
                chkUpdate.Checked = false;
                chkInsert.Enabled = false;
                chkDelete.Enabled = false;
                chkUpdate.Enabled = false;
                chkReadOnly.Enabled = false;
                CheckBoxReadonlyAllSelect.Enabled = false;
                CheckBoxDeleteAllSelect.Enabled = false;
                CheckBoxInsertAllSelect.Enabled = false;
                CheckBoxUpdateAllSelect.Enabled = false;
                CheckBoxReadonlyAllSelect.Checked = false;
                CheckBoxDeleteAllSelect.Checked = false;
                CheckBoxInsertAllSelect.Checked = false;
                CheckBoxUpdateAllSelect.Checked = false;
            }
        }

    }
    protected void CheckBoxReadonlyAllSelect_CheckedChanged(object sender, EventArgs e)
    {
        AllReadOnlyCheckBoxSelect();
        if (CheckBoxReadonlyAllSelect.Checked == true && CheckBoxReadonlyAllSelect.Enabled == true)
        {
            CheckBoxInsertAllSelect.Enabled = true;
            CheckBoxUpdateAllSelect.Enabled = true;
            CheckBoxDeleteAllSelect.Enabled = true;
        }
        else
        {
            CheckBoxInsertAllSelect.Enabled = false;
            CheckBoxUpdateAllSelect.Enabled = false;
            CheckBoxDeleteAllSelect.Enabled = false;

            CheckBoxInsertAllSelect.Checked = false;
            CheckBoxUpdateAllSelect.Checked = false;
            CheckBoxDeleteAllSelect.Checked = false;
        }
    }
    protected void CheckBoxInsertAllSelect_CheckedChanged(object sender, EventArgs e)
    {
        AllInsertCheckBoxSelect();
    }
    protected void CheckBoxUpdateAllSelect_CheckedChanged(object sender, EventArgs e)
    {
        AllUpdateCheckBoxSelect();
    }
    protected void CheckBoxDeleteAllSelect_CheckedChanged(object sender, EventArgs e)
    {
        AllDeleteCheckBoxSelect();
    }
    protected void grdForms_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //((GridView )sender).Font
        /*
        if (e.Row.RowType != DataControlRowType.Header)
        {
            CheckBox oChRead = (CheckBox)e.Row.FindControl("chkReadOnly");
            if (oChRead != null)
            {
            }
        }
        */
    }
    protected void CheckBoxInsert_CheckedChanged(object sender, EventArgs e)
    {

    }

    #endregion
}
