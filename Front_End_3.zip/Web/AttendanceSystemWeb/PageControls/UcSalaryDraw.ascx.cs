﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;


public partial class PageControls_UcSalaryDraw : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYDRAW.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    loadCompany();
                    loadEmployee();
                    loadDepartment();
                    LoadYear();
                    objCommonName.Addmonth(drpSalaryMonth);
                    drpDept.Enabled = false;
                    drpEmpId.Enabled = false;
                    RadioButtonAll.Checked = true;
                    RadioButtonAll.Enabled = true;
                    RadioButtonCompany.Checked = false;
                    RadioButtonDepartment.Checked =false;
                    rdbtnEmployee.Checked = false;
                    btnBankAdvice.Visible = false;
                    btnBonusSlip.Visible = false;
                    btnDraw.Visible = false;
                    //String ReportDateShow = Convert.ToString(System.DateTime.Now);
                    //ReportDateShow = ReportDateShow.Substring(0, 10);
                    //txtReportDate.Text = ReportDateShow;
                    Session["NotReadPermission"] = null;
                    /*if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
                    {

                        drpCmp.Enabled = true;
                        RadioButtonAll.Enabled = true;
                        RadioButtonDepartment.Enabled = true;
                        rdbtnEmployee.Enabled = true;
                    }

                    else
                    {
                        
                        RadioButtonAll.Enabled = false;
                        RadioButtonDepartment.Enabled = false;
                        rdbtnEmployee.Enabled = false;
                    }*/
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");

    }

    private void LoadYear()
    {
        drpSalaryYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 7; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drpSalaryYear.DataSource = li;
        drpSalaryYear.Items.AddRange(items.ToArray());
    }

    
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void loadDepartment()
    {

        try
        {
            drpDept.Items.Clear();
            string strSQL = "Select Dept_Number, DeptName from tblDepartment where comp_number = " + drpCmp.SelectedValue + " ";
            ClsCommon.drplistAdd(drpDept, strSQL, "DeptName", "Dept_Number");
            drpDept.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

    }

    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
        RadioButtonAll.Checked = true;
        RadioButtonDepartment.Checked = false;
        RadioButtonCompany.Checked = false;
        rdbtnEmployee.Checked = false;
    }
  
    protected void RadioButtonDepartment_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = true;
        drpEmpId.Enabled = false;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = true;
        rdbtnEmployee.Checked = false;
        RadioButtonCompany.Checked = false;

        loadDepartment();
    }
    private ArrayList GetOption()
    {
        try
        {
            if (RadioButtonAll.Checked)
            {
                
                OptionArralist.Add("All");
                OptionArralist.Add("All");
            }
            else if (RadioButtonCompany.Checked)
            {
           
                OptionArralist.Add("COM");
                OptionArralist.Add(drpCmp.SelectedItem.Text);
            }
            else if (RadioButtonDepartment.Checked)
            {
              
                OptionArralist.Add(drpCmp.SelectedItem.Text);
                OptionArralist.Add(drpDept.SelectedItem.Text);
            }
            else
            {
               
                OptionArralist.Add("EMP");
                OptionArralist.Add(drpEmpId.SelectedItem.Text);
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }

    protected void btnSalarySheet_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if(Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblErrorMessage.Text = "";
                    Session["ReportName"] = "rptSalarySheet.rpt";
                    Session["TableName"] = "dsSalarySheet";
                    Session["CompanyName"] = drpCmp.SelectedItem.Text;
                    Session["Month"] = drpSalaryMonth.SelectedItem.Text;
                    Session["Year"] = drpSalaryYear.SelectedItem.Text;

                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_SalarySheet";


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private bool Validate()
    {
        bool retVal = true;
        if (RadioButtonAll.Checked)
        {
            retVal = true;
        }
        if (drpDept.SelectedItem.Text == "Select" && RadioButtonDepartment.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Department".ToString(), System.Drawing.Color.Red);
        }
        if (drpEmpId.SelectedItem.Text == "Select" && rdbtnEmployee.Checked)
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Employee".ToString(), System.Drawing.Color.Red);
        }

        if (drpSalaryYear.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Year".ToString(), System.Drawing.Color.Red);
        }
        if (drpSalaryMonth.SelectedItem.Text == "Select")
        {
            retVal = false;
            objCommonName.LabelMessageandColor(lblErrorMessage, "Select Month".ToString(), System.Drawing.Color.Red);
        }
        return retVal;
    }

    protected void btnPaySleep_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblErrorMessage.Text = "";
                    Session["ReportName"] = "rptPaySlip.rpt";
                    Session["TableName"] = "dsSalarySheet";
                    Session["ToDate"] = null;
                    Session["FromDate"] = null;
                    Session["CompanyName"] = null;

                    Session["CompanyName"] = drpCmp.SelectedItem.Text;
                    //Session["Company_Number"] = drpCmp.SelectedValue;
                    Session["Month"] = drpSalaryMonth.SelectedItem.Text;
                    Session["Year"] = drpSalaryYear.SelectedItem.Text;

                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_SalarySheet";


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnBankAdvice_Click(object sender, EventArgs e)
    {

    }
    protected void btnBonusSlip_Click(object sender, EventArgs e)
    {

    }
    protected void btnDraw_Click(object sender, EventArgs e)
    {

    }
   
    protected void salaryDrawGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void salaryDrawGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void salaryDrawGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void salaryDrawGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void salaryDrawGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        lblEmpname.Text=objCommonName.EmployeeName(drpEmpId.SelectedItem.Text);
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadDepartment();
        loadEmployee();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(drpEmpId, drpEmpId.SelectedValue.ToString(), lblEmpname);
        Clear();
    }
    private void Clear()
    {

    }

    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
       
    }

    protected void rdbtnEmployee_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = true;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = false;
        RadioButtonCompany.Checked = false;
        rdbtnEmployee.Checked = true;
      
        
    }
    protected void RadioButtonCompany_CheckedChanged1(object sender, EventArgs e)
    {
        drpDept.Enabled = false;
        drpEmpId.Enabled = false;
        RadioButtonCompany.Checked = true;
        RadioButtonAll.Checked = false;
        RadioButtonDepartment.Checked = false;
        rdbtnEmployee.Checked = false;
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnShortSalary_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (Validate())
            {
                try
                {
                    //Initially All Report Session Clear//////////////////////////////////////////////////////////////
                    lblErrorMessage.Text = "";
                    Session["ReportName"] = "rptShortSalary.rpt";
                    Session["TableName"] = "dsSalarySheet";
                    Session["CompanyName"] = drpCmp.SelectedItem.Text;
                    Session["Month"] = drpSalaryMonth.SelectedItem.Text;
                    Session["Year"] = drpSalaryYear.SelectedItem.Text;

                    ArralistOption = GetOption();
                    Session["option"] = ArralistOption[0];
                    Session["option1"] = ArralistOption[1];
                    Session["reportstorage"] = "sp_SalarySheet";


                    string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window",
                                                            "window.open('" + strPath +
                                                            "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');",
                                                            true);
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }
}
