﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;


public partial class PageControls_ucLeaveInformationEntry : System.Web.UI.UserControl
{
    #region Declaration
    string halfday = "";
    String ReportDateShow;
    String TimeShow;
    TimeSpan ts;
    public string lastlimit = "";
    CommonName objCommonName;
    int PostLeave = 0;
    protected TemplatedWebPart templatedWP;
    #endregion

    #region Page Load

    public string Fyear = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        string strSQL = "SELECT Financial_Year FROM tblFinancial_Year where Running_Flag=1";
        DataSet FinYear = new DataSet();
        FinYear = ClsCommon.GetAdhocResult(strSQL);
        if (FinYear.Tables[0].Rows.Count != 0)
        {
            Fyear = FinYear.Tables[0].Rows[0][0].ToString();
        }
        if (!IsPostBack)
        {

            
            //if (WebPartManager1.Personalization.Scope == PersonalizationScope.User)
            //{
            //    if (WebPartManager1.Personalization.CanEnterSharedScope)
            //    {
            //        WebPartManager1.Personalization.ToggleScope();
            //    }
            //}
           
            //templatedWP = new TemplatedWebPart();
            //WebPartManager1.
            //AddWebPart(templatedWP, TestZone, 1);
            Page.ClientScript.RegisterStartupScript(Type.GetType("System.String"), "addScript", "displayWindow()", true);

            if (Session["LogIn"] != null)
            {
                if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEENTRY.ToString(), "R"))
                {
                    GetAllorSpecificEmployees();
                    btnUpdate.Enabled = false;
                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    TimeShow = ReportDateShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);
                    txtSearchEndDate.Text = ReportDateShow;
                    txtSearchFromDate.Text = ReportDateShow;
                    dptFromDate.Text = ReportDateShow;
                    dtpToDate.Text = ReportDateShow;
                    ts = System.DateTime.Now.Subtract(System.DateTime.Now);
                    string str = ts.ToString();
                    str = str.Substring(0, 1);
                    int FinalDay = Convert.ToInt32(str) + 1;
                    txtTotalDays.Text = Convert.ToString(FinalDay);
                    FinancialYear();
                    Test();
                    objCommonName = new CommonName();
                    objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
                    rntMessage();
                    Session["NotReadPermission"] = null;
                    EmployeeImage.LoadImageEmp(ddlEmployeelist, tblIdMaster, EmpImage);
                    chkFirst.Enabled = false;
                    ChkSecond.Enabled = false;
                   
                }
                else
                {
                    Session["NotReadPermission"] = "NotReadPermission";
                    Response.Redirect("Default.aspx");
                }
            }
            else
                Response.Redirect("login.aspx");
        }
        if (Request.QueryString["editID"] != null)
        {
            LoadEditData();
            btnSave.Enabled = false;
        }
        if (Request.QueryString["delID"] != null)
        {
            DeleteAllData();
        }
    }
    //void Page_Init(object src, EventArgs e)
    //{
    //    GenericWebPart gwp = Parent as GenericWebPart;
    //    if (gwp != null)
    //    {
    //        gwp.Title = "My custom user control";
    //        //gwp.TitleIconImageUrl = @"~\images\Attn_Salary.jpg";
    //        //gwp.CatalogIconImageUrl = @"~\images\Attn_Salary.jpg";
    //    }
    //}


    #endregion

    #region Private Methods

    private void rntMessage()
    {
        if (Session["UserType"].ToString() != "ADMIN" || Session["UserType"].ToString() != "SUPERADMIN")
        {
            Int32 emplll = Convert.ToInt32(Session["User_Number"].ToString());
            LeaveStatusIndividualEMployee(emplll);
            lblMessage.Visible = true;
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "You have remaining " + LeaveStatusIndividualEMployee(int.Parse(Session["User_Number"].ToString())).ToString() + " day(s) leave";
        }
        else
        {
            Int32 emplll = Convert.ToInt32(Session["User_Number"].ToString());
            LeaveStatusIndividualEMployee(emplll);
            lblMessage.Visible = true;
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "You have remaining " + LeaveStatusIndividualEMployee(int.Parse(Session["User_Number"].ToString())).ToString() + " day(s) leave";
        }
    }
    public double LeaveStatusIndividualEMployee(Int32 Employee_Number)
    {
        Double BalanceLeave = 0;
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();

        String Sql = "Select (MAX_Balance-Avail) as Balance from tblLeave_Balance";
        Sql = Sql + " inner join tblLeave_Type on tblLeave_Type.Leave_Type_Number = tblLeave_Balance.Leave_Type_Number";
        Sql = Sql + " where Employee_Number = " + Employee_Number + " and  Ispaid = 1";

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            BalanceLeave = double.Parse(reader["Balance"].ToString());
        }
        return BalanceLeave;
    }
    public void SetEmpID()
    {
        DataSet dsResult = ClsCommon.GetAdhocResult(" select Emp_Number from tblEmployee where EmpId='" + ddlEmployeelist.SelectedItem.Text.Trim() + "'");
        if (dsResult.Tables.Count > 0)
        {
            if (dsResult.Tables[0].Rows.Count > 0)
            {
                hidEmpID.Value = dsResult.Tables[0].Rows[0]["Emp_Number"].ToString().Trim();
            }
        }
    }
    private void FinancialYear()
    {
        try
        {
            string strSQL = "select Opening_Date,Closing_Date,Financial_Year from  tblFinancial_Year where Running_Flag = 1";
            ClsCommon.drplistAdd(ddlFinancialYear, strSQL, "Financial_Year", "Opening_Date", "Closing_Date");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private void Test()
    {
        if (ddlEmployeelist.SelectedItem.Value.Trim() != "NA")
        {
            string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
            SetEmpID();
            PopulateGridData(false, false, false, int.MinValue, String.Empty, String.Empty);
        }
    }
    protected void GetAllorSpecificEmployees()
    {
        try
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                string[] str = { "All"};
                ddlEmployeelist.DataSource = str;
                //ddlEmployeelist.DataTextField = str[0];
                //ddlEmployeelist.DataValueField = str[1];
                ddlEmployeelist.DataBind();
                ClsCommon.drplistAddWithObject(ddlEmployeelist, " select EmpId,Emp_Number,EmpName from  tblEmployee where EmpEd=1 order by empId asc ", "EmpId", "Emp_Number");
                ddlEmployeelist.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                ClsCommon.drplistAddWithObject(ddlEmployeelist, " select EmpId,Emp_Number,EmpName from  tblEmployee where Emp_Number=" + Convert.ToInt32(Session["User_Number"].ToString()) + " and EmpEd=1 order by empId asc ", "EmpId", "Emp_Number");
                //ddlEmployeelist.Items.Insert(0, new ListItem("Select", "NA,NA"));
            }
            ClsCommon.drplistAdd(ddlLeaveType, " select Leave_Type_Number,Leave_Name from  tblLeave_Type ", "Leave_Name", "Leave_Type_Number");
            ddlLeaveType.Items.Insert(0, new ListItem("Select", "NA"));
            ClsCommon.drplistAdd(ddlSearchTypelIst, " select Leave_Type_Number,Leave_Name from  tblLeave_Type ", "Leave_Name", "Leave_Type_Number");
            ddlSearchTypelIst.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception e)
        {
            e.Message.ToString();

        }

    }
    protected void PopulateGridData(bool isadmin, bool upnewset, bool searchFilter, int leavetype, String startDate, String endDate)
    {
        bool IsAdminGroup = false;
        string empID = "";
        string[] values = ddlEmployeelist.SelectedItem.Value.Trim().Split(',');

        if (Session["UserType"].ToString() != "ADMIN" && Session["UserType"].ToString() != "SUPERADMIN")
        {
            empID = Session["User_Number"].ToString();
        }
        else
            empID = values[0];

        string strFilter = "";

        if (Session["Find"] != null)
        {
            if (searchFilter)
            {
                strFilter = " where tblLeave_Type.Leave_Type_Number = tblLeave_Apply.Leave_Type_Number and From_Date>='" + startDate + "' and To_Date<='" + endDate + "' and tblLeave_Apply.Leave_Type_Number=" + leavetype + " ";
            }

            ProcessLeaveView oLView = new ProcessLeaveView();
            oLView.ProcedureParams = new Object[] { strFilter };
            oLView.invoke();

            Session["LeaveData"] = (DataTable)oLView.LeaveDS.Tables[0];

            if (oLView.LeaveDS.Tables[0].Rows.Count > 0)
            {
                hidEditCheckedIDS.Value = "";
                DataTable dt2 = (DataTable)Session["LeaveData"];
                grvLeaveList.DataSource = dt2;
                grvLeaveList.DataBind();
            }
            else
            {
                hidEditCheckedIDS.Value = "";
                grvLeaveList.EmptyDataText = "Sorry ! no data found.";
                grvLeaveList.DataSource = null;
                grvLeaveList.DataBind();
            }
            lblMessage.Text = "";
        }
        else
        {
            if (empID.Trim() != "NA")
            {
                try
                {
                    strFilter = " where tblLeave_Apply.Leave_Year = '" + ddlFinancialYear.SelectedItem.Text.Trim() + "' and  tblLeave_Apply.Employee_Number =" + empID + " and  tblLeave_Type.Leave_Type_Number = tblLeave_Apply.Leave_Type_Number ";
                    ProcessLeaveView oLView = new ProcessLeaveView();
                    oLView.ProcedureParams = new Object[] { strFilter };
                    oLView.invoke();

                    Session["LeaveData"] = (DataTable)oLView.LeaveDS.Tables[0];

                    if (oLView.LeaveDS.Tables[0].Rows.Count > 0)
                    {
                        hidEditCheckedIDS.Value = "";
                        DataTable dt2 = (DataTable)Session["LeaveData"];
                        grvLeaveList.DataSource = dt2;
                        grvLeaveList.DataBind();
                    }
                    else
                    {
                        hidEditCheckedIDS.Value = "";
                        grvLeaveList.EmptyDataText = "Sorry ! no data found.";
                        grvLeaveList.DataSource = null;
                        grvLeaveList.DataBind();
                    }
                    lblMessage.Text = "";
                }
                catch (Exception ex)
                {
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Please select!";
            }

        }
    }
    private Int32 GetUserNumber()
    {
        Int32 User_Number;
        String UserName = Convert.ToString(Session["Username"]);
        String Sql = "Select User_Number from tblUser where UserId = '" + UserName + "'";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        User_Number = Convert.ToInt32(cmd.ExecuteScalar());

        return User_Number;
    }
    protected LeaveApplied PrepareLeaveData()
    {
        LeaveApplied oLeaveApplied = new LeaveApplied();
        if ("NA" != ddlLeaveType.SelectedValue.Trim())
        {
            if (Session["UserType"].ToString() != "ADMIN" && Session["UserType"].ToString() != "SUPERADMIN")
            {
                oLeaveApplied.Employee_Number = int.Parse(Session["User_Number"].ToString());
            }
            else
            {
                string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
                if (strValues[0] == "All")
                    strValues[0] = "0";
                oLeaveApplied.Employee_Number = int.Parse(strValues[0].ToString());
            }
            if (oLeaveApplied.Employee_Number == 0)
            {
                oLeaveApplied.Total_Days = float.Parse(txtTotalDays.Text.Trim());
                if (txtTotalDays.Text.Trim() == ".5")
                {
                    if (chkFirst.Checked)
                    {
                        oLeaveApplied.halfleave = "1";
                    }
                    else
                    {
                        oLeaveApplied.halfleave = "2";
                    }
                }
                else
                {
                    oLeaveApplied.halfleave = "0";
                }
                oLeaveApplied.Leave_Type_Number = int.Parse(ddlLeaveType.SelectedValue.Trim());
                oLeaveApplied.From_Date = Convert.ToDateTime(dptFromDate.Text);
                oLeaveApplied.To_Date = Convert.ToDateTime(dtpToDate.Text);
                oLeaveApplied.Approval = 1;
                oLeaveApplied.ApprovalDes = "Approved";
                oLeaveApplied.Remarks = txtRemarks.Text;
                oLeaveApplied.EntryBy = 1;
                oLeaveApplied.EntryDate = DateTime.Now;
                oLeaveApplied.PC = Request.UserHostAddress;
            }
            else
            {
                oLeaveApplied.Total_Days = float.Parse(txtTotalDays.Text.Trim());
                if (txtTotalDays.Text.Trim() == ".5")
                {
                    if (chkFirst.Checked)
                    {
                        oLeaveApplied.halfleave = "1";
                    }
                    else
                    {
                        oLeaveApplied.halfleave = "2";
                    }
                }
                else
                {
                    oLeaveApplied.halfleave = "0";
                }
                oLeaveApplied.Leave_Type_Number = int.Parse(ddlLeaveType.SelectedValue.Trim());
                oLeaveApplied.From_Date = Convert.ToDateTime(dptFromDate.Text);
                oLeaveApplied.To_Date = Convert.ToDateTime(dtpToDate.Text);
                oLeaveApplied.Approval = 0;
                oLeaveApplied.ApprovalDes = "Pending";
                oLeaveApplied.Remarks = txtRemarks.Text;
                oLeaveApplied.EntryBy = 1;
                oLeaveApplied.EntryDate = DateTime.Now;
                oLeaveApplied.PC = Request.UserHostAddress;
            }
        }
        return oLeaveApplied;
    }
    protected void SaveDataInDB()
    {
        LeaveApplied oLived = PrepareLeaveData();
        if (oLived != null)
        {
            ProcessEmployeeLeaveApply oLeaveApply = new ProcessEmployeeLeaveApply();
            oLeaveApply.LeaveApplly = oLived;
            oLeaveApply.invoke();
            PopulateGridData(false, false, true, int.MinValue, String.Empty, String.Empty);
        }

    }
    protected void UpdateInDB(Int32 LeaveApplyNumber)
    {
        Int32 EmpNo = int.Parse(hidEmpID.Value.Trim());
        Int32 LeavetTypeNo = Convert.ToInt32(ddlLeaveType.SelectedValue);
        DateTime FromDate = Convert.ToDateTime(dptFromDate.Text.Trim());
        DateTime ToDate = Convert.ToDateTime(dtpToDate.Text.Trim());
        float Days = float.Parse(txtTotalDays.Text.Trim().ToString());
        String Remarks = Convert.ToString(txtRemarks.Text);
        Int32 EntryBy = 1;
        DateTime EntryDate = DateTime.Now.Date;
        String PC = Convert.ToString(Request.UserHostAddress);
        string halfleave = "";
        if (txtTotalDays.Text.Trim() == ".5")
        {
            if (chkFirst.Checked)
            {
               halfleave = "1";
            }
            else
            {
                halfleave = "2";
            }
        }
        else
        {
            halfleave = "0";
        }


        String LeaveType = "sp_LeaveApplied_Update";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = LeaveType;

        cmd.Parameters.AddWithValue("@Employee_Number", EmpNo);
        cmd.Parameters.AddWithValue("@Leave_Apply_Number", LeaveApplyNumber);
        cmd.Parameters.AddWithValue("@From_Date", FromDate);
        cmd.Parameters.AddWithValue("@To_Date", ToDate);
        cmd.Parameters.AddWithValue("@Total_Days", Days);
        cmd.Parameters.AddWithValue("@Leave_Type_Number", LeavetTypeNo);
        cmd.Parameters.AddWithValue("@EntryBy", EntryBy);
        cmd.Parameters.AddWithValue("@EntryDate", EntryDate);
        cmd.Parameters.AddWithValue("@PC", PC);
        cmd.Parameters.AddWithValue("@Remarks", Remarks);
        cmd.Parameters.AddWithValue("@HFLeave", halfleave);
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void LoadEditData()
    {
        foreach (GridViewRow oRow in grvLeaveList.Rows)
        {
            System.Web.UI.WebControls.CheckBox oCheckBoxEdit = (System.Web.UI.WebControls.CheckBox)oRow.FindControl("chkEdit");

            if (oCheckBoxEdit.Checked)
            {
                HiddenField oHidApply_Number = (HiddenField)oRow.FindControl("hidLeave_Apply_Number");
                HiddenField oHidEmployeeNumber = (HiddenField)oRow.FindControl("hidEmployee_Number");
                HiddenField oHidLeaveTypenUmber = (HiddenField)oRow.FindControl("hidLeave_Type_Number");
                Session["LeaveApplyNumber"] = oHidApply_Number.Value.ToString();

                ddlLeaveType.SelectedValue = oHidLeaveTypenUmber.Value.Trim();
                dptFromDate.Text = oRow.Cells[0].Text;
                dtpToDate.Text = oRow.Cells[1].Text;
                txtTotalDays.Text = oRow.Cells[2].Text;

                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }
        }
    }
    protected void DeleteAllData()
    {
        ArrayList oDelList = new ArrayList();

        foreach (GridViewRow grdDel in grvLeaveList.Rows)
        {
            System.Web.UI.WebControls.CheckBox chkDelete = (System.Web.UI.WebControls.CheckBox)grdDel.FindControl("chkDelete");

            if (chkDelete.Checked)
            {
                HiddenField oApplyNumber = (HiddenField)grdDel.FindControl("hidLeave_Apply_Number");
                oDelList.Add(oApplyNumber.Value);
            }
        }
        foreach (string strDelID in oDelList)
        {
            DeleteLeave(strDelID);
        }
    }
    protected void DeleteLeave(string strDeletID)
    {
        try
        {
            LeaveApplied oLeaveApplied = new LeaveApplied();

            oLeaveApplied.Leave_Apply_Number = int.Parse(strDeletID.Trim());
            ProcessEmployeeLeaveDelete oLeveDelete = new ProcessEmployeeLeaveDelete();
            oLeveDelete.LeaveApplly = oLeaveApplied;
            oLeveDelete.invoke();
            PopulateGridData(false, false, false, int.MinValue, String.Empty, String.Empty);

        }
        catch (Exception eDeleteLeave)
        {
            eDeleteLeave.Message.ToString();

        }
    }
    protected string PrePareEditURL(object oRow)
    {
        DataRowView oDataRowView = (DataRowView)oRow;
        oDataRowView.Row["Leave_Apply_Number"].ToString();
        return "~/Default.aspx?Page=LeaveEntry&editID=" + oDataRowView.Row["Leave_Apply_Number"].ToString();
    }
    protected string PrepareDeleteURL(object oRow)
    {
        DataRowView oDataRowView = (DataRowView)oRow;
        oDataRowView.Row["Leave_Apply_Number"].ToString();

        return "~/Default.aspx?Page=LeaveEntry&delID=" + oDataRowView.Row["Leave_Apply_Number"].ToString();
    }
    protected void ClearAllFields()
    {
        dptFromDate.Text = "";

        dtpToDate.Text = "";

        txtTotalDays.Text = "";

    }
    private void Refresh()
    {
        dtpToDate.Text = "";
        dptFromDate.Text = "";
        txtTotalDays.Text = "";
        ddlEmployeelist.SelectedIndex = 0;
        ddlLeaveType.SelectedIndex = 0;

        ddlFinancialYear.SelectedIndex = 0;
        txtRemarks.Text = "";
    }
    private bool FromDateToDate(DateTime FromDate, DateTime ToDate)
    {
        bool retnvalue = false;
        Int32 Count = 0;
        ArrayList FromDateArr = new ArrayList();
        ArrayList ToDateArr = new ArrayList();
        Int32 Employee_Number = 0;

        if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
        {
            string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
            if (strValues[0] == "All")
                strValues[0] = "0";
            Employee_Number = int.Parse(strValues[0].ToString());
        }
        else
        {
            Employee_Number = int.Parse(Session["User_Number"].ToString());
        }
        String Sql = "Select From_Date,To_Date from tblLeave_Apply where Employee_Number = " + Employee_Number + "";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == false || Employee_Number==0)
        {
            retnvalue = true;
        }
        else
        {
            while (reader.Read())
            {
                FromDateArr.Add(reader[0]);
                ToDateArr.Add(reader[1]);
            }
            for (int i = 0; i < FromDateArr.Count; i++)
            {
                DateTime TempFromDate = Convert.ToDateTime(FromDateArr[i]);
                DateTime TemToDate = Convert.ToDateTime(ToDateArr[i]);

                if ((TempFromDate > FromDate && TempFromDate > ToDate)
                    || (FromDate > TemToDate && ToDate > TemToDate))
                {
                    Count++;
                }
                else
                {
                    retnvalue = false;
                }
            }
            if (Count == FromDateArr.Count)
            {
                retnvalue = true;
            }
        }
        return retnvalue;
    }
    private bool RetunLeaveProcess()
    {
        bool retnvalue = false;
        Int32 Count = 0;
        Int32 Employee_Number = 0;
        if (Session["UserType"].ToString() != "ADMIN" || Session["UserType"].ToString() != "SUPERADMIN")
        {
            Employee_Number = int.Parse(Session["User_Number"].ToString());
        }
        else
        {
            string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
            Employee_Number = int.Parse(strValues[0].ToString());
        }
        String Sql = "Select * from tblLeave_Balance where Employee_Number = " + Employee_Number + " and Leave_Year='"+Fyear+"'";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        /*double balance = 0;
        double avail = 0;
        string strSQL = "Select MAX_Balance,Avail from tblLeave_Balance where Employee_Number = " + Employee_Number + " and Leave_Year='" + finyear + "'" + " and  Leave_Type_Number=";
        DataSet FinYear = new DataSet();
        FinYear = ClsCommon.GetAdhocResult(strSQL);
        if (FinYear.Tables[0].Rows.Count != 0)
        {
            balance = Convert.ToDouble(FinYear.Tables[0].Rows[0][0].ToString());
            avail = Convert.ToDouble(FinYear.Tables[0].Rows[0][0]);
        }
        if((balance-avail)<=0)
        {
            retnvalue = false;
        }*/

        if (reader.HasRows == true)
        {
            retnvalue = true;
        }
        else
        {
            retnvalue = false;
        }
        
        return retnvalue;
    }
    private bool RetuntPendingLeave()
    {
        bool retnvalue = false;
        Int32 Employee_Number = 0;

        if (Session["UserType"].ToString() != "ADMIN" || Session["UserType"].ToString() != "SUPERADMIN")
        {
            Employee_Number = int.Parse(Session["User_Number"].ToString());
        }
        else
        {
            string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
            Employee_Number = int.Parse(strValues[0].ToString());
        }

        String Sql = "Select  *from tblLeave_Apply where Employee_Number = " + Employee_Number + " and Approval = 0";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows == true)
        {
            retnvalue = true;
        }
        else
        {
            retnvalue = false;
        }
        return retnvalue;
    }
    private int ValidationApplication()
    {
        int permission = 1;
        #region Required Field Validation

        if (ddlEmployeelist.SelectedIndex == 0)
        {
            permission = 0;
        }
        #endregion
        return permission;
    }
    private bool returnLeaveApplyAtAll()
    {
        bool chkvalue = false;
        Int32 EmpId = 0;
        SqlConnection objReturnedConn;
        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        ReportData obj_ReportData = new ReportData();

        if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
        {
            string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
            EmpId = Convert.ToInt32(strValues[0]);
        }
        else
            EmpId = int.Parse(Session["User_Number"].ToString());

        objReturnedConn = obj_ReportData.GetDBConn();
        objReturnedConn.Open();
        cmd.Connection = objReturnedConn;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_LeaveApplyAtAll";
        cmd.Parameters.AddWithValue("@Parameter", EmpId);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            chkvalue = true;
        }
        else
        {
            chkvalue = false;
        }
        return chkvalue;
    }
    private Int32 ReturnDate(DateTime FromDate, DateTime ToDate, Int32 EmpId)
    {
        Int32 rtnValue = 0;
        SqlCommand cmd = new SqlCommand();
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();

        String SqlString = "select count(*) as CountValue from tblProcessed_Data ";
        SqlString = SqlString + " where PunchDate between '" + FromDate.ToString("dd/MMM/yyyy") + "' and '" + ToDate.ToString("dd/MMM/yyyy") + "'";
        SqlString = SqlString + " and (Sts = 'P' or Sts = 'L' or Sts = 'OSD')";
        SqlString = SqlString + " and Emp_Number = " + EmpId + "";

        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = SqlString;

        Int32 GetValue = int.Parse(cmd.ExecuteScalar().ToString());

        if (GetValue <= 2)
            rtnValue = 1;

        con.Close();

        return rtnValue;
    }

    #endregion

    #region Button Handler

    protected void ddlEmployeelist_SelectedIndexChanged(object sender, EventArgs e)
    {
        Test();
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeelist, ddlEmployeelist.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeelist, tblIdMaster, EmpImage);
        if (Session["UserType"].ToString() != "ADMIN" || Session["UserType"].ToString() != "SUPERADMIN" && ddlEmployeelist.SelectedItem.Text!="Select")
        {
        
            Int32 emplll = Convert.ToInt32(Session["User_Number"].ToString());
            LeaveStatusIndividualEMployee(emplll);
            lblMessage.Visible = true;
            string a=ddlEmployeelist.SelectedValue.ToString().Split(',')[0];
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = ddlEmployeelist.SelectedItem.Text + " have remaining " + LeaveStatusIndividualEMployee(int.Parse(a)).ToString() + " day(s) leave";
        
        
        }
        
    }
    protected void btnFind_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                if (ddlSearchTypelIst.SelectedIndex != 0)
                {
                    Session["Find"] = "Find";
                    String FromDate = Convert.ToDateTime(txtSearchFromDate.Text).ToString("dd/MMM/yyyy");
                    String ToDate = Convert.ToDateTime(txtSearchEndDate.Text).ToString("dd/MMM/yyyy");
                    PopulateGridData(false, false, true, int.Parse(ddlSearchTypelIst.SelectedValue), FromDate, ToDate);
                }
            }
            catch (Exception ex)
            {
                lblMessage.Visible = true;
                lblMessage.Text = ex.Message.ToString();
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
        else
            Response.Redirect("login.aspx");

        Session["Find"] = null;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (dptFromDate.Text != "" && dtpToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text.Trim());
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text.Trim());

            if (Session["LogIn"] != null)
            {


                /*******************************************************/
                if (CheckApplyHourBefore())
                {
                    if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVEENTRY.ToString(), "C"))
                    {
                        if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
                        {
                            DateTime TmpToDateApply = DateTime.Now.Date.AddDays(-1);
                            String[] EmpId = ddlEmployeelist.SelectedValue.ToString().Split(',');
                            if (EmpId[0] == "All")
                                EmpId[0] = "0";
                            //if (ReturnDate(FromDate, TmpToDateApply, int.Parse(EmpId[0])) == 1)
                            //{
                            if (CheckHalf())
                            {
                                if (GetApplyPercentage())
                                {
                                    try
                                    {
                                        if (Session["UserType"].ToString() == "ADMIN" ||
                                            Session["UserType"].ToString() == "SUPERADMIN")
                                        {
                                            if (ddlEmployeelist.SelectedIndex != 0 && ddlLeaveType.SelectedIndex != 0)
                                            {
                                                bool retLeaveProcess = Convert.ToBoolean(RetunLeaveProcess());

                                                if (retLeaveProcess == true)
                                                {
                                                    if (ddlLeaveType.SelectedItem.Text.Trim() != "ML")
                                                    {
                                                        bool value = Convert.ToBoolean(FromDateToDate(FromDate, ToDate));
                                                        if (value == true)
                                                        {
                                                            SaveDataInDB();
                                                            lblMessage.Visible = true;
                                                            lblMessage.ForeColor = System.Drawing.Color.Green;
                                                            lblMessage.Text = " Data saved successful. ";
                                                            UpdatePostLeave();
                                                            Refresh();
                                                        }
                                                        else
                                                        {
                                                            lblMessage.Visible = true;
                                                            lblMessage.ForeColor = System.Drawing.Color.Red;
                                                            lblMessage.Text = " Sorry, apply not possible. ";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ddlLeaveType.SelectedItem.Text.Trim() == "ML")
                                                        {
                                                            ReportData objReportData = new ReportData();
                                                            SqlConnection con = new SqlConnection();
                                                            SqlCommand cmd = new SqlCommand();
                                                            string[] strValues =
                                                                ddlEmployeelist.SelectedItem.Value.Split(',');
                                                            String Sex = "";
                                                            String MarStatus = "";
                                                            String Sql =
                                                                "Select MF,MarSts from tblEmployee where emp_Number = " +
                                                                strValues[0] + "";
                                                            con = objReportData.GetDBConn();
                                                            con.Open();
                                                            cmd.Connection = con;
                                                            cmd.CommandType = CommandType.Text;
                                                            cmd.CommandText = Sql;
                                                            SqlDataReader reader = cmd.ExecuteReader();
                                                            while (reader.Read())
                                                            {
                                                                Sex = Convert.ToString(reader[0]).Trim();
                                                                MarStatus = Convert.ToString(reader[1]).Trim();

                                                            }
                                                            if (MarStatus == "Married" && Sex == "F")
                                                            {
                                                                FromDateToDate(FromDate, ToDate);

                                                                SaveDataInDB();
                                                                lblMessage.Visible = true;
                                                                lblMessage.ForeColor = System.Drawing.Color.Green;
                                                                lblMessage.Text = " Data saved successful. ";
                                                                UpdatePostLeave();
                                                                Refresh();
                                                            }
                                                            else
                                                            {
                                                                lblMessage.Visible = true;
                                                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                                                lblMessage.Text = "Only married female are allowed!";
                                                            }
                                                        }

                                                        else
                                                        {
                                                            FromDateToDate(FromDate, ToDate);

                                                            SaveDataInDB();
                                                            lblMessage.Visible = true;
                                                            lblMessage.ForeColor = System.Drawing.Color.Green;
                                                            lblMessage.Text = " Data saved successful. ";
                                                            UpdatePostLeave();
                                                            Refresh();
                                                        }
                                                    }

                                                }
                                                else
                                                {
                                                    lblMessage.Visible = true;
                                                    lblMessage.ForeColor = System.Drawing.Color.Red;
                                                    lblMessage.Text = "Leave has not been processed for this person,yet";
                                                }
                                            }
                                            else
                                            {
                                                lblMessage.Visible = true;
                                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                                lblMessage.Text = "Please select!";
                                            }
                                        }
                                        else
                                        {
                                            if (ddlLeaveType.SelectedIndex != 0)
                                            {
                                                bool retLeaveProcess = Convert.ToBoolean(RetunLeaveProcess());

                                                if (retLeaveProcess == true)
                                                {
                                                    //bool retLeaveProcess = Convert.ToBoolean(RetunLeaveProcess());
                                                    if (ddlLeaveType.SelectedItem.Text.Trim() != "ML")
                                                    {
                                                        bool value = Convert.ToBoolean(FromDateToDate(FromDate, ToDate));
                                                        if (value == true)
                                                        {
                                                            SaveDataInDB();
                                                            lblMessage.Visible = true;
                                                            lblMessage.ForeColor = System.Drawing.Color.Green;
                                                            lblMessage.Text = " Data saved successful. ";
                                                            UpdatePostLeave();
                                                            Refresh();
                                                        }
                                                        else
                                                        {
                                                            lblMessage.Visible = true;
                                                            lblMessage.ForeColor = System.Drawing.Color.Red;
                                                            lblMessage.Text = " Sorry, apply not possible. ";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (ddlLeaveType.SelectedItem.Text.Trim() == "ML")
                                                        {
                                                            ReportData objReportData = new ReportData();
                                                            SqlConnection con = new SqlConnection();
                                                            SqlCommand cmd = new SqlCommand();
                                                            string[] strValues =
                                                                ddlEmployeelist.SelectedItem.Value.Split(',');
                                                            String Sex = "";
                                                            String MarStatus = "";
                                                            String Sql =
                                                                "Select MF,MarSts from tblEmployee where emp_Number = " +
                                                                strValues[0] + "";
                                                            con = objReportData.GetDBConn();
                                                            con.Open();
                                                            cmd.Connection = con;
                                                            cmd.CommandType = CommandType.Text;
                                                            cmd.CommandText = Sql;
                                                            SqlDataReader reader = cmd.ExecuteReader();
                                                            while (reader.Read())
                                                            {
                                                                Sex = Convert.ToString(reader[0]).Trim();
                                                                MarStatus = Convert.ToString(reader[1]).Trim();

                                                            }
                                                            if (MarStatus == "Married" && Sex == "F")
                                                            {
                                                                FromDateToDate(FromDate, ToDate);
                                                            }
                                                            else
                                                            {
                                                                lblMessage.Visible = true;
                                                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                                                lblMessage.Text = "Only married female are allowed!";
                                                            }
                                                        }

                                                        else
                                                        {
                                                            FromDateToDate(FromDate, ToDate);
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    lblMessage.Visible = true;
                                                    lblMessage.ForeColor = System.Drawing.Color.Red;
                                                    lblMessage.Text = "Leave has not been processed for this person,yet";
                                                }
                                            }
                                            else
                                            {
                                                lblMessage.Visible = true;
                                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                                lblMessage.Text = "Please select!";
                                            }
                                        }

                                    }

                                    catch (Exception ebtnEdit)
                                    {
                                        lblMessage.Visible = true;
                                        lblMessage.Text = ebtnEdit.Message;
                                    }
                                //}
                                //else
                                //{
                                //    lblMessage.Visible = true;
                                //    lblMessage.ForeColor = System.Drawing.Color.Red;
                                //    lblMessage.Text = "Your leave application date has been expired!";
                                //}
                            }
                            else
                            {
                                lblMessage.Visible = true;
                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                lblMessage.Text = "25% Employee of the Dept.applied for leave";

                            }
                        }
                            else
                            {
                                lblMessage.Visible = true;
                                lblMessage.ForeColor = System.Drawing.Color.Red;
                                lblMessage.Text = "Check First or Second half.";

                            }
                        }
                        else
                        {
                            lblMessage.Visible = true;
                            lblMessage.ForeColor = System.Drawing.Color.Red;
                            lblMessage.Text = "From date must be less than to date!";
                        }
                    }




                    else
                    {
                        lblMessage.Visible = true;
                        lblMessage.Text = "Unable to process request";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
                else
                {
                    string mas=""; 
                    DateTime A1 = System.DateTime.Now;
                    DateTime A2 = DateTime.Parse(Convert.ToDateTime(dptFromDate.Text+" "+ System.DateTime.Now.ToString("HH:mm:ss")).ToString("dd/MMM/yyyy HH:mm:ss"));
                    if (PostLeave == 1)
                    {
                        mas = "Select Employee Id";
                        PostLeave = 0;
                    
                    }
                    else if (A1 > A2)
                    {
                        mas = "Your don't have the permision";
                    }
                    else
                    {
                        mas = "Your have to apply for leave before 72 hours!";
                    }
                    lblMessage.Visible = true;
                    lblMessage.Text = mas; 
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }

                /*****************************************/
            }
         
            else
                Response.Redirect("login.aspx");
        }

}

    private bool GetApplyPercentage()
    {
        bool rtv = true;
        string r = ddlEmployeelist.SelectedValue.ToString().Split(',')[0];
        string strSql = "select EmpId,Emp_Number,EmpName from  tblEmployee where EmpEd=1 and Emp_Number in (select Emp_Number from tbl_LeavePermission where LeaveApproveTag=1 and Emp_Number=" + r + ") order by EmpId asc "; 
        String Sql = "sp_LeaveDeptCount";
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();
        con = objReportData.GetDBConn();
        con.Open();
        SqlCommand cmd = new SqlCommand(Sql, con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@EmpNumber",int.Parse(r));
        cmd.Parameters.AddWithValue("@FDate", Convert.ToDateTime(dptFromDate.Text));
        cmd.Parameters.AddWithValue("@TDate", Convert.ToDateTime(dtpToDate.Text));
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        if (ds.Tables[0].Rows[0][0].ToString()=="1")
        {
            rtv = false;
        }
        else
        {
            rtv = true;
        }

        if (ddlEmployeelist.SelectedItem.Text != "Select")
        {
            if (chkPostLeave.Checked && (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "APPLICATIONUSER") && ClsCommon.ItemCheck(strSql))
            {
                rtv = true;
            }
        }
        return rtv;
    }

    private void UpdatePostLeave()
    {
        if (chkPostLeave.Checked)
        {
            int rtv = 0;
            String Sql = "sp_LeavePermission_Delete";
            SqlConnection con = new SqlConnection();
            ReportData objReportData = new ReportData();
            DataSet ds = new DataSet();
            con = objReportData.GetDBConn();
            con.Open();
            SqlCommand cmd = new SqlCommand(Sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;
            string a = ddlEmployeelist.SelectedItem.Text;
            cmd.Parameters.AddWithValue("@EmpId", a);
            rtv = cmd.ExecuteNonQuery();
            con.Close();
            chkPostLeave.Checked = false;
            ddlEmployeelist.Items.Clear();
            GetAllorSpecificEmployees();
            
        
        }
    }
    protected bool CheckApplyHourBefore()
    {
        bool rvt = false;
        DateTime A1 = System.DateTime.Now;
        DateTime A2 = DateTime.Parse(Convert.ToDateTime(dptFromDate.Text + " " + System.DateTime.Now.ToString("HH:mm:ss")).ToString("dd/MMM/yyyy HH:mm:ss"));



        String Sql = "sp_LeaveHourCheck";
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();
        con = objReportData.GetDBConn();
        con.Open();
        SqlCommand cmd = new SqlCommand(Sql, con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@FromDate", A2);

        cmd.Parameters.Add(new SqlParameter("@ReturnValue", SqlDbType.Int, 4));
        cmd.Parameters["@ReturnValue"].Direction = ParameterDirection.Output;
        cmd.ExecuteReader();
        int reader = Convert.ToInt32(cmd.Parameters["@ReturnValue"].Value);
        con.Close();


        
        string r = ddlEmployeelist.SelectedValue.ToString().Split(',')[0];
        string strSql = "select EmpId,Emp_Number,EmpName from  tblEmployee where EmpEd=1 and Emp_Number in (select Emp_Number from tbl_LeavePermission where LeaveApproveTag=1 and Emp_Number=" + r + ") order by EmpId asc "; 
        double DhrFrom = (A2 - A1).TotalHours;
        if (DhrFrom > reader)
        {
            rvt = true;
        }
        if (Session["UserType"].ToString() == "SUPERADMIN")
        {
            rvt = true;
        }
        if (ddlEmployeelist.SelectedItem.Text != "Select")
        {
            if (chkPostLeave.Checked && (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "APPLICATIONUSER") && ClsCommon.ItemCheck(strSql))
            {
                rvt = true;
            }
        }
        else
        {
            PostLeave = 1;
        }
        return rvt;
    }
    protected void dtpToDate_DateChanged(object sender, EventArgs e)
    {
        DateTime dtfrom = DateTime.Parse(dptFromDate.Text);
        DateTime dtto = DateTime.Parse(dtpToDate.Text);
        TimeSpan oTimeSpan = dtto.Subtract(dtfrom);

        int showday = 0;
        txtTotalDays.Text = oTimeSpan.Days.ToString();

        if (oTimeSpan.Days == 0)
        {
            showday = oTimeSpan.Days + 1;
            txtTotalDays.Text = showday.ToString();

        }
        else if (oTimeSpan.Days > 0)
        {
            showday = oTimeSpan.Days + 1;
            txtTotalDays.Text = showday.ToString();
        }
        else if (oTimeSpan.Days < 0)
        {
            txtTotalDays.Text = "";
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSave_Init(object sender, EventArgs e)
    {
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void grvLeaveList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            System.Web.UI.WebControls.CheckBox editCheckbox = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;


            System.Web.UI.WebControls.CheckBox deleteCheckbox = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("chkDelete");

            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";

            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected override void OnUnload(EventArgs e)
    {
        base.OnUnload(e);
    }
    protected void btnUpdate_Init(object sender, EventArgs e)
    {

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if(CheckHalf())
            {
                try
                {
                    if (Session["LeaveApplyNumber"] != null)
                        UpdateInDB(int.Parse(Session["LeaveApplyNumber"].ToString()));
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Data updated successful.";
                    btnSave.Enabled = true;
                    btnUpdate.Enabled = false;
                    ddlEmployeelist.SelectedIndex = 0;
                    ddlLeaveType.SelectedIndex = 0;
                    txtRemarks.Text = "";
                    txtTotalDays.Text = "";
                }
                catch (Exception ebtnEdit)
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = ebtnEdit.Message;
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Check First or Second Half";
            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private bool CheckHalf()
    {
        bool checkval = true;
        if (txtTotalDays.Text == ".5") 
        {
            if (chkFirst.Checked == false && ChkSecond.Checked == false)
            {
                checkval = false;
            }
        }
        return checkval;
    }
    protected void grvLeaveList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvLeaveList.PageIndex = e.NewPageIndex;
        if (ddlLeaveType.SelectedValue != "NA")
        {
            if (txtSearchFromDate.Text == "" || txtSearchEndDate.Text == "")
            {
                PopulateGridData(false, false, false, int.MinValue, String.Empty, String.Empty);
            }
            else
            {
                String FromDate = Convert.ToDateTime(txtSearchFromDate.Text).ToString("dd/MMM/yyyy");
                String ToDate = Convert.ToDateTime(txtSearchEndDate.Text).ToString("dd/MMM/yyyy");
                PopulateGridData(false, false, true, int.Parse(ddlLeaveType.SelectedValue), FromDate, ToDate);
            }
        }
        else
        {
            PopulateGridData(false, false, false, int.MinValue, String.Empty, String.Empty);

        }
    }
    protected void txtTotalDays_Init(object sender, EventArgs e)
    {
    }
    protected void btnCancel_Init(object sender, EventArgs e)
    {
    }
    protected void ddlLeaveType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLeaveType.SelectedIndex != 0)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";
        }
    }
    protected void dptFromDate_TextChanged(object sender, EventArgs e)
    {
        if (dptFromDate.Text != "" && dtpToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);

            int FinalDay = 0;
            string str = "";
            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                if (DateTime.Compare(ToDate, FromDate) == 0)
                {
                    ts = ToDate.Subtract(FromDate.AddDays(-1));
                    str = ts.ToString();
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str);
                    str = string.Empty;
                    str = "";
                }
                else
                {
                    ts = ToDate.Subtract(FromDate);
                    str = ts.ToString();
                }
                if (str.Length == 10)
                {
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 11)
                {
                    str = str.Substring(0, 2);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 12)
                {
                    str = str.Substring(0, 3);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                txtTotalDays.Text = Convert.ToString(FinalDay);
                lblMessage.Visible = false;
                lblMessage.Text = "";
                if (txtTotalDays.Text == ".5")
                {
                    chkFirst.Enabled = true;
                    ChkSecond.Enabled = true;
                }
                else
                {
                    chkFirst.Enabled = false;
                    ChkSecond.Enabled = false;
                    chkFirst.Checked = false;
                    ChkSecond.Checked = false;
                
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.Text = "From date must be less than to date!";
            }
        }
    }
    protected void dtpToDate_TextChanged(object sender, EventArgs e)
    {
        if (dptFromDate.Text != "" && dtpToDate.Text != "")
        {
            DateTime FromDate = Convert.ToDateTime(dptFromDate.Text);
            DateTime ToDate = Convert.ToDateTime(dtpToDate.Text);
            int FinalDay = 0;
            string str = "";
            if (DateTime.Compare(ToDate, FromDate) == 0 || DateTime.Compare(ToDate, FromDate) > 0)
            {
                if (DateTime.Compare(ToDate, FromDate) == 0)
                {
                    ts = ToDate.Subtract(FromDate.AddDays(-1));
                    str = ts.ToString();
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str);
                    str = string.Empty;
                    str = "";
                }
                else
                {
                    ts = ToDate.Subtract(FromDate);
                    str = ts.ToString();
                }
                if (str.Length == 10)
                {
                    str = str.Substring(0, 1);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 11)
                {
                    str = str.Substring(0, 2);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                else if (str.Length == 12)
                {
                    str = str.Substring(0, 3);
                    FinalDay = Convert.ToInt32(str) + 1;
                }
                txtTotalDays.Text = Convert.ToString(FinalDay);

                lblMessage.Visible = false;
                lblMessage.Text = "";
                if (txtTotalDays.Text == ".5")
                {
                    chkFirst.Enabled = true;
                    ChkSecond.Enabled = true;
                }
                else
                {
                    chkFirst.Enabled = false;
                    ChkSecond.Enabled = false;
                    chkFirst.Checked = false;
                    ChkSecond.Checked = false;

                }

            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.Text = "From date must be less than to date!";
            }

        }
    }
    protected void HlnkDelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow oRow in grvLeaveList.Rows)
        {
            System.Web.UI.WebControls.CheckBox oCheckBoxEdit = (System.Web.UI.WebControls.CheckBox)oRow.FindControl("chkDelete");

            if (oCheckBoxEdit.Checked)
            {

                HiddenField oHidApply_Number = (HiddenField)oRow.FindControl("hidLeave_Apply_Number");
                Int32 Leave_Apply_Number = Convert.ToInt32(oHidApply_Number.Value);
                String LeaveType = "sp_LeaveDelete";
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                ReportData objReportData = new ReportData();
                con = objReportData.GetDBConn();
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = LeaveType;
                cmd.Parameters.AddWithValue("@leaveDel", Leave_Apply_Number);
                cmd.ExecuteNonQuery();
                con.Close();
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Visible = true;
                lblMessage.Text = "Data deleted successful.";
            }
        }
        Test();
    }
    protected void HlnkEdit_Click(object sender, EventArgs e)
    {

        String strToDate = Convert.ToString(System.DateTime.Now);
        strToDate = strToDate.Substring(0, 10);

        foreach (GridViewRow oRow in grvLeaveList.Rows)
        {
            String srtGridToDate = Convert.ToString(oRow.Cells[1].Text);
            DateTime ToDate = Convert.ToDateTime(strToDate);
            DateTime GridToDate = Convert.ToDateTime(srtGridToDate);
            TimeSpan tss = new TimeSpan(2, 0, 0, 0);

            System.Web.UI.WebControls.CheckBox oCheckBoxEdit = (System.Web.UI.WebControls.CheckBox)oRow.FindControl("chkEdit");

            if (oCheckBoxEdit.Checked)
            {
                ToDate = ToDate.Subtract(tss);

                if (DateTime.Compare(ToDate, GridToDate) > 0)
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Update date expired ";
                }
                else
                {
                    LoadEditData();
                }
            }
        }
    }
    protected void btnApplication_Click(object sender, EventArgs e)
    {
        if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
        {
            if (ValidationApplication() == 1)
            {
                if (returnLeaveApplyAtAll() == true)
                {
                    string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');

                    if (Session["UserType"].ToString() != "ADMIN" && Session["UserType"].ToString() != "SUPERADMIN")
                    {
                        Session["EmployeeNumber"] = Session["User_Number"].ToString();
                    }
                    else
                        Session["EmployeeNumber"] = strValues[0];

                    Session["TableName"] = "dsDailyReports";
                    Session["ReportName"] = "rptLeaveApplication.rpt";
                    Session["CompanyName"] = "General Automation Limited.";
                    Session["reportstorage"] = "sp_LeaveApplicationForm";
                    string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                    //string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
                }
                else
                {
                    lblMessage.Visible = true;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Leave has not been applied.";
                }
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Please select an employee";
            }
        }
        else
        {
            if (returnLeaveApplyAtAll() == true)
            {

                string[] strValues = ddlEmployeelist.SelectedItem.Value.Split(',');
                if (Session["UserType"].ToString() != "ADMIN" && Session["UserType"].ToString() != "SUPERADMIN")
                {
                    Session["EmployeeNumber"] = Session["User_Number"].ToString();
                }
                else
                    Session["EmployeeNumber"] = strValues[0];

                Session["TableName"] = "dsDailyReports";
                Session["ReportName"] = "rptLeaveApplication.rpt";
                Session["CompanyName"] = "General Automation Limited.";
                Session["reportstorage"] = "sp_LeaveApplicationForm";
                // string strPath = ConfigurationManager.AppSettings["ReportURLString"] + "/Reports/FrmReportContainer.aspx";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            else
            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Leave has not been applied at all for this person";
            }
        }
    }
  
    #endregion
    protected void txtTotalDays_TextChanged(object sender, EventArgs e)
    {
        if (txtTotalDays.Text == ".5")
        {
            halfday = "T";
            chkFirst.Enabled = true;
            ChkSecond.Enabled = true;
        }
        else
        {
            halfday = "";
            chkFirst.Enabled = false;
            ChkSecond.Enabled = false;
        }
    }
    protected void chkFirst_CheckedChanged(object sender, EventArgs e)
    {
        if(chkFirst.Checked)
        {
            ChkSecond.Checked = false;
            halfday = "1";
        }
    }
    protected void ChkSecond_CheckedChanged(object sender, EventArgs e)
    {
        if (ChkSecond.Checked)
        {
            chkFirst.Checked = false;
            halfday = "2";
        }
    }
    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        lblMessage.Text = "";
    }
    protected void ddlFinancialYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void chkPostLeave_CheckedChanged(object sender, EventArgs e)
    {
        if (chkPostLeave.Checked)
        {
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                ddlEmployeelist.Items.Clear();
                ClsCommon.drplistAddWithObject(ddlEmployeelist, " select EmpId,Emp_Number,EmpName from  tblEmployee where EmpEd=1 and Emp_Number in (select Emp_Number from tbl_LeavePermission where LeaveApproveTag=1) order by EmpId asc ", "EmpId", "Emp_Number");
                ddlEmployeelist.Items.Insert(0, new ListItem("Select", "NA"));
            }
            else
            {
                string r = ddlEmployeelist.SelectedValue.ToString().Split(',')[0];
                ddlEmployeelist.Items.Clear();

                string a = "select EmpId,Emp_Number,EmpName from  tblEmployee where EmpEd=1 and Emp_Number in (select Emp_Number from tbl_LeavePermission where LeaveApproveTag=1 and Emp_Number=" + r + ") order by EmpId asc ";
                ClsCommon.drplistAddWithObject(ddlEmployeelist, a, "EmpId", "Emp_Number");
                ddlEmployeelist.Items.Insert(0, new ListItem("Select", "NA"));
            }
        }
        else 
        {
            ddlEmployeelist.Items.Clear();
            GetAllorSpecificEmployees();        
        }
    }
}
