﻿using System;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Security;
using System.Security.Cryptography;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.Data;
using GAVarificationService;

public partial class PageControls_UcCreateUser : System.Web.UI.UserControl
{
    #region Private Variables

    private User _obj;
    ProcessUserSelect pus = new ProcessUserSelect();
    DataTable dt = new DataTable();
    public string decusernumberString = "0";
    public int newEntry = int.MinValue;
    CommonName objCommonName = new CommonName();

    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    btnSave.Enabled = true;
                    btnFresh.Enabled = true;
                    btnClose.Enabled = true;
                    btnUpdate.Enabled = false;
                    GridUserShow();
                    loadEmpId();
                    Session["NotReadPermission"] = null;
                    objCommonName = new CommonName();
                    objCommonName.EmployeeTolTip(ddlEmployeeId, ddlEmployeeId.SelectedValue.ToString(), lblEmpname);
                    EmployeeImage.LoadImageEmp(ddlEmployeeId, tblIdMaster, EmpImage);
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    public void GridUserShow()
    {
        try
        {
            string strSearchUser = "select User_Number,Username,UserId,UserPassword,UserType,Email,ValidDate from tblUser";
            DataSet dsUser = new DataSet();
            dsUser = ClsCommon.GetAdhocResult(strSearchUser);
            gvwUser.DataSource = dsUser;
            gvwUser.DataBind();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void Refresh()
    {
        UserNameTextBox.Text = "";
        passtxt.Text = "";
        ConPassTextBox.Text = "";
        GridUserShow();
        btnSave.Enabled = true;
        txtEmail.Text = "";
    }
    public void AddUser()
    {
        string plainText = passtxt.Text.Trim();    // original plaintext
        _obj = new User();
        try
        {
            _obj.UAccept = UserNameTextBox.Text;
            _obj.UPassword = new CUtility().Encrypt(plainText);
            _obj.UType = ddlUserType.SelectedValue.ToString();
            _obj.UName = ddlEmployeeId.SelectedValue.ToString();
            _obj.Email = txtEmail.Text.Trim();
            _obj.ValidDate = DateTime.Parse(txtValidDate.Text.Trim().ToString() + " " + txtValidTime.Text.Trim());

            ProcessUserInsert pui = new ProcessUserInsert();
            pui.PUser = _obj;
            pui.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void loadEmpId()
    {
        try
        {
            string strSQL = "select EmpId,Emp_Number,EmpName from  tblEmployee where empED=1 order by empId asc  ";
            ClsCommon.drplistAddNew(ddlEmployeeId, strSQL, "EmpId", "Emp_Number");
            ddlEmployeeId.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void UserDelete()
    {
        User _objectUser = new User();
        try
        {
            _objectUser.UserNo = Convert.ToInt16(Session["HidDelUser_Number"].ToString());
            ProcessUserDelete pud = new ProcessUserDelete();
            pud.Ur = _objectUser;
            pud.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    public void UpdateUser()
    {
        User _objUpUser = new User();
        try
        {
            // receive the drop down list value(userPassword)
            _objUpUser.UserNo = Convert.ToInt16(Session["HidUser_Number"].ToString());
            _objUpUser.UAccept = UserNameTextBox.Text.Trim();
            _objUpUser.UPassword = passtxt.Text.Trim();
            _objUpUser.UType = ddlUserType.SelectedValue.ToString(); //Session["UserType"].ToString();
            _objUpUser.UName = ddlEmployeeId.SelectedValue.ToString();
            _objUpUser.Email = txtEmail.Text.Trim();
            _objUpUser.ValidDate = DateTime.Parse(txtValidDate.Text.Trim().ToString() + " " + txtValidTime.Text.Trim());

            ProcessUserUpdate puu = new ProcessUserUpdate();
            puu.userUp = _objUpUser;
            puu.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected bool AbleToCreateUser()
    {
        string usersinsystem = " select count(*) as num_user from tblUser ";
        int availableuser = 0;
        DataSet ds_usersinsystem = ClsCommon.GetAdhocResult(usersinsystem);

        availableuser = int.Parse(ds_usersinsystem.Tables[0].Rows[0]["num_user"].ToString());

        string strSQl = " select * from tblAccessControl where CompId='" + ConfigurationSettings.AppSettings["APPLICATIONID"].ToString() + "' ";
        DataSet dsResult = ClsCommon.GetAdhocResult(strSQl);

        if (dsResult.Tables[0].Rows.Count > 0)
        {
            string encUserNumberString = "";

            if (!DBNull.Value.Equals(dsResult.Tables[0].Rows[0]["NoOfUser"]))
            {
                newEntry = 2;
                encUserNumberString = dsResult.Tables[0].Rows[0]["NoOfUser"].ToString(); //"<;:@<::A:";
            }
            else
            {
                newEntry = 2;
                return false;
            }

            decusernumberString = DeCryptData(encUserNumberString);

            string decAcctualstr = decusernumberString.Substring(0, decusernumberString.Length - 1);

            int strNumberUser = int.Parse(decAcctualstr.Substring(5));

            if (availableuser < strNumberUser)
            {
                return true;
            }
            else
            {
                newEntry = 1;
                return false;
            }

            newEntry = 2;
            return true;
        }
        else
        {
            newEntry = 1;
            return false;
        }
        return true;
    }
    public bool IsTempared(string DBstr, string servicestr)
    {
        return false;
    }
    protected bool UpdateUserPermissionFromGAL(string MyCompId, int numberofuser)
    {
        string decServiceStr = "";
        string sqlUpdate = "";
        int returnHints = 0;
        bool returnval = false;

        try
        {
            GAVarificationService.VerificationServiceClient oVarify = new VerificationServiceClient("BasicHttpBinding_IVerificationService", "http://192.168.0.1/GALService/GVerify.svc/basic");

            decServiceStr = oVarify.GetNumberOfUser(MyCompId, numberofuser);
            string[] GivenValues = decServiceStr.Split(',');

            if (newEntry == 1)
            {
                sqlUpdate = " update tblAccessControl set NoOfUser='" + GivenValues[1] + "' where CompId='" + MyCompId + "' ";
            }

            returnHints = ClsCommon.ExecuteAdhocQuery(sqlUpdate);

            if (returnHints > 0)
            {
                returnval = true;
            }
            else
            {
                returnval = false;
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return returnval;
    }
    public static string GenerateID(string str)
    {
        double b_k, b_p, b_6, b_7, b_x, b_remndr, b_12thdgt, b_Check;
        b_k = 11;
        b_7 = 7;
        b_6 = 6;
        b_x = 0;

        for (b_p = 2; b_p < b_7; b_p++)
        {
            b_x = b_x + b_p * (Convert.ToDouble(str));
            b_k = b_k - 1;
        }
        for (b_p = 2; b_p < b_6; b_p++)
        {
            b_x = b_x + b_p * Convert.ToDouble(str);
            b_k = b_k - 1;
        }
        b_remndr = b_x % 11;
        if (b_remndr == 1)
            b_12thdgt = 1;
        else if (b_remndr == 0)
            b_12thdgt = 0;
        else
            b_12thdgt = 11 - b_remndr;
        b_Check = b_12thdgt;


        return str + b_Check.ToString();

    }
    public static string DeCryptData(string Data)
    {
        string Encrypt;
        int CharStr;
        int i;
        Encrypt = "";
        for (i = 0; i < Data.Length; i++)
        {
            char[] df = Data.Substring(i, 1).ToCharArray();
            CharStr = Convert.ToInt16(df[0]) - 10;
            Encrypt = Encrypt + Convert.ToChar(CharStr);
        }
        return Encrypt;
    }

    #endregion

    #region Button Click

    protected void btnDelChkUser_Click(Object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "D"))
            {
                try
                {
                    foreach (GridViewRow gr in gvwUser.Rows)
                    {
                        CheckBox del = (CheckBox)gr.FindControl("userDeleteCheckBox");
                        if (del.Checked)
                        {
                            HiddenField HidUser_Number = (HiddenField)gr.FindControl("HidDelUser_Number");
                            Session["HidDelUser_Number"] = Convert.ToInt16(HidUser_Number.Value);
                            UserDelete();
                            objCommonName.LabelMessageandColor(userLabel, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);
                            GridUserShow();
                        }
                    }
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(userLabel, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEditChkUser_Click(Object sender, EventArgs e)
    {
        String ValidDateTime = "";
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "U"))
            {
                try
                {
                    foreach (GridViewRow gr in gvwUser.Rows)
                    {
                        CheckBox _edit = (CheckBox)gr.FindControl("userEditCheckBox");
                        if (_edit.Checked)
                        {
                            HiddenField HidUser_Number = (HiddenField)gr.FindControl("HidUser_Number");
                            HiddenField HidUser_Id = (HiddenField)gr.FindControl("HidUserId");
                            HiddenField HidUserPass = (HiddenField)gr.FindControl("HidUserPass");
                            HiddenField HidEmail = (HiddenField)gr.FindControl("HidEmail");
                            HiddenField HidUserType = (HiddenField)gr.FindControl("HidUserType"); //Username
                            HiddenField HidUsername = (HiddenField)gr.FindControl("HidEmpId"); //
                            HiddenField hidValidDateTime = (HiddenField)gr.FindControl("ValidDateTime");

                            String Password = new CUtility().Decrypt(HidUserPass.Value.ToString());
                            ValidDateTime = hidValidDateTime.Value.ToString();

                            UserNameTextBox.Text = HidUser_Id.Value;
                            passtxt.Enabled = false;
                            ConPassTextBox.Enabled = false;
                            Session["HidUser_Number"] = Convert.ToInt16(HidUser_Number.Value);
                            headerLabel.Text = "Update User ";
                            txtEmail.Text = HidEmail.Value;
                            ddlUserType.Text = HidUserType.Value;
                            ddlEmployeeId.SelectedValue = HidUsername.Value;
                            Session["UserType"] = HidUserType.Value.ToString();

                            if (ValidDateTime.Length > 15)
                            {
                                txtValidDate.Text = ValidDateTime.Substring(0, 10);
                                txtValidTime.Text = ValidDateTime.Substring(11, 5);
                            }
                            else
                            {
                                txtValidDate.Text = "";
                                txtValidTime.Text = "";
                            }
                        }
                    }
                    btnSave.Enabled = false;
                    btnUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(userLabel, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUpd_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                string strUser = "select * from tblUser where UserId='" + UserNameTextBox.Text + "'";
                if (UserNameTextBox.Text.Trim().Equals(""))
                    objCommonName.LabelMessageandColor(userLabel, "Please fills the required fields", System.Drawing.Color.Red);
                else
                {
                    UpdateUser();
                    objCommonName.LabelMessageandColor(userLabel, objCommonName.UpdateMessage, System.Drawing.Color.Green);
                }
                GridUserShow();
                Refresh();
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnUserSearch_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                int userIndex = 0;
                userIndex = ddlSearchUser.SelectedIndex;
                DataSet dsUser = new DataSet();
                if (userIndex == 0)
                {
                    string strUser = "select * from tblUser where UserId='" + searchUserTextBox.Text + "'";
                    dsUser = ClsCommon.GetAdhocResult(strUser);
                    gvwUser.DataSource = dsUser;
                    gvwUser.DataBind();
                }
                else
                {
                    string strUser = "select * from tblUser where User_Number='" + searchUserTextBox.Text + "'";
                    userIndex = ddlSearchUser.SelectedIndex;
                    dsUser = ClsCommon.GetAdhocResult(strUser);
                    gvwUser.DataSource = dsUser;
                    gvwUser.DataBind();
                }
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnFresh_Click(object sender, EventArgs e)
    {
        Refresh();
        GridUserShow();
        userLabel.Text = "";
        headerLabel.Text = "";
    }
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CREATEUSER.ToString(), "C"))
            {
                string strUser = "select * from tblUser where UserId='" + UserNameTextBox.Text + "'";
                bool user;
                user = ClsCommon.ItemCheck(strUser);

                if (UserNameTextBox.Text.Trim().Equals("") || passtxt.Text.Trim().Equals(""))
                    objCommonName.LabelMessageandColor(userLabel, "Please fills the required fields", System.Drawing.Color.Red);
                else if (ddlUserType.SelectedIndex == 0)
                {
                    objCommonName.LabelMessageandColor(userLabel, objCommonName.SelectMessage, System.Drawing.Color.Red);
                }
                else if (user)
                {
                    objCommonName.LabelMessageandColor(userLabel, objCommonName.AlreadyExistMessage, System.Drawing.Color.Red);
                }
                else
                {
                    AddUser();
                    objCommonName.LabelMessageandColor(userLabel, objCommonName.SavedMessage, System.Drawing.Color.Green);
                }
                Refresh();
                GridUserShow();
            }
            else
            {
                objCommonName.LabelMessageandColor(userLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
        }
    }

    #endregion

    #region Event Handlers

    protected void UserNameTextBox_TextChanged(object sender, EventArgs e)
    {
    }
    protected void gvwUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvwUser.PageIndex = e.NewPageIndex;
        GridUserShow();
    }
    protected void gvwUser_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("userEditCheckBox");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("userDeleteCheckBox");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

    #endregion
    protected void ddlEmployeeId_SelectedIndexChanged(object sender, EventArgs e)
    {
        objCommonName = new CommonName();
        objCommonName.EmployeeTolTip(ddlEmployeeId, ddlEmployeeId.SelectedValue.ToString(), lblEmpname);
        EmployeeImage.LoadImageEmp(ddlEmployeeId, tblIdMaster, EmpImage);
        passtxt.Attributes["Value"] = passtxt.Text;
        ConPassTextBox.Attributes["Value"] = ConPassTextBox.Text;
    }
    
}
