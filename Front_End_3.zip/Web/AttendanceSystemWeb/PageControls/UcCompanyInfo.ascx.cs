﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using System.IO;

public partial class PageControls_UcCompanyInfo : System.Web.UI.UserControl
{
    #region Declaration
    private Company _comp;
    CommonName objCommonName = new CommonName();
    #endregion

    #region Page Laod

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYSETUP.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    ShowCompany();
                    loadItem();
                    btnUpdate.Enabled = false;
                    btnSave.Enabled = true;
                    Label1.Visible = false;
                    Session["NotReadPermission"] = null;
                }
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private Methods

    public string GetImage()
    {
        String strFileName = "";
        String FilePath = "";
        String FakeName = "";
        string[] FakeName2;
        string[] FakeName3;
        string[] FakeName1;
        string[] BFileName;
        String FinalStringForeFileName = "";
        Session["FinalStringForeFileName"] = null;

        if (flUploadEmployee.HasFile)
        {
            strFileName = flUploadEmployee.FileName.Substring(flUploadEmployee.FileName.LastIndexOf('\\') + 1);
            BFileName = strFileName.Split('.');

            if (BFileName[1] == "jpg" || BFileName[1] == "bmp" || BFileName[1] == "jpeg" || BFileName[1] == "gif")
            {
                FakeName = DateTime.Now.ToString();
                FakeName1 = FakeName.Split(' ');
                FakeName2 = FakeName1[0].Split('/');
                FakeName3 = FakeName1[1].Split(':');
                FinalStringForeFileName = FakeName2[0] + FakeName2[1] + FakeName2[2] + FakeName3[0] + FakeName3[1] + FakeName3[2] + BFileName[0] + "." + BFileName[1];

                FilePath = Server.MapPath("images\\" + FinalStringForeFileName);
                if (File.Exists(FilePath))
                {
                    File.Delete(FilePath);
                }
                flUploadEmployee.PostedFile.SaveAs(Server.MapPath("images\\" + FinalStringForeFileName));
                Session["FinalStringForeFileName"] = FinalStringForeFileName;
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please browse a file first ";
        }

        return FinalStringForeFileName;
    }
    private void PictureUpload()
    {
        string path = "";
        String FullPath = "";

        try
        {
            path = Session["FinalStringForeFileName"].ToString();
            if (path != "")
            {
                FullPath = "~/images/" + path;
            }
        }
        catch (Exception ex)
        {
        }
    }
    protected void deleteCompany(string id)
    {
        objCommonName = new CommonName();
        string strSql = "Select Comp_Number From tblDepartment Where Comp_Number='" + id + "'";
        if (!ClsCommon.ItemCheck(strSql))
        {
            Company compD = new Company();
            compD.CompNo = Convert.ToInt32(hidUpdateID.Value);
            ProcessCompanyDelete PComD = new ProcessCompanyDelete();
            PComD.Comp = compD;
            PComD.invoke();
            hidUpdateID.Value = "";
            ShowCompany();
            objCommonName.LabelMessageandColor(Label1, objCommonName.DeleteMessage, System.Drawing.Color.Green);
        }
        else
        {
            objCommonName.LabelMessageandColor(Label1, "You Must Delete Department First", System.Drawing.Color.Red);
        }
    }
    private void loadCompany(string id)
    {
        txtId1.Enabled = true;
        txtRestuarent.Enabled = true;
        DataTable dt = new DataTable();
        dt = (DataTable)Session["CompanyDS"];
        foreach (DataRow dr in dt.Rows)
        {
            if (dr[0].ToString() == id)
            {
                txtId1.Text = dr[1].ToString();
                txtRestuarent.Text = dr[2].ToString();
                txtAddress.Text = dr[3].ToString();
                txtEmail.Text = dr[4].ToString();
                String Phone = dr[5].ToString();
                string CompLogo = dr["CompanyLogo"].ToString();
                if (CompLogo != "")
                {
                    string[] fileEntries = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/TextFile/"), CompLogo);
                    if (fileEntries.Length != 0)
                    {
                        foreach (string filename in fileEntries)
                        {
                            string name = Path.GetFileName(filename);
                            if (CompLogo == name)
                            {

                                imgContent.ImageUrl = "~/TextFile/" + CompLogo;
                            }
                            else
                            {
                               
                                //ImageEmp.ImageUrl = "~/images/None.bmp";
                            }
                        }
                    }
                    else
                    {
                    }
                    // ImageEmp.ImageUrl = "~/images/None.bmp";
                }
                else
                {
                    
                }
                //ImageEmp.ImageUrl = "~/images/None.bmp";








                if (Phone != String.Empty && Phone != "" && Phone.Length > 10)
                {

                    String PhnCountryCode = Phone.Substring(0, 2);
                    String subPhnone = Phone.Substring(2, Phone.Length - 2);
                    String PhnAreaCode = subPhnone.Substring(0, subPhnone.Length - 7);
                    String PhnNumber = Phone.Substring(Phone.Length - 7, 7);
                    txtPhone.Text = PhnCountryCode;
                    txtPhoneAreacode.Text = PhnAreaCode;
                    txtPhoneNumber.Text = PhnNumber;
                }
                String Fax = dr[6].ToString();
                if (Fax != String.Empty && Fax != "" && Phone.Length > 10)
                {
                    String FaxCntryCode = Fax.Substring(0, 2);
                    String subFax = Fax.Substring(2, Fax.Length - 2);
                    String FaxAreaCode = subFax.Substring(0, subFax.Length - 7);
                    String FaxNumber = Fax.Substring(Fax.Length - 7, 7);
                    txtFax.Text = FaxCntryCode;
                    txtFaxAreaCode.Text = FaxAreaCode;
                    txtFaxNumber.Text = FaxNumber;
                }
                txtWeb.Text = dr[7].ToString();
                String Cell = dr[8].ToString();
                if (Cell != String.Empty && Cell != "" && Cell.Length > 11)
                {
                    String CellCntCod = Cell.Substring(0, 2);
                    String CellNumber = Cell.Substring(2, Cell.Length - 2);
                    txtCellPhone.Text = CellCntCod;
                    txtCelPhoneNumber.Text = CellNumber;
                }

                Session["FinalStringForeFileName"] = dr[8].ToString();
            }
        }
    }
    public void AddCompany()
    {
        GetImage();
        String PhnCountryCode = txtPhone.Text.Trim();
        String PhnAreaCode = txtPhoneAreacode.Text.Trim();
        String PhnNumber = txtPhoneNumber.Text.Trim();
        String Phone = PhnCountryCode + PhnAreaCode + PhnNumber;

        String FaxCountryCode = txtFax.Text.Trim();
        String FaxAreacode = txtFaxAreaCode.Text.Trim();
        String FaxNumber = txtFaxNumber.Text.Trim();
        String Fax = FaxCountryCode + FaxAreacode + FaxNumber;

        String CellCountryCode = txtCellPhone.Text.ToString();
        String CellNumber = txtCelPhoneNumber.Text.ToString();
        String CellComp = CellCountryCode + CellNumber;

        _comp = new Company();
        _comp.CompId = txtId1.Text.Trim();
        _comp.CompName = txtRestuarent.Text.Trim();
        _comp.CompAddress = txtAddress.Text.Trim();
        _comp.CompPhone = Phone;
        _comp.CompEmail = txtEmail.Text.Trim();
        _comp.CompFax = Fax;
        _comp.CompWeb = txtWeb.Text.Trim();
        _comp.CompCell = CellComp;
        _comp.Entryby = 1;
        _comp.PC = System.Net.Dns.GetHostName().ToString();
        if (Session["FinalStringForeFileName"] != null)
        {
            _comp.CompanyLogo = Session["FinalStringForeFileName"].ToString();
        }

        ProcessCompanyInsert proc = new ProcessCompanyInsert();
        proc.Comp = _comp;
        proc.invoke();
    }
    private bool isValidData()
    {
        if (txtId1.Text.Trim().Equals(""))
        {
            objCommonName.LabelMessageandColor(Label1, "Company " + objCommonName.IDRequired, System.Drawing.Color.Red);
            txtId1.Focus();
            return false;

        }
        else if (txtRestuarent.Text.Trim().Equals(""))
        {
            objCommonName.LabelMessageandColor(Label1, "Company " + objCommonName.NameRequired, System.Drawing.Color.Red);
            txtRestuarent.Focus();
            return false;
        }
        else if (txtAddress.Text.Trim().Equals(""))
        {
            objCommonName.LabelMessageandColor(Label1, "Company " + objCommonName.AddressRequired, System.Drawing.Color.Red);
            txtAddress.Focus();
            return false;
        }
        else
        {
            return true;
        }
    }
    protected void clearall()
    {
        txtId1.Text = "";
        txtRestuarent.Text = "";
        txtAddress.Text = "";
        txtEmail.Text = "";
        txtPhone.Text = "";
        txtSearch.Text = "";
        txtFax.Text = "";
        txtWeb.Text = "";
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        txtId1.ReadOnly = false;
        txtRestuarent.ReadOnly = false;
        txtFaxAreaCode.Text = "";
        txtFaxNumber.Text = "";

        txtPhoneAreacode.Text = "";
        txtPhoneNumber.Text = "";
        txtCelPhoneNumber.Text = "";

        txtCellPhone.Text = "";
        // hidEditCheckedIDS.Value = "";
    }
    protected void ShowCompany()
    {
        try
        {
            ProcessCompanySelect pcs = new ProcessCompanySelect();
            pcs.invoke();
            hidEditCheckedIDS.Value = "";
            Session["CompanyDS"] = pcs.CompanyDS.Tables[0];
            grdComplist.DataSource = pcs.CompanyDS.Tables[0];
            grdComplist.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    public void loadItem()
    {
        try
        {
            drpCompId.Items.Clear();
            drpCompId.Items.Insert(0, new ListItem("Select", "NA"));
            drpCompId.Items.Insert(1, new ListItem("ID", "ID"));
            drpCompId.Items.Insert(2, new ListItem("Name", "Name"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void CompUpdate()
    {
        if (GetImage() != "")
        {
            _comp = new Company();
            String PhnCountryCode = txtPhone.Text.Trim();
            String PhnAreaCode = txtPhoneAreacode.Text.Trim();
            String PhnNumber = txtPhoneNumber.Text.Trim();
            String Phone = PhnCountryCode + PhnAreaCode + PhnNumber;
            String FaxCountryCode = txtFax.Text.Trim();
            String FaxAreacode = txtFaxAreaCode.Text.Trim();
            String FaxNumber = txtFaxNumber.Text.Trim();
            String Fax = FaxCountryCode + FaxAreacode + FaxNumber;
            String CellCountryCode = txtCellPhone.Text.ToString();
            String CellNumber = txtCelPhoneNumber.Text.ToString();
            String CellComp = CellCountryCode + CellNumber;

            _comp.CompNo = int.Parse(hidUpdateID.Value);
            _comp.CompId = txtId1.Text.Trim();
            _comp.CompName = txtRestuarent.Text.Trim();
            _comp.CompAddress = txtAddress.Text.Trim();
            _comp.CompPhone = Phone;
            _comp.CompEmail = txtEmail.Text.Trim();
            _comp.CompWeb = txtWeb.Text.Trim();
            _comp.CompFax = Fax;
            _comp.CompCell = CellComp;
            _comp.Entryby = 1;
            _comp.PC = System.Net.Dns.GetHostName().ToString();

            if (Session["FinalStringForeFileName"] != null)
            {
                _comp.CompanyLogo = Session["FinalStringForeFileName"].ToString();
            }

            ProcessCompanyUpdate prcu = new ProcessCompanyUpdate();
            prcu.Comp = _comp;
            prcu.invoke();
            hidUpdateID.Value = "";
            clearall();
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Green;
            Label1.Text = "Data updated successful.";
            ShowCompany();
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Please browse a valid file ";
        }

    }
    protected void SearchData()
    {
        string Searchquery;
        if (drpCompId.SelectedIndex == 0)
        {
            objCommonName.LabelMessageandColor(Label1, objCommonName.SearchItem, System.Drawing.Color.Red);
        }
        if (drpCompId.SelectedIndex == 1)
        {
            Searchquery = "Select Comp_Number,CompId,CompName,CompAddress,CompEmail,CompFax,CompWeb,CompPhone From tblCompany Where CompId='" + txtSearch.Text + "'";
            ClsCommon.GetAdhocResult(Searchquery);
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(Searchquery);
            hidEditCheckedIDS.Value = "";
            grdComplist.DataSource = ds;
            grdComplist.DataBind();


        }
        else if (drpCompId.SelectedIndex == 2)
        {
            Searchquery = "Select Comp_Number,CompId,CompName,CompAddress,CompEmail,CompFax,CompWeb,CompPhone From tblCompany Where CompName like '" + txtSearch.Text + "%'";
            ClsCommon.GetAdhocResult(Searchquery);
            DataSet ds = new DataSet();
            ds = ClsCommon.GetAdhocResult(Searchquery);
            hidEditCheckedIDS.Value = "";
            grdComplist.DataSource = ds;
            grdComplist.DataBind();
        }
        else
        {
            objCommonName.LabelMessageandColor(Label1, objCommonName.InvalidSearchItem, System.Drawing.Color.Red);
        }
    }
    protected void loadFormGrid()
    {

        foreach (GridViewRow oRow in grdComplist.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
            if (oCheckBoxEdit.Checked)
            {
                HiddenField hCompId1 = (HiddenField)oRow.FindControl("hCompID");
                hidUpdateID.Value = hCompId1.Value;
                loadCompany(hCompId1.Value);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }
        }
    }

    #endregion

    #region Button

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {

            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYSETUP.ToString(), "C"))
            {
                string strSql = "Select CompId From tblCompany Where CompId='" + txtId1.Text + "'";
                if (!ClsCommon.ItemCheck(strSql))
                {
                    string strSql1 = "Select CompName From tblCompany Where CompName='" + txtRestuarent.Text.Trim() + "'";
                    if (!ClsCommon.ItemCheck(strSql1))
                    {
                        if (isValidData())
                        {
                            AddCompany();
                            objCommonName.LabelMessageandColor(Label1, objCommonName.SavedMessage, System.Drawing.Color.Green);
                            clearall();
                            ShowCompany();
                        }
                    }
                    else
                    {
                        objCommonName.LabelMessageandColor(Label1, objCommonName.AlreadyExistMessage, System.Drawing.Color.Red);
                    }
                }
                else
                {
                    objCommonName.LabelMessageandColor(Label1, objCommonName.AlreadyExistMessage, System.Drawing.Color.Red);
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ShowCompany();
        clearall();

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (isValidData())
            {
                //DataTable dt = (DataTable)Session["CompanyDS"];
                //DataRow[] dtRow = dt.Select("CompName = '" + txtRestuarent.Text.Trim() + "'");
                // DataRow[] dtRow1 = dt.Select("CompId = '" + txtId1.Text.Trim() + "'");

                // if (dtRow.Length <= 0 || dtRow1.Length <= 0)
                // {
                CompUpdate();
                // }
                //else
                //{
                //Label1.Visible = true;
                //Label1.ForeColor = System.Drawing.Color.Red;
                //Label1.Text = "Data already exist.";
                //}
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            SearchData();
            clearall();
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYSETUP.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
            {
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.COMPANYSETUP.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grdComplist.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        HiddenField hCompId1 = (HiddenField)oRow.FindControl("hCompID");
                        hidUpdateID.Value = hCompId1.Value;
                        deleteCompany(hCompId1.Value);
                    }
                }
            }
            else
            {
                objCommonName.LabelMessageandColor(Label1, objCommonName.UnableProcess, System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    

    #endregion

    #region Event Handlers

    protected void grdComplist_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdComplist.PageIndex = e.NewPageIndex;
        grdComplist.DataSource = (DataTable)Session["Company"];
        grdComplist.DataBind();
    }
    protected void txtNo_TextChanged(object sender, EventArgs e)
    {

    }
    protected void drpCompId_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpCompId.Items.Count > 0)
        {
            if (drpCompId.SelectedValue.Trim() != "NA")
            {
                loadCompany(drpCompId.SelectedItem.Value);
            }
        }
    }
    protected void grdComplist_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void grdComplist_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    #endregion

}
