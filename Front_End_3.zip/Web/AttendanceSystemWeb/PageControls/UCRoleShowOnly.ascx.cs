﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;

public partial class PageControls_UCRoleShowOnly : System.Web.UI.UserControl
{
    #region Declarations

    Int32 UserId = 0;
    int roleId = 0;
    HiddenField hdRoleId = new HiddenField();
    HiddenField hdUserId = new HiddenField();
    CommonName objCommonName = new CommonName();

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["User_Number"] != null)
                {
                    UserId = Convert.ToInt32(Request.QueryString["User_Number"].Trim().ToString());
                    loadRole();
                    loadRole(UserId);
                }

              
                hdUserId.Value = UserId.ToString();
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Private

    protected void loadRole()
    {
        try
        {
            string strSQL = "Select distinct Role_Number, Role_Name from tlbRole ";
            ClsCommon.drplistAdd(drplist, strSQL, "Role_Name", "Role_Number");
            drplist.Items.Insert(0, new ListItem("Select", "NA"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    private void loadRole(Int32 id)
    {
        string strSearchUser = "select  Role_Number  from tblUser where User_Number=" +id+ " ";
        DataSet dsUser = new DataSet();
        dsUser = ClsCommon.GetAdhocResult(strSearchUser);
        string roleId1= dsUser.Tables[0].Rows[0]["Role_Number"].ToString();
        if (roleId1 !="")
        {
            roleId = Int32.Parse(roleId1);
        }
      
        DataTable dt = new DataTable();
        try
        {
            ProcessRoleDataSelect obj_ProcessRoleDataSelect = new ProcessRoleDataSelect();
            obj_ProcessRoleDataSelect.invoke();
            Session["RoleDS"] = obj_ProcessRoleDataSelect.RoleDS.Tables[0];

            dt = (DataTable)Session["RoleDS"];
            foreach (DataRow dr in dt.Rows)
            {
                if (int.Parse(dr[0].ToString()) == roleId)
                {
                    loadRole();
                    drplist.SelectedValue = dr["Role_Number"].ToString();
                    hdRoleId.Value = dr["Role_Number"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    private void RoleUpdate()
    {
        ReportData objReportData = new ReportData();
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        String Sql = "sp_RoleAssigntoUser";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;
        cmd.Parameters.AddWithValue("@RoleId", int.Parse(drplist.SelectedValue.ToString()));
        cmd.Parameters.AddWithValue("@UserId", int.Parse(Request.QueryString["User_Number"].ToString()));
        SqlDataReader reader = cmd.ExecuteReader();
        cmd.Parameters.Clear();
    }
    #endregion

    #region Button Handlers

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            RoleUpdate();
            objCommonName.LabelMessageandColor(userLabel, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(userLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    #endregion
}
