﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;

public partial class PageControls_UcEmployeeBrouser : System.Web.UI.UserControl
{
    Int32 CompId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATIONLIST.ToString(), "R"))
        {
            if (!IsPostBack)
            {
                hidUpdateID.Value = "";
                loadItemCompany();

                CompId = Int32.Parse(ddlCompany.SelectedValue.ToString());
                Showdata(CompId);
                Session["NotReadPermission"] = null;
            }
            loadItem();
        }
        else
        {
            Session["NotReadPermission"] = "NotReadPermission";
            Response.Redirect("Default.aspx");
        }
    }
    protected void deleteEmployee(string delID)
    {

        Employee EmpD = new Employee();

        EmpD.EmpNumber = Convert.ToInt32(delID);

        ProcessEmployeeDelete PEmpD = new ProcessEmployeeDelete();
        PEmpD.Emp = EmpD;
        PEmpD.invoke();

        hidUpdateID.Value = "";

        CompId = Int32.Parse(ddlCompany.SelectedValue.ToString());
        Showdata(CompId);

    }
    public void Showdata(Int32 CompId)
    {
        try
        {
            string a = Session["UserType"].ToString();
            if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
            {
                SqlCommand cmd = new SqlCommand();
                DataSet ds = new DataSet();
                SqlConnection objReturnedConn;
                ReportData obj_ReportData = new ReportData();

                objReturnedConn = obj_ReportData.GetDBConn();
                objReturnedConn.Open();
                cmd.Connection = objReturnedConn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Employee_Select";
                cmd.Parameters.AddWithValue("@CompId", CompId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                Session["EmployeeDS"] = ds;
                grdEmployee.DataSource = ds;
                grdEmployee.DataBind();
            }
            else
            {
                Int32 User_Number = Convert.ToInt32(Session["User_Number"].ToString());
                SqlCommand cmd = new SqlCommand();
                DataSet ds = new DataSet();
                SqlConnection objReturnedConn;
                ReportData obj_ReportData = new ReportData();

                objReturnedConn = obj_ReportData.GetDBConn();
                objReturnedConn.Open();
                cmd.Connection = objReturnedConn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Employee_Select_Individual_ByLoginId";

                cmd.Parameters.AddWithValue("@Emp_Number", User_Number);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                Session["EmployeeDS"] = ds;
                grdEmployee.DataSource = ds;
                grdEmployee.DataBind();
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }
    }
    public void loadItemCompany()
    {
        try
        {
            string strSQL = "Select Comp_Number,CompName,CompId from tblCompany ";
            ClsCommon.drplistAdd(ddlCompany, strSQL, "CompName", "Comp_Number");
            //ddlCompany.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

    }
    protected void grdEmployee_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void grdCompany_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdEmployee_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnREdit_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATIONLIST.ToString(), "U"))
        {
            loadFormGrid();
            Response.Redirect("Default.aspx?Page=Employee");
        }
        else
        {
            lblErrorMessage.Visible = true;
            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            lblErrorMessage.Text = "Unable to process request";
        }
    }
    protected void loadFormGrid()
    {
        foreach (GridViewRow oRow in grdEmployee.Rows)
        {
            CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkEdit");
            if (oCheckBoxEdit.Checked)
            {
                HiddenField hCompId1 = (HiddenField)oRow.FindControl("hCompID");
                hidUpdateID.Value = hCompId1.Value;
                string id = hCompId1.Value;
                Session["empId"] = id;
                break;
            }
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPLOYEEINFORMATIONLIST.ToString(), "D"))
        {
            foreach (GridViewRow oRow in grdEmployee.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");
                if (oCheckBoxEdit.Checked)
                {
                    HiddenField hCompId1 = (HiddenField)oRow.FindControl("hCompID");
                    hidUpdateID.Value = hCompId1.Value;
                    deleteEmployee(hCompId1.Value);
                }
            }
        }
        else
        {
            lblErrorMessage.Visible = true;
            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            lblErrorMessage.Text = "Unable to process request";
        }
    }
    protected void grdEmployee_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');

            HiddenField hdnEmpED = (HiddenField)e.Row.FindControl("hdnEmpEd");
            if (hdnEmpED.Value == "0")
            {
                for (Int32 i = 0; i < e.Row.Cells.Count; i++)
                {
                    e.Row.Cells[i].ForeColor = System.Drawing.Color.Red;
                }
            }

        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        hidEditCheckedIDS.Value = "";
        SearchData();
    }
    public void loadItem()
    {
        try
        {
            drpComplist.Items.Clear();
            drpComplist.Items.Insert(0, new ListItem("Select", "NA"));
            drpComplist.Items.Insert(1, new ListItem("ID", "ID"));
            drpComplist.Items.Insert(2, new ListItem("Name", "Name"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

    }
    protected void SearchData()
    {
        if (Session["UserType"].ToString() == "ADMIN" || Session["UserType"].ToString() == "SUPERADMIN")
        {
            string Searchquery;
            if (drpComplist.SelectedIndex == 0)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Enter search item.";
            }
            if (drpComplist.SelectedIndex == 1)
            {
                Searchquery = "SELECT e.Emp_Number,e.EmpId,e.CardId,e.EmpName,e.JDate,e.EmpED, ";
                Searchquery = Searchquery + " e.Tel,e.OT,e.EmpSts,e.QuitDate,d.DeptName,des.DesigName,";
                Searchquery = Searchquery + " s.SectName,st.ShiftName,d.DeptId FROM  tblEmployee as e left JOIN ";
                Searchquery = Searchquery + " tblDesignation as des ON e.Desig_Number = des.Desig_Number left JOIN";
                Searchquery = Searchquery + " tblSection as s ON e.Sect_Number = s.Sect_Number left JOIN";
                Searchquery = Searchquery + " tbl_ShiftNameSettings as st ON e.Shift_Number = st.Shift_Number left JOIN";
                Searchquery = Searchquery + " tblDepartment as d ON s.Dept_Number = d.Dept_Number Where d.Comp_Number = " + int.Parse(ddlCompany.SelectedValue) + " and e.EmpId LIKE '%" + txtSearch.Text + "%'";

                ClsCommon.GetAdhocResult(Searchquery);
                DataSet ds = new DataSet();
                ds = ClsCommon.GetAdhocResult(Searchquery);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    grdEmployee.DataSource = ds;
                    grdEmployee.DataBind();
                    lblErrorMessage.Visible = false;
                    lblErrorMessage.Text = "";
                }
                else
                {
                    grdEmployee.DataSource = ds;
                    grdEmployee.DataBind();

                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    lblErrorMessage.Text = "Search item not found";
                }

            }
            else if (drpComplist.SelectedIndex == 2)
            {
                //Searchquery = "Select * From tblEmployee Where EmpName like '" + txtSearch.Text + "%'";
                Searchquery = "SELECT e.Emp_Number,e.EmpId,e.CardId,e.EmpName,e.JDate,e.EmpED,";
                Searchquery = Searchquery + " e.Tel,e.OT,e.EmpSts,e.QuitDate,d.DeptName,des.DesigName,";
                Searchquery = Searchquery + " s.SectName,st.ShiftName,d.DeptId FROM  tblEmployee as e left JOIN ";
                Searchquery = Searchquery + " tblDesignation as des ON e.Desig_Number = des.Desig_Number left JOIN";
                Searchquery = Searchquery + " tblSection as s ON e.Sect_Number = s.Sect_Number left JOIN";
                Searchquery = Searchquery + " tbl_ShiftNameSettings as st ON e.Shift_Number = st.Shift_Number left JOIN";
                Searchquery = Searchquery + " tblDepartment as d ON s.Dept_Number = d.Dept_Number Where d.Comp_Number = " + int.Parse(ddlCompany.SelectedValue) + " and e.EmpName Like '%" + txtSearch.Text + "%'";
                ClsCommon.GetAdhocResult(Searchquery);
                DataSet ds = new DataSet();
                ds = ClsCommon.GetAdhocResult(Searchquery);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    grdEmployee.DataSource = ds;
                    grdEmployee.DataBind();

                    lblErrorMessage.Visible = false;
                    lblErrorMessage.Text = "";
                }
                else
                {
                    grdEmployee.DataSource = ds;
                    grdEmployee.DataBind();

                    lblErrorMessage.Visible = true;
                    lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                    lblErrorMessage.Text = "Search item not found";
                }
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblErrorMessage.Text = "Invalid search item";
            }
        }
        else
        {
            lblErrorMessage.Visible = true;
            lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            lblErrorMessage.Text = "Unable to process request";
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //if (ddlCompany.SelectedIndex != 0)
        // {
        CompId = Int32.Parse(ddlCompany.SelectedValue.ToString());
        Showdata(CompId);
        drpComplist.SelectedIndex = 0;
        txtSearch.Text = "";
        //}
    }
    protected void grdEmployee_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdEmployee.PageIndex = e.NewPageIndex;
        // if (ddlCompany.SelectedIndex != 0)
        //{
        CompId = Int32.Parse(ddlCompany.SelectedValue.ToString());
        Showdata(CompId);
        //}
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlCompany.SelectedIndex != 0)
        // {
        CompId = Int32.Parse(ddlCompany.SelectedValue.ToString());
        Showdata(CompId);
        // }
    }
    protected void grdEmployee_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}
