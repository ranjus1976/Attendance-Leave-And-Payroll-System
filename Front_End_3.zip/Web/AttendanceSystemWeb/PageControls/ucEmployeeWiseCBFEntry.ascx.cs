﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.BLL.CBF;

public partial class PageControls_ucEmployeeWiseCBFEntry : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    string action = "";
    EmpWiseCBF objEmpWiseCBF = new EmpWiseCBF();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadCompany();
            loadEmployee();

            EmpNameTxtBox.ReadOnly = true;
            TextBoxEmpGross.ReadOnly = true;
            rbtPercentage.Checked = false;
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            rbtManual.Checked = false;
            rbtSlab.Checked = true;
            TextBoxEmpDiposit.Visible = false;
            TextBoxCmpDiposit.Visible = true;
            TextBoxEmpAmount.Visible = true;
            TextBoxCmpAmount.Visible = true;
            showGridView(drpCmp.SelectedValue);
        }
    }
    protected void loadCompany()
    {
        string strSQL = "Select Comp_Number, CompName from tblCompany";
        ClsCommon.drplistAdd(drpCmp, strSQL, "CompName", "Comp_Number");

    }
    private void showGridView(string id)
    {
        string searchStr = "SELECT tbl_Emp_Wise_CBF_Entry.EmpID,tbl_Emp_Wise_CBF_Entry.EmpName,Gross_Salary,Emp_Deposit_Per,Emp_Deposit_Amt,Comp_Deposit_Per,Comp_Deposit_Amt  FROM tbl_Emp_Wise_CBF_Entry  inner join tblEmployee on tblEmployee.EmpId=tbl_Emp_Wise_CBF_Entry.EmpId inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number where EmpED = 1 and Comp_Number=" + id + "order by tbl_Emp_Wise_CBF_Entry.EmpId";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grvEmpCbfEn.DataSource = dsMonthDeduct.Tables[0];
        grvEmpCbfEn.DataBind();
    }
    public void loadEmployee()
    {
        try
        {
            string strSQL = "Select Emp_Number, EmpId,EmpName from tblEmployee";
            strSQL = strSQL + " inner join tblSection on tblSection.Sect_Number = tblEmployee.Sect_Number";
            strSQL = strSQL + " inner join tblDepartment on tblDepartment.Dept_number = tblSection.Dept_number ";
            strSQL = strSQL + " where EmpED = 1 and Comp_Number=" + Convert.ToInt32(drpCmp.SelectedValue.ToString()) + " order by EmpId";

            drpEmpId.Items.Clear();
            ClsCommon.drplistAdd(drpEmpId, strSQL, "EmpId", "Emp_Number");
            drpEmpId.Items.Insert(0, new ListItem("Select", "NA"));

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBF.ToString(), "C"))
            {
                string sqlquery = "select EmpId from tbl_Emp_Wise_CBF_Entry where EmpID='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "'";
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                ReportData objReportData = new ReportData();
                con = objReportData.GetDBConn();
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sqlquery;
                String Employee = Convert.ToString(cmd.ExecuteScalar());
                if (Employee == "")
                {
                    if (Validate())
                    {
                        action = "save";
                        AddEmpWiseCBF();
                        objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                        showGridView(drpCmp.SelectedValue);
                        action = "";

                    }

                    else
                        objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                }
                else
                    objCommonName.LabelMessageandColor(labelEmpSlab, Employee + " " + objCommonName.AlreadyExistMessage.ToString() + " Please Update", System.Drawing.Color.Red);
            }
            else
                objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");

    }

    private void AddEmpWiseCBF()
    {
        try
        {
            string SlabLog = "";
            //EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
            objEmpWiseCBF.EmpId = Convert.ToString(drpEmpId.SelectedItem.Text);
            objEmpWiseCBF.EmpName = drpEmpId.SelectedValue;
            objEmpWiseCBF.Gross = int.Parse(TextBoxEmpGross.Text);
            objEmpWiseCBF.EmpPer = int.Parse(TextBoxEmpDiposit.Text);
            objEmpWiseCBF.EmpAmount = int.Parse(TextBoxEmpAmount.Text);
            objEmpWiseCBF.CmpPer = int.Parse(TextBoxCmpDiposit.Text);
            objEmpWiseCBF.CmpAmount = int.Parse(TextBoxCmpAmount.Text);
            if (rbtSlab.Checked)
            {
                SlabLog = "0";
            }
            else if (rbtManual.Checked)
            {
                SlabLog = "1";
            }
            else
            {
                SlabLog = "2";
                objEmpWiseCBF.CmpAmount = 0;
                objEmpWiseCBF.EmpAmount = 0;
            }
            objEmpWiseCBF.SlabLog = int.Parse(SlabLog);
            objEmpWiseCBF.Action = action;
            ProcessEmpWiseCBF procmbbilladj = new ProcessEmpWiseCBF();
            procmbbilladj.EmpCBF = objEmpWiseCBF;
            procmbbilladj.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelEmpSlab, ex.Message.ToString(), System.Drawing.Color.Red);

        }
    }
    private bool Validate()
    {
        return true;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddEmpWiseCBF();
        objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView(drpCmp.SelectedValue);
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        drpEmpId.Enabled = true;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        clearall();
    }
    private void clearall()
    {
        drpCmp.SelectedIndex = 1;
        drpEmpId.SelectedIndex = 0;
        EmpNameTxtBox.Text = "";
        TextBoxEmpGross.Text = "";
        TextBoxEmpDiposit.Text = "";
        TextBoxEmpAmount.Text = "";
        TextBoxCmpAmount.Text = "";
        TextBoxCmpDiposit.Text = "";
        labelEmpSlab.Text = "";
        drpEmpId.Enabled = true;

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void drpEmpId_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBoxEmpDiposit.Text = "";
        TextBoxEmpAmount.Text = "";
        TextBoxCmpDiposit.Text = "";
        TextBoxCmpAmount.Text = "";
       
  
        EmpNameTxtBox.Text = objCommonName.EmployeeName(Convert.ToString(drpEmpId.SelectedItem.Text));
        EmployeeImage.LoadImageEmp(drpEmpId, tblIdMaster, EmpImage);
        string strSQL = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) + "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
        DataSet Gross = new DataSet();
        Gross = ClsCommon.GetAdhocResult(strSQL);
        if (Gross.Tables[0].Rows.Count != 0)
        {
            TextBoxEmpGross.Text = Gross.Tables[0].Rows[0][0].ToString();
        }
        gretindividualCBF();

    }
    private bool gretindSalarySlab(string id)
    {
        bool cbfvalue = false;
        string sqlCBF = "select Emp_Deposit_Per,Emp_Deposit_Amt,Comp_Deposit_Per,Comp_Deposit_Amt,SlabLog from tbl_Emp_Wise_CBF_Entry where EmpID='" + id + "'";
        DataSet dsCBF = new DataSet();
        dsCBF = ClsCommon.GetAdhocResult(sqlCBF);

        if (dsCBF.Tables[0].Rows.Count != 0)
        {

            string EmpPer = dsCBF.Tables[0].Rows[0][0].ToString();
            string EmpAmount = dsCBF.Tables[0].Rows[0][1].ToString();
            string CmpPer = dsCBF.Tables[0].Rows[0][2].ToString();
            string CmpAmount = dsCBF.Tables[0].Rows[0][3].ToString();
            string Gross = TextBoxEmpGross.Text;


            int rbt = int.Parse(dsCBF.Tables[0].Rows[0][4].ToString());
            if (rbt == 0)
            {
                rbtPercentage.Checked = false;
                rbtManual.Checked = false;
                rbtSlab.Checked = true;
                TextBoxEmpDiposit.Visible = false;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpDiposit.Visible = true;
                TextBoxCmpAmount.Visible = true;

                TextBoxEmpDiposit.Text = EmpPer;
                TextBoxEmpAmount.Text = EmpAmount;
                TextBoxCmpDiposit.Text = CmpPer;
                TextBoxCmpAmount.Text = CmpAmount;
            }
            else if (rbt == 1)
            {

                rbtManual.Checked = true;
                rbtSlab.Checked = false;
                rbtPercentage.Checked = false;
                TextBoxEmpDiposit.Visible = false;
                TextBoxCmpDiposit.Visible = false;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpAmount.Visible = true;
                TextBoxEmpDiposit.Text = "0";
                TextBoxEmpAmount.Text = EmpAmount;
                TextBoxCmpDiposit.Text = "0";
                TextBoxCmpAmount.Text = CmpAmount;

            }
            else
            {
                rbtPercentage.Checked = true;
                rbtManual.Checked = false;
                rbtSlab.Checked = false;
                TextBoxEmpDiposit.Visible = true;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpDiposit.Visible = true;
                TextBoxCmpAmount.Visible = true;

                TextBoxEmpDiposit.Text = EmpPer;
                TextBoxEmpAmount.Text = numberstring((int.Parse(Gross) * int.Parse(EmpPer) / 100).ToString());
                TextBoxCmpDiposit.Text = CmpPer;
                TextBoxCmpAmount.Text = numberstring((int.Parse(TextBoxEmpAmount.Text) * int.Parse(CmpPer) / 100).ToString());

            }

            cbfvalue = true;
        }
        else
        {
            rbtSlab.Checked = true;
            rbtManual.Checked = false;
            rbtPercentage.Checked = false;
            TextBoxEmpDiposit.Visible = false;
            TextBoxCmpDiposit.Visible = true;
            TextBoxCmpAmount.Visible = true;
            TextBoxEmpAmount.Visible = true;
            cbfvalue = false;
        }
        return cbfvalue;
    }
    private void gretindividualCBF()
    {

        bool retVal = gretindSalarySlab(Convert.ToString(drpEmpId.SelectedItem.Text));
        if (!retVal)
        {
            string sqlCBF = "select StartingRange,ClosingRange,EmpDipositAmt,CompPerticipationRatio,CompPayableAmount from tbl_Salary_Slab";
            DataSet dsCBF = new DataSet();
            dsCBF = ClsCommon.GetAdhocResult(sqlCBF);
            if (TextBoxEmpGross.Text.ToString() != "")
            {
                int gross = int.Parse(TextBoxEmpGross.Text.ToString());

                foreach (DataRow dtRow in dsCBF.Tables[0].Rows)
                {
                    int s = int.Parse(dtRow["StartingRange"].ToString());
                    int c = int.Parse(dtRow["ClosingRange"].ToString());
                    if (s <= gross && c >= gross)
                    {
                        TextBoxEmpDiposit.Text = "0";
                        TextBoxEmpAmount.Text = dtRow["EmpDipositAmt"].ToString();
                        TextBoxCmpDiposit.Text = dtRow["CompPerticipationRatio"].ToString();
                        TextBoxCmpAmount.Text = dtRow["CompPayableAmount"].ToString();
                    }
                }

            }
        }
    }
    protected void drpCmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadEmployee();
        Clear();
    }

    private void Clear()
    {
        // throw new NotImplementedException();
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        string searchStr = "SELECT EmpID,EmpName,Gross_Salary,Emp_Deposit_Per,Emp_Deposit_Amt,Comp_Deposit_Per,Comp_Deposit_Amt  FROM tbl_Emp_Wise_CBF_Entry where EmpId='" + txtSearch.Text + "'";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        grvEmpCbfEn.DataSource = dsMonthDeduct.Tables[0];
        grvEmpCbfEn.DataBind();
    }
    protected void rbtPercentage_CheckedChanged(object sender, EventArgs e)
    {
        if (rbtPercentage.Checked)
        {
            rbtManual.Checked = false;
            rbtSlab.Checked = false;
            TextBoxEmpDiposit.Text = "0";
            TextBoxCmpDiposit.Text = "30";
            TextBoxEmpAmount.Text = "0";
            TextBoxCmpAmount.Text = "0";
            TextBoxEmpDiposit.Visible = true;
            TextBoxCmpDiposit.Visible = true;
            TextBoxEmpAmount.Visible = true;
            TextBoxCmpAmount.Visible = true;
        }
    }
    protected void rbtManual_CheckedChanged(object sender, EventArgs e)
    {
        if (rbtManual.Checked)
        {
            rbtPercentage.Checked = false;
            rbtSlab.Checked = false;
            TextBoxEmpDiposit.Text = "0";
            TextBoxCmpDiposit.Text = "0";
            TextBoxEmpAmount.Text = "0";
            TextBoxCmpAmount.Text = "0";
            TextBoxEmpDiposit.Visible = false;
            TextBoxCmpDiposit.Visible = false;
            TextBoxEmpAmount.Visible = true;
            TextBoxCmpAmount.Visible = true;
        }
    }
    protected void rbtSlab_CheckedChanged(object sender, EventArgs e)
    {
        if (rbtSlab.Checked)
        {
            rbtPercentage.Checked = false;
            rbtManual.Checked = false;
            TextBoxEmpDiposit.Text = "0";
            TextBoxCmpDiposit.Text = "30";
            TextBoxEmpAmount.Text = "0";
            TextBoxCmpAmount.Text = "0";
            TextBoxEmpDiposit.Visible = false;
            TextBoxCmpDiposit.Visible = true;
            TextBoxEmpAmount.Visible = true;
            TextBoxCmpAmount.Visible = true;
        }
    }
    protected void grvEmpCbfEn_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvEmpCbfEn_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void grvEmpCbfEn_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void grvEmpCbfEn_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grvEmpCbfEn_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }
    public void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBF.ToString(), "D"))
            {
                foreach (GridViewRow oRow in grvEmpCbfEn.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        objEmpWiseCBF.EmpId = grvEmpCbfEn.Rows[i].Cells[0].Text;
                        ProcessEmpWiseCBFDelete EmpCBFD = new ProcessEmpWiseCBFDelete();
                        EmpCBFD.EMPCBFD = objEmpWiseCBF;
                        EmpCBFD.invoke();

                    }
                    i++;
                }
                showGridView(drpCmp.SelectedValue);
                objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    public void btnREdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.EMPWISECBF.ToString(), "U"))
            {
                loadFormGrid();
            }
            else
            {
                objCommonName.LabelMessageandColor(labelEmpSlab, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
            }

        }
        else
            Response.Redirect("login.aspx");
    }
    private void loadFormGrid()
    {

        foreach (GridViewRow gvrow in grvEmpCbfEn.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadSalaryBreakUp(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }
    private void loadSalaryBreakUp(string id, int row)
    {
        try
        {
            string a = HiddenField1.Value;
            string strSQL = "Select EmpId,EmpName from tblEmployee where EmpId= '" + id + "'";
            DataSet dsEmp = new DataSet();
            dsEmp = ClsCommon.GetAdhocResult(strSQL);

            if (dsEmp.Tables[0].Rows.Count != 0)
            {
                drpEmpId.SelectedValue = dsEmp.Tables[0].Rows[0][1].ToString();
                drpEmpId.Enabled = false;
                EmpNameTxtBox.ReadOnly = true;
                EmpNameTxtBox.Text = dsEmp.Tables[0].Rows[0][1].ToString();
            }

            string strSQL1 = "SELECT Gross FROM tblEmpSalInfo where EmpId='" + Convert.ToString(drpEmpId.SelectedItem.Text) +
            "' and ConfDate<=Convert(datetime,'" + System.DateTime.Now + "',103) order by ConfDate DESC";
            ReportData objReportData = new ReportData();
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = strSQL1;
            String Gross = Convert.ToString(cmd.ExecuteScalar());
            TextBoxEmpGross.Text = Gross;
            string EmpPer = grvEmpCbfEn.Rows[row].Cells[2].Text;
            string EmpAmount = grvEmpCbfEn.Rows[row].Cells[3].Text;
            string CmpPer = grvEmpCbfEn.Rows[row].Cells[4].Text;
            string CmpAmount = grvEmpCbfEn.Rows[row].Cells[5].Text;
            if (EmpPer == "0" && CmpPer == "0")
            {
                rbtManual.Checked = true;
                rbtSlab.Checked = false;
                rbtPercentage.Checked = false;
                TextBoxEmpDiposit.Visible = false;
                TextBoxCmpDiposit.Visible = false;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpAmount.Visible = true;
                TextBoxEmpDiposit.Text = "0";
                TextBoxEmpAmount.Text = EmpAmount;
                TextBoxCmpDiposit.Text = "0";
                TextBoxCmpAmount.Text = CmpAmount;

            }
            else if (EmpAmount == "0" && CmpAmount == "0")
            {
                rbtPercentage.Checked = true;
                rbtManual.Checked = false;
                rbtSlab.Checked = false;
                TextBoxEmpDiposit.Visible = true;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpDiposit.Visible = true;
                TextBoxCmpAmount.Visible = true;

                TextBoxEmpDiposit.Text = EmpPer;
                TextBoxEmpAmount.Text = numberstring((int.Parse(Gross) * int.Parse(EmpPer) / 100).ToString());
                TextBoxCmpDiposit.Text = CmpPer;
                TextBoxCmpAmount.Text = numberstring((int.Parse(TextBoxEmpAmount.Text) * int.Parse(CmpPer) / 100).ToString());

            }
            else
            {
                rbtPercentage.Checked = false;
                rbtManual.Checked = false;
                rbtSlab.Checked = true;
                TextBoxEmpDiposit.Visible = false;
                TextBoxEmpAmount.Visible = true;
                TextBoxCmpDiposit.Visible = true;
                TextBoxCmpAmount.Visible = true;

                TextBoxEmpDiposit.Text = EmpPer;
                TextBoxEmpAmount.Text = EmpAmount;
                TextBoxCmpDiposit.Text = CmpPer;
                TextBoxCmpAmount.Text = CmpAmount;

            }

        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelEmpSlab, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    protected void TextBoxEmpDiposit_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxEmpGross.Text != "")
        {
            TextBoxEmpAmount.Text = numberstring((int.Parse(TextBoxEmpGross.Text) * int.Parse(TextBoxEmpDiposit.Text) / 100).ToString());

        }
        if (TextBoxEmpAmount.Text != "" && TextBoxCmpDiposit.Text != "")
        {
            TextBoxCmpAmount.Text = numberstring((int.Parse(TextBoxEmpAmount.Text) * int.Parse(TextBoxCmpDiposit.Text) / 100).ToString());

        }

    }
    private string numberstring(string numstr)
    {
        string result;
        int i = numstr.IndexOf('.');
        if (i > 0)
        {
            result = numstr.Substring(0, i);
        }
        else
        {
            result = numstr;
        }
        return result;
    }
    protected void TextBoxCmpDiposit_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxEmpAmount.Text != "")
        {
            TextBoxCmpAmount.Text = numberstring(((int.Parse(TextBoxEmpAmount.Text) * int.Parse(TextBoxCmpDiposit.Text)) / 100).ToString());


        }
    }
    protected void TextBoxEmpAmount_TextChanged(object sender, EventArgs e)
    {
        if (TextBoxEmpAmount.Text != "")
        {
            TextBoxCmpAmount.Text = numberstring(((int.Parse(TextBoxEmpAmount.Text) * int.Parse(TextBoxCmpDiposit.Text)) / 100).ToString());


        }
    }
}