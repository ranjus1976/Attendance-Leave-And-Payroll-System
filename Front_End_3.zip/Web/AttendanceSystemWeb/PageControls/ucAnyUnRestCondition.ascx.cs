﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.BLL;

public partial class PageControls_ucAnyUnRestCondition : System.Web.UI.UserControl
{
    #region Declaration
    SqlConnection con;
    SqlCommand cmd;
    DataSet ds;
    ReportData objReportData = new ReportData();
    String ReportDateShow;
    String TimeShow;
    CommonName objCommonName = new CommonName();

    Shift _shift;
    #endregion

    #region Page Load

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ANYUNREST.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    LoadGridData();
                    btnEdit.Enabled = false;

                    ReportDateShow = Convert.ToString(System.DateTime.Now);
                    TimeShow = "00:00";//ReportDateShow.Substring(11, 5);
                    ReportDateShow = ReportDateShow.Substring(0, 10);

                    txtUnrestShiftIn.Text = TimeShow;
                    txtUnrestShiftOut.Text = TimeShow;
                    txtUnrestShiftLate.Text = TimeShow;
                    txtEffectiveDate.Text = ReportDateShow;
                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Private

    private void LoadGridData()
    {
        try
        {
            ProcessUnrestSelect pcs = new ProcessUnrestSelect();
            pcs.invoke();
            Session["UnrestDS"] = pcs.UnrestDS.Tables[0];
            gvwShift.DataSource = pcs.UnrestDS.Tables[0];
            gvwShift.DataBind();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void SaveData()
    {
        try
        {
            _shift = new Shift();
            _shift.ShiftName = txtUnrestShiftName.Text.Trim();
            _shift.ShiftInTime = Convert.ToDateTime(txtUnrestShiftIn.Text.Trim());
            _shift.ShiftOutTime = Convert.ToDateTime(txtUnrestShiftOut.Text.Trim());
            _shift.ShiftLate = Convert.ToDateTime(txtUnrestShiftLate.Text.Trim());
            _shift.EffectiveDate = DateTime.Parse(txtEffectiveDate.Text.Trim().ToString());

            ProcessUnrestInsert objProcessUnrestInsert = new ProcessUnrestInsert();
            objProcessUnrestInsert.Shift = _shift;
            objProcessUnrestInsert.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }

    }
    private void updateData(Int32 ShiftEditNumber)
    {
        try
        {
            _shift = new Shift();
            _shift.ShiftId = ShiftEditNumber;
            _shift.ShiftName = txtUnrestShiftName.Text.Trim();
            _shift.ShiftInTime = Convert.ToDateTime(txtUnrestShiftIn.Text.Trim());
            _shift.ShiftOutTime = Convert.ToDateTime(txtUnrestShiftOut.Text.Trim());
            _shift.ShiftLate = Convert.ToDateTime(txtUnrestShiftLate.Text.Trim());
            _shift.EffectiveDate = DateTime.Parse(txtEffectiveDate.Text.Trim().ToString());

            ProcessUnrestUpdate objProcessUnrestUpdate = new ProcessUnrestUpdate();
            objProcessUnrestUpdate.Shift = _shift;
            objProcessUnrestUpdate.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void deleteData(Int32 ShiftNumber)
    {
        try
        {
            _shift = new Shift();
            _shift.ShiftId = ShiftNumber;

            ProcessUnrestDelete objProcessUnrestDelete = new ProcessUnrestDelete();
            objProcessUnrestDelete.Shift = _shift;
            objProcessUnrestDelete.invoke();
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }
    private void loadFormGrid()
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                foreach (GridViewRow gr in gvwShift.Rows)
                {
                    CheckBox chb = (CheckBox)gr.FindControl("shiftEditCheckBox");

                    if (chb.Checked)
                    {
                        HiddenField HidShift_Number = (HiddenField)gr.FindControl("HidShift_Number");
                        HiddenField HidShiftName = (HiddenField)gr.FindControl("HidShiftName");
                        HiddenField HidShiftIn = (HiddenField)gr.FindControl("HidShiftIn");
                        HiddenField HidShiftOut = (HiddenField)gr.FindControl("HidShiftOut");
                        HiddenField HidShiftLate = (HiddenField)gr.FindControl("HidShiftLate");
                        HiddenField HiddenField1 = (HiddenField)gr.FindControl("HiddenField1");

                        Session["ShiftNumber"] = Convert.ToInt16(HidShift_Number.Value);

                        txtUnrestShiftName.Text = HidShiftName.Value;
                        txtUnrestShiftIn.Text = HidShiftIn.Value;
                        txtUnrestShiftOut.Text = HidShiftOut.Value;
                        txtUnrestShiftLate.Text = HidShiftLate.Value;
                        txtEffectiveDate.Text = HiddenField1.Value;
                    }
                }
                btnSave.Enabled = false;
                btnEdit.Enabled = true;
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private void CLear()
    {
        txtUnrestShiftIn.Text = "";
        txtUnrestShiftLate.Text = "";
        txtUnrestShiftName.Text = "";
        txtUnrestShiftOut.Text = "";
    }

    #endregion

    #region Button Click

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ANYUNREST.ToString(), "C"))
            {
                SaveData();
                CLear();
                LoadGridData();
                objCommonName.LabelMessageandColor(shiftLabel, objCommonName.SavedMessage, System.Drawing.Color.Green);
            }
            else
                objCommonName.LabelMessageandColor(shiftLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                Int32 ShiftEditNumber = Convert.ToInt32(Session["ShiftNumber"]);
                updateData(ShiftEditNumber);
                CLear();
                objCommonName.LabelMessageandColor(shiftLabel, objCommonName.UpdateMessage, System.Drawing.Color.Green);
                LoadGridData();
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnFresh_Click(object sender, EventArgs e)
    {
        CLear();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnEditChk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ANYUNREST.ToString(), "U"))
            {
                try
                {
                    loadFormGrid();
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(shiftLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnDeleteChk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.ANYUNREST.ToString(), "D"))
            {
                try
                {
                    foreach (GridViewRow gr in gvwShift.Rows)
                    {
                        CheckBox del = (CheckBox)gr.FindControl("shiftDeleteCheckBox");
                        if (del.Checked)
                        {
                            HiddenField HidShift_Number = (HiddenField)gr.FindControl("HidShiftNumber");
                            Int32 ShiftNumber = Convert.ToInt16(HidShift_Number.Value);
                            deleteData(ShiftNumber);
                            objCommonName.LabelMessageandColor(shiftLabel, objCommonName.DeleteMessage, System.Drawing.Color.Green);
                            LoadGridData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    objCommonName.LabelMessageandColor(shiftLabel, ex.Message.ToString(), System.Drawing.Color.Red);
                }
            }
            else
                objCommonName.LabelMessageandColor(shiftLabel, objCommonName.UnableProcess, System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    #endregion

    #region Event Handlers

    protected void gvwShift_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("shiftEditCheckBox");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("shiftDeleteCheckBox");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }

    #endregion
}
