﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;

public partial class PageControls_ucLeaveTransfer : System.Web.UI.UserControl
{
    #region Private varibles
    ReportLeaveBalance obj_ReportLeaveBalance = new ReportLeaveBalance();
    DataSet dsLeave = new DataSet();
    SqlDataAdapter daLeave;
    SqlCommand cmdLeave = new SqlCommand();
    SqlConnection objReturnedConn;
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETRANSFER.ToString(), "R"))
            {
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Button Handlers and Events

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ddlFromYear.SelectedIndex = 0;
        ddlToYear.SelectedIndex = 0;
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.LEAVETRANSFER.ToString(), "C"))
            {

                String FromYear = ddlFromYear.SelectedValue;
                String ToYear = ddlToYear.SelectedValue;
                if (ddlFromYear.SelectedIndex != 0 && ddlToYear.SelectedIndex != 0)
                {
                    objReturnedConn = obj_ReportLeaveBalance.GetDBConn();
                    objReturnedConn.Open();
                    cmdLeave.Connection = objReturnedConn;
                    cmdLeave.CommandType = CommandType.StoredProcedure;
                    cmdLeave.CommandText = "sp_Leave_Transfer";
                    cmdLeave.Parameters.AddWithValue("@FromYear", FromYear);
                    cmdLeave.Parameters.AddWithValue("@ToYear", ToYear);

                    daLeave = new SqlDataAdapter(cmdLeave);
                    daLeave.Fill(dsLeave);
                    objReturnedConn.Close();

                    lblDateError.Text = "Leave transferred successful.";
                    lblDateError.Visible = true;
                    lblDateError.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblDateError.Visible = true;
                    lblDateError.ForeColor = System.Drawing.Color.Red;
                    lblDateError.Text = "Please select!";
                }
            }
            else
                Response.Redirect("Default.aspx");
        }
        else
            Response.Redirect("login.aspx");

    }
    protected void ddlFromYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlFromYear.SelectedIndex != 0 && ddlToYear.SelectedIndex != 0)
        {
            lblDateError.Visible = false;
            lblDateError.Text = "";
        }
    }
    protected void ddlToYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlFromYear.SelectedIndex != 0 && ddlToYear.SelectedIndex != 0)
        {
            lblDateError.Visible = false;
            lblDateError.Text = "";
        }
    }

    #endregion
}
