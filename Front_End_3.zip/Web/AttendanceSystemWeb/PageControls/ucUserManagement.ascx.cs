﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using AttendanceSystem.Core;

public partial class PageControls_ucUserManagement : System.Web.UI.UserControl
{
    Role obj_Role;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["UserId"] != null)
                {
                    string userName = Request.QueryString["UserId"].Trim();
                    ShowRole();
                    txtUserName.Text = userName;
                    txtUserName.ReadOnly = true;
                    Session["UserName1"] = userName;
                }
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    #region Private Methods

    protected void ShowRole()
    {
        try
        {
            ProcessRoleDataSelect obj_ProcessRoleDataSelect = new ProcessRoleDataSelect();
            obj_ProcessRoleDataSelect.invoke();
            Session["RoleDS"] = obj_ProcessRoleDataSelect.RoleDS.Tables[0];
            grdRoles.DataSource = obj_ProcessRoleDataSelect.RoleDS.Tables[0];
            grdRoles.DataBind();
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #endregion

    #region Button Handlers
    
    protected void rdnSelectRole_CheckedChanged(object sender, EventArgs e)
    {
        RadioButton rb = (RadioButton)sender;
        GridViewRow row = (GridViewRow)rb.NamingContainer;
        Session["Role_Number"] = Convert.ToInt32(grdRoles.DataKeys[row.RowIndex].Values["Role_Number"]);
        Session["RoleName"] = Convert.ToString(grdRoles.Rows[row.RowIndex].Cells[1].Text.Trim());
    }
    protected void grdRoles_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        obj_Role = new Role();
        Int32 CountRow = 0;
        if (Session["LogIn"] != null)
        {
            foreach (GridViewRow oRow in grdRoles.Rows)
            {
                CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkSelect");

                if (oCheckBoxEdit.Checked)
                {
                    HiddenField hdnRoleNumber = (HiddenField)oRow.FindControl("hdnRoleNumber");
                    HiddenField hdnRoleName = (HiddenField)oRow.FindControl("hdnRoleName");

                    obj_Role.RoleNumber = Convert.ToInt32(hdnRoleNumber.Value.ToString());
                    obj_Role.RoleName = hdnRoleName.Value.ToString();
                    obj_Role.User = txtUserName.Text.Trim();
                    obj_Role.EntryBy = "1";
                    obj_Role.EntryDate = Convert.ToDateTime(System.DateTime.Today);
                    obj_Role.PC = System.Net.Dns.GetHostName().ToString();

                    ProcessRoleDataUpdate objProcessRoleDataUpdate = new ProcessRoleDataUpdate();
                    objProcessRoleDataUpdate.Role = obj_Role;
                    objProcessRoleDataUpdate.invoke();

                    lblRoletoUser.Visible = true;
                    lblRoletoUser.ForeColor = System.Drawing.Color.Green;
                    lblRoletoUser.Text = "Role assigned successfully";
                }
                else
                    CountRow = CountRow + 1;
            }
            if (CountRow == grdRoles.Rows.Count)
            {
                lblRoletoUser.Visible = true;
                lblRoletoUser.ForeColor = System.Drawing.Color.Red;
                lblRoletoUser.Text = "Please select minimum a row";
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    protected void btnFresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void grdRoles_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkSelect");
            hdnUpdateLeaveTypeChek.Value = hdnUpdateLeaveTypeChek.Value + "," + editCheckbox.ClientID;
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hdnUpdateLeaveTypeChek.ClientID + "','" + editCheckbox.ClientID + "')";
            hdnUpdateLeaveTypeChek.Value = hdnUpdateLeaveTypeChek.Value.TrimStart(',');
        }
    }

    #endregion
}
