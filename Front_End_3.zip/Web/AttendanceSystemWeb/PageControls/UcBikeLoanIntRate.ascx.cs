﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using System.IO;
using System.Collections.Generic;
using AttendanceSystem.BLL.Moblie;
using AttendanceSystem.BLL.CBF;
using AttendanceSystem.BLL.BikeLoan;

public partial class PageControls_UcBikeLoanIntRate : System.Web.UI.UserControl
{
    CommonName objCommonName = new CommonName();
    ReportData objReportData = new ReportData();
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //loadCompany();
            showGridView();
            BikeId();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            TextBoxLnType.ReadOnly = true;
            TextBoxIntRte.Text = "0";
        }
    }

    private void BikeId()
    {
        String Sql = "SELECT max(LoanType) FROM tblCompLIntRate";
        con = objReportData.GetDBConn();
        con.Open();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = Sql;
        String BikeId = Convert.ToString(cmd.ExecuteScalar());
        string maxBikeId;

        if(BikeId == "")
        {
            maxBikeId = "12";
        }
        else
        {
            maxBikeId = (int.Parse(BikeId) + 12).ToString();
        }
        TextBoxLnType.Text = maxBikeId;
    }

    private void showGridView()
    {
        string searchStr = "select CompId,Duration,IntRate,LoanType from tblCompLIntRate where bikeInstLog=1 order by LoanType";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeLmintGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeLmintGridView.DataBind();
    }
  
    protected void BikeLmintGridView_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLmintGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void BikeLmintGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            CheckBox editCheckbox = (CheckBox)e.Row.FindControl("chkEdit");
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value + "," + editCheckbox.ClientID;
            CheckBox deleteCheckbox = (CheckBox)e.Row.FindControl("chkDel");
            editCheckbox.Attributes["onclick"] = "javascript:EditCheckEffect('" + hidEditCheckedIDS.ClientID + "','" + editCheckbox.ClientID + "','" + deleteCheckbox.ClientID + "')";
            deleteCheckbox.Attributes["onclick"] = "javascript:DeleteCheckEffect('" + deleteCheckbox.ClientID + "','" + editCheckbox.ClientID + "')";
            hidEditCheckedIDS.Value = hidEditCheckedIDS.Value.TrimStart(',');
        }
    }
    protected void BikeLmintGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BikeLmintGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CMPLOANINTRATE.ToString(), "U"))
            {
               
                loadFormGrid();

            }
            else
            {

                objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);

            }

        }
        else
            Response.Redirect("login.aspx");
    }

    private void loadFormGrid()
    {
        foreach (GridViewRow gvrow in BikeLmintGridView.Rows)
        {
            CheckBox CheckBox1 = (CheckBox)gvrow.FindControl("chkEdit");
            if (CheckBox1.Checked)
            {
                int i = gvrow.RowIndex;
                string id = gvrow.Cells[0].Text;
                loadBikeLoanInt(id, i);
                btnSave.Enabled = false;
                btnUpdate.Enabled = true;
                break;
            }

        }
    }

    private void loadBikeLoanInt(string id, int row)
    {
        try
        {
            string a = HiddenField1.Value;
            string strSQL = "Select CompId,Duration,IntRate,LoanType from tblCompLIntRate where LoanType= '" + a + "'";
            DataSet dsEmp = new DataSet();
            dsEmp = ClsCommon.GetAdhocResult(strSQL);

           
            TextDuration.Text = BikeLmintGridView.Rows[row].Cells[1].Text;
            TextBoxIntRte.Text = BikeLmintGridView.Rows[row].Cells[2].Text;
            TextBoxLnType.Text = BikeLmintGridView.Rows[row].Cells[0].Text;
            //MedicalTimeTextBox.Text = mbBilAdGridView.Rows[row].Cells[5].Text;
            //CBFTextBox.Text = mbBilAdGridView.Rows[row].Cells[6].Text;
            //txtFromDate.Text = mbBilAdGridView.Rows[row].Cells[1].Text;



        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(labelBikeInsRate, ex.Message.ToString(), System.Drawing.Color.Red);
        }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            int i = 0;
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CMPLOANINTRATE.ToString(), "D"))
            {
                BikeLoanIntRate objBikeLoanIntRate = new BikeLoanIntRate();
                foreach (GridViewRow oRow in BikeLmintGridView.Rows)
                {
                    CheckBox oCheckBoxEdit = (CheckBox)oRow.FindControl("chkDel");

                    if (oCheckBoxEdit.Checked)
                    {
                        // HiddenField hDeptId1 = (HiddenField)oRow.FindControl("hDeptID");

                        objBikeLoanIntRate.LoanType = BikeLmintGridView.Rows[i].Cells[0].Text;
                        ProcessBikeLoanIntsDelete BikeLoanIntsD = new ProcessBikeLoanIntsDelete();
                        BikeLoanIntsD.BikeLoanIntD = objBikeLoanIntRate;
                        BikeLoanIntsD.invoke();

                    }
                    i++;
                }
                showGridView();
                objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.DeleteMessage.ToString(), System.Drawing.Color.Green);

            }
            else
                objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.CMPLOANINTRATE.ToString(), "C"))
            {
                string sqlquery = "select LoanType from tblCompLIntRate  where LoanType='" + Convert.ToString(TextBoxLnType.Text) + "' and bikeInstLog=1";
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                ReportData objReportData = new ReportData();
                con = objReportData.GetDBConn();
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sqlquery;
                String LoanType = Convert.ToString(cmd.ExecuteScalar());
                if (LoanType == "")
                {
                    if (Validate())
                    {
                        action = "save";
                        AddBikeLoanIns();
                        objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.SavedMessage.ToString(), System.Drawing.Color.Green);
                        showGridView();
                        BikeId();
                        TextDuration.Text = "";
                        TextBoxIntRte.Text = "0";
                        action = "";

                    }

                    else
                    {
                        //objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
                    }
                }
                else
                    objCommonName.LabelMessageandColor(labelBikeInsRate, "Loan "+objCommonName.AlreadyExistMessage.ToString(), System.Drawing.Color.Red);
            }
            else
                objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UnableProcess.ToString(), System.Drawing.Color.Red);
        }
        else
            Response.Redirect("login.aspx");
    }

    private void AddBikeLoanIns()
    {
        BikeLoanIntRate objBikeLoanIntRate=new BikeLoanIntRate();
        objBikeLoanIntRate.CompId = "";
        objBikeLoanIntRate.Duration = int.Parse(TextDuration.Text);
        objBikeLoanIntRate.IntRate = int.Parse(TextBoxIntRte.Text);
        objBikeLoanIntRate.LoanType = TextBoxLnType.Text;
        objBikeLoanIntRate.Action = action;
        ProcessBikeLoanInsRateInsert objProcessBikeLoanInsRateInsert=new ProcessBikeLoanInsRateInsert();
        objProcessBikeLoanInsRateInsert.bikeloanIntrate = objBikeLoanIntRate;
        objProcessBikeLoanInsRateInsert.invoke();

    }

    private bool Validate()
    {
        bool retval = true;
        if (TextDuration.Text == "")
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelBikeInsRate, "Give Duration", System.Drawing.Color.Red);
        }
        else if (TextBoxIntRte.Text =="")
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelBikeInsRate, "Give Initiate Rate", System.Drawing.Color.Red);
        }
        else if (TextBoxLnType.Text == "")
        {
            retval = false;
            objCommonName.LabelMessageandColor(labelBikeInsRate, "Give Loan Type", System.Drawing.Color.Red);
        }
        return retval;
       
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        action = "Update";
        AddBikeLoanIns();
        objCommonName.LabelMessageandColor(labelBikeInsRate, objCommonName.UpdateMessage.ToString(), System.Drawing.Color.Green);
        action = "";
        HiddenField1.Value = "";
        showGridView();
        btnSave.Enabled = true;
        btnUpdate.Enabled = false;
        
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        string searchStr = "select CompId,Duration,IntRate,LoanType from tblCompLIntRate where LoanType='" + txtSearch.Text + "' order by LoanType";
        DataSet dsMonthDeduct = new DataSet();
        dsMonthDeduct = ClsCommon.GetAdhocResult(searchStr);
        BikeLmintGridView.DataSource = dsMonthDeduct.Tables[0];
        BikeLmintGridView.DataBind();
    }
}
