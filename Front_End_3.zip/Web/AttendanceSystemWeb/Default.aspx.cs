﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Role;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Report;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using AjaxControlToolkit;

public partial class _Default : System.Web.UI.Page
{
    #region Declarations

    CommonName objCommonName = new CommonName();
    RoleData obj_RoleData;
    SqlCommand cmd = new SqlCommand();
    SqlConnection con;
    ArrayList arrUsername = new ArrayList();
    ArrayList arrUserNumber = new ArrayList();
    ArrayList arrFormName = new ArrayList();
    ArrayList arrFormDescription = new ArrayList();
    ArrayList arrSessionUserName = new ArrayList();
    ArrayList arrSessionUserNumber = new ArrayList();
    String scriptString = "";

    #endregion

    #region Private Methods

  private void LeaveNotification(String UserId, String UserType, String tmpRoleType)
  {
        String MainString = "";
        SqlConnection con = new SqlConnection();
        ReportData objReportData = new ReportData();
        DataSet ds = new DataSet();
        String Sql = "sp_LeaveInfoNotification";
        con = objReportData.GetDBConn();
        con.Open();
        SqlCommand cmd = new SqlCommand(Sql, con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = Sql;

        cmd.Parameters.AddWithValue("@UserType", UserType);
        cmd.Parameters.AddWithValue("@UserId", int.Parse(UserId));
        cmd.Parameters.AddWithValue("@DeptHead", tmpRoleType);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            Label[] lbl_arr = new Label[ds.Tables[0].Rows.Count];
            Label[] lbl_arr1 = new Label[ds.Tables[0].Rows.Count];
            Label[] lbl_arr2 = new Label[ds.Tables[0].Rows.Count];
            Label lblCommon = new Label();
            lblCommon.Text = "Disapproved leave ";
            pnlLeaveNotification.Controls.Add(lblCommon);
            Int32 i = 0;
            for ( i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                lbl_arr[i] = new Label();
                lbl_arr1[i] = new Label();
                lbl_arr2[i] = new Label();
                MainString =  ds.Tables[0].Rows[i]["EmpInfo"].ToString();
                
                lbl_arr[i].Style["padding-left"] = "7px";
                lbl_arr[i].Style["padding-right"] = "7px";
                lbl_arr[i].Text = MainString;
                lbl_arr[i].BorderStyle = BorderStyle.Solid;
                lbl_arr1[i].Text = MainString.Substring(10, 4);

                lbl_arr[i].Attributes.Add("onclick", "NotificationDoubleClick('" + lbl_arr1[i].Text + "')");
                pnlLeaveNotification.Controls.Add(lbl_arr[i]);
                lbl_arr2[i].Text = "-";
                pnlLeaveNotification.Controls.Add(lbl_arr2[i]);
            }
            pnlLeaveNotification.Controls.Remove(lbl_arr2[i - 1]);
        }
        else
            pnlLeaveNotification.Visible = false;
    }
    
    private void GetScriptValue()
    {
        scriptString = "  function changeMouseOver(btn){ ";
        scriptString += " if (! btn.style){ ";
        scriptString += " alert('Sorry, your browser does not support this operation.'); ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " btn.style.color = '#2E9AFE'; ";
        scriptString += " btn.style.cursor = 'pointer'; ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " function changeMouseOut(btn) ";
        scriptString += " {";
        scriptString += " if (! btn.style) ";
        scriptString += " { ";
        scriptString += " alert('Sorry, your browser does not support this operation.'); ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " btn.style.color = '#666666'; ";
        scriptString += " btn.style.cursor = 'auto'; ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " function changeMouseOverHref(btn) ";
        scriptString += " { ";
        scriptString += " if (! btn.style) ";
        scriptString += " { ";
        scriptString += " alert('Sorry, your browser does not support this operation.'); ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " if(btn.href!= '')";
        scriptString += " btn.style.color = '#2E9AFE'; ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " function changeMouseOutHref(btn) ";
        scriptString += " { ";
        scriptString += " if (! btn.style) ";
        scriptString += " { ";
        scriptString += " alert('Sorry, your browser does not support this operation.'); ";
        scriptString += " return; ";
        scriptString += " } ";
        scriptString += " if(btn.href!= '')";
        scriptString += " btn.style.color = '#0A5892'; ";
        scriptString += " return; ";
        scriptString += " } ";

        HtmlGenericControl oGen = new HtmlGenericControl("script");
        oGen.Attributes.Add("type", "text/javascript");
        oGen.Attributes.Add("language", "javascript");
        oGen.InnerHtml = scriptString;
        Head1.Controls.Add(oGen);
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

    }
   public bool CheckUserPermission(string PermissionKey, string PermValue)
    {
        int index = 0;
        bool reteunval = false;

        if (Session["FormConstant"] != null && Session["FunctionDesc"] != null)
        {
            ArrayList oFormList = (ArrayList)Session["FormConstant"];
            ArrayList oFuncDesc = (ArrayList)Session["FunctionDesc"];

            string strPerm = "";
            for (int i = 0; i < oFormList.Count; i++)
            {
                if (oFormList[i].ToString() == PermissionKey)
                {
                    index = i;
                    strPerm = oFuncDesc[index].ToString();
                    break;
                }
                strPerm = "GA";
            }

            if (strPerm.Contains(PermValue))
            {
                reteunval = true;
            }
        }
        return reteunval;
    }
    public void CheckUserPermissionFirstTimeLoad()
    {
        bool reteunval = false;
        String strPerm = "";
        String formName = "";

        if (Session["FormConstant"] != null && Session["FunctionDesc"] != null)
        {
            ArrayList oFormList = (ArrayList)Session["FormConstant"];
            ArrayList oFuncDesc = (ArrayList)Session["FunctionDesc"];

            for (int i = 0; i < oFormList.Count; i++)
            {
                strPerm = oFuncDesc[i].ToString();
                formName = oFormList[i].ToString();

                if (objCommonName.PermissionReturn(formName, "COMPANYSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimCompanyHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "DEPARTMENTSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDepartmentHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "DESIGNATIONSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDesignationHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "BIKEENTRYDETSIL", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBikeEntryDetailHref);
                    continue;
                }
               
                else if (objCommonName.PermissionReturn(formName, "SECTIONSETUP", strPerm))
                {
                    // objCommonName.InitialHyperLinkControl(DimSectionHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "SHIFTSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimShiftHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "WEEKLYHOLIDAY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimWeeklyHolidayHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "GOVTHOLIDAY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimGovtHoliDayHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEINFORMATION", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpInfoHref);
                    continue;
                }


                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEINFORMATIONLIST", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpInfoListHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "INSBONUS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimIncentiveBonusHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEENABLEDISABLE", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpEnableDisableHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "SALARYBREAKUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimSalaryBreakupHref);
                    continue;
                }
                //else if (objCommonName.PermissionReturn(formName, "EMPLOYEEIDCONVERTER", strPerm))
                //{
                //    objCommonName.InitialHyperLinkControl(DimEmpIdConversionHref);
                //    continue;
                //}
                else if (objCommonName.PermissionReturn(formName, "LEAVEPERMISSION", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveApplyPermissionHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEPROXYIDCONVERTER", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimProxyIdConversionHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "DATACOLLECION", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDataCollectionHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "DATAPROCESS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDataProcessHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "BONUSPROCESS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBonusProcessHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVETYPESETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveTypeSetupHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVECONFIG", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveProcessHref);
                    continue;
                }

                else if (objCommonName.PermissionReturn(formName, "LEAVEENTRY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveApplyHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVEAPPROVE", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveApprovedHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVESTATUS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveStatusHref);
                    continue;
                }
                //else if (objCommonName.PermissionReturn(formName, "LEAVETRANSFER", strPerm))
                //{
                //    objCommonName.InitialHyperLinkControl(DimLeaveTransferHref);
                //    continue;
                //}
                else if (objCommonName.PermissionReturn(formName, "DAILYREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDailyReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "MONTHLYREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimMonthlyReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "JOBCARD", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimJobCardReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEINFOREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpInfoReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOYEEDETAILSINFOREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpDetailInfoReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "NEWEMPLOYEEINFO", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimCNewEmpInfoReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "RESIGNEMPLOYEEINFO", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimOldEmpInfoReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVEINFORMATIONREPOR", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeaveInfoReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LEAVEBALANCEREPOR", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimLeavebalanceReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "ACTIONTAKEN", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimActionTakenHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "OVERNIGHTDUTY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimONDHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "ANYUNREST", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimAnyUnrestHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "OSDSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimOSDHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "COMPANYMANUALENTRY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimmanuslEntryHref);
                    continue;
                }

                else if (objCommonName.PermissionReturn(formName, "REMARKS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimRemarksHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPWISECBFSTART", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpWiseCBFSatrtHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "CREATEUSER", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimCreateUserHref);
                    continue;
                }

                else if (objCommonName.PermissionReturn(formName, "ROLECREAION", strPerm))
                {
                    //DimCreateRole.Visible = true;
                    objCommonName.InitialHyperLinkControl(DimCreateRoleHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "BIKELOANSETUP", strPerm))
                {
                    //DimCreateRole.Visible = true;
                    objCommonName.InitialHyperLinkControl(DimBikeLoanSetupHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "MBBILAdJADJUSTMENTENTRY", strPerm))
                {
                    //DimCreateRole.Visible = true;
                    objCommonName.InitialHyperLinkControl(DimMbBilAdJustmentEntryHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPWISECBF", strPerm))
                {
                    //DimCreateRole.Visible = true;
                    objCommonName.InitialHyperLinkControl(DimEmployeeWiseCBFEntryHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "CBFDETAILS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimCBFDetailslHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOANSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpLoanSetupHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "LOANADJENTRY", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmployeeLoanAdjHref);
                    continue;
                }


                else if (objCommonName.PermissionReturn(formName, "SALARYDRAW", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimSalaryDrawHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "SALARYPROCESS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimSalaryProcessHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "SALARYADJ", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimSalaryAdjustmentHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "CONFIRMATIONDATE", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimConfDateHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "PROJECTBONUS", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimProjectBonusHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "SALARYSLABSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimSalarySlabEntryHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "CONTREMPSAL", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimContructualEmpSalaryhref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "CMPLOANINTRATE", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBikeLoanIntRateHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "BIKELOANADJ", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBikeLoanAdjmentHref);
                    continue;
                }
               
                else if (objCommonName.PermissionReturn(formName, "DATABASEBACKUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimDatabaseBacHRef);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "PROJECTSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimProjectSetUphref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "MOBILEBILLREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimMobileBillReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "BIKELOANREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBikeLoanReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "EMPLOANREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimEmpPrsnlLoanReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "FINSETUP", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimFinantialYearHref);
                    continue;
                }
                    //Added By Sanjoy
                else if (objCommonName.PermissionReturn(formName, "BONUSREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimBonusReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "PROJECTBONUSREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimProjectBonusReportHref);
                    continue;
                }
                else if (objCommonName.PermissionReturn(formName, "INSBONUSREPORT", strPerm))
                {
                    objCommonName.InitialHyperLinkControl(DimIncentiveReportHref);
                    continue;
                }

            }
        }
    }

    #endregion

    #region Button Handlers

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CheckUserPermissionFirstTimeLoad();
            String welComeMessage = Convert.ToString(Session["EmpName"]);
            lblLoginName.Text = welComeMessage.ToString();
            //String StrPath = Server.MapPath("~\\images\\");
            //imgContent.ImageUrl = new CUtility().PictureUpload(StrPath);
        }
        UserControl Uc = null;

    

        if (Request.Params["Page"] != null)
        {
            Uc = (UserControl)Page.LoadControl("PageControls\\Uc" + Request.Params["Page"].ToString() + ".ascx");
       
        }
        else
        {
            Uc = (UserControl) Page.LoadControl("PageControls/ucDefaultControl.ascx");
        }

        midContent.Controls.Add(Uc);
        //FunctionaUserRole();
         GetScriptValue();

        if (Session["tmpEmp_Number"] != null && Session["UserType"] != null && Session["tmpDept_Head"] != null)
            LeaveNotification(Session["tmpEmp_Number"].ToString(), Session["UserType"].ToString(), Session["tmpDept_Head"].ToString());

        //if (!this.Page.User.Identity.IsAuthenticated)
        //{
        //    Response.Redirect("login.aspx");
        //}

        if (Session["NoLeave="] == "NoLeave")
        {
            lblMessageforMiddleContent.ForeColor = System.Drawing.Color.Red;
            lblMessageforMiddleContent.Visible = true;
            lblMessageforMiddleContent.Text = "No pending leave application";
            Session["NoLeave="] = null;
        }
    }

   

    #endregion
}
