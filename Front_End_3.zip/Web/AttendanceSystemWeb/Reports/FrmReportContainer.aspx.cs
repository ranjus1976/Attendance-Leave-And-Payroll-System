﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Report;
using GAL.Components;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.IO;
using System.Text;

public partial class Reports_FrmReportContainer : System.Web.UI.Page
{
    public string ReportName = "";
    public string ReportTable = "";
    public String CompanyName = "";
    public Int32 CompanyNumber;
    public String UserType = "";
    public Int32 User_Number;
    ReportDocument myReportDocument = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TableName"] != null && Session["ReportName"] != null)
        {
            ReportName = Convert.ToString(Session["ReportName"].ToString());
            ReportTable = Convert.ToString(Session["TableName"].ToString());
            CompanyName = Convert.ToString(Session["CompanyName"]);
            CompanyNumber = Convert.ToInt32(Session["Company_Number"]);
        }

        ShowReport(ReportName);

    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        if (myReportDocument != null)
        {
            myReportDocument.Close();
            myReportDocument.Dispose();
            crvRpt.Dispose();
        }
    }
    private void ShowReport(string ReortName)
    {
        String rptSubstring = "";

        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        SqlConnection objReturnedConn;
        rptSubstring = ReortName.Substring(0, ReortName.Length - 4);
        UserType = Session["UserType"].ToString();

        if (UserType != "ADMIN" && UserType != "SUPERADMIN")
        {
            String CurrentLoginUserNumber = Session["User_Number"].ToString();
            User_Number = int.Parse(CurrentLoginUserNumber);
        }

        if (rptSubstring == "rptDailyAttendance")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);


            CreateReport(ReportName, ds);
            
            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }


//Updated By Sanjoy
        if (rptSubstring == "rptSalarySheet")
        {
            ReportEmpSalarySheet obj_ReportSalarySheet = new ReportEmpSalarySheet();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String compname = Session["CompanyName"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;
            cmd.CommandTimeout = 0;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@CompName", compname);
            //cmd.Parameters.AddWithValue("@UserType", UserType);
            //cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        if (rptSubstring == "rptShortSalary")
        {
            ReportEmpSalarySheet obj_ReportSalarySheet = new ReportEmpSalarySheet();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String compname = Session["CompanyName"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;
            cmd.CommandTimeout = 0;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@CompName", compname);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }



        //Added By Sanjoy 

        if (rptSubstring == "rptPaySlip")
        {
            ReportEmpSalarySheet obj_ReportSalarySheet = new ReportEmpSalarySheet();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String compname = Session["CompanyName"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@CompName", compname);
           

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }



           ///Terminated By Sanjoy

            //Added By Sanjoy 5-12-2012 Bike ln Report

        if (rptSubstring == "rptIncentiveBonus")
        {
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        if (rptSubstring == "rptIncentivePaySlip")
        {
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
         if (rptSubstring == "rptIncentiveShortBonus")
        {
            
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        // Bonus Added By Sanjoy 

        if (rptSubstring == "rptBonus")
        {
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();
           

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        if (rptSubstring == "rptBonusPaySlip")
        {
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        if (rptSubstring == "rptShortFestibleBonus")
        {
            ReportBonus obj_ReportSalarySheet = new ReportBonus();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String CompanyName = Session["CompanyName"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;


            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        if (rptSubstring == "rptProjectBonusReport")
        {
            ReportProjectBonus obj_ReportProjectBonus = new ReportProjectBonus();
            objReturnedConn = obj_ReportProjectBonus.GetDBConn();
            String ProcedureName = Session["reportstorage"].ToString();
            String CompanyName = Session["CompanyName"].ToString();
            String ProjectName = Session["ProjectName"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@ProjectName", ProjectName);


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        if (rptSubstring == "rptProjectBonusPaySlip")
        {
            ReportProjectBonus obj_ReportProjectBonus = new ReportProjectBonus();
            objReturnedConn = obj_ReportProjectBonus.GetDBConn();
            String ProcedureName = Session["reportstorage"].ToString();
            String CompanyName = Session["CompanyName"].ToString();
            String ProjectName = Session["ProjectName"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@ProjectName", ProjectName);


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptBikeLoan")
        {

            ReportBikeLoan Obj_ReportBikeLoan = new ReportBikeLoan();
            objReturnedConn = Obj_ReportBikeLoan.GetDBConn();

            int StartMonthNo = Convert.ToInt32(Session["StartMonthNo"]);
            String StartYear = Session["StartYear"].ToString();
            int EndmonthNo = Convert.ToInt32(Session["EndMonthNo"]);
            String EndYear = Session["Endyear"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option2 = Session["option1"].ToString();
            String compname = Session["CompanyName"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;
            cmd.CommandTimeout = 0;
            cmd.Parameters.AddWithValue("@StartMonthNumber", StartMonthNo);
            cmd.Parameters.AddWithValue("@StartYear", StartYear);
            cmd.Parameters.AddWithValue("@EndMonthNumber", EndmonthNo);
            cmd.Parameters.AddWithValue("@Endyear", EndYear);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option2", Option2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
//Emp Loan Report
        else if (rptSubstring == "rptEmpLoanReport")
        {

            ReportBikeLoan Obj_ReportBikeLoan = new ReportBikeLoan();
            objReturnedConn = Obj_ReportBikeLoan.GetDBConn();

            int StartMonthNo = Convert.ToInt32(Session["StartMonthNo"]);
            String StartYear = Session["StartYear"].ToString();
            int EndmonthNo = Convert.ToInt32(Session["EndMonthNo"]);
            String EndYear = Session["Endyear"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String CompanyName = Session["CompanyName"].ToString();
            string Start = Session["lnStartDatefrom"].ToString() + " 12:00:00 AM";
            string End = Session["lnStartDateto"].ToString() + " 12:00:00 AM";
            ds.Tables.Add(new DataTable(ReportTable));
            if (ProcedureName == "sp_Emp_Comp_Loan_Report")
            {
                cmd.Parameters.AddWithValue("@StartDate", Start);
                cmd.Parameters.AddWithValue("@EndDate", End);
            }
            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;
            cmd.CommandTimeout = 0;
            cmd.Parameters.AddWithValue("@StartMonthNo", StartMonthNo);
            cmd.Parameters.AddWithValue("@StartYear", StartYear);
            cmd.Parameters.AddWithValue("@EndMonthNo", EndmonthNo);
            cmd.Parameters.AddWithValue("@Endyear", EndYear);
            cmd.Parameters.AddWithValue("@Option", Option);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
            Session["lnStartDatefrom"] = null;
            Session["lnStartDateto"] = null;
        }

//cbf details
        else if (rptSubstring == "rptCBFDetail")
        {

            ReportBikeLoan Obj_ReportBikeLoan = new ReportBikeLoan();
            objReturnedConn = Obj_ReportBikeLoan.GetDBConn();

            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String Compname = Session["CompanyName"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option2 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));
            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;
            cmd.CommandTimeout = 0;
            cmd.Parameters.AddWithValue("@MonthName", Month);
            cmd.Parameters.AddWithValue("@YearName", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option2", Option2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }






      else  if (rptSubstring == "rptMobileBill")
        {
            ReportMobileBill obj_ReportSalarySheet = new ReportMobileBill();
            objReturnedConn = obj_ReportSalarySheet.GetDBConn();
            String Year = Session["Year"].ToString();
            String Month = Session["Month"].ToString();
            String Compname = Session["CompanyName"].ToString();
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Month", Month);
            cmd.Parameters.AddWithValue("@Year", Year);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptLeaveApplication")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();

            String ProcedureName = Session["reportstorage"].ToString();
            Int32 EmployeeId = Convert.ToInt32(Session["EmployeeNumber"]);
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@EmpId", EmployeeId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptDailyPresent")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptDailyAbsent")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptDailyLate")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptDailyMissOut")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();


            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptDailySummary")
        {
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);
        }
        else if (rptSubstring == "rptDailyMovement")
        {
            DateTime Date = Convert.ToDateTime(Session["Date"]);
            String ProcedureName = Session["reportstorage"].ToString();
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();

            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = ProcedureName;

            cmd.Parameters.AddWithValue("@Date", Date);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            //cmd.Parameters.AddWithValue("@UserType", UserType);
            //cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);
        }

        else if (rptSubstring == "rptJobCard")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportData.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptEmployeeConfDate")
        {
            ReportData obj_ReportData = new ReportData();
            objReturnedConn = obj_ReportData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_Employee_ConfDate_Information";

            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@GivenFromDate", FromDate);
            cmd.Parameters.AddWithValue("@GivenToDate", ToDate);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptMonthlyPresent")
        {
            ReportMonthlyPresentDaysData obj_ReportMonthlyPresentDaysData = new ReportMonthlyPresentDaysData();
            objReturnedConn = obj_ReportMonthlyPresentDaysData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMonthlyPresentDaysData.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptMonthlyAbsentDays")
        {
            ReportMonthlyAbsentDaysData obj_ReportMonthlyAbsentDaysData = new ReportMonthlyAbsentDaysData();
            objReturnedConn = obj_ReportMonthlyAbsentDaysData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMonthlyAbsentDaysData.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptMonthlyLateDays")
        {
            ReportMonthlyLateDaysData obj_ReportMonthlyLateDaysData = new ReportMonthlyLateDaysData();
            objReturnedConn = obj_ReportMonthlyLateDaysData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMonthlyLateDaysData.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptMonthlyOvertime")
        {
            ReportMontlyOTHourData obj_ReportMontlyOTHourData = new ReportMontlyOTHourData();
            objReturnedConn = obj_ReportMontlyOTHourData.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMontlyOTHourData.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptMonthlyAttendence")
        {
            ReportMonthlyAttendence obj_ReportMonthlyAttendence = new ReportMonthlyAttendence();
            objReturnedConn = obj_ReportMonthlyAttendence.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMonthlyAttendence.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
        else if (rptSubstring == "rptMonthlySummaryReport")
        {
            ReportMonthlySummary obj_ReportMonthlySummary = new ReportMonthlySummary();
            objReturnedConn = obj_ReportMonthlySummary.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportMonthlySummary.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "EmployeeInfo")
        {
            ReportEmployeeInformationData obj_ReportEmployeeInformationData = new ReportEmployeeInformationData();
            objReturnedConn = obj_ReportEmployeeInformationData.GetDBConn();

            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportEmployeeInformationData.ProcedureName();

            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "EmployeeDetailInfo")
        {
            ReportEmployeeInformationData obj_ReportEmployeeInformationData = new ReportEmployeeInformationData();
            objReturnedConn = obj_ReportEmployeeInformationData.GetDBConn();

            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportEmployeeInformationData.ProcedureName();

            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            /*************IMAGE PICTURE***************/
            ds.Tables[0].Columns.Add(new DataColumn("image_stream", typeof(System.Byte[])));
            DataTable dtEmpInfo = (DataTable)ds.Tables[0];
            int dtRow = dtEmpInfo.Rows.Count;
            while (dtRow != 0)
            {
             

                string picPath = "";
                try
                {
                    picPath = Convert.ToString(Server.MapPath("~\\TextFile\\" + dtEmpInfo.Rows[dtRow - 1]["EmpFileName"].ToString()));
                }
                catch
                {
                    picPath =  Convert.ToString(Server.MapPath("~\\Image\\Blank.jpg"));
                }

                FileStream fs;
                try
                {
                    fs = new FileStream(picPath, FileMode.Open, FileAccess.Read);
                }
                catch
                {
                    picPath = Convert.ToString(Server.MapPath("~\\Images\\Blank.jpg"));
                    fs = new FileStream(picPath, FileMode.Open, FileAccess.Read);

                }


                BinaryReader br = new BinaryReader(fs);
                byte[] imgByte = new byte[fs.Length + 1];
                imgByte = br.ReadBytes(Convert.ToInt32(fs.Length));
                //dr[3] = imgByte;

                //Sultan LoadImage(ds.Tables[0].Rows[dtRow - 1], "image_stream", picPath);
                ds.Tables[0].Rows[dtRow-1]["image_stream"] = imgByte;





                //dtEmpInfo.Rows[0]["Image"] = imgByte;

                dtRow--;
            }




            /*************End of IMAGE PICTURE***************/


            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }


        else if (rptSubstring == "rptEmployeeNewInformation")
        {
            ReportNewEmployeeInformation obj_ReportNewEmployeeInformation = new ReportNewEmployeeInformation();
            objReturnedConn = obj_ReportNewEmployeeInformation.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportNewEmployeeInformation.ProcedureName();

            cmd.Parameters.AddWithValue("@GivenFromDate", FromDate);
            cmd.Parameters.AddWithValue("@GivenToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptEmployeeResignInformation")
        {
            ReportResignEmployeeInformation obj_ReportResignEmployeeInformation = new ReportResignEmployeeInformation();
            objReturnedConn = obj_ReportResignEmployeeInformation.GetDBConn();
            DateTime FromDate = Convert.ToDateTime(Session["FromDate"]);
            DateTime ToDate = Convert.ToDateTime(Session["ToDate"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportResignEmployeeInformation.ProcedureName();

            cmd.Parameters.AddWithValue("@GivenFromDate", FromDate);
            cmd.Parameters.AddWithValue("@GivenToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
                objReturnedConn.Close();
        }
        else if (rptSubstring == "rptLeaveInformation")
        {
            bool ApproveorNot = true;
            ReportLeaveInformation obj_ReportLeaveInformation = new ReportLeaveInformation();
            objReturnedConn = obj_ReportLeaveInformation.GetDBConn();
            string FinancialYear = Convert.ToString(Session["FinancialYear"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            String FromDate = Session["FromDate"].ToString();
            String ToDate = Session["ToDate"].ToString();
            if (Session["ApproveorNot"] != null)
                ApproveorNot = bool.Parse(Session["ApproveorNot"].ToString());

            ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportLeaveInformation.ProcedureName();

            cmd.Parameters.AddWithValue("@FromDate", FromDate);
            cmd.Parameters.AddWithValue("@ToDate", ToDate);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);
            cmd.Parameters.AddWithValue("@ApproveorNot", ApproveorNot);
            Session["FakeValue"] = "Need";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds.Tables[0]);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }

        else if (rptSubstring == "rptYearlyLeaveBalance")
        {
            ReportLeaveBalance obj_ReportLeaveBalance = new ReportLeaveBalance();
            objReturnedConn = obj_ReportLeaveBalance.GetDBConn();
            string FinancialYear = Convert.ToString(Session["FinancialYear"]);
            String Option = Session["option"].ToString();
            String Option1 = Session["option1"].ToString();
            //ds.Tables.Add(new DataTable(ReportTable));

            objReturnedConn.Open();
            cmd.Connection = objReturnedConn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = obj_ReportLeaveBalance.ProcedureName();

            cmd.Parameters.AddWithValue("@FinancialYear", FinancialYear);
            cmd.Parameters.AddWithValue("@Option", Option);
            cmd.Parameters.AddWithValue("@Option1", Option1);
            cmd.Parameters.AddWithValue("@Comp_Number", CompanyNumber);
            cmd.Parameters.AddWithValue("@UserType", UserType);
            cmd.Parameters.AddWithValue("@User_Number", User_Number);

            DataTable dtTemp = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);


            da.Fill(dtTemp);

            DataTable oldDataTable = dtTemp;//(DataTable) ds.Tables[1];
            DataTable dt = new DataTable("dsYearlyLeaveBalance");
            dt.Columns.Add("EmpId", typeof(string));
            dt.Columns.Add("EmpName", typeof(string));
            dt.Columns.Add("DeptName", typeof(string));
            dt.Columns.Add("DesigName", typeof(string));
            dt.Columns.Add("CompName", typeof(string));
            dt.Columns.Add("SectName", typeof(string));

            dt.Columns.Add("CLMaxBalance", typeof(int));
            dt.Columns.Add("CLAvail", typeof(float));
            dt.Columns.Add("CLbalance", typeof(float));

            dt.Columns.Add("SLMaxbalance", typeof(float));
            dt.Columns.Add("SLAvail", typeof(float));
            dt.Columns.Add("SLBalance", typeof(float));

            dt.Columns.Add("MLMaxbalance", typeof(float));
            dt.Columns.Add("MLAvail", typeof(float));
            dt.Columns.Add("MLBalance", typeof(float));

            dt.Columns.Add("ELAvail", typeof(float));

            dt.Columns.Add("LWPAvail", typeof(float));

            String empId = String.Empty;
            DataRow drNew = null;

            foreach (DataRow dr in oldDataTable.Rows)
            {
                if (dr["EmpId"].ToString() != empId)
                {
                    drNew = dt.NewRow();
                    dt.Rows.Add(drNew);
                    empId = Convert.ToString(dr["EmpId"]);
                    drNew["EmpId"] = dr["EmpId"];
                    drNew["EmpName"] = dr["EmpName"];
                    drNew["DeptName"] = dr["DeptName"];
                    drNew["CompName"] = dr["CompName"];
                    drNew["DesigName"] = dr["DesigName"];
                    drNew["SectName"] = dr["SectName"];
                }
                if (dr["Type"].ToString() == "GL")
                {
                    drNew["CLMaxBalance"] = dr[7];
                    drNew["CLAvail"] = dr[8];
                    drNew["CLbalance"] = dr[9];
                }

                if (dr["Type"].ToString() == "SL")
                {
                    drNew["SLMaxBalance"] = dr["MAX_Balance"];
                    drNew["SLAvail"] = dr["Avail"];
                    drNew["SLBalance"] = dr["Balance"];
                }
                if (dr["Type"].ToString() == "EL")
                {
                    drNew["MLMaxBalance"] = dr["MAX_Balance"];
                    drNew["MLAvail"] = dr["Avail"];
                    drNew["MLBalance"] = dr["Balance"];
                }
                if (dr["Type"].ToString() == "ML")
                {
                    drNew["ELAvail"] = dr["Avail"];
                }
                if (dr["Type"].ToString() == "LWP")
                {
                    drNew["LWPAvail"] = dr["Avail"];
                }
            }
            ds.Tables.Add(dt);
            CreateReport(ReportName, ds);

            if (objReturnedConn.State == ConnectionState.Open)
            {
                objReturnedConn.Close();
            }
        }
    }
    private void CreateReport(string ReportName, DataSet drJobCard)
    {
        crvRpt.DisplayGroupTree = false;
        crvRpt.HasCrystalLogo = false;

        string ReportPath = Convert.ToString(Server.MapPath("~\\Reports\\Report\\" + ReportName));

        myReportDocument.Load(ReportPath);
        myReportDocument.SetDataSource(drJobCard);


        if (Session["FakeValue"] == "Need")
        {
            String srtToDate = Convert.ToString(Session["ToDate"]);
            String strFromDate = Convert.ToString(Session["FromDate"]);
            strFromDate = strFromDate.Substring(0, 11);
            srtToDate = srtToDate.Substring(0, 11);

            myReportDocument.SetParameterValue("ParameterFromDate", strFromDate);
            myReportDocument.SetParameterValue("ParameterDatetime", srtToDate);
            myReportDocument.SetParameterValue("CompanyName", CompanyName);
        }      
       //Updated By Sanjoy
         else if (Session["ToDate"] != null && Session["FromDate"] != null && Session["CompanyName"] != null && Session["FakeValue"] == null)
         {
             String srtToDate = Convert.ToString(Session["ToDate"]);
             String strFromDate = Convert.ToString(Session["FromDate"]);
             strFromDate = strFromDate.Substring(0, 10);
             srtToDate = srtToDate.Substring(0, 10);

             myReportDocument.SetParameterValue("ParameterFromDate", strFromDate);
             myReportDocument.SetParameterValue("ParameterDatetime", srtToDate);
             myReportDocument.SetParameterValue("CompanyName", CompanyName);
         }


        else if (Session["FinancialYear"] != null && Session["CompanyName"] != null)
        {
            String financialYear = Convert.ToString(Session["FinancialYear"]);
            myReportDocument.SetParameterValue("ParameterFinancialYear", financialYear);
            myReportDocument.SetParameterValue("CompanyName", CompanyName);
        }
        else if (Session["Date"] != null && Session["CompanyName"] != null)
        {
            String Date = Session["Date"].ToString();
            Date = Date.Substring(0, 10);

            myReportDocument.SetParameterValue("ParameterDate", Date);
            myReportDocument.SetParameterValue("CompanyName", CompanyName);
        }
        else if (Session["lnStartDatefrom"] != null && Session["lnStartDateto"] != null && Session["CompanyName"] != null)
        {
            String LnFromDate = Session["lnStartDatefrom"].ToString();
            String LnToDate = Session["lnStartDateto"].ToString();

            myReportDocument.SetParameterValue("FromDate", LnFromDate);
            myReportDocument.SetParameterValue("ToDate", LnToDate);
            myReportDocument.SetParameterValue("CompanyName", CompanyName);
        }

    
    

        else
        {
            myReportDocument.SetParameterValue("CompanyName", CompanyName);
        }

        Session["FakeValue"] = null;
        crvRpt.ReportSource = myReportDocument;
        crvRpt.DataBind();

    }
    protected void crvRpt_Init(object sender, EventArgs e)
    {

    }
    protected void Page_Error(object sender, EventArgs e)
    {
        
        //myReportDocument.Dispose();
        //if (objReturnedConn != null)
        //{
        //    objReturnedConn.Close();
        //}
        //Exception oec = Server.GetLastError();
        //String fgVariable = oec.Message + "\n" + oec.StackTrace.ToString();
        //Response.Write(fgVariable);
        //Server.ClearError();
         
    }
    protected void crvRpt_Unload(object sender, EventArgs e)
    {
        if (myReportDocument != null)
        {
            myReportDocument.Close();
            myReportDocument.Dispose();
            crvRpt.Dispose();
        }
    }
    protected void crvRpt_Disposed(object sender, EventArgs e)
    {
        if (myReportDocument != null)
        {
            myReportDocument.Close();
            myReportDocument.Dispose();
            crvRpt.Dispose();
        }
    }

    
    protected void crvRpt_Navigate(object source, CrystalDecisions.Web.NavigateEventArgs e)
    {

    }
}
