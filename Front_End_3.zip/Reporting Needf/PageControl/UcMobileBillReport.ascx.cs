﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AttendanceSystem.BLL;
using System.Collections.Generic;

public partial class PageControls_UcMobileBillReport : System.Web.UI.UserControl
{
    #region  Declaration
    ArrayList ArralistOption = new ArrayList();
    ArrayList OptionArralist = new ArrayList();
    CommonName objCommonName = new CommonName();
    #endregion
    private string action = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["LogIn"] != null)
        {
            if (((_Default)this.Page).CheckUserPermission(CRoleConstant.SecurityConstant.SALARYDRAW.ToString(), "R"))
            {
                if (!IsPostBack)
                {
                    
                    LoadYear();
                    objCommonName.Addmonth(drpMonth);
                   
                    RadioButtonAll.Checked = true;
                    RadioButtonAll.Enabled = true;
                   

                    Session["NotReadPermission"] = null;

                }
                Session["NotReadPermission"] = null;
            }
            else
            {
                Session["NotReadPermission"] = "NotReadPermission";
                Response.Redirect("Default.aspx");
            }
        }
        else
            Response.Redirect("login.aspx");
    }
    private void LoadYear()
    {
        drYear.Items.Clear();
        List<ListItem> items = new List<ListItem>();
        items.Add(new ListItem("Select", "0"));
        int year = System.DateTime.Now.Year;
        int lastyear = (year + 1);
        ListItem[] li = new ListItem[15];
        for (int i = 10; i > 0; i--)
        {
            items.Add(new ListItem(lastyear.ToString(), i.ToString()));
            lastyear--;
        }
        drYear.DataSource = li;
        drYear.Items.AddRange(items.ToArray());
    }
    protected void RadioButtonAll_CheckedChanged1(object sender, EventArgs e)
    {

    }
    protected void drpMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnReport_Click(object sender, EventArgs e)
    {
        if (Session["LogIn"] != null)
        {
            try
            {
                Session["ReportName"] = "rptMobileBill.rpt";
                Session["TableName"] = "dsMobileBill";
                Session["CompanyName"] = "Genarell Automation Limited";
                Session["Month"] = drpMonth.SelectedItem.Text;
                Session["Year"] = drYear.SelectedItem.Text;
                ArralistOption = GetOption();
                Session["option"] = ArralistOption[0];
                Session["option1"] = ArralistOption[1];
                Session["reportstorage"] = "sp_Mobile_Bill";
                string strPath = Request.ApplicationPath + "/Reports/FrmReportContainer.aspx";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Open Window", "window.open('" + strPath + "' , 'no', 'height=680, width= 1024, top=300, left=500, location=1, scrollbars=1, resizable=1');", true);
            }
            catch (Exception ex)
            {
                objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
            }
        }
        else
            Response.Redirect("login.aspx");
    }

    private ArrayList GetOption()
    {
        try
        {
            if (RadioButtonAll.Checked && FullYearChkBx.Checked==false)
            {

                OptionArralist.Add("All");
                OptionArralist.Add("All");
            }
            else 
            {
                OptionArralist.Add("All");
                OptionArralist.Add("FullYear");
            }
        }
        catch (Exception ex)
        {
            objCommonName.LabelMessageandColor(lblErrorMessage, ex.Message.ToString(), System.Drawing.Color.Red);
        }
        return OptionArralist;
    }
    protected void btnExit_Click(object sender, EventArgs e)
    {

    }
    protected void FullYearChkBx_CheckedChanged(object sender, EventArgs e)
    {
        if (FullYearChkBx.Checked)
        {
            drpMonth.Enabled = false;
        }
        else
        {
            drpMonth.Enabled = true;
        }
    }
}
