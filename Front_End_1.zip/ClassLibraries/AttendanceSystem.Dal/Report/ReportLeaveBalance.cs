﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace AttendanceSystem.Dal.Report
{
    public class ReportLeaveBalance : DataAccessBase
    {
        public ReportLeaveBalance()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Balance_Report.ToString();
        }

        public string ProcedureName()
        {
            return this.StoredProcedureName;
        }

        public SqlConnection GetDBConn()
        {
            SqlConnection oConn = new SqlConnection(this.ConnectionString);
            return oConn;
        }
    }
}
