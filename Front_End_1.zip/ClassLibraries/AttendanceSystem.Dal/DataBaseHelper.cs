/* ===============================================================================
   General Automation Ltd.
 * Designed By Faruk Hossain
  * Descripttion: This is the ....
// ==============================================================================*/


using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using Microsoft.ApplicationBlocks.Data;

namespace AttendanceSystem.Dal
{
   public class DataBaseHelper: DataAccessBase
    {
        private SqlParameter[] _parameters;


        /// <summary>
        /// Cost ructor that helps to initialize with the procedure name.
        /// </summary>
        /// <param name="storedprocedurename"></param>
       public DataBaseHelper(string storedprocedurename)
       {
           StoredProcedureName = storedprocedurename;
       }

       /// <summary>
       /// 
       /// </summary>
       public DataBaseHelper()
       {
       }


        /// <summary>
        /// Run the procedure(Inherited from Base) with the specific transaction
        /// </summary>
        /// <param name="transaction">Sql Transaction</param>
        public void Run( SqlTransaction transaction )
		{
			SqlHelper.ExecuteNonQuery( transaction , CommandType.StoredProcedure , StoredProcedureName , Parameters );
		}


        /// <summary>
        /// Run the procedure(Inherited from Base) with the specific transaction and required Parameters.
        /// </summary>
        /// <param name="transaction">Sql Transaction</param>
        /// <param name="parameters">Parameters that required by the procedure.</param>
        public void Run( SqlTransaction transaction , SqlParameter[] parameters )
		{
			SqlHelper.ExecuteNonQuery( transaction , CommandType.StoredProcedure , StoredProcedureName , parameters );
		}

        
        /// <summary>
        /// Run the procedure(Inherited from Base) with required Parameters And Specific Connection String.
        /// </summary>
        /// <param name="connectionstring">Connection string for the Database</param>
        /// <param name="parameters">Parameters that required by the procedure.</param>
        /// <returns> return type is System.Data.DataSet</returns>
		public DataSet Run( string connectionstring , SqlParameter[ ] parameters )
		{
			DataSet ds;
			ds = SqlHelper.ExecuteDataset( connectionstring , StoredProcedureName , parameters );
			return ds;
		}


       
        //public DataSet Run(string connectionstring, SqlParameter[] parameters)
        //{
        //    DataSet ds;
        //    ds = SqlHelper.ExecuteDataset(connectionstring, StoredProcedureName, parameters);
        //    return ds;
        //}


        /// <summary>
        /// Call the procedure(Inherited from Base) for getting some scalar/single value. provide required Parameters And Specific Connection String.
        /// </summary>
        /// <param name="connectionstring">Connection string for the Database</param>
        /// <param name="parameters">Parameters that required by the procedure.</param>
        /// <returns>Return the scalar value as System.object type.</returns>
		public object RunScalar( string connectionstring , SqlParameter[ ] parameters )
		{
			object obj;
			obj = SqlHelper.ExecuteScalar( connectionstring , StoredProcedureName , parameters );
			return obj;
		}


        /// <summary>
        /// Run the procedure(Inherited from Base) with specified Transaction and SqlParameters list for getting Scalar onject.
        /// </summary>
        /// <param name="transaction">Sql Transaction</param>
        /// <param name="parameters">Parameters that required by the procedure.</param>
        /// <returns>Return the scalar value as System.object type.</returns>
		public object RunScalar( SqlTransaction transaction , SqlParameter[] parameters )
		{
			object obj;
			obj = SqlHelper.ExecuteScalar( transaction , StoredProcedureName , parameters );
			return obj;
		}


        /// <summary>
        /// Run the procedure(Inherited from Base) with specified connection string for getting Dataset.
        /// </summary>
        /// <param name="connectionstring">Connection string for the Database.</param>
        /// <returns>return System.Data.DataSet</returns>
		public DataSet Run( string connectionstring )
		{
			DataSet ds;
			ds = SqlHelper.ExecuteDataset( connectionstring , CommandType.StoredProcedure , StoredProcedureName );
			return ds;
		}

        public DataSet RunReport(string connectionstring,string ReportName)
        {
            DataSet ds;
            ds = SqlHelper.ExecuteReportDataset(connectionstring, CommandType.StoredProcedure, StoredProcedureName, ReportName);
            return ds;
        }


       /// <summary>
       /// 
       /// </summary>
       /// <param name="connectionstring"></param>
       /// <param name="cmdType"></param>
       /// <param name="CommandText"></param>
       /// <returns></returns>
        public DataSet Run(CommandType cmdType, string CommandText)
        {
            DataSet ds;
            ds = SqlHelper.ExecuteDataset(base.ConnectionString, cmdType, CommandText);
            return ds;
        }


       //public static DataTable ExecuteDataTable(SqlConnection connection, bool isProc, string commandText)

       public DataTable getTable(string connectionString, bool isProc, string commandText)
       {
           DataTable dt;
           dt = SqlHelper.ExecuteDataTable(connectionString, isProc, commandText);
           return dt;
       }

       public DataTable getTable(bool isProc, string commandText)
       {
           DataTable dt;
           dt = SqlHelper.ExecuteDataTable(base.ConnectionString,isProc, commandText);
           return dt;
       }


		
        /// <summary>
        /// Run the procedure(Inherited from Base). return type void.
        /// </summary>
        public void Run()
		{
			SqlHelper.ExecuteNonQuery( base.ConnectionString , CommandType.StoredProcedure , StoredProcedureName , Parameters );
		}

        public int RunSalaryProcess()
        {
            int i=SqlHelper.ExecuteNonQuery(base.ConnectionString, CommandType.StoredProcedure, StoredProcedureName, Parameters);
            return i;
        }

        /// <summary>
        /// Run the procedure(Inherited from Base) with the parameters list.
        /// </summary>
        /// <param name="parameters">Parameters that required by the procedure.</param>
        /// <returns>Return System.Data.SqlClient.SqlDataReader</returns>
		public SqlDataReader ExecuteReader( SqlParameter[ ] parameters )
		{
			SqlDataReader dr;
			dr = SqlHelper.ExecuteReader( base.ConnectionString , CommandType.StoredProcedure , StoredProcedureName , parameters );
			return dr;            
		}
        public SqlDataReader ExecuteReader(string strQuery,string commandtype)
        {
            SqlDataReader dr;
            dr = SqlHelper.ExecuteReader(base.ConnectionString, CommandType.Text, strQuery);
            return dr;
        }
       
       /// <summary>
       /// 
       /// </summary>
       /// <param name="parameters"></param>
       /// <returns></returns>
       public SqlDataReader ExecuteReader(string connectionString)
       {
           //SqlDataReader dr;
           return  SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, StoredProcedureName);
       }

       /// <summary>
       /// Execute A valid Non Query Command.
       /// </summary>
       /// <param name="commandText"></param>
       /// <param name="commandType"></param>
       /// <returns></returns>
       public int ExecuteNonQuery(string commandText, CommandType commandType)
       {
           if (commandText.Contains("--") || commandText.Contains("Drop "))
           {
               throw new Exception("Not a Valid Sql Syntex.");
           }
           return SqlHelper.ExecuteNonQuery(base.ConnectionString, commandType, commandText);
       }


        /// <summary>
        /// Get or Set the Parameters that required by procedure.
        /// </summary>
		public SqlParameter[ ] Parameters
		{
			get { return _parameters; }
			set { _parameters = value; }
		}

        /// <summary>
        /// Make stored procedure param.
        /// </summary>
        /// <param name="ParamName">Name of param.</param>
        /// <param name="DbType">Param type.</param>
        /// <param name="Size">Param size.</param>
        /// <param name="Direction">Parm direction.</param>
        /// <param name="Value">Param value.</param>
        /// <returns>New parameter.</returns>
        public static SqlParameter MakeParam(string ParamName, SqlDbType DbType, Int32 Size, ParameterDirection Direction, object Value)
        {
            SqlParameter param;

            if (Size > 0)
                param = new SqlParameter(ParamName, DbType, Size);
            else
                param = new SqlParameter(ParamName, DbType);

            param.Direction = Direction;
            if (!(Direction == ParameterDirection.Output && Value == null))
                param.Value = Value;

            return param;
        }
    }
}
