﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;

namespace AttendanceSystem.Dal.Delete
{
    public class EmpWiseCBFStartDeleteData : DataAccessBase
    {
        public EmpWiseCBFStartDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_EmpWiseCBFStart_Delete.ToString();
        }

        public EmpWiseCBFStart EmpCbfStart { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteEmpCbf()
        {

            EmpWiseCBFStartDeleteDataParameter EmpCbfStartD = new EmpWiseCBFStartDeleteDataParameter(EmpCbfStart);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = EmpCbfStartD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class EmpWiseCBFStartDeleteDataParameter
    {
        public EmpWiseCBFStartDeleteDataParameter(EmpWiseCBFStart EmpCbfStart)
        {
            this.EmpcbfStartD = EmpCbfStart;
            BuildParameter();
        }


        public EmpWiseCBFStart EmpcbfStartD { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,EmpcbfStartD.EmpId.Trim())
                                   
                                   };
            this.Param = param;
        }

    }
}
