﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class OSDDeleteData:DataAccessBase
    {
        public OSDDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_OSD_Delete.ToString();
        }
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        public void DeleteOSDData()
        {
            OSDDeleteDataParameter osdParam = new OSDDeleteDataParameter(this.OsdData);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = osdParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class OSDDeleteDataParameter
    {
        public OSDDeleteDataParameter(OSD osdData)
        {
            this.OSDData = osdData;
            BuildDeleteParameter();
        }
        private OSD _OSDData;

        public OSD OSDData
        {
            get { return _OSDData; }
            set { _OSDData = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildDeleteParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@OSD_Number",SqlDbType.Int,4,ParameterDirection.Input,OSDData.OSDNumber)
                                   };
            this.Param = param;
        }
    }
}
