using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class CompanyDeleteData : DataAccessBase
    {
        public CompanyDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Company_Delete.ToString();
        }

        private Company _Comp;

        public Company Comp
        {
            get { return _Comp; }
            set { _Comp = value; }
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteCompany()
        {
            CompanyDeleteDataParameter ComD = new CompanyDeleteDataParameter(Comp);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = ComD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    class CompanyDeleteDataParameter
    {
        public CompanyDeleteDataParameter(Company Comp)
        {
            this._Comp = Comp;
            BuildParameter();
        }
        private Company _Comp;

        public Company Comp
        {
            get { return _Comp; }
            set { _Comp = value; }
        }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,4,ParameterDirection.Input,Comp.CompNo)
                                   };
            this.Param = param;
        }

    }
}
