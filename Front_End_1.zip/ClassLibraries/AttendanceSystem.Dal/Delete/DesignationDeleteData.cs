using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class DesignationDeleteData:DataAccessBase
    {
        public DesignationDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Designation_Delete.ToString();        
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void DeleteDesignation()
        {
            DesignationDeleteDataParameter dddp = new DesignationDeleteDataParameter(Desig);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = dddp.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class DesignationDeleteDataParameter
    {
        public DesignationDeleteDataParameter(Designation desig)
        {
            this.Desig = desig;
            BuildParameter();
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Desig_Number",SqlDbType.Int,4,ParameterDirection.Input,Desig.DesigNumber)
                                   };
            this.Param=param;
        }

    }
   
}
