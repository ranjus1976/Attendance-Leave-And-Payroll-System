﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class RoleDelete : DataAccessBase
    {
        public RoleDelete()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Role_Delete.ToString();
        }

        private AttendanceSystem.Core.Role _Role;

        public AttendanceSystem.Core.Role Role
        {
            get { return _Role; }
            set { _Role = value; }
        }

        public void DeleteRole()
        {

            RoleDeleteDataParameter obj_RoleDeleteDataParameter = new RoleDeleteDataParameter(Role);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_RoleDeleteDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class RoleDeleteDataParameter
    {
        private AttendanceSystem.Core.Role _Role;

        public RoleDeleteDataParameter(AttendanceSystem.Core.Role Role)
        {
            this._Role = Role;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Role_Number",SqlDbType.Int,4,ParameterDirection.Input,_Role.RoleNumber)
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }
}
