﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class DayDeductDeleteData : DataAccessBase
    {
        public DayDeductDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_DayFineDelete.ToString();
        }

        private DayDeduct _DayDeduct;

        public DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteDayDeduct()
        {
            DayDeductDeleteDataParameter ComD = new DayDeductDeleteDataParameter(DayDeduct);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = ComD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    class DayDeductDeleteDataParameter
    {
        private DayDeduct _DayDeduct;

        public DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        public DayDeductDeleteDataParameter(DayDeduct DayDeduct)
        {
            this._DayDeduct = DayDeduct;
            BuildParameter();
        }
        
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@DeductId",SqlDbType.Int,4,ParameterDirection.Input,DayDeduct.DayDeductId)
                                   };
            this.Param = param;
        }
    }
}
