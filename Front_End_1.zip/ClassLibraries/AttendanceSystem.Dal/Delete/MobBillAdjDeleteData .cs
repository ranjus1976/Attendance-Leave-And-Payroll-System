using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;

namespace AttendanceSystem.Dal.Delete
{
    public class MobBillAdjDeleteData : DataAccessBase
    {
        public MobBillAdjDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_MobBillAdj_Delete.ToString();
        }

        public MbBBillAdj Mob { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteMob()
        {

            MobBilltDeleteDataParameter MobD = new MobBilltDeleteDataParameter(Mob);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = MobD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    class MobBilltDeleteDataParameter
    {
        public MobBilltDeleteDataParameter(MbBBillAdj Mob)
        {
            this.Mob = Mob;
            BuildParameter();
        }


        public MbBBillAdj Mob { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,Mob.EmpId),
                                   DataBaseHelper.MakeParam("@MonthName",SqlDbType.VarChar,20,ParameterDirection.Input,Mob.MonthName),
                                   DataBaseHelper.MakeParam("@Year",SqlDbType.VarChar,20,ParameterDirection.Input,Mob.Year)
                                   };
            this.Param = param;
        }

    }
}
