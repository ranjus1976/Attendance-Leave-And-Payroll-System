﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;

namespace AttendanceSystem.Dal.Delete
{
    public class EmpWiseCBFDeleteData : DataAccessBase
    {
        public EmpWiseCBFDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_EmpWiseCBF_Delete.ToString();
        }

        public EmpWiseCBF EmpCbf { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteEmpCbf()
        {

            EmpWiseCBFDeleteDataParameter EmpCbfD = new EmpWiseCBFDeleteDataParameter(EmpCbf);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = EmpCbfD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class EmpWiseCBFDeleteDataParameter
    {
        public EmpWiseCBFDeleteDataParameter(EmpWiseCBF EmpCbf)
        {
            this.EmpcbfD = EmpCbf;
            BuildParameter();
        }


        public EmpWiseCBF EmpcbfD { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,EmpcbfD.EmpId.Trim())
                                   
                                   };
            this.Param = param;
        }

    }
}
