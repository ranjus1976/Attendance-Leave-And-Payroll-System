﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Delete
{
   public class LeaveDeleteData:DataAccessBase
    {

       public LeaveDeleteData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_LeaveDelete.ToString();

       }


       private LeaveApplied _Leave_Applied;

       public LeaveApplied Leave_Applied
       {
           get { return _Leave_Applied; }
           set { _Leave_Applied = value; }
       }
       public void AddLeaveAppliedDeleteParameter()
       {
           LeaveDeleteParameter oLeaveDeleteParam = new LeaveDeleteParameter(this.Leave_Applied);

           DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
           try
           {
               oDBhalper.Parameters = oLeaveDeleteParam.Param;
               oDBhalper.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (oDBhalper != null)
                   oDBhalper = null;
           }
       }

       public class LeaveDeleteParameter
       {

           private LeaveApplied oLiveApplied;
           public LeaveDeleteParameter(LeaveApplied oLeaveAppliedP)
           {
               this.oLiveApplied = oLeaveAppliedP;
               this.Build();
           }

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }
           void Build()
           {
               try
               {
                   //@leaveDel  numeric (9)

                   SqlParameter[] param = {                                              
                                         DataBaseHelper.MakeParam("@leaveDel",SqlDbType.Int,9,ParameterDirection.Input,oLiveApplied.Leave_Apply_Number)
                                          };
                   this._param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }

       }

    }
}
