﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Delete
{
    public class DeleteLeaveTypeData : DataAccessBase
    {
        public DeleteLeaveTypeData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Type_Delete.ToString();
        }

        private LeaveType _LeaveType;

        public LeaveType LeaveType
        {
            get { return _LeaveType; }
            set { _LeaveType = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteLeaveType()
        {
            LeaveTypeDeleteDataParameter objLeaveTypeDeleteDataParameter = new LeaveTypeDeleteDataParameter(LeaveType);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = objLeaveTypeDeleteDataParameter.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    class LeaveTypeDeleteDataParameter
    {
        public LeaveTypeDeleteDataParameter(LeaveType LeaveT)
        {
            this._LeaveType = LeaveT;
            BuildParameter();
        }
        private LeaveType _LeaveType;

        public LeaveType LeaveType
        {
            get { return _LeaveType; }
            set { _LeaveType = value; }
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@LeaveTypeId",SqlDbType.Int,4,ParameterDirection.Input,LeaveType.LeaveTypeNumber)
                                   };
            this.Param = param;
        }

    }
}
