﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;
namespace AttendanceSystem.Dal.Delete
{
    public class BikeLoanIntsDeleteData : DataAccessBase
    {
        public BikeLoanIntsDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeLoanInts_Delete.ToString();
        }

        public BikeLoanIntRate BikeLoanIntD { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteBikeLoanIntD()
        {

            BikeLoanIntDeleteDataParameter BikeLoanIntDData = new BikeLoanIntDeleteDataParameter(BikeLoanIntD);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = BikeLoanIntDData.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class BikeLoanIntDeleteDataParameter
    {
        public BikeLoanIntDeleteDataParameter(BikeLoanIntRate BikeLoanInt)
        {
            this.BikeLoanInt = BikeLoanInt;
            BuildParameter();
        }


        public BikeLoanIntRate BikeLoanInt { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@LoanType",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanInt.LoanType)
                                   
                                   };
            this.Param = param;
        }

    }
}
