﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class WeeklyHolidayDeleteData:DataAccessBase
    {
        public WeeklyHolidayDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_delete_WeeklyHoliday.ToString();
        }
        private WeeklyHoliDay1 _holiDay;

        public WeeklyHoliDay1 HoliDay
        {
            get { return _holiDay; }
            set { _holiDay = value; }
        }
        public void DeleteWeeklyHoliday()
        {
            WeeklyHolidayDeleteParameter delParam = new WeeklyHolidayDeleteParameter(this.HoliDay);
            
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = delParam.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();

                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
        
    }

    public class WeeklyHolidayDeleteParameter
    {
        
        public WeeklyHolidayDeleteParameter(WeeklyHoliDay1 holiday)
        {
            this.Holiday = holiday;
            BuildParameter();
        }
        private WeeklyHoliDay1 _holiday;

        public WeeklyHoliDay1 Holiday
        {
            get { return _holiday; }
            set { _holiday = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,4,ParameterDirection.Input,Convert.ToInt32(Holiday.CompNumber)),
                                   DataBaseHelper.MakeParam("@Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,Convert.ToInt32(Holiday.DeptNumber))
                                   };
            this.Param = param;
        }

    }
}
