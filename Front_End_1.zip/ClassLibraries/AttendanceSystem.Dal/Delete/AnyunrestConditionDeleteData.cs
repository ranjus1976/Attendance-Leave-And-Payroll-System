﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class AnyunrestConditionDeleteData : DataAccessBase
    {
        public AnyunrestConditionDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Unrest_Condition_Delete.ToString();
        }

        private Shift _shft;
        public Shift Shft
        {
            get { return _shft; }
            set { _shft = value; }
        }

        public void DeleteUnrestShift()
        {
            UnrestShiftDeleteDataParameter sip = new UnrestShiftDeleteDataParameter(Shft);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = sip.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }

        }
    }

    public class UnrestShiftDeleteDataParameter
    {
        private Shift _shft;
        private SqlParameter[] _param;

        public UnrestShiftDeleteDataParameter(Shift Shft)
        {
            this._shft = Shft;
            Build();
        }
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void Build()
        {
            try
            {
                SqlParameter[] param ={
                           
                            DataBaseHelper.MakeParam("UnrestShift_Number",SqlDbType.Int,4,ParameterDirection.Input,_shft.ShiftId)
                            };
                this._param = param;
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
        }
    }
}
