﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Delete
{
    public class SalarySlabDeleteData : DataAccessBase 
    {
        public SalarySlabDeleteData()
     {
         StoredProcedureName = StoredProcedure.Name.sp_SalarySlab_Delete.ToString();
     }

        public SalarySlab slab { get; set; }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void DeleteSalarySlab()
        {

            SalarySlabDeleteDataParameter SlabD = new SalarySlabDeleteDataParameter(slab);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = SlabD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
        class SalarySlabDeleteDataParameter
        {
            public SalarySlabDeleteDataParameter(SalarySlab slab)
            {
                this.slab = slab;
                BuildParameter();
            }

            public SalarySlab slab { get; set; }




            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }
            public void BuildParameter()
            {
                SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@SalarySlabID ",SqlDbType.VarChar,20,ParameterDirection.Input,slab.SalarySlabID)
                                   };
                this.Param = param;
            }

        }
    }
}
