using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class DepartmentSelect : DataAccessBase
    {
        public DepartmentSelect()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Department_Select.ToString();
        }

        public DataSet SelectDepartment()
        {
            try
            {
                DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
                return dbh.Run(base.ConnectionString);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
