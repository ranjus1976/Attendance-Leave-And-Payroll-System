﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class WeeklyHoliDaySelect1:DataAccessBase
    {
        public WeeklyHoliDaySelect1()
        {
            StoredProcedureName = StoredProcedure.Name.sp_CompanyWiseWHD.ToString();
        }
        private DataSet _holiDayDS;

        public DataSet HoliDayDS
        {
            get { return _holiDayDS; }
            set { _holiDayDS = value; }
        }
        public void SelectAllWHDays()
        {
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            HoliDayDS = dbh.Run(base.ConnectionString);
        }
    }

    public class WeeklyHoliDaySelectCheck : DataAccessBase
    {
        public WeeklyHoliDaySelectCheck()
        {
            StoredProcedureName = StoredProcedure.Name.sp_WHD_CheckBox.ToString();
        }
        public string ProcedureName()
        {
            return this.StoredProcedureName;
        }

        public SqlConnection GetDBConn()
        {
            SqlConnection oConn = new SqlConnection(this.ConnectionString);
            return oConn;
        }
    }
}
