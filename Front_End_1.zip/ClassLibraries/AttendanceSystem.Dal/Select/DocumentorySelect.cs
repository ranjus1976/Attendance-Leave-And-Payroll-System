﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Select
{
    public class DocumentorySelect:DataAccessBase
    {

       public DocumentorySelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Documentory_Select.ToString();
       }
      
      private Documentory _Doc;

       public Documentory Doc
       {
           get { return _Doc; }
           set { _Doc = value; }
       }
       public DataSet SelectDocumentory()
       {
           try
           {
               DocumentoryStatusParameters oStatusPAram = new DocumentoryStatusParameters(this.Doc);
               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               return dbh.Run(base.ConnectionString, oStatusPAram.Param);
               //DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               //return dbh.Run(base.ConnectionString);
           }
           catch (Exception)
           {
               throw;
           }
       }

       public class DocumentoryStatusParameters
       {
           public DocumentoryStatusParameters(Documentory oDoc)
           {
               this.Docobj = oDoc;
               Build();
           }

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }

           private Documentory _Docobj;

           public Documentory Docobj
           {
               get { return _Docobj; }
               set { _Docobj = value; }
           }

          
           void Build()
           {
               try
               {
                   SqlParameter[] param = {
                                             
                                              DataBaseHelper.MakeParam("@EmpCode",SqlDbType.VarChar,50,ParameterDirection.Input,Docobj.EmpCode )  
                                          };
                   this.Param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }
       }
    }
}
