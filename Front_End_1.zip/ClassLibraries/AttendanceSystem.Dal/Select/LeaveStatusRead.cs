﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using AttendanceSystem.Core;


namespace AttendanceSystem.Dal.Select
{
    public class LeaveStatusRead : DataAccessBase
    {

        public LeaveStatusRead()
        {
            StoredProcedureName = StoredProcedure.Name.sp_LeaveBalanceRead.ToString();
        }

        private LeaveBalance _LeaveBalance;

        public LeaveBalance LeaveBalance
        {
            get { return _LeaveBalance; }
            set { _LeaveBalance = value; }
        }

        public DataSet GetBalanceStatus()
        {
            try
            {
                LeaveStatusParameters oStatusPAram = new LeaveStatusParameters(this.LeaveBalance);
                DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
                return dbh.Run(base.ConnectionString, oStatusPAram.Param);
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public class LeaveStatusParameters
        {
            public LeaveStatusParameters(LeaveBalance oBalance)
            {
                this.LeaveBalanceobj = oBalance;
                Build();
            }

            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private LeaveBalance _LeaveBalanceobj;

            public LeaveBalance LeaveBalanceobj
            {
                get { return _LeaveBalanceobj; }
                set { _LeaveBalanceobj = value; }
            }
            void Build()
            {
                try
                {
                    SqlParameter[] param = {
                                              DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,LeaveBalanceobj.Employee_Number),
                                              DataBaseHelper.MakeParam("@Leave_Year",SqlDbType.VarChar,20,ParameterDirection.Input,LeaveBalanceobj.Leave_Year )  
                                          };
                    this.Param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
