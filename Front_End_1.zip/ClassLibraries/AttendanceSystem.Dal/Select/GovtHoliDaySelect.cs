﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Select
{
    public class GovtHoliDaySelect:DataAccessBase
    {
        public GovtHoliDaySelect()
        {
            StoredProcedureName = StoredProcedure.Name.sp_GovtHoliDay_SelectAll.ToString();
        }
        private GovtHoliday _gHoliday;

        public GovtHoliday GHoliday
        {
            get { return _gHoliday; }
            set { _gHoliday = value; }
        }
        private DataSet _govtDS;

        public DataSet GovtDS
        {
            get { return _govtDS; }
            set { _govtDS = value; }
        }
        public void SelectGovtHoliDayAll()
        {
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            
            try
            {
                this.GovtDS = dbh.Run(base.ConnectionString);
            }
            catch(Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    
}
