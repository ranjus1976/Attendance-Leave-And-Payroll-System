﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public  class DeptSelectData:DataAccessBase
    {
        public DeptSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Department_Select.ToString();
        }
        public DataSet DeptSelect()
        {
            try
            {
                DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
                return  dbh.Run(base.ConnectionString);
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        
       

    }
}
