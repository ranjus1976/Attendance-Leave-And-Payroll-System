﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace AttendanceSystem.Dal.Select
{
    public class EmployeeLeaveSelect : DataAccessBase
    {
       public EmployeeLeaveSelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_ReadLeaveForSearch.ToString();

       }
       public DataSet SelectEmployeeLeave()
       {
           try
           {
               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               return dbh.Run(base.ConnectionString);
           }
           catch (Exception)
           {

               throw;
           }
       }

    }

}
