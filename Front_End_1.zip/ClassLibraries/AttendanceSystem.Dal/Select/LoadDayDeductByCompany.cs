﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Report;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class LoadDayDeductByCompany : DataAccessBase
    {
        public SqlDataReader DayDeductDataByCompany(Int32 DayDeductId)
        {
            String Sql = StoredProcedure.Name.sp_SelectDayDeductByCompany.ToString();
            SqlCommand cmd = new SqlCommand();
            SqlConnection con = new SqlConnection();
            ReportData objReportData = new ReportData();

            con = objReportData.GetDBConn();
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = Sql;
            cmd.Parameters.AddWithValue("@DayDeductId", DayDeductId);

            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }
    }
}
