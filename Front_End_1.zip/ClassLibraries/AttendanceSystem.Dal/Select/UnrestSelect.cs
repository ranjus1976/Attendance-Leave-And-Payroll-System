﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class UnrestSelect : DataAccessBase
    {
        public UnrestSelect()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Unrest_Condition_Select.ToString();
        }
        public DataSet SelectUnrest()
        {
            try
            {
                DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
                return dbh.Run(base.ConnectionString);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
