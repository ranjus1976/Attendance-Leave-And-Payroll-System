using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class LeaveApplied
    {
        public LeaveApplied()
        {

        }

        private int _Leave_Apply_Number;

        public int Leave_Apply_Number
        {
            get { return _Leave_Apply_Number; }
            set { _Leave_Apply_Number = value; }
        }

        private int _Employee_Number;

        public int Employee_Number
        {
            get { return _Employee_Number; }
            set { _Employee_Number = value; }
        }

        private DateTime _From_Date;

        public DateTime From_Date
        {
            get { return _From_Date; }
            set { _From_Date = value; }
        }

        private DateTime _To_Date;

        public DateTime To_Date
        {
            get { return _To_Date; }
            set { _To_Date = value; }
        }

        private float _Total_Days;

        public float Total_Days
        {
            get { return _Total_Days; }
            set { _Total_Days = value; }
        }

        private int _Leave_Type_Number;

        public int Leave_Type_Number
        {
            get { return _Leave_Type_Number; }
            set { _Leave_Type_Number = value; }
        }

        private int _Approval;

        public int Approval
        {
            get { return _Approval; }
            set { _Approval = value; }
        }
        private String _ApprovalDes;

        public String ApprovalDes
        {
            get { return _ApprovalDes; }
            set { _ApprovalDes = value; }
        }

        private string _Remarks;

        public string Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }

        private string _FinancialYear;

        public string FinancialYear
        {
            get { return _FinancialYear; }
            set { _FinancialYear = value; }
        }

        private int _EntryBy;

        public int EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }

        private int _ApproveBy;

        public int ApproveBy
        {
            get { return _ApproveBy; }
            set { _ApproveBy = value; }
        }

        private int _RecommenedBy;

        public int RecommenedBy
        {
            get { return _RecommenedBy; }
            set { _RecommenedBy = value; }
        }

        private DateTime _EntryDate;

        public DateTime EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }

        private DateTime _ApprovedDate;

        public DateTime ApprovedDate
        {
            get { return _ApprovedDate; }
            set { _ApprovedDate = value; }
        }


        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

        private String _AppRecomTag;

        public String AppRecomTag
        {
            get { return _AppRecomTag; }
            set { _AppRecomTag = value; }
        }

        private float _Avail;

        public float Avail
        {
            get { return _Avail; }
            set { _Avail = value; }
        }

        

        private string _Leave_Year;

        public string Leave_Year
        {
            get { return _Leave_Year; }
            set { _Leave_Year = value; }
        }

    }
}
