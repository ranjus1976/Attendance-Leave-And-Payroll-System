﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
   public class Shift
   {
       private string _pc;
       private int _entryBy;
       private int  _shfitId;
       private string _shiftName;
       private DateTime _inTime;
       private DateTime _OutTime;
       private DateTime _breakTime;
       private DateTime _shiftLate;
       private DateTime _regHour;
     
       private DateTime _ramInTime;
       private DateTime _ramLateTime;
       private DateTime _ramTimeOut; 
       

       public Shift() 
       {
       }
       public int EntryBy
       {
           get { return _entryBy; }
           set { _entryBy = value; }
       }
       public string PC
       {
           get { return _pc; }
           set { _pc = value; }
       }
       public int ShiftId
       {
           get { return _shfitId; }
           set { _shfitId = value; }
       }
       public string ShiftName
       {
           get { return _shiftName; }
           set { _shiftName = value; }
       }
       public DateTime ShiftInTime
       {
           get { return _inTime; }
           set { _inTime = value; }
       }
       public DateTime ShiftOutTime
       {
           get { return _OutTime; }
           set { _OutTime = value; }
       }
       public DateTime BreakTime
       {
           get { return _breakTime; }
           set { _breakTime = value; }
       }
       public DateTime ShiftLate
       {
           get { return _shiftLate; }
           set {_shiftLate = value; }
       }
       
       public DateTime ShiftRamInTime
       {
           get { return _ramInTime; }
           set { _ramInTime = value; }
       }
       public DateTime ShiftRamLateTime
       {
           get { return _ramLateTime; }
           set { _ramLateTime = value; }
       }
       public DateTime ShiftRamTimeOut
       {
           get { return _ramTimeOut; }
           set { _ramTimeOut = value; }
       }

       private DateTime _EffectiveDate = System.DateTime.Now.Date;

       public DateTime EffectiveDate
       {
           get { return _EffectiveDate; }
           set { _EffectiveDate = value; }
       }
   }
}
