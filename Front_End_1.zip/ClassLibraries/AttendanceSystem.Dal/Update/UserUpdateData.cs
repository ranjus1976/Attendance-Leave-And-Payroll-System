﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Update
{
    public class UserUpdateData : DataAccessBase
    {
        private User _usrUp;
        public UserUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_User_Update.ToString();
        }
        public User UsrUp
        {
            get { return _usrUp; }
            set { _usrUp = value; }
        }
        public void UserUpdate()
        {
            try
            {
                UserUpdateDataParameter uudp = new UserUpdateDataParameter(_usrUp);
                DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
                try
                {
                    db.Parameters = uudp.Proms;
                    db.Run();
                }
                catch(Exception e)
                {
                    e.Message.ToString();
                }
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }

        }
    }
    public class UserUpdateDataParameter
    {
        private User _upara;
        private SqlParameter[] proms;
        public UserUpdateDataParameter(User _usr)
        {
            this._upara = _usr;
            BuildPara();
        }

        public SqlParameter[] Proms
        {
            get { return proms; }
            set { proms = value; }
        }
        public void BuildPara()
        {
            try
            {
                SqlParameter[] param = {
                  DataBaseHelper.MakeParam("@UserNo", SqlDbType.Int, 4, ParameterDirection.Input,_upara.UserNo),
                  DataBaseHelper.MakeParam("@UserId",SqlDbType.VarChar,20,ParameterDirection.Input,_upara.UAccept),
                  DataBaseHelper.MakeParam("@UserName",SqlDbType.VarChar,20,ParameterDirection.Input,_upara.UName),
                  DataBaseHelper.MakeParam("@UserPassword",SqlDbType.VarChar,20,ParameterDirection.Input,_upara.UPassword),
                  DataBaseHelper.MakeParam("@UserType",SqlDbType.VarChar,20,ParameterDirection.Input,_upara.UType),
                  DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,7),
                  DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,5,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                  DataBaseHelper.MakeParam("@Email",SqlDbType.VarChar,100,ParameterDirection.Input,_upara.Email),
                  DataBaseHelper.MakeParam("@ValidDate",SqlDbType.DateTime,8,ParameterDirection.Input,_upara.ValidDate)
                  };
                this.proms = param;
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
        }

    }

}
