﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Dal.Update
{
    class DisableEmployee
    {
    }
}
