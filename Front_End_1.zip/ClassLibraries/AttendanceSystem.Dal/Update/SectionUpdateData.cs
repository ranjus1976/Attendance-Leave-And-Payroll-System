using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;
 

namespace AttendanceSystem.Dal.Update
{
   public class SectionUpdateData :DataAccessBase 
    {
       public SectionUpdateData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Section_Update.ToString(); 
       }

       private Section _Sect;

       public Section Sect
       {
           get { return _Sect; }
           set { _Sect = value; }
       }

       public void UpdateSection()
       { 
        
           SectionUpdateParameter s = new SectionUpdateParameter(Sect);
           DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
           try
           {
               db.Parameters = s.Param;
               db.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (db != null)
                   db = null;
           }
       }

      //
       class SectionUpdateParameter
       {
           public SectionUpdateParameter(Section Sect)
           {
               this._Sect = Sect;
               Build();
           }


           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }

           private Section _Sect;

           void Build()
           {
               try
               {
                   SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Sect_Number",SqlDbType.Int,4,ParameterDirection.Input,_Sect.SectNo ),
                    DataBaseHelper.MakeParam("@SectId",SqlDbType.VarChar,4,ParameterDirection.Input,_Sect.SectId),
                    DataBaseHelper.MakeParam("@SectName",SqlDbType.VarChar,150,ParameterDirection.Input,_Sect.SectName ),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,_Sect.DeptNo )
                };//collection
                   this._param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }
       }

       //
    }
}
