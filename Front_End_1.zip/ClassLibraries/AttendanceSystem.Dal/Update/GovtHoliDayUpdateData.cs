﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Update
{
    public class GovtHoliDayUpdateData:DataAccessBase
    {
        public GovtHoliDayUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_GovtHoliDay_Update.ToString();                                                                                                                                                                                                                                                              
        }
        private GovtHoliday _gHoliday;

        public GovtHoliday GHoliday
        {
            get { return _gHoliday; }
            set { _gHoliday = value; }
        }
        public void UpdateGovtHoliday()
        {
            GovtHoliDayUpdateDataParameter ghParam = 
                new GovtHoliDayUpdateDataParameter(this.GHoliday);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = ghParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class GovtHoliDayUpdateDataParameter
    {
        private GovtHoliday _holiDay;

        public GovtHoliday HoliDay
        {
            get { return _holiDay; }
            set { _holiDay = value; }
        }
        SqlParameter[] param;

        public SqlParameter[] Param
        {
            get { return param; }
            set { param = value; }
        }
        public GovtHoliDayUpdateDataParameter(GovtHoliday gHD)
        {
            this.HoliDay = gHD;
            BuildParameter();
        }
        public void  BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@GHNumber",SqlDbType.Int,4,ParameterDirection.Input,HoliDay.GHNumber),
                                   DataBaseHelper.MakeParam("@GHName",SqlDbType.VarChar,50,ParameterDirection.Input,HoliDay.GHName),
                                   DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,4,ParameterDirection.Input,HoliDay.FromDate),
                                   DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,4,ParameterDirection.Input,HoliDay.ToDate)
                                   };
            this.Param = param;
        }
    }
}
