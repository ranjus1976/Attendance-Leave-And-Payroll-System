﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Update
{
    public class EmployeeEnableDisableUpdate : DataAccessBase
    {
        public EmployeeEnableDisableUpdate()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Employee_EnableDisable_Update.ToString();
       }

       private Employee _Emp;

       public Employee Emp
       {
           get { return _Emp; }
           set { _Emp = value; }
       }

       public void UpdateEnableDisableEmployee()
       {
           EmployeeEnableDisableUpdateParameter obj_EmployeeEnableDisableUpdateParameter = new EmployeeEnableDisableUpdateParameter(Emp);
           DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
           try
           {
               db.Parameters = obj_EmployeeEnableDisableUpdateParameter.Param;
               db.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (db != null)
               {

               }
           }
       }

       class EmployeeEnableDisableUpdateParameter
       {
           public EmployeeEnableDisableUpdateParameter(Employee Emp)
           {
               this._Emp = Emp;
               Build();
           }

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }
           private Employee _Emp;


           void Build()
           {
               try
               {
                   SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Emp_Number",SqlDbType.Int,4,ParameterDirection.Input,_Emp.EmpNumber),
                    DataBaseHelper.MakeParam("@EmpSts",SqlDbType.Int,4,ParameterDirection.Input,_Emp.EmpSts)

                };//collection
                   this._param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }
       }
    }
}
