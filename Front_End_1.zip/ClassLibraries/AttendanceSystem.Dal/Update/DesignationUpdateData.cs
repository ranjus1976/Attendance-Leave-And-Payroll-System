using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Update
{
    public class DesignationUpdateData : DataAccessBase
    {
        public DesignationUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Designation_Update.ToString();
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public void UpdateDesignation()
        {
            DesignationUpdateDataParameter dugp = new DesignationUpdateDataParameter(Desig);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dugp.BuildUpdateParameter();
                dbh.Parameters = dugp.Param;

                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }

    }
    class DesignationUpdateDataParameter
    {
        public DesignationUpdateDataParameter(Designation desig)
        {
            this.Desig = desig;

        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        private SqlParameter[] param;

        public SqlParameter[] Param
        {
            get { return param; }
            set { param = value; }
        }
        public void BuildUpdateParameter()
        {
            SqlParameter[] param = { 
                                       DataBaseHelper.MakeParam("@CompId",SqlDbType.Int,4,ParameterDirection.Input,Desig.Company),
                                        DataBaseHelper.MakeParam(
                                            "@Desig_Number",
                                            SqlDbType.Int,
                                            4,
                                            ParameterDirection.Input,
                                            Desig.DesigNumber),
                                        DataBaseHelper.MakeParam(
                                            "@DesigId",
                                            SqlDbType.Char,
                                            6,
                                            ParameterDirection.Input,
                                            Desig.DesigId
                                            ),
                                        DataBaseHelper.MakeParam(
                                            "@DesigName",
                                            SqlDbType.VarChar,
                                            50,
                                            ParameterDirection.Input,
                                            Desig.DesigName
                                            ),
                                        DataBaseHelper.MakeParam(
                                            "@Grade",
                                            SqlDbType.VarChar,
                                            20,
                                            ParameterDirection.Input,
                                            Desig.Grade
                                            ),
                                        DataBaseHelper.MakeParam(
                                            "@Priority",
                                            SqlDbType.Int,
                                            4,
                                            ParameterDirection.Input,
                                            Desig.Priority
                                            )
                                   };
            this.Param = param;
        }

    }
}
