﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Update
{
    public class FunctionUpdate : DataAccessBase
    {
        public FunctionUpdate()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Function_Update.ToString();
        }
        private Function _Function;

        public Function Function
        {
            get { return _Function; }
            set { _Function = value; }
        }
        public void UpdateFunction()
        {

            FunctionUpdateDataParameter obj_FunctionUpdateDataParameter = new FunctionUpdateDataParameter(Function);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_FunctionUpdateDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class FunctionUpdateDataParameter
    {
        private Function _Function;

        public FunctionUpdateDataParameter(Function Function)
        {
            this._Function = Function;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Function_Number",SqlDbType.Int,3,ParameterDirection.Input,_Function.FunctionNumber),
                    DataBaseHelper.MakeParam("@Role_Number",SqlDbType.Int,3,ParameterDirection.Input,_Function.RoleNumber),
                    DataBaseHelper.MakeParam("@FormName",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FunctioName),
                    DataBaseHelper.MakeParam("@FormConstant",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FormConstantName),
                    DataBaseHelper.MakeParam("@Function_Desc",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FunctionDescription),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,4,ParameterDirection.Input,_Function.EntryBy),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,40,ParameterDirection.Input,_Function.EntryDate),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }

}
