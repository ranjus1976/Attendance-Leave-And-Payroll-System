﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class CompanyUpdateData : DataAccessBase
    {
        public CompanyUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Company_Update.ToString();
        }

        private Company _Company;

        public Company Company
        {
            get { return _Company; }
            set { _Company = value; }
        }

        public void UpdateCompany()
        {
            CompanyUpdateParameter d = new CompanyUpdateParameter(Company);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = d.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class CompanyUpdateParameter
        {
            public CompanyUpdateParameter(Company objCompany)
            {
                this._Company = objCompany;
                Build();
            }


            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private Company _Company;

            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,3,ParameterDirection.Input,_Company.CompNo),
                    DataBaseHelper.MakeParam("@CompId",SqlDbType.VarChar,3,ParameterDirection.Input,_Company.CompId),
                    DataBaseHelper.MakeParam("@CompName",SqlDbType.VarChar,150,ParameterDirection.Input,_Company.CompName),
                    DataBaseHelper.MakeParam("@CompAddress",SqlDbType.VarChar,150,ParameterDirection.Input,_Company.CompAddress ),
                    DataBaseHelper.MakeParam("@CompPhone",SqlDbType.VarChar,50,ParameterDirection.Input,_Company.CompPhone),  
                    DataBaseHelper.MakeParam("@CompFax",SqlDbType.VarChar,50,ParameterDirection.Input,_Company.CompFax),  
                    DataBaseHelper.MakeParam("@CompMail",SqlDbType.VarChar,50,ParameterDirection.Input,_Company.CompEmail ),
                    DataBaseHelper.MakeParam("@CompWeb",SqlDbType.VarChar,50,ParameterDirection.Input,_Company.CompWeb),  
                    DataBaseHelper.MakeParam("@CompCell",SqlDbType.VarChar,50,ParameterDirection.Input,_Company.CompCell),  
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@CompanyLogo",SqlDbType.VarChar,100,ParameterDirection.Input,_Company.CompanyLogo)
                };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
