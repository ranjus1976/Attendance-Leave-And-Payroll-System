﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Update
{
    public class FinancialYearUpdateData : DataAccessBase
    {
        public FinancialYearUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Financial_Year_Update.ToString();
        }

        private FinancialYear _FinancialYear;

        public FinancialYear FinancialYear
        {
            get { return _FinancialYear; }
            set { _FinancialYear = value; }
        }

        public void UpdateFinancilayera()
        {
            FinancilaYearUpdateParameter d = new FinancilaYearUpdateParameter(FinancialYear);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = d.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class FinancilaYearUpdateParameter
        {
            FinancialYear _FinancialYear;
            public FinancilaYearUpdateParameter(FinancialYear FinancialYear)
            {
                this._FinancialYear = FinancialYear;
                Build();
            }
            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }
            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Financial_Number",SqlDbType.Int,4,ParameterDirection.Input,_FinancialYear.FinancialYearNumber ),
                   DataBaseHelper.MakeParam("@Financial_Year",SqlDbType.VarChar,150,ParameterDirection.Input,_FinancialYear.FinancialYearName ),
                    DataBaseHelper.MakeParam("@StartDate",SqlDbType.DateTime,8,ParameterDirection.Input,_FinancialYear.StartDate),  
                    DataBaseHelper.MakeParam("@EndDate",SqlDbType.DateTime,8,ParameterDirection.Input,_FinancialYear.EndDate ),
                    DataBaseHelper.MakeParam("@Running_Flag",SqlDbType.Bit,1,ParameterDirection.Input,_FinancialYear.RunningFlag)
                };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
