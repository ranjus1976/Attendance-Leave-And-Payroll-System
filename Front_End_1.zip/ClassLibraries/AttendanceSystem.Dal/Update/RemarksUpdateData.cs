﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class RemarksUpdateData : DataAccessBase
    {
        public RemarksUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Remarks_Update.ToString();
        }
        private Remarks _Remarks;

        public Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        public void UpdateRemarksData()
        {
            RemarksUpdateDataParameter osdUpdateParam = new RemarksUpdateDataParameter(this.Remarks);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = osdUpdateParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {

                }
            }
        }
    }
    class RemarksUpdateDataParameter
    {
        private Remarks _Remarks;
        public Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        private SqlParameter[] _param;
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public RemarksUpdateDataParameter(Remarks Remarks)
        {
            this.Remarks = Remarks;
            BuildUpdateParameter();
        }
        public void BuildUpdateParameter()
        {
            SqlParameter[] param ={
                          DataBaseHelper.MakeParam("@RemarksId",SqlDbType.Int,4,ParameterDirection.Input,Remarks.RemarksId),
                          DataBaseHelper.MakeParam("@EmpId",SqlDbType.Int,4,ParameterDirection.Input,Remarks.EmpId),
                          DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,100,ParameterDirection.Input,Remarks.Remarks1),
                          DataBaseHelper.MakeParam("@CurrDate",SqlDbType.DateTime,8,ParameterDirection.Input,Remarks.RemarksDate),
                          DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,100,ParameterDirection.Input,Remarks.PC),
                          DataBaseHelper.MakeParam("@EntryBy",SqlDbType.VarChar,100,ParameterDirection.Input,Remarks.EntryBy),
                          DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,8,ParameterDirection.Input,Remarks.EntryDate)
                                 };
            this.Param = param;
        }
    }
}
