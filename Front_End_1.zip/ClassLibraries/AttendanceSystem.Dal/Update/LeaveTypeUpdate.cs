﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class LeaveTypeUpdate : DataAccessBase
    {
        public LeaveTypeUpdate()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Type_Update.ToString();
        }
        private LeaveType _objLeaveType;

        public LeaveType ObjLeaveType
        {
            get { return _objLeaveType; }
            set { _objLeaveType = value; }
        }

        public void UpdateLeaveType()
        {
            LeaveUpdateParameter objLeaveUpdateParameter = new LeaveUpdateParameter(ObjLeaveType);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = objLeaveUpdateParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class LeaveUpdateParameter
        {
            public LeaveUpdateParameter(LeaveType LeaveType)
            {
                this.objLeaveType = LeaveType;
                Build();
            }

            private LeaveType objLeaveType;
            private SqlParameter[] _param;
            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }            

            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@LeaveTypeId",SqlDbType.Int,4,ParameterDirection.Input,objLeaveType.LeaveTypeNumber),
                     DataBaseHelper.MakeParam("@LeaveTypeName",SqlDbType.VarChar,150,ParameterDirection.Input,objLeaveType.LeaveName),
                    DataBaseHelper.MakeParam("@Balance",SqlDbType.Int,4,ParameterDirection.Input,objLeaveType.LeaveBalance),
                    DataBaseHelper.MakeParam("@IsRequired",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsRequired),
                    DataBaseHelper.MakeParam("@IsFSpecific",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsFSpecific),
                    DataBaseHelper.MakeParam("@IsPaid",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsPaid),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,150,ParameterDirection.Input,objLeaveType.EntryBy),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,150,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,50,ParameterDirection.Input,objLeaveType.EntryDate)
                };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
