﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class AnyunrestConditionUpdateData : DataAccessBase
    {
        public AnyunrestConditionUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Unrest_Condition_Update.ToString();
        }

        private Shift _shft;
        public Shift Shft
        {
            get { return _shft; }
            set { _shft = value; }
        }

        public void UpdateUnrestShift()
        {
            UnrestShiftUpdateDataParameter sip = new UnrestShiftUpdateDataParameter(Shft);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = sip.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }

        }
    }

    public class UnrestShiftUpdateDataParameter
    {
        private Shift _shft;
        private SqlParameter[] _param;

        public UnrestShiftUpdateDataParameter(Shift Shft)
        {
            this._shft = Shft;
            Build();
        }
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void Build()
        {
            try
            {
                SqlParameter[] param ={
                           
                            DataBaseHelper.MakeParam("@UnrestShift_Number",SqlDbType.Int,4,ParameterDirection.Input,_shft.ShiftId),
                            DataBaseHelper.MakeParam("@ShiftName",SqlDbType.VarChar,50,ParameterDirection.Input,_shft.ShiftName),
                            DataBaseHelper.MakeParam("@ShiftIn",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftInTime),
                            DataBaseHelper.MakeParam("@ShiftOut",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftOutTime),
                            DataBaseHelper.MakeParam("@ShiftLate",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftLate),
                            DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,8,ParameterDirection.Input,DateTime.Now),
                            DataBaseHelper.MakeParam("@EffectiveDate",SqlDbType.DateTime,8,ParameterDirection.Input,_shft.EffectiveDate)
                            };
                this._param = param;
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
        }
    }
}
