﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
    public class UserInsertData:DataAccessBase
    {
        public UserInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_User_Add.ToString();
        }
        private User _obUser;
        public User Obuser
        {
            get { return _obUser; }
            set { _obUser = value; }
        }

        public void AddUser()
        {
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            UserInsertDataParameter uidp = new UserInsertDataParameter(Obuser);
            try
            {
                db.Parameters = uidp.Param;
                db.Run();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
 
        }
    }

    public class UserInsertDataParameter
    {
        User uObject;
        SqlParameter[] _param;
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
 
        }
        public UserInsertDataParameter(User paraUser)
        {
            this.uObject = paraUser;
            Build();
        }

        public void Build()
        {
            try
            {
                SqlParameter[] param = {
                  DataBaseHelper.MakeParam("@UserId",SqlDbType.VarChar,20,ParameterDirection.Input,uObject.UAccept),
                  DataBaseHelper.MakeParam("@UserPassword",SqlDbType.VarChar,200,ParameterDirection.Input,uObject.UPassword),
                  DataBaseHelper.MakeParam("@UserType",SqlDbType.VarChar,20,ParameterDirection.Input,uObject.UType),
                  DataBaseHelper.MakeParam("@UserName",SqlDbType.VarChar,20,ParameterDirection.Input,uObject.UName),
                  DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,7),
                  DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,5,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                  DataBaseHelper.MakeParam("@Email",SqlDbType.VarChar,100,ParameterDirection.Input,uObject.Email),
                  DataBaseHelper.MakeParam("@ValidDate",SqlDbType.DateTime,8,ParameterDirection.Input,uObject.ValidDate)
                  };
                this._param = param;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

 
        }
    }
}
