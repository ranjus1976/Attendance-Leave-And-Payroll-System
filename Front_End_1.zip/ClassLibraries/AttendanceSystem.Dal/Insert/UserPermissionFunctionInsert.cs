﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
   public class UserPermissionFunctionInsert : DataAccessBase
    {
       public UserPermissionFunctionInsert()
       {
           StoredProcedureName = StoredProcedure.Name.sp_UserPermission_Function_Insert.ToString(); 
       }

        private UserPermission _UserPermissionFunction;

        public UserPermission UserPermission
        {
            get { return _UserPermissionFunction; }
            set { _UserPermissionFunction = value; }
        }

       public void AddUserPermissionFunction()
       {

           UserPermissionFunctionInsertDataParameter obj_UserPermissionFunctionInsertDataParameter = new UserPermissionFunctionInsertDataParameter(UserPermission);
           DataBaseHelper obj_DataBaseHelper = new DataBaseHelper(StoredProcedureName);
           try
           {
               obj_DataBaseHelper.Parameters = obj_UserPermissionFunctionInsertDataParameter.Param;
               obj_DataBaseHelper.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (obj_DataBaseHelper != null)
                   obj_DataBaseHelper = null;
           }
       }

    }

    class UserPermissionFunctionInsertDataParameter

    {
        private UserPermission _UserPermissionFunction;
        private SqlParameter[] _param;

        public UserPermissionFunctionInsertDataParameter(UserPermission UserPermission)
        {
            this._UserPermissionFunction = UserPermission;
            Build();
        }
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

       void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Function_Number",SqlDbType.Int,4,ParameterDirection.Input,_UserPermissionFunction.Function_Number),
                    DataBaseHelper.MakeParam("@Function_Description",SqlDbType.VarChar,100,ParameterDirection.Input,_UserPermissionFunction.Function_Description)
                };//collection
                this._param = param;
            }
            catch(Exception e)
            {
                e.ToString();
            }
        }
    }
}
