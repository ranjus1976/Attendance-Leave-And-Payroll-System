﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
   public class DocumentoryInsertData:DataAccessBase
    {
      public DocumentoryInsertData()
      {
          StoredProcedureName = StoredProcedure.Name.sp_Documentory_Add.ToString();
      }

      private Documentory _Doc;

      public Documentory Doc
      {
          get { return _Doc; }
          set { _Doc = value; }
      }
      public void AddDocumentory()
      {
          DocumentoryInsertDataParameter ee = new DocumentoryInsertDataParameter(Doc);
          DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
          try
          {
              db.Parameters = ee.Param;
              db.Run();
          }
          catch (Exception e)
          {
              e.ToString();
          }
          finally
          {
              if (db != null)
                  db = null;
          }
      }
    }

   class DocumentoryInsertDataParameter
   {
       public DocumentoryInsertDataParameter(Documentory Doc)
       {
           this._Doc = Doc;
           Build();
       }

       private SqlParameter[] _param;

       public SqlParameter[] Param
       {
           get { return _param; }
           set { _param = value; }
       }

       private Documentory _Doc;

       void Build()
       {
           try
           {
               SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@EmpCode",SqlDbType.VarChar,50,ParameterDirection.Input,_Doc.EmpCode),
                    DataBaseHelper.MakeParam("@EmpDocumentoryList",SqlDbType.VarChar,100,ParameterDirection.Input,_Doc.EmpDocumentoryList),
                    
                };//collection
               this._param = param;
           }
           catch (Exception e)
           {
               e.ToString();
           }
       }
   }
}
