using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient; 

namespace AttendanceSystem.Dal.Insert
{
  public class TextDataInsert : DataAccessBase 
    {
      public TextDataInsert() 
      {
          StoredProcedureName = StoredProcedure.Name.sp_TextData_Add.ToString();
      }

      private TextDataCollect _Text;

      public TextDataCollect Text
      {
          get { return _Text; }
          set { _Text = value; }
      }

      public void AddTextData()
      {
          TextInsertDataParameter tt = new TextInsertDataParameter(Text);
          DataBaseHelper db = new DataBaseHelper(StoredProcedureName);

          try 
          {
              db.Parameters = tt.Param;
              db.Run();
          }
          catch(Exception e) 
          {
              e.ToString();
          }
          finally
          {
              if (db != null)
                  db = null;
          }

      }
      class TextInsertDataParameter
      {
          public TextInsertDataParameter(TextDataCollect Text)
          {
              this._Text = Text;
              Build();
          }

          private SqlParameter[] _param;

          public SqlParameter[] Param
          {
              get { return _param; }
              set { _param = value; }
          }

          private TextDataCollect _Text;

          void Build()
          {
              try
              {
                  SqlParameter[] param =
                  {
                      DataBaseHelper.MakeParam("@CardId",SqlDbType.VarChar,10,ParameterDirection.Input,_Text.CardId),
                      DataBaseHelper.MakeParam("@PunchDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Text.PunchDate),
                      DataBaseHelper.MakeParam("@PunchTime",SqlDbType.VarChar,50,ParameterDirection.Input,_Text.PunchTime),
                      DataBaseHelper.MakeParam("@StNo",SqlDbType.VarChar,4,ParameterDirection.Input,_Text.StNo),
                      DataBaseHelper.MakeParam("@inout",SqlDbType.VarChar,4,ParameterDirection.Input,_Text.InOut),
                      DataBaseHelper.MakeParam("@OvNMark",SqlDbType.VarChar,1,ParameterDirection.Input,_Text.OvNMark),
                      DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,50,ParameterDirection.Input,String.Empty),
                      DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                  };
                  this._param = param;
              }
              catch { }
          }
      }
    }
}
