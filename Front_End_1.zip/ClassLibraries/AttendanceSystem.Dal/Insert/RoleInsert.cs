﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class RoleInsert : DataAccessBase
    {
        public RoleInsert()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Role_Add.ToString();
        }

        private AttendanceSystem.Core.Role _Role;

        public AttendanceSystem.Core.Role Role
        {
            get { return _Role; }
            set { _Role = value; }
        }

        public void AddRole()
        {

            RoleInsertDataParameter obj_RoleInsertDataParameter = new RoleInsertDataParameter(Role);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_RoleInsertDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class RoleInsertDataParameter
    {
        private AttendanceSystem.Core.Role _Role;

        public RoleInsertDataParameter(AttendanceSystem.Core.Role Role)
        {
            this._Role = Role;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@RoleName",SqlDbType.VarChar,50,ParameterDirection.Input,_Role.RoleName),
                    DataBaseHelper.MakeParam("@AspRole",SqlDbType.VarChar,150,ParameterDirection.Input,_Role.AspRole),
                    DataBaseHelper.MakeParam("@User_Name",SqlDbType.VarChar,150,ParameterDirection.Input,_Role.User ),
                    DataBaseHelper.MakeParam("@Mode",SqlDbType.VarChar,50,ParameterDirection.Input,_Role.Mode),  
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,50,ParameterDirection.Input,_Role.EntryBy),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,50,ParameterDirection.Input,_Role.EntryDate ),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }
}
