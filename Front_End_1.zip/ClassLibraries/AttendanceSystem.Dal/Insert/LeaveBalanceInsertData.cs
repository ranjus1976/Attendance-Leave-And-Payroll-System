﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;


namespace AttendanceSystem.Dal.Insert
{
    public class LeaveBalanceInsertData : DataAccessBase
    {

      public LeaveBalanceInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Balance.ToString();
        }

      private LeaveBalance _LeaveProcess;

      public LeaveBalance LeaveProcess
      {
          get { return _LeaveProcess; }
          set { _LeaveProcess = value; }
      }

      public void AddLeaveBalance()
      {
          LeaveBalanceParameters oLeaveProParam = new LeaveBalanceParameters(this.LeaveProcess);

          DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
          try
          {
              oDBhalper.Parameters = oLeaveProParam.Param;
              oDBhalper.Run();
          }
          catch (Exception e)
          {
              e.ToString();
          }
          finally
          {
              if (oDBhalper != null)
                  oDBhalper = null;
          }
      }

      public class LeaveBalanceParameters
      {
          public LeaveBalanceParameters(LeaveBalance oLeaveBalance)
          {
              this._LeaveBalance = oLeaveBalance;
              Build();
          }
          private LeaveBalance _LeaveBalance;
          private SqlParameter[] _param;
          public SqlParameter[] Param
          {
              get { return _param; }
              set { _param = value; }
          }

          //DataBaseHelper.MakeParam("@EntryDate_IN",SqlDbType.DateTime,8,ParameterDirection.Input,_LeaveBalance.EntryDate)

          void Build()
          {
              try
              {
                  SqlParameter[] param = {
                                              
                                         DataBaseHelper.MakeParam("@Filter_Dept",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Dept), 
                                         DataBaseHelper.MakeParam("@Filter_Sec",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Sec),
                                         DataBaseHelper.MakeParam("@Filter_Emp",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Emp),
                                         DataBaseHelper.MakeParam("@Comp_Name",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Comp_Name),
                                         DataBaseHelper.MakeParam("@Leave_Year",SqlDbType.VarChar,15,ParameterDirection.Input,_LeaveBalance.Leave_Year),
                                         DataBaseHelper.MakeParam("@PC_IN",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveBalance.PC),
                                         DataBaseHelper.MakeParam("@EntryBy_IN",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.EntryBy),
                                         DataBaseHelper.MakeParam("@tempyear1",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveBalance.tempyear1 ),
                                         DataBaseHelper.MakeParam("@tempyear2",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveBalance.tempyear2),
                                         DataBaseHelper.MakeParam("@PreviousYear",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveBalance.PreviousYear),
                                         };
                  this._param = param;
              }
              catch (Exception e)
              {
                  e.ToString();
              }
          }
      }

    }



}
