using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core; 
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
   public class CompanyInsertData : DataAccessBase 
    {
       public CompanyInsertData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Company_Add.ToString(); 
       }

       private Company _Comp;

       public Company Comp
       {
           get { return _Comp; }
           set { _Comp = value; }
       }
       
       public void AddCompany()
       {
          
           CompanyInsertDataParameter c = new CompanyInsertDataParameter(Comp);
           DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
           try
           {
               db.Parameters = c.Param;
               db.Run();
               ReturningValue.rtnValue = 1;
           }
           catch (Exception ex)
           {
               ReturningValue.rtnValue = 0;
               ReturningValue.rtnErrorMessage = ex.Message.ToString();
           }
           finally
           {
               if (db != null)
                   db = null;
           }
       }

    }

    class CompanyInsertDataParameter

    {
        private Company _Comp;

        public CompanyInsertDataParameter(Company Comp)
        {
            this._Comp = Comp;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param = 
                {
                    DataBaseHelper.MakeParam("@CompId",SqlDbType.VarChar,3,ParameterDirection.Input,_Comp.CompId),
                    DataBaseHelper.MakeParam("@CompName",SqlDbType.VarChar,150,ParameterDirection.Input,_Comp.CompName),
                    DataBaseHelper.MakeParam("@CompAddress",SqlDbType.VarChar,150,ParameterDirection.Input,_Comp.CompAddress ),
                    DataBaseHelper.MakeParam("@CompPhone",SqlDbType.VarChar,50,ParameterDirection.Input,_Comp.CompPhone),  
                    DataBaseHelper.MakeParam("@CompFax",SqlDbType.VarChar,50,ParameterDirection.Input,_Comp.CompFax),  
                    DataBaseHelper.MakeParam("@CompMail",SqlDbType.VarChar,50,ParameterDirection.Input,_Comp.CompEmail ),
                    DataBaseHelper.MakeParam("@CompWeb",SqlDbType.VarChar,50,ParameterDirection.Input,_Comp.CompWeb),  
                    DataBaseHelper.MakeParam("@CompCell",SqlDbType.VarChar,50,ParameterDirection.Input,_Comp.CompCell),  
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@CompanyLogo",SqlDbType.VarChar,100,ParameterDirection.Input,_Comp.CompanyLogo)
                };
                this._param = param;
            }
            catch(Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
        
    }
}
