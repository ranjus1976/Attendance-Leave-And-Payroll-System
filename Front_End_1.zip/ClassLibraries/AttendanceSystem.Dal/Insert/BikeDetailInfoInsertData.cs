﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class BikeDetailInfoInsertData : DataAccessBase
    {
        public BikeDetailInfoInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeDetail_Add.ToString();
        }
        public BikeDetailInfo BikeDetailInfodata { get; set; }
        public void InsertBikeDetailInfo()
        {
            BikeDetailInfoInsertDataParameter BikeDetailInfoParam = new BikeDetailInfoInsertDataParameter(BikeDetailInfodata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = BikeDetailInfoParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class BikeDetailInfoInsertDataParameter
    {
        private BikeDetailInfo BikeDetailInfoData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public BikeDetailInfoInsertDataParameter(BikeDetailInfo BikeDetailInfoData)
        {
            this.BikeDetailInfoData = BikeDetailInfoData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@Model",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.Model),
                            DataBaseHelper.MakeParam("@Manufecturer",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.Manufecturer),
                            DataBaseHelper.MakeParam("@ManuYear",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.ManuYear),
                            DataBaseHelper.MakeParam("@RegistrationNo",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.RegistrationNo),
                            DataBaseHelper.MakeParam("@EngineNo",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.EngineNo),
                            DataBaseHelper.MakeParam("@ChesisNo",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.ChesisNo),
                            DataBaseHelper.MakeParam("@Narration",SqlDbType.VarChar,200,ParameterDirection.Input,BikeDetailInfoData.Narration),
                            DataBaseHelper.MakeParam("@Price",SqlDbType.Int,16,ParameterDirection.Input,BikeDetailInfoData.Price),
                            DataBaseHelper.MakeParam("@PurchaseDate",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.PurchaseDate),
                            DataBaseHelper.MakeParam("@RegCharge",SqlDbType.Int,16,ParameterDirection.Input,BikeDetailInfoData.RegCharge),
                            DataBaseHelper.MakeParam("@InsuranceNo",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.InsuranceNo),
                            DataBaseHelper.MakeParam("@InsurIssueDate",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.InsurIssueDate),
                            DataBaseHelper.MakeParam("@InsurExpireDate",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.InsurExpireDate),
                            DataBaseHelper.MakeParam("@InsuranceCost",SqlDbType.Int,16,ParameterDirection.Input,BikeDetailInfoData.InsuranceCost),
                            DataBaseHelper.MakeParam("@ImageLoc",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.ImageLoc),
                            DataBaseHelper.MakeParam("@Others",SqlDbType.Int,16,ParameterDirection.Input,BikeDetailInfoData.Others),
                            DataBaseHelper.MakeParam("@TotalCost",SqlDbType.Int,16,ParameterDirection.Input,BikeDetailInfoData.TotalCost),
                            DataBaseHelper.MakeParam("@Color",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.Color),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,50,ParameterDirection.Input,BikeDetailInfoData.Action)
                                   };
            this.Param = param;
        }
    }
}
