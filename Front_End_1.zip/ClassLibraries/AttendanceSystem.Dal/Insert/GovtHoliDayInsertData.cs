﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Insert
{
    public class GovtHoliDayInsertData:DataAccessBase
    {
        public GovtHoliDayInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_GovtHoliDay_Add.ToString();
        }
        private GovtHoliday _gHoliDay;

        public GovtHoliday GHoliDay
        {
            get { return _gHoliDay; }
            set { _gHoliDay = value; }
        }
        public void InsertGovtHoliDayData()
        {
            GovtHoliDayInsertDataParameter ghInsertParam = new GovtHoliDayInsertDataParameter(this.GHoliDay);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = ghInsertParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class GovtHoliDayInsertDataParameter
    {
        private GovtHoliday _gHoliDay;

        public GovtHoliday GHoliDay
        {
            get { return _gHoliDay; }
            set { _gHoliDay = value; }
        }
        public GovtHoliDayInsertDataParameter(GovtHoliday gHoliDay)
        {
            this.GHoliDay = gHoliDay;
            BuildGovtHoliDayParameters();
        }
        private SqlParameter[] _Param;

        public SqlParameter[] Param
        {
            get { return _Param; }
            set { _Param = value; }
        }
        public void BuildGovtHoliDayParameters()
        {
            SqlParameter[] param = { 
                              DataBaseHelper.MakeParam("@GHName",SqlDbType.VarChar,50,ParameterDirection.Input,GHoliDay.GHName),
                              DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,4,ParameterDirection.Input,GHoliDay.FromDate),
                              DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,4,ParameterDirection.Input,GHoliDay.ToDate),
                              DataBaseHelper.MakeParam("@Financial_Year_Number",SqlDbType.VarChar,50,ParameterDirection.Input,GHoliDay.FinYearNo),
                              DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,GHoliDay.EntryBy),
                              DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,4,ParameterDirection.Input,GHoliDay.EntryDate),
                              DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,GHoliDay.PC)
                                   };
            this.Param = param;
        }
    }
}
