﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class UserPermissionInsert : DataAccessBase
    {
        public UserPermissionInsert()
       {
           StoredProcedureName = StoredProcedure.Name.sp_UserPermission_Insert.ToString(); 
       }

        private UserPermission _UserPermission;

        public UserPermission UserPermission
        {
            get { return _UserPermission; }
            set { _UserPermission = value; }
        }

       public void AddUserPermission()
       {

           UserPermissionInsertDataParameter obj_UserPermissionInsertDataParameter = new UserPermissionInsertDataParameter(UserPermission);
           DataBaseHelper obj_DataBaseHelper = new DataBaseHelper(StoredProcedureName);
           try
           {
               obj_DataBaseHelper.Parameters = obj_UserPermissionInsertDataParameter.Param;
               obj_DataBaseHelper.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (obj_DataBaseHelper != null)
                   obj_DataBaseHelper = null;
           }
       }

    }

    class UserPermissionInsertDataParameter

    {
        private UserPermission _UserPermission;
        private SqlParameter[] _param;

        public UserPermissionInsertDataParameter(UserPermission UserPermission)
        {
            this._UserPermission = UserPermission;
            Build();
        }
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

       void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@User_Number",SqlDbType.Int,4,ParameterDirection.Input,_UserPermission.User_Number ),
                    DataBaseHelper.MakeParam("@Function_Number",SqlDbType.Int,4,ParameterDirection.Input,_UserPermission.Function_Number),
                    DataBaseHelper.MakeParam("@Entry_By",SqlDbType.Int,4,ParameterDirection.Input,_UserPermission.Entry_By),
                    DataBaseHelper.MakeParam("@Entry_Date",SqlDbType.SmallDateTime,5,ParameterDirection.Input,_UserPermission.Entry_Date),  
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                };//collection
                this._param = param;
            }
            catch(Exception e)
            {
                e.ToString();
            }
        }
    }
}
