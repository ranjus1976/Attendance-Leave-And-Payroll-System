﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class FunctionInsert : DataAccessBase
    {
        public FunctionInsert()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Function_Add.ToString();
        }
        private Function _Function;

        public Function Function
        {
            get { return _Function; }
            set { _Function = value; }
        }
        public void AddFunction()
        {

            FunctionInsertDataParameter obj_FunctionInsertDataParameter = new FunctionInsertDataParameter(Function);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_FunctionInsertDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class FunctionInsertDataParameter
    {
        private Function _Function;

        public FunctionInsertDataParameter(Function Function)
        {
            this._Function = Function;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Role_Number",SqlDbType.Int,4,ParameterDirection.Input,_Function.RoleNumber),
                    DataBaseHelper.MakeParam("@FormName",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FunctioName),
                    DataBaseHelper.MakeParam("@FormConstant",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FormConstantName),
                    DataBaseHelper.MakeParam("@Function_Desc",SqlDbType.VarChar,150,ParameterDirection.Input,_Function.FunctionDescription),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,70,ParameterDirection.Input,_Function.EntryBy),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Function.EntryDate),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }

}
