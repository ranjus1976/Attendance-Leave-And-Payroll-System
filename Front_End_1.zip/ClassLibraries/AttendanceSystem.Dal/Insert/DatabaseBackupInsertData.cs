using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core; 
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
   public class DatabaseBackupInsertData : DataAccessBase 
    {
       public DatabaseBackupInsertData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Databasebackup.ToString(); 
       }

       private DatabaseBackup _DatabaseBackup;

       public DatabaseBackup DatabaseBackup
       {
           get { return _DatabaseBackup; }
           set { _DatabaseBackup = value; }
       }
       public void AddDatabaseBack()
       {

           DatabaseBackupInsertDataParameter c = new DatabaseBackupInsertDataParameter(DatabaseBackup);
           DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
           try
           {
               db.Parameters = c.Param;
               db.Run();
               ReturningValue.rtnValue = 1;
           }
           catch (Exception ex)
           {
               ReturningValue.rtnValue = 0;
               ReturningValue.rtnErrorMessage = ex.Message.ToString();
           }
           finally
           {
               if (db != null)
                   db = null;
           }
       }

    }

    class DatabaseBackupInsertDataParameter

    {
        private DatabaseBackup _DatabaseBackup;

        public DatabaseBackupInsertDataParameter(DatabaseBackup DatabaseBackup)
        {
            this._DatabaseBackup = DatabaseBackup;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param = 
                {
                    DataBaseHelper.MakeParam("DatabaseLocaton",SqlDbType.VarChar,1000,ParameterDirection.Input,_DatabaseBackup.Path)
                };
                this._param = param;
            }
            catch(Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
        
    }
}
