﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;


namespace AttendanceSystem.Dal.Insert
{
    public class SalaryProcessInsert : DataAccessBase
    {
        public SalaryProcessInsert()
        {
            StoredProcedureName = StoredProcedure.Name.sp_SalaryProcess.ToString();
        }

        public SalaryProcess SalaryProcessObj { get; set; }
        public void ProcessData()
        {
            DataBaseHelper dbhelp = new DataBaseHelper(StoredProcedureName);
            try
            {
                SqlParameter[] Para = 
                {
                        DataBaseHelper.MakeParam("@Critaria",SqlDbType.Int,8,ParameterDirection.Input,SalaryProcessObj.Critaria),
                        DataBaseHelper.MakeParam("@Company",SqlDbType.VarChar,20,ParameterDirection.Input,SalaryProcessObj.Company),
                        DataBaseHelper.MakeParam("@DeptId",SqlDbType.VarChar,20, ParameterDirection.Input,SalaryProcessObj.DeptId),
                        DataBaseHelper.MakeParam("@EmployeeId",SqlDbType.VarChar,20,ParameterDirection.Input,SalaryProcessObj.EmployeeId),
                        DataBaseHelper.MakeParam("@MonthName",SqlDbType.VarChar,20,ParameterDirection.Input,SalaryProcessObj.MonthName),
                        DataBaseHelper.MakeParam("@MontnNumber",SqlDbType.VarChar,20,ParameterDirection.Input,SalaryProcessObj.MontnNumber),
                        DataBaseHelper.MakeParam("@YearName",SqlDbType.VarChar,20,ParameterDirection.Input,SalaryProcessObj.YearName)
                        
                };
               
                dbhelp.Parameters = Para;
                int i=dbhelp.RunSalaryProcess();
                if (i == 1 || i==-1)
                {
                    ReturningValue.rtnValue = 1;
                }
                if(i==0)
                {
                    ReturningValue.rtnValue = 0;
                }
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbhelp != null)
                    dbhelp = null;
            }
        }
    }
}
