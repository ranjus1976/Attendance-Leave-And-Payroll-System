﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class BikeLoanIntRateInsertData : DataAccessBase
    {
        public BikeLoanIntRateInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeLoanIntRate_Add.ToString();
        }
        public BikeLoanIntRate BikeLoanIntRatedata { get; set; }
        public void InsertBikeLoanIntRate()
        {
            BikeLoanIntRateInsertDataParameter BikeLoanIntRateParam = new BikeLoanIntRateInsertDataParameter(BikeLoanIntRatedata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = BikeLoanIntRateParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class BikeLoanIntRateInsertDataParameter
    {
        private BikeLoanIntRate BikeLoanIntRateData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public BikeLoanIntRateInsertDataParameter(BikeLoanIntRate BikeLoanIntRateDataData)
        {
            this.BikeLoanIntRateData = BikeLoanIntRateDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@CompId",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanIntRateData.CompId),
                            DataBaseHelper.MakeParam("@Duration",SqlDbType.Int,16,ParameterDirection.Input,BikeLoanIntRateData.Duration),
                            DataBaseHelper.MakeParam("@IntRate",SqlDbType.Int,16,ParameterDirection.Input,BikeLoanIntRateData.IntRate),
                            DataBaseHelper.MakeParam("@LoanType",SqlDbType.VarChar,30,ParameterDirection.Input,BikeLoanIntRateData.LoanType),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanIntRateData.Action)
                                   };
            this.Param = param;
        }
    }
}
