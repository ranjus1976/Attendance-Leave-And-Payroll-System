﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class SalarySlabInsertData : DataAccessBase
    {
        public SalarySlabInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_SalarySlab_Add.ToString();
        }

        public SalarySlab Slab { get; set; }

        public void AddAddSalarySlab()
        {
            SalarySlabInsertDataParameter desigParam = new SalarySlabInsertDataParameter(Slab);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                dbh.Parameters = desigParam.Param;
                dbh.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbh != null)
                    dbh = null;
            }
        }

        private class SalarySlabInsertDataParameter
        {

            public SalarySlabInsertDataParameter(SalarySlab slab)
            {
                this.salarySlab = slab;
                Build();
            }

            public SalarySlab salarySlab { get; set; }
            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private void Build()
            {
                try
                {
                    SqlParameter[] param =
                        {
                            DataBaseHelper.MakeParam("@SalarySlabID", SqlDbType.NVarChar, 20, ParameterDirection.Input,
                                                     salarySlab.SalarySlabID),
                            DataBaseHelper.MakeParam("@StartingRange", SqlDbType.Float, 8, ParameterDirection.Input,
                                                     salarySlab.StartingRange),
                            DataBaseHelper.MakeParam("@ClosingRange", SqlDbType.Float, 8, ParameterDirection.Input,
                                                     salarySlab.ClosingRange),
                            DataBaseHelper.MakeParam("@EmpDipositAmt", SqlDbType.Float, 8, ParameterDirection.Input,
                                                     salarySlab.EmpDipositAmt),
                            DataBaseHelper.MakeParam("@CompPerticipationRatio", SqlDbType.Float, 8,
                                                     ParameterDirection.Input, salarySlab.CompPerticipationRatio),
                            DataBaseHelper.MakeParam("@CompPayableAmount", SqlDbType.Float, 8, ParameterDirection.Input,
                                                     salarySlab.CompPayableAmount),
                            DataBaseHelper.MakeParam("@Action", SqlDbType.VarChar,20, ParameterDirection.Input,
                                                     salarySlab.Action)



                        };
                    this._param = param;
                }
                catch (Exception ex)
                {
                    ReturningValue.rtnValue = 0;
                    ReturningValue.rtnErrorMessage = ex.Message.ToString();
                }
            }
        }
    }
}
