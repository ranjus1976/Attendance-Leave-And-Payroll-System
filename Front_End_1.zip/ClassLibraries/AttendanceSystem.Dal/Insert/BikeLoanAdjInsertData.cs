﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class BikeLoanAdjInsertData : DataAccessBase
    {
        public BikeLoanAdjInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeLoanAdjAdd_Add.ToString();
        }
        public BikeLoanAdj BikeLoanAdjdata { get; set; }
        public void InsertBikeLoanAdj()
        {
            BikeLoanAdjInsertDataParameter BikeLoanAdjParam = new BikeLoanAdjInsertDataParameter(BikeLoanAdjdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = BikeLoanAdjParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class BikeLoanAdjInsertDataParameter
    {
        private BikeLoanAdj BikeLoanAdjData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public BikeLoanAdjInsertDataParameter(BikeLoanAdj BikeLoanAdjDataData)
        {
            this.BikeLoanAdjData = BikeLoanAdjDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanAdjData.EmpId),
                            DataBaseHelper.MakeParam("@AdjAmount",SqlDbType.Int,16,ParameterDirection.Input,BikeLoanAdjData.AdjAmount),
                            DataBaseHelper.MakeParam("@Date",SqlDbType.DateTime,8,ParameterDirection.Input,BikeLoanAdjData.Date),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanAdjData.Action)
                                   };
            this.Param = param;
        }
    }
}
