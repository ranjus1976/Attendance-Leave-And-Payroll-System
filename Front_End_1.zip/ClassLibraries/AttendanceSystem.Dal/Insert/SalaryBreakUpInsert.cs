﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class SalaryBreakUpInsert : DataAccessBase
    {
        public SalaryBreakUpInsert()
        {
            StoredProcedureName = StoredProcedure.Name.sp_SalaryBreakup_Add.ToString();
        }

        public SalaryBreakup salbreak { get; set; }
        public void AddAddSalaryBreak()
        {
            SalaryBreakUpInsertDataParameter desigParam = new SalaryBreakUpInsertDataParameter(salbreak);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                dbh.Parameters = desigParam.Param;
                dbh.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbh != null)
                    dbh = null;
            }
        }
        private class SalaryBreakUpInsertDataParameter
        {

            public SalaryBreakUpInsertDataParameter(SalaryBreakup salabr)
            {
                this.salarybreak = salabr;
                Build();
            }

            public SalaryBreakup salarybreak { get; set; }
            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private void Build()
            {
                try
                {
                    SqlParameter[] param =
                        {
                            DataBaseHelper.MakeParam("@EmpId", SqlDbType.VarChar, 50, ParameterDirection.Input,
                                                     salarybreak.EmpId),
                            DataBaseHelper.MakeParam("@ConfDate", SqlDbType.VarChar, 20, ParameterDirection.Input,
                                                     salarybreak.ConfDate),
                            
                            DataBaseHelper.MakeParam("@Basic", SqlDbType.Int, 8, ParameterDirection.Input,
                                                     salarybreak.Basic),
                            DataBaseHelper.MakeParam("@HouseRent", SqlDbType.Int, 8, ParameterDirection.Input,
                                                     salarybreak.HouseRent),
                            DataBaseHelper.MakeParam("@MedicalAllow", SqlDbType.Int, 8,
                                                     ParameterDirection.Input, salarybreak.MedicalAllow),
                            DataBaseHelper.MakeParam("@Gross", SqlDbType.Int, 8, ParameterDirection.Input,
                                                     salarybreak.Gross),
                            DataBaseHelper.MakeParam("@CBF", SqlDbType.Int, 8,
                                                     ParameterDirection.Input, salarybreak.CBF),
                            DataBaseHelper.MakeParam("@MobileCeling", SqlDbType.Int, 8,ParameterDirection.Input, salarybreak.MobileCeling),
                            DataBaseHelper.MakeParam("@Action", SqlDbType.VarChar,20, ParameterDirection.Input,
                                                     salarybreak.Actiction)



                        };
                    this._param = param;
                }
                catch (Exception ex)
                {
                    ReturningValue.rtnValue = 0;
                    ReturningValue.rtnErrorMessage = ex.Message.ToString();
                }
            }
        }
    }
}
