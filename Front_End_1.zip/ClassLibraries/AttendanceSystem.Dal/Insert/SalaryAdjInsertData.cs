﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class SalaryAdjInsertData : DataAccessBase
    {
        public SalaryAdjInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_SalaryADj_Add.ToString();
        }
        public SalaryAdj SalaryAdjIntrate { get; set; }
        public void SalaryAdjdata()
        {
            SalaryAdjInsertDataParameter SalaryAdjParam = new SalaryAdjInsertDataParameter(SalaryAdjIntrate);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = SalaryAdjParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class SalaryAdjInsertDataParameter
    {
        private SalaryAdj SalaryAdjData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public SalaryAdjInsertDataParameter(SalaryAdj SalaryAdjData)
        {
            this.SalaryAdjData = SalaryAdjData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,50,ParameterDirection.Input,SalaryAdjData.EmpId),
                            DataBaseHelper.MakeParam("@Month",SqlDbType.VarChar,50,ParameterDirection.Input,SalaryAdjData.Month),
                            DataBaseHelper.MakeParam("@Year",SqlDbType.VarChar,50,ParameterDirection.Input,SalaryAdjData.Year),
                            DataBaseHelper.MakeParam("@AdjAmount",SqlDbType.Int,8,ParameterDirection.Input,SalaryAdjData.AdjAmount),
                            DataBaseHelper.MakeParam("@Log",SqlDbType.Int,8,ParameterDirection.Input,SalaryAdjData.Log),
                            DataBaseHelper.MakeParam("@Remark",SqlDbType.VarChar,50,ParameterDirection.Input,SalaryAdjData.Remark),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,50,ParameterDirection.Input,SalaryAdjData.Action)
                                   };
            this.Param = param;
        }
    }
}
