﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class OSDInsertData:DataAccessBase
    {
        public OSDInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_OSD_Add.ToString();
        }
        private OSD _OSDData;

        public OSD OSDData
        {
            get { return _OSDData; }
            set { _OSDData = value; }
        }
        public void InsertOSDData()
        {
            OSDInsertDataParameter osdParam = new OSDInsertDataParameter(OSDData);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = osdParam.Param;
                dbh.Run();
            }
            catch(Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class OSDInsertDataParameter
    {
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public OSDInsertDataParameter(OSD osdData)
        {
            this.OsdData = osdData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            //DataBaseHelper.MakeParam("",SqlDbType.Int,4,ParameterDirection.Input,OsdData.OSDNumber),
                            DataBaseHelper.MakeParam("@Emp_Number",SqlDbType.Int,4,ParameterDirection.Input,OsdData.EmpNumber),
                            DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,4,ParameterDirection.Input,OsdData.FromDate),
                            DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,4,ParameterDirection.Input,OsdData.ToDate),
                            DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,OsdData.EntryBy),
                            DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,4,ParameterDirection.Input,OsdData.EntryDate),
                            DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,OsdData.PC),
                            DataBaseHelper.MakeParam("@Location",SqlDbType.VarChar,100,ParameterDirection.Input,OsdData.Location)
                                   };
            this.Param = param;
        }
    }
}
