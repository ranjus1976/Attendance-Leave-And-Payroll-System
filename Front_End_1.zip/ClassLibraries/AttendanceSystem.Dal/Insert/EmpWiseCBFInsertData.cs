﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class EmpWiseCBFInsertData : DataAccessBase
    {
        public EmpWiseCBFInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_EmpWiseCBF_Add.ToString();
        }
        public EmpWiseCBF empwisecbf{get; set; }
        public void InsertEmpWiseCBF()
        {
            EmpWiseCBFInsertDataParameter empwisecbfParam = new EmpWiseCBFInsertDataParameter(empwisecbf);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = empwisecbfParam.Param;
                dbh.Run();
            }
            catch(Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class EmpWiseCBFInsertDataParameter
    {
        private EmpWiseCBF empwisewbf { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public EmpWiseCBFInsertDataParameter(EmpWiseCBF empwisewbfDataData)
        {
            this.empwisewbf = empwisewbfDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbf.EmpId),
                            DataBaseHelper.MakeParam("@EmpName",SqlDbType.VarChar,50,ParameterDirection.Input,empwisewbf.EmpName),
                            DataBaseHelper.MakeParam("@Gross_Salary",SqlDbType.Float,4,ParameterDirection.Input,(float)empwisewbf.Gross),
                            DataBaseHelper.MakeParam("@Emp_Deposit_Per",SqlDbType.Float,4,ParameterDirection.Input,(float)empwisewbf.EmpPer),
                            DataBaseHelper.MakeParam("@Emp_Deposit_Amt",SqlDbType.Float,4,ParameterDirection.Input,(float)empwisewbf.EmpAmount),
                            DataBaseHelper.MakeParam("@Comp_Deposit_Per",SqlDbType.Float,4,ParameterDirection.Input,(float)empwisewbf.CmpPer),
                            DataBaseHelper.MakeParam("@Comp_Deposit_Amt",SqlDbType.Float,4,ParameterDirection.Input,(float)empwisewbf.CmpAmount),
                            DataBaseHelper.MakeParam("@SlabLog",SqlDbType.Int,4,ParameterDirection.Input,empwisewbf.SlabLog),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbf.Action)
                                   };
            this.Param = param;
        }
    }
}
