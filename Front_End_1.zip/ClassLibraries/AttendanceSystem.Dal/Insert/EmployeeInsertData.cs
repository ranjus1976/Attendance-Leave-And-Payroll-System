using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Insert
{
    public class EmployeeInsertData : DataAccessBase
    {

        public EmployeeInsertData()
        {

            StoredProcedureName = StoredProcedure.Name.sp_Employee_Add.ToString();
        }

        private Employee _Emp;

        public Employee Emp
        {
            get { return _Emp; }
            set { _Emp = value; }
        }

        public void AddEmployee()
        {
            EmployeeInsertDataParameter ee = new EmployeeInsertDataParameter(Emp);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = ee.Param;
                db.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class EmployeeInsertDataParameter
        {
            public EmployeeInsertDataParameter(Employee Emp)
            {
                this._Emp = Emp;
                Build();
            }

            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private Employee _Emp;

            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,_Emp.EmpId),
                    DataBaseHelper.MakeParam("@CardId",SqlDbType.VarChar,20,ParameterDirection.Input,_Emp.CardId),
                    DataBaseHelper.MakeParam("@EmpName",SqlDbType.VarChar,50,ParameterDirection.Input,_Emp.EmpName ),
                    DataBaseHelper.MakeParam("@EmpFName",SqlDbType.VarChar,50,ParameterDirection.Input,_Emp.EmpFName ),
                    DataBaseHelper.MakeParam("@EmpMName",SqlDbType.VarChar,50,ParameterDirection.Input,_Emp.EmpMName),
                    DataBaseHelper.MakeParam("@JDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Emp.JDate),
                    DataBaseHelper.MakeParam("@ConfDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Emp.ConfDate),
                    DataBaseHelper.MakeParam("@BirthDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Emp.BirthDate) ,
                    DataBaseHelper.MakeParam("@PreAddress",SqlDbType.VarChar,200,ParameterDirection.Input,_Emp.PreAddress),
                    DataBaseHelper.MakeParam("@PerAddress",SqlDbType.VarChar,200,ParameterDirection.Input,_Emp.PerAddress),
                    DataBaseHelper.MakeParam("@EmergencyContact",SqlDbType.VarChar,20,ParameterDirection.Input,_Emp.EmergencyContact),
                    DataBaseHelper.MakeParam("@Tel",SqlDbType.VarChar,20,ParameterDirection.Input,_Emp.Tel),
                    DataBaseHelper.MakeParam("@MF",SqlDbType.VarChar,10,ParameterDirection.Input,_Emp.MF),
                    DataBaseHelper.MakeParam("@MarSts",SqlDbType.VarChar,10,ParameterDirection.Input,_Emp.MarSts),
                    DataBaseHelper.MakeParam("@Religion",SqlDbType.VarChar,15,ParameterDirection.Input,_Emp.Religion ),
                    DataBaseHelper.MakeParam("@BloodGroup",SqlDbType.VarChar,10,ParameterDirection.Input,_Emp.BloodGroup),
                    DataBaseHelper.MakeParam("@OT",SqlDbType.VarChar,1,ParameterDirection.Input,_Emp.OT ),
                    DataBaseHelper.MakeParam("@Sect_Number",SqlDbType.Int,4,ParameterDirection.Input,_Emp.Sect_Number),
                    DataBaseHelper.MakeParam("@Shift_Number",SqlDbType.Int,4,ParameterDirection.Input,_Emp.Shift_Number),
                    DataBaseHelper.MakeParam("@Desig_Number",SqlDbType.Int,4,ParameterDirection.Input,_Emp.Desig_Number),
                    DataBaseHelper.MakeParam("@EmpED",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@EmpSts",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@HusWifeName",SqlDbType.VarChar,50,ParameterDirection.Input,_Emp.HusWifeName),
                    //DataBaseHelper.MakeParam("@QuitDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Emp.QuitDate),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@EmpFileName",SqlDbType.VarChar,100,ParameterDirection.Input,_Emp.FileName ),
                    DataBaseHelper.MakeParam("@EmpStatus",SqlDbType.VarChar,50,ParameterDirection.Input,_Emp.EmpStatus)
                    
                };//collection
                    this._param = param;
                }
                catch (Exception ex)
                {
                    ReturningValue.rtnValue = 0;
                    ReturningValue.rtnErrorMessage = ex.Message.ToString();
                }
            }
        }
    }
}
