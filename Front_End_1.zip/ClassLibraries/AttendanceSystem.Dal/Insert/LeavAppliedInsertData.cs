using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient; 



namespace AttendanceSystem.Dal.Insert
{
   public class LeavAppliedInsertData : DataAccessBase 
    {

       public LeavAppliedInsertData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_LeaveApplied_Add.ToString();
       }

       private LeaveApplied _LeavApp;

       public LeaveApplied LeavApp
       {
           get { return _LeavApp; }
           set { _LeavApp = value; }
       }

       public void AddLeavApplied()
       {
           LeaveApplyParameters oleaveApplyParameter = new LeaveApplyParameters(this.LeavApp);

           DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
           try
           {
               oDBhalper.Parameters = oleaveApplyParameter.Param;
               oDBhalper.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (oDBhalper != null)
                   oDBhalper = null;
           }

       }

       public class LeaveApplyParameters
       {

           public LeaveApplyParameters(LeaveApplied oLeaveApplied)
           {
               this._LeavEntryApp = oLeaveApplied;
               Build();
           }

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }

           private LeaveApplied _LeavEntryApp;

           public LeaveApplied LeavEntryApp
           {
               get { return _LeavEntryApp; }
               set { _LeavEntryApp = value; }
           }
           void Build()
           {
               try
               {
                   SqlParameter[] param = {
                                              
                                         DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,_LeavEntryApp.Employee_Number), 
                                         DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,8,ParameterDirection.Input,_LeavEntryApp.From_Date),
                                         DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,8,ParameterDirection.Input,_LeavEntryApp.To_Date),
                                         DataBaseHelper.MakeParam("@Avail",SqlDbType.Float,8,ParameterDirection.Input,_LeavEntryApp.Total_Days),
                                         DataBaseHelper.MakeParam("@Leave_Type_Number",SqlDbType.Int,8,ParameterDirection.Input,_LeavEntryApp.Leave_Type_Number),
                                         DataBaseHelper.MakeParam("@Approval",SqlDbType.Bit,1,ParameterDirection.Input,_LeavEntryApp.Approval),
                                         DataBaseHelper.MakeParam("@ApprovalDescrp",SqlDbType.VarChar,50,ParameterDirection.Input,_LeavEntryApp.ApprovalDes),
                                         DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,50,ParameterDirection.Input,_LeavEntryApp.Remarks),
                                         DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,20,ParameterDirection.Input,_LeavEntryApp.EntryDate),
                                         DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,_LeavEntryApp.PC),
                                         DataBaseHelper.MakeParam("@HFLeave",SqlDbType.VarChar,50,ParameterDirection.Input,_LeavEntryApp.halfleave)
                                         };
                   this._param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }

       }
    }
}
