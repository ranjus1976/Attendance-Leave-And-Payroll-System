﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;

namespace AttendanceSystem.BLL
{
    public class ProcessWeeklyHoliDaySelect1
    {
        public ProcessWeeklyHoliDaySelect1()
        { 
        
        }
        private DataSet _holiDayDS;

        public DataSet HoliDayDS
        {
            get { return _holiDayDS; }
            set { _holiDayDS = value; }
        }
        public void invoke()
        {
            WeeklyHoliDaySelect1 holidaySelect = new WeeklyHoliDaySelect1();
            holidaySelect.SelectAllWHDays();
            this.HoliDayDS = holidaySelect.HoliDayDS;
        }
    }
}
