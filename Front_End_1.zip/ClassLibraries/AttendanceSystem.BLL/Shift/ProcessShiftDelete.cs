﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL
{
    public class ProcessShiftDelete : IProcessLogic
    {
        private Shift _st;
        public Shift Sht
        {
            get { return _st; }
            set { _st = value; }
        }
       public  void invoke()
        {
            ShiftDeleteData ddata = new ShiftDeleteData();
            ddata.Shf = this.Sht;
            ddata.ShiftDelete();
        }

    }
}
