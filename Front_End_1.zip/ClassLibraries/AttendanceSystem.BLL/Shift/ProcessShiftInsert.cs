﻿using System;
using System.Collections.Generic;
using System.Text;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;


namespace AttendanceSystem.BLL
{
    public class ProcessShiftInsert : IProcessLogic
    {
        private Shift  _shft;

        public Shift Shft
        {
            get { return _shft; }
            set { _shft = value; }
        }
        public void invoke()
        {
            ShiftInsertData data = new ShiftInsertData();
            data.Shft = this._shft;
            data.AddShift();
        }

    }              
  
}
