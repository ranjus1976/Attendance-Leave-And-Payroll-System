﻿using System;
using System.Collections.Generic;
using System.Text;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
   public  class ProcessShiftUpdate:IProcessLogic
   {
       private Shift _sh;
       public ProcessShiftUpdate()
       {
 
       }
       public Shift OBShift
       {
           get { return _sh; }
           set { _sh = value; }
       }

       public void invoke()
       {
           ShiftUpdateData udata = new ShiftUpdateData();
           udata.ObShift = this._sh;
           udata.UpdateShift();
       }
   }
}
