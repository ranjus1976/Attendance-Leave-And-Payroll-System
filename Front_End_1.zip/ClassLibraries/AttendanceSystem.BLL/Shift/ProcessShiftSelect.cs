﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;


namespace AttendanceSystem.BLL
{
    public class ProcessShiftSelect:IProcessLogic
    {
        public ProcessShiftSelect() { }
        private DataSet _oshift;
        public DataSet ObShift
        {
            get { return _oshift; }
            set { _oshift = value; }
        }
        public void invoke()
        {
            ShiftSelectData data = new ShiftSelectData();
            this.ObShift=data.SelectShift();
            
        }



      
    }
}
