﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;
  
namespace AttendanceSystem.BLL
{
   public  class ProcessEmployeeUpdate: IProcessLogic
   {
       private Employee _empUp;
       public ProcessEmployeeUpdate()
       { }
       public Employee EmpUp
       {
           get { return _empUp; }
           set { _empUp = value; }
       }
       public void invoke()
       {
           EmployeeUpdateData empdata = new EmployeeUpdateData();
           empdata.Emp = this._empUp;
           empdata.UpdateEmployee();
           
       }
   }
}
