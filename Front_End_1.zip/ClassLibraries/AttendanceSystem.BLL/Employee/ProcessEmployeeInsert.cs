﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
   
namespace AttendanceSystem.BLL
{
  public  class ProcessEmployeeInsert:IProcessLogic 
    {
        private Employee _Emp;

        public Employee Emp
        {
            get { return _Emp; }
            set { _Emp = value; }
        }

        public void invoke()
        {
            EmployeeInsertData edata = new EmployeeInsertData();
            edata.Emp = this._Emp;
            edata.AddEmployee();
        }
    }
}
