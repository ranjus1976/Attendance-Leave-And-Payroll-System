﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
  
namespace AttendanceSystem.BLL
{
   public class ProcessEmployeeSelect :IProcessLogic 
    {
       public ProcessEmployeeSelect()
       { 
       }
       private DataSet _EmployeeDS;

       public DataSet EmployeeDS
       {
           get { return _EmployeeDS; }
           set { _EmployeeDS = value; }
       }

       public void invoke()
       {
           EmployeeSelect Emp = new EmployeeSelect();
           this._EmployeeDS = Emp.SelectEmployee();
       }
    }
}
