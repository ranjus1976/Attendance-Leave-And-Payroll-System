﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;
   
namespace AttendanceSystem.BLL
{
   public class ProcessEmployeeDelete :IProcessLogic 
    {
       public ProcessEmployeeDelete()
      { 
      }

       private Employee _Emp;

       public Employee Emp
       {
           get { return _Emp; }
           set { _Emp = value; }
       }

       public void invoke()
       {
           EmployeeDeleteData EmpD = new EmployeeDeleteData();
           EmpD.Emp = this.Emp;
           EmpD.DeleteEmployee();
       }
    }
}
