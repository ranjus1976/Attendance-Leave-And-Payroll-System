﻿using System;
using System.Collections.Generic;
using System.Text;
 using System.Data;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessEmpSelect:IProcessLogic
    {

        private  DataSet _emp;

        public DataSet Emp
        {
            get { return _emp; }
            set { _emp = value; }
        }
        public void invoke()
        {
            EmployeeSelectData esd = new EmployeeSelectData();
            this.Emp = esd.EmpoyeeList();
          
        }


    }
}
