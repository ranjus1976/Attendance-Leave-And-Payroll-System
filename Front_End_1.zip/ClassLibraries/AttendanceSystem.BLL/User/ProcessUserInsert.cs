﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;


namespace AttendanceSystem.BLL
{
    public  class ProcessUserInsert:IProcessLogic
    {

        private User _user;
        public User PUser
        {
            get { return _user; }
            set { _user = value; }
        }
        public void invoke()
        {
            UserInsertData uid = new UserInsertData();
            uid.Obuser = this.PUser;
            uid.AddUser();
            
        }

       
    }
}
