﻿using System;
using System.Collections.Generic;
using System.Text;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessEmployeeLeaveApply : IProcessLogic
    {
        private LeaveApplied _LeaveApplly;

        public LeaveApplied LeaveApplly
        {
            get { return _LeaveApplly; }
            set { _LeaveApplly = value; }
        }

        public ProcessEmployeeLeaveApply()
        {
        }

        public void invoke()
        {
            LeavAppliedInsertData oLeaveAppliedInsertData = new LeavAppliedInsertData();
            oLeaveAppliedInsertData.LeavApp = this._LeaveApplly;
            oLeaveAppliedInsertData.AddLeavApplied();
        }
    }


}
