﻿using System;
using System.Collections.Generic;
using System.Text;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
  public  class ProcessEmployeeLeaveBalance : IProcessLogic
    {

        private LeaveBalance _Balance;

        public LeaveBalance Balance
        {
            get { return _Balance; }
            set { _Balance = value; }
        }

      public ProcessEmployeeLeaveBalance()
      {
      }

      public void invoke()
      {
          LeaveBalanceInsertData oBalanceData = new LeaveBalanceInsertData();
          oBalanceData.LeaveProcess = this._Balance;
          oBalanceData.AddLeaveBalance();

          //EmployeeInsertData edata = new EmployeeInsertData();
          //edata.Emp = this._Emp;
          //edata.AddEmployee();


      }

    }
}
