﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.BLL
{
   public class ProcessEmployeeLeaveStatusRead
    {

       public ProcessEmployeeLeaveStatusRead()
       {
       }

       private DataSet _LeaveBalanceDS;

       public DataSet LeaveBalanceDS
       {
           get { return _LeaveBalanceDS; }
           set { _LeaveBalanceDS = value; }
       }

       private LeaveBalance _LeaveBalance;
       
       public LeaveBalance LeaveBalance
       {
           get { return _LeaveBalance; }
           set { _LeaveBalance = value; }
       }
       

       public void invoke()
       {
           LeaveStatusRead oRead = new LeaveStatusRead();
           oRead.LeaveBalance = this.LeaveBalance;
           this.LeaveBalanceDS = oRead.GetBalanceStatus();
      
        


       }
    }
}
