﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
namespace AttendanceSystem.BLL
{
    public class ProcessEmployeeLeave : IProcessLogic
    {

        private Employee _Emp;

        public Employee Emp
        {
            get { return _Emp; }
            set { _Emp = value; }
        }

        public ProcessEmployeeLeave()
        {
        }

        public void invoke()
        {
        }

    }


}
