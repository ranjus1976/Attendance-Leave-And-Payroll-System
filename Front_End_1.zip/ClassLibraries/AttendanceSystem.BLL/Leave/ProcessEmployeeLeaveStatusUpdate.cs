﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
   public class ProcessEmployeeLeaveStatusUpdate
    {

       public ProcessEmployeeLeaveStatusUpdate()
       {
       }


       private LeaveBalance _LeaveBalance;

       public LeaveBalance LeaveBalance
       {
           get { return _LeaveBalance; }
           set { _LeaveBalance = value; }
       }

       public void invoke()
       {

           LeaveEmployeeLeaveStatusData oLeaveUpdate = new LeaveEmployeeLeaveStatusData();
           oLeaveUpdate.Leave_Balance = this.LeaveBalance;
           oLeaveUpdate.UpdateLeaveBalanceFromStatus();

       }


    }
}
