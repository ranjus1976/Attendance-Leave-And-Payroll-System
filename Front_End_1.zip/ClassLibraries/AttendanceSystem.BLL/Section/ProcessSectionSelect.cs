using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;  

namespace AttendanceSystem.BLL
{
   public class ProcessSectionSelect :IProcessLogic 
    {
       public ProcessSectionSelect()
       { 
       
       }
       private DataSet _SectionDS;

       public DataSet SectionDS
       {
           get { return _SectionDS; }
           set { _SectionDS = value; }
       }

       public void invoke()
       {
           SectionSelect Sect = new SectionSelect();
           this._SectionDS = Sect.SelectSection();
       }
    }
}
