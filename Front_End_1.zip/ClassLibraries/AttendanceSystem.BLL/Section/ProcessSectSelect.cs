﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessSectSelect:IProcessLogic
    {
        private DataSet _sect;
        public DataSet Sect
        {
            get { return _sect; }
            set { _sect = value; }
        }
        public void invoke()
        {
            SectionSelectData ssd = new SectionSelectData();
            this.Sect= ssd.SectionList();
        }

    }
}
