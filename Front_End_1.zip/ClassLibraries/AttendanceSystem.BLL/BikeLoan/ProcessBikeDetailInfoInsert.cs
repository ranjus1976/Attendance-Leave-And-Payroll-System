﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeDetailInfoInsert : IProcessLogic
    {
        public BikeDetailInfo bikeDetailInfoIntrate { get; set; }
        public void invoke()
        {
            BikeDetailInfoInsertData BikeDetailInfoData = new BikeDetailInfoInsertData();
            BikeDetailInfoData.BikeDetailInfodata = this.bikeDetailInfoIntrate;
            BikeDetailInfoData.InsertBikeDetailInfo();
        }
    }
}
