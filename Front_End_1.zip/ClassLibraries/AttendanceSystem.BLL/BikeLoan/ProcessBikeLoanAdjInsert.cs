﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeLoanAdjInsert : IProcessLogic
    {
        public BikeLoanAdj BikeLoanAdjIntrate { get; set; }
        public void invoke()
        {
            BikeLoanAdjInsertData BikeLoanAdjData = new BikeLoanAdjInsertData();
            BikeLoanAdjData.BikeLoanAdjdata = this.BikeLoanAdjIntrate;
            BikeLoanAdjData.InsertBikeLoanAdj();
        }
    }
}
