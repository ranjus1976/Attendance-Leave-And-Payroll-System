﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessFunctionDataInsert : IProcessLogic
    {
        public ProcessFunctionDataInsert()
        {  
        }

        private AttendanceSystem.Core.Function _Function;

        public AttendanceSystem.Core.Function Function
        {
            get { return _Function; }
            set { _Function = value; }
        }
        public void invoke()
        {
            FunctionInsert obj_FunctionInsert = new FunctionInsert();
            obj_FunctionInsert.Function = this._Function;
            obj_FunctionInsert.AddFunction();

        }
    }
}
