﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    class ProcessFunctionDataUpdate : IProcessLogic
    {
        public ProcessFunctionDataUpdate()
        {
        }
        private Function _Function;

        public Function Function
        {
            get { return _Function; }
            set { _Function = value; }
        }
        public void invoke()
        {
            FunctionUpdate obj_FunctionUpdate = new FunctionUpdate();
            obj_FunctionUpdate.Function = this._Function;
            obj_FunctionUpdate.UpdateFunction();
        }
    }
}
