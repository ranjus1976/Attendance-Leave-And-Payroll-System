﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
namespace AttendanceSystem.BLL.EmployeeLoan
{
    public class ProcessEmpLoanAdjInsert : IProcessLogic
    {
        public EmployeeLoanAdjEntry EmployeeLoanAdjEntryIN { get; set; }

        public void invoke()
        {
            EmployeeLoanAdjEntryInsertData edata = new EmployeeLoanAdjEntryInsertData();
            edata.EmployeeLoanAdjEntrydata = this.EmployeeLoanAdjEntryIN;
            edata.InsertEmployeeLoanAdjEntry();
        }
    }
}
