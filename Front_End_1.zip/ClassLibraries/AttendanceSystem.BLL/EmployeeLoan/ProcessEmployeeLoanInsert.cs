﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
namespace AttendanceSystem.BLL.EmployeeLoan
{
    public class ProcessEmployeeLoanInsert : IProcessLogic 
    {
        public EmployeeLoanSetup EmployeeLoanSetupIN { get; set; }

        public void invoke()
        {
            EmployeeLoanInsertData edata = new EmployeeLoanInsertData();
            edata.EmployeeLoanSetupInsert = this.EmployeeLoanSetupIN;
            edata.AddEmployeeLoanSetup();
        }
    }
}
