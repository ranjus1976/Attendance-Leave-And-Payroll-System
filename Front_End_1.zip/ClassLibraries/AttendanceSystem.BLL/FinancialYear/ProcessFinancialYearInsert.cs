﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessFinancialYearInsert : IProcessLogic
    {
        private Company _Comp;

        public Company Comp
        {
            get { return _Comp; }
            set { _Comp = value; }
        }

        public void invoke()
        {
            CompanyInsertData data = new CompanyInsertData();
            data.Comp = this._Comp;
            data.AddCompany();

        }
    }
}
