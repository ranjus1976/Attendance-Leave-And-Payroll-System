﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
   public class ProcessDocumentoryDelete:IProcessLogic
    {

      public ProcessDocumentoryDelete()
      { 
      
      }

      private Documentory _Doc;

      public Documentory Doc
      {
          get { return _Doc; }
          set { _Doc = value; }
      }

       public void invoke()
       {
           DocumentoryDeleteData DocD = new DocumentoryDeleteData();
           DocD.Doc = this.Doc;
           DocD.DeleteDocumentory();
       }
    }
}
