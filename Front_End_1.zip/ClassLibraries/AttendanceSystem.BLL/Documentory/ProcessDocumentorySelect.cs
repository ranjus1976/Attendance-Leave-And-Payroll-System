﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
   public class ProcessDocumentorySelect:IProcessLogic
    {
       public ProcessDocumentorySelect()
       { 
       
       }
       private Documentory _Doc;

       public Documentory Doc
       {
           get { return _Doc; }
           set { _Doc = value; }
       }

       private DataSet _DocumentoryDS;

       public DataSet DocumentoryDS
       {
           get { return _DocumentoryDS; }
           set { _DocumentoryDS = value; }
       }

       public void invoke()
       {
           //EmployeeSelect Emp = new EmployeeSelect();
           //this._EmployeeDS = Emp.SelectEmployee();
           DocumentorySelect Ds = new DocumentorySelect();
           Ds.Doc = this.Doc;
           this._DocumentoryDS = Ds.SelectDocumentory();
          
       }
   
    }
}
