﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Web.UI.WebControls;
using AttendanceSystem.Core;
using AttendanceSystem.Dal;
using System.Data.SqlClient;

namespace AttendanceSystem.BLL
{
    public class ClsCommon
    {
        public static void drplistAdd(DropDownList ddl, string strQuery, string displayField, string valueField)
        {
            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);
            ddl.DataTextField = displayField.Trim();
            ddl.DataValueField = valueField.Trim();
            ddl.DataSource = ds;
            ddl.DataBind();
        }
        public static void drplistAddNew(DropDownList ddl, string strQuery, string displayField, string valueField)
        {

            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                ListItem oItem = new ListItem();
                oItem.Text = dr["EmpId"].ToString().Trim();
                oItem.Value = dr["Emp_Number"].ToString();
                ddl.Items.Add(oItem);

                //ddl.DataTextField = displayField ;
                // ddl.DataValueField = valueField;
                // ddl.DataSource = ds;
                // ddl.DataBind();
            }
        }
        public static void drplistAdd(DropDownList ddl, string strQuery, string displayField, string valueField1, string valueField2)
        {
            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);

            if (ds.Tables.Count > 0)
            {
                DataTable dt = (DataTable)ds.Tables[0];
                foreach (DataRow dr in dt.Rows)
                {
                    ListItem oItem = new ListItem(dr[displayField].ToString().Trim(), dr[valueField1].ToString().Trim() + "," + dr[valueField2].ToString().Trim());
                    ddl.Items.Add(oItem);
                }
            }
        }
        public static void drplistAdd1(DropDownList ddl, string strQuery, string displayField, string valueField)
        {

            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);



            if (ds.Tables.Count > 0)
            {
                DataTable dt = (DataTable)ds.Tables[0];
                foreach (DataRow dr in dt.Rows)
                {
                    ListItem oItem = new ListItem(dr[displayField].ToString().Trim(), dr["Comp_Number"].ToString().Trim() + "," + dr["CompId"].ToString().Trim());
                    ddl.Items.Add(oItem);
                }
            }

        }
        public static bool ItemCheck(string strQuery)
        {
            DataTable dt = new DataTable();
            DataBaseHelper db = new DataBaseHelper();
            dt = db.getTable(false, strQuery);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static DataSet GetAdhocResult(string strQuery)
        {
            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);
            return ds;
        }
        public static void drplistAddWithObject(DropDownList ddl, string strQuery, string displayField, string valueField)
        {

            DataSet ds = new DataSet();
            DataBaseHelper db = new DataBaseHelper();
            ds = db.Run(CommandType.Text, strQuery);
            if (ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];

                List<Employee> oEmpList = new List<Employee>();
                ListItemCollection oListCollection = new ListItemCollection();
               
                foreach (DataRow dr in dt.Rows)
                {
                    ListItem oItem = new ListItem();
                    oItem.Text = dr["EmpId"].ToString().Trim();
                    oItem.Value = dr["Emp_Number"].ToString() + "," + dr["EmpName"].ToString();
                    ddl.Items.Add(oItem);
                }
            }
        }
        public static int ExecuteAdhocQuery(string strQuery)
        {
            DataBaseHelper db = new DataBaseHelper();
            return db.ExecuteNonQuery(strQuery, CommandType.Text);

        }
        public static SqlDataReader ExecuteReaderString(string strQuery)
        {
            DataBaseHelper db = new DataBaseHelper();
            return db.ExecuteReader(strQuery,"text");
        }
    }
}
