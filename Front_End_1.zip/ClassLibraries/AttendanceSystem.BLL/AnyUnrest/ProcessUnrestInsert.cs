using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert; 

namespace AttendanceSystem.BLL
{
    public class ProcessUnrestInsert : IProcessLogic
    {
        private Shift _Shift;

        public Shift Shift
        {
            get { return _Shift; }
            set { _Shift = value; }
        }
       
        public void invoke()
        {
            AnyunrestConditionInsertData data = new AnyunrestConditionInsertData();
            data.Shft = this._Shift;
            data.AddUnrestShift();
            
        }

    }
}
