﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL.CBF
{
    public class ProcessEmpWiseCBFDelete : IProcessLogic 
    {
        public ProcessEmpWiseCBFDelete()
      {

      }

        public EmpWiseCBF EMPCBFD { get; set; }
      public void invoke()
      {

          EmpWiseCBFDeleteData EmpCbfD = new EmpWiseCBFDeleteData();
          EmpCbfD.EmpCbf = this.EMPCBFD;
          EmpCbfD.DeleteEmpCbf();

         
      }
    }
}
