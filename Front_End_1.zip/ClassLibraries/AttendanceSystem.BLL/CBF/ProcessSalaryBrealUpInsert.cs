﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessSalaryBreakUpInsert : IProcessLogic
    {
        public SalaryBreakup salarybreakup { get; set; }

        public void invoke()
        {
            SalaryBreakUpInsert SalBrInstData = new SalaryBreakUpInsert();
            SalBrInstData.salbreak = this.salarybreakup;
            SalBrInstData.AddAddSalaryBreak();
        }

    }
}
