﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;


namespace AttendanceSystem.BLL.Salary
{
    public class ProcessSalaryAdjInsert : IProcessLogic
    {
        public SalaryAdj SalaryAdjIntrate { get; set; }
        public void invoke()
        {
            SalaryAdjInsertData SalaryAdjIntrateData = new SalaryAdjInsertData();
            SalaryAdjIntrateData.SalaryAdjIntrate = this.SalaryAdjIntrate;
            SalaryAdjIntrateData.SalaryAdjdata();
        }
    }
}
