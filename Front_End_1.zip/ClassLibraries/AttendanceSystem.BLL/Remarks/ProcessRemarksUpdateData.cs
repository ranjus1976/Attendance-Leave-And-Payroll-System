﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Update;
using AttendanceSystem.Core;


namespace AttendanceSystem.BLL
{
    public class ProcessRemarksUpdateData : IProcessLogic
    {
        private AttendanceSystem.Core.Remarks _Remarks;

        public AttendanceSystem.Core.Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        public void invoke()
        {
            RemarksUpdateData data = new RemarksUpdateData();
            data.Remarks = this._Remarks;
            data.UpdateRemarksData();
        }
    }
}
