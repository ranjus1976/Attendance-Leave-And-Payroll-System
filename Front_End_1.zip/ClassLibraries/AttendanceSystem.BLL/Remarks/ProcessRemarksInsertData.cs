﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Core;


namespace AttendanceSystem.BLL
{
    public class ProcessRemarksInsertData : IProcessLogic
    {
        private AttendanceSystem.Core.Remarks _Remarks;

        public AttendanceSystem.Core.Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        public void invoke()
        {
            RemarksInsertData data = new RemarksInsertData();
            data.Remarks = this._Remarks;
            data.InsertRemarksData();
        }

    }
}
