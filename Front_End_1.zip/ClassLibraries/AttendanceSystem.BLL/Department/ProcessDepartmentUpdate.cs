using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessDepartmentUpdate : IProcessLogic 
    {
        private Department _Dept;

        public Department Dept
        {
            get { return _Dept; }
            set { _Dept = value; }
        }
       
       public void invoke()
       
       {
           DepartmentUpdateData dupdate = new DepartmentUpdateData();
           dupdate.Dept = this._Dept;
           dupdate.UpdateDepartment(); 
       }
    }
}
