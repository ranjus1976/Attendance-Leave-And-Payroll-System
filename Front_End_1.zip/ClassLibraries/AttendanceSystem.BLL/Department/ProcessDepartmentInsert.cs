using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Core;


namespace AttendanceSystem.BLL
{
    public class ProcessDepartmentInsert : IProcessLogic
    {
        private Department _Dept;

        public Department Dept
        {
            get { return _Dept; }
            set { _Dept = value; }
        }




        public void invoke()
        {
            DepartmentInsertData data = new DepartmentInsertData();
            data.Dept = this._Dept;
            data.AddDepartment();
        }

    }

}
