using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;
   
namespace AttendanceSystem.BLL
{
   public class ProcessDepartmentSelect : IProcessLogic 
    {
       public ProcessDepartmentSelect()
       { 

       }


       private DataSet _DepartmentDS;

       public DataSet DepartmentDS
       {
           get { return _DepartmentDS; }
           set { _DepartmentDS = value; }
       }


       public void invoke()
       {
           DepartmentSelect Dept = new DepartmentSelect();
           this._DepartmentDS = Dept.SelectDepartment();
       }

    }

   
}
