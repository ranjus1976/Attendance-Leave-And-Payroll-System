﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessGovtHoliDayDelete:IProcessLogic
    {
        private GovtHoliday _gHoliday;

        public GovtHoliday GHoliday
        {
            get { return _gHoliday; }
            set { _gHoliday = value; }
        }
        
        public void invoke()
        {
            GovtHoliDayDeleteData delData = new GovtHoliDayDeleteData();
            delData.Gdata = this.GHoliday;
            delData.DeleteGovtHoliDay();
        }
    }
}
