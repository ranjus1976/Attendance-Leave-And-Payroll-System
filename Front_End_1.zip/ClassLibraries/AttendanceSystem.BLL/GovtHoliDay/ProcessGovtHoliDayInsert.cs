﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessGovtHoliDayInsert:IProcessLogic
    {
        public ProcessGovtHoliDayInsert()
        { 
        
        }
        private GovtHoliday _gHoliDay;

        public GovtHoliday GHoliDay
        {
            get { return _gHoliDay; }
            set { _gHoliDay = value; }
        }
        public void invoke()
        {
            GovtHoliDayInsertData govtHDInsertData = new GovtHoliDayInsertData();
            govtHDInsertData.GHoliDay = this.GHoliDay;
            govtHDInsertData.InsertGovtHoliDayData();
        }
    }
}
