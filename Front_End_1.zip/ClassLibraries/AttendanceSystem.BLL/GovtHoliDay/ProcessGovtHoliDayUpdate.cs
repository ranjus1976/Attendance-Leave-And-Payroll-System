﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessGovtHoliDayUpdate:IProcessLogic
    {
        public ProcessGovtHoliDayUpdate()
        { 
        
        }
        private GovtHoliday _holiday;

        public GovtHoliday Holiday
        {
            get { return _holiday; }
            set { _holiday = value; }
        }
        public void invoke()
        {
            GovtHoliDayUpdateData update = new GovtHoliDayUpdateData();
            update.GHoliday = this.Holiday;
            update.UpdateGovtHoliday();
        }
    }
}
