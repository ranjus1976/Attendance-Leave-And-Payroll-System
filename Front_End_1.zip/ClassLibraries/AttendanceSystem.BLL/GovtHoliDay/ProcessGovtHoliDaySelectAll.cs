﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;

namespace AttendanceSystem.BLL
{
    public class ProcessGovtHoliDaySelectAll:IProcessLogic
    {
        public ProcessGovtHoliDaySelectAll()
        { 
        
        }
        private GovtHoliday _gHoliDay;

        public GovtHoliday GHoliDay
        {
            get { return _gHoliDay; }
            set { _gHoliDay = value; }
        }
        private DataSet _govtHoliDayDS;

        public DataSet GovtHoliDayDS
        {
            get { return _govtHoliDayDS; }
            set { _govtHoliDayDS = value; }
        }
        public void invoke()
        {
            GovtHoliDaySelect holiDaySelect = new GovtHoliDaySelect();
            
            holiDaySelect.SelectGovtHoliDayAll();
            this.GovtHoliDayDS = holiDaySelect.GovtDS;
        }
    }
}
