using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public  class ProcessDesignationUpdate:IProcessLogic
    {
        public ProcessDesignationUpdate()
        { 
        
        }

        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public void invoke()
        {
            DesignationUpdateData dupd = new DesignationUpdateData();
            dupd.Desig = this.Desig;
            dupd.UpdateDesignation();
    
        }
    }
}
