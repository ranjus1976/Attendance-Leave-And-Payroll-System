using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessDesignationInsert: IProcessLogic
    {
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public void invoke()
        {
            DesignationInsertData desigInstData = new DesignationInsertData();
            desigInstData.Desig = this.Desig;
            desigInstData.AddDesignation();
        }
    }
}
