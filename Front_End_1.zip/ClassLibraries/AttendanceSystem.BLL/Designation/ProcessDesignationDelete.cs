using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessDesignationDelete:IProcessLogic
    {
        public ProcessDesignationDelete()
        { 
        
        }

        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public void invoke()
        {
           
            DesignationDeleteData delData = new DesignationDeleteData();
            delData.Desig = this.Desig;
            delData.DeleteDesignation();
        }
    }
}
