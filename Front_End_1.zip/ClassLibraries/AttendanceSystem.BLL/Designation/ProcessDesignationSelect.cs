using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;
namespace AttendanceSystem.BLL
{
    public class ProcessDesignationSelect: IProcessLogic
    {
        public ProcessDesignationSelect()
        { 
            
        }
        private DataSet _desigDS;

        public DataSet DesigDS
        {
            get { return _desigDS; }
            set { _desigDS = value; }
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }

        public void invoke()
        {
            DesignationSelect desigSelect = new DesignationSelect();
            desigSelect.Desig = this.Desig;
            DesigDS = desigSelect.SelectAllDesignation();
            
        }
    }
}
