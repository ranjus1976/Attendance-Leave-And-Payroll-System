﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessLeaveTypeSelect : IProcessLogic
    {
        public ProcessLeaveTypeSelect()
        {
        }

        private DataSet _LeaveTypeDS;

        public DataSet LeaveTypeDS
        {
            get { return _LeaveTypeDS; }
            set { _LeaveTypeDS = value; }
        }

        public void invoke()
        {
            LeaveTypeSelectData objLeaveTypeSelectData = new LeaveTypeSelectData();
            this._LeaveTypeDS = objLeaveTypeSelectData.SelectLeaveType();
        }
    }
}
