﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessLeaveTypeUpdate : IProcessLogic
    {
        private AttendanceSystem.Core.LeaveType _LeaveType;
        public AttendanceSystem.Core.LeaveType LeaveType
        {
            get { return _LeaveType; }
            set { _LeaveType = value; }
        }
        public void invoke()
        {
            LeaveTypeUpdate objLeaveTypeUpdate = new LeaveTypeUpdate();
            objLeaveTypeUpdate .ObjLeaveType= this._LeaveType;
            objLeaveTypeUpdate.UpdateLeaveType();
        }
    }
}
