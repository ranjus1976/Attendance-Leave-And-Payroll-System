﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Delete;
using AttendanceSystem.Core;

namespace AttendanceSystem.BLL
{
    public class ProcessLeaveTypeDelete : IProcessLogic
    {
        public ProcessLeaveTypeDelete()
        {
        }
        private AttendanceSystem.Core.LeaveType _LeaveType;
        public AttendanceSystem.Core.LeaveType LeaveType
        {
            get { return _LeaveType; }
            set { _LeaveType = value; }
        }

        public void invoke()
        {
            DeleteLeaveTypeData objDeleteLeaveTypeData = new DeleteLeaveTypeData();
            objDeleteLeaveTypeData.LeaveType = this._LeaveType;
            objDeleteLeaveTypeData.DeleteLeaveType();
        }
    }
}
