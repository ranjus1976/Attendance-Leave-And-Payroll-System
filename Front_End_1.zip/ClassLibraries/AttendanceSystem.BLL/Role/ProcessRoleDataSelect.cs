﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessRoleDataSelect : IProcessLogic
    {
        public ProcessRoleDataSelect()
        {
        }
        private DataSet _RoleDS;

        public DataSet RoleDS
        {
            get { return _RoleDS; }
            set { _RoleDS = value; }
        }

        public void invoke()
        {
            RoleSelect obj_RoleSelect = new RoleSelect();
            this._RoleDS = obj_RoleSelect.SelectRole();
        }
    }
}
