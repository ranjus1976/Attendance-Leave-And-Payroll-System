﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessRoleDataUpdate : IProcessLogic
    {
        private Role _Role;

        public Role Role
        {
            get { return _Role; }
            set { _Role = value; }
        }
        public void invoke()
        {
            RoleUpdate obj_RoleUpdate = new RoleUpdate();
            obj_RoleUpdate.Role = this._Role;
            obj_RoleUpdate.UpdateRole();
        }
    }
}
