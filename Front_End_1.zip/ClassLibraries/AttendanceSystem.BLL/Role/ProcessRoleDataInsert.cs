﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert; 

namespace AttendanceSystem.BLL
{
    public class ProcessRoleDataInsert : IProcessLogic
    {
        private AttendanceSystem.Core.Role _Role;

        public AttendanceSystem.Core.Role Role
        {
            get { return _Role; }
            set { _Role = value; }
        }
        public void invoke()
        {
            RoleInsert obj_RoleInsert = new RoleInsert();
            obj_RoleInsert.Role = this._Role;
            obj_RoleInsert.AddRole();

        }
    }
}
