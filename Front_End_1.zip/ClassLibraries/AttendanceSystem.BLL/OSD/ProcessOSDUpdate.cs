﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessOSDUpdate:IProcessLogic
    {
        public ProcessOSDUpdate()
        { 
        
        }
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        public void invoke()
        {
            OSDUpdateData osdUpdateProcess = new OSDUpdateData();
            osdUpdateProcess.OsdData = this.OsdData;
            osdUpdateProcess.UpdateOSDData();
        }
    }
}
