﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessOSDInsert:IProcessLogic
    {
        public ProcessOSDInsert()
        { 
        
        }
        private OSD _OSDBLL;

        public OSD OSDBLL
        {
            get { return _OSDBLL; }
            set { _OSDBLL = value; }
        }

        
        public void invoke()
        {
            OSDInsertData osdInsert = new OSDInsertData();
            osdInsert.OSDData = this.OSDBLL;
            osdInsert.InsertOSDData();

         
        }
    }
}
