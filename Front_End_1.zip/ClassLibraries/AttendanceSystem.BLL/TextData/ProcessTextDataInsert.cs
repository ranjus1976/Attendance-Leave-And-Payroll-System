﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
   public  class ProcessTextDataInsert:IProcessLogic 
    {
        private TextDataCollect _DataCollect;

        public TextDataCollect DataCollect
        {
            get { return _DataCollect; }
            set { _DataCollect = value; }
        }

        public void invoke()
        {
            TextDataInsert tdata = new TextDataInsert();
            tdata.Text = this._DataCollect;
            tdata.AddTextData();
        
        }
    }
}
