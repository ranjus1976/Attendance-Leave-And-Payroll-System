﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
   public class UserPermission
    {
        private Int32 _User_Number;

        public Int32 User_Number
        {
            get { return _User_Number; }
            set { _User_Number = value; }
        }
        private Int32 _Function_Number;

        public Int32 Function_Number
        {
            get { return _Function_Number; }
            set { _Function_Number = value; }
        }
        private String _Function_Description;

        public String Function_Description
        {
            get { return _Function_Description; }
            set { _Function_Description = value; }
        }
        private Int32 _Entry_By;

        public Int32 Entry_By
        {
            get { return _Entry_By; }
            set { _Entry_By = value; }
        }
        private DateTime _Entry_Date;

        public DateTime Entry_Date
        {
            get { return _Entry_Date; }
            set { _Entry_Date = value; }
        }
        private String _PC;

        public String PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
    }
}
