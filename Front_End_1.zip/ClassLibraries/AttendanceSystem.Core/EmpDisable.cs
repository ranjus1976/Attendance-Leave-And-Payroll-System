﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
  public class EmpDisable
    {
      public EmpDisable()
      { 
      }

      private string _EmpId;

      public string EmpId
      {
          get { return _EmpId; }
          set { _EmpId = value; }
      }
    }
}
