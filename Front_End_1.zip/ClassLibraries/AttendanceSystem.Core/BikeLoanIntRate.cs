﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class BikeLoanIntRate
    {
        public string CompId { get; set; }
        public int Duration { get; set; }
        public int IntRate { get; set; }
        public string LoanType { get; set; }
        public string Action { get; set; }
    }
}
