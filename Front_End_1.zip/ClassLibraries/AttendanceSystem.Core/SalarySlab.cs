﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class SalarySlab
    {
        public SalarySlab()
        {
        }

        public string SalarySlabID { get; set; }
        public int StartingRange { get; set; }
        public int ClosingRange { get; set; }
        public int EmpDipositAmt { get; set; }
        public float CompPerticipationRatio { get; set; }
        public int CompPayableAmount { get; set; }
        public string Action{ get; set; }
    }
}
