﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class SalaryBreakup
    {
        public SalaryBreakup(){}
        public string EmpId { get; set; }
        public string ConfDate { get; set; }
        public int Basic { get; set; }
        public int HouseRent { get; set; }
        public int MedicalAllow { get; set; }
        public int Gross { get; set; }
        public int CBF { get; set; }
        public int MobileCeling { get; set; }
        public string Actiction { get; set; }
    }
}
