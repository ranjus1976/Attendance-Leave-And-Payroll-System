﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class SalaryProcess
    {
   
        public int Critaria { get; set; }
        public string Company { get; set; }
        public string DeptId { get; set; }
        public string EmployeeId { get; set; }
        public string MonthName { get; set; }
        public string MontnNumber { get; set; }
        public string YearName { get; set; }
        public int Rate { get; set; }
        public string User { get; set; }
        public string Bname { get; set; }
    }
}
