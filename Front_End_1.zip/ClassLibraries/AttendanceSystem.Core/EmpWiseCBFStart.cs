﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class EmpWiseCBFStart
    {
        public string EmpId { get; set; }
        public string EmpName { get; set; }
        public string MonthName { get; set; }
        public string YearName { get; set; }
        public int CbfLog { get; set; }
        public string Action { get; set; }
    }
}
