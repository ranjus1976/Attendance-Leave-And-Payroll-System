﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class FinancialYear
    {
        public FinancialYear()
        {

        }

        private int _FinancialYearNumber;

        public int FinancialYearNumber
        {
            get { return _FinancialYearNumber; }
            set { _FinancialYearNumber = value; }
        }
        private string _FinancialYearName = "";

        public string FinancialYearName
        {
            get { return _FinancialYearName; }
            set { _FinancialYearName = value; }
        }
        private DateTime _StartDate;

        public DateTime StartDate
        {
            get { return _StartDate; }
            set { _StartDate = value; }
        }
        private DateTime _EndDate;

        public DateTime EndDate
        {
            get { return _EndDate; }
            set { _EndDate = value; }
        }
        private bool _RunningFlag;

        public bool RunningFlag
        {
            get { return _RunningFlag; }
            set { _RunningFlag = value; }
        }

    }
}
