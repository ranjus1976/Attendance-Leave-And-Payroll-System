﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class FinantialYear
    {
        public FinantialYear()
        {

        }

        public int FinYearId { get; set; }
        public string FinYear { get; set; }
        public DateTime OpeningDate { get; set; }
        public DateTime ClosingDate { get; set; }
        public bool ActiveBit { get; set; }
        public string Action { get; set; }
       
    }
}
