using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Employee
    {
        public Employee()
        {

        }
        
    private string _EmpId;

    public string EmpId
    {
        get { return _EmpId; }
        set { _EmpId = value; }
    }

    private string _CardId;

    public string CardId
    {
        get { return _CardId; }
        set { _CardId = value; }
    }
    private string _EmpName;

    public string EmpName
    {
        get { return _EmpName; }
        set { _EmpName = value; }
    }
              

        private string _EmpFName;

        public string EmpFName
        {
            get { return _EmpFName; }
            set { _EmpFName = value; }
        }

        private string _EmpMName;

        public string EmpMName
        {
            get { return _EmpMName; }
            set { _EmpMName = value; }
        }

        private DateTime _JDate;

        public DateTime JDate
        {
            get { return _JDate; }
            set { _JDate = value; }
        }

        private DateTime _ConfDate;

        public DateTime ConfDate
        {
            get { return _ConfDate; }
            set { _ConfDate = value; }
        }
        private DateTime _BirthDate;

        public DateTime BirthDate
        {
            get { return _BirthDate; }
            set { _BirthDate = value; }
        }

        private string _PreAddress;

        public string PreAddress
        {
            get { return _PreAddress; }
            set { _PreAddress = value; }
        }

        private string _PerAddress;

        public string PerAddress
        {
            get { return _PerAddress; }
            set { _PerAddress = value; }
        }
        private string _Tel;

        public string Tel
        {
            get { return _Tel; }
            set { _Tel = value; }
        }
        private string _EmergencyContact;

        public string EmergencyContact
        {
            get { return _EmergencyContact; }
            set { _EmergencyContact = value; }
        }

        private string _MF;

        public string MF
        {
            get { return _MF; }
            set { _MF = value; }
        }

        private string _MarSts;

        public string MarSts
        {
            get { return _MarSts; }
            set { _MarSts = value; }
        }

        private string _Religion;

        public string Religion
        {
            get { return _Religion; }
            set { _Religion = value; }
        }
        private string _BloodGroup;

        public string BloodGroup
        {
            get { return _BloodGroup; }
            set { _BloodGroup = value; }
        }

        private string _OT;

        public string OT
        {
            get { return _OT; }
            set { _OT = value; }
        }
        private int _Sect_Number;

        public int Sect_Number
        {
            get { return _Sect_Number; }
            set { _Sect_Number = value; }
        }
        private int _Shift_Number;

        public int Shift_Number
        {
            get { return _Shift_Number; }
            set { _Shift_Number = value; }
        }
        private int _Desig_Number;

        public int Desig_Number
        {
            get { return _Desig_Number; }
            set { _Desig_Number = value; }
        }

        private int _EmpED;

        public int EmpED
        {
            get { return _EmpED; }
            set { _EmpED = value; }
        }

        private int _EmpSts;

        public int EmpSts
        {
            get { return _EmpSts; }
            set { _EmpSts = value; }
        }

        private string _HusWifeName;

        public string HusWifeName
        {
            get { return _HusWifeName; }
            set { _HusWifeName = value; }
        }
        private DateTime _QuitDate;

        public DateTime QuitDate
        {
            get { return _QuitDate; }
            set { _QuitDate = value; }
        }
        private int _Entryby;

        public int Entryby
        {
            get { return _Entryby; }
            set { _Entryby = value; }
        }
        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

        private int _empNumber;

        public int EmpNumber
        {
            get { return _empNumber; }
            set { _empNumber = value; }
        }
        private string _FileName;

        public string FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }

        public string EmpStatus { get; set; }
    }
}
