﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
   public class EmpWiseCBF
    {
       public EmpWiseCBF() { }
       public string EmpId { get; set; }
       public string EmpName { get; set; }
       public int Gross { get; set; }
       public int EmpPer { get; set; }
       public int EmpAmount { get; set; }
       public int CmpPer { get; set; }
       public int CmpAmount { get; set; }
       public int SlabLog { get; set; }
       public string Action { get; set; }
    }
}
