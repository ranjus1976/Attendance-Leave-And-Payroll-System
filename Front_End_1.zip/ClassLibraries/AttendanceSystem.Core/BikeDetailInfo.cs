﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class BikeDetailInfo
    {
        public int BikeID { get; set; }
        public string Model { get; set; }
        public string Manufecturer { get; set; }
        public string ManuYear { get; set; }
        public string RegistrationNo { get; set; }
        public string EngineNo { get; set; }
        public string ChesisNo { get; set; }
        public string Narration { get; set; }
        public int Price { get; set; }
        public string PurchaseDate { get; set; }
        public int RegCharge { get; set; }
        public string InsuranceNo { get; set; }
        public string InsurIssueDate { get; set; }
        public string InsurExpireDate { get; set; }
        public int InsuranceCost { get; set; }
        public string ImageLoc { get; set; }
        public int Others { get; set; }
        public int BikeLog { get; set; }
        public int TotalCost { get; set; }
        public string Color { get; set; }
        public string Action { get; set; }
    }
}
