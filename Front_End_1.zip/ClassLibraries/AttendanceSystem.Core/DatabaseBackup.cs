using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class DatabaseBackup
    {
        public DatabaseBackup()
        {
        }
        private String _Path = "";

        public String Path
        {
            get { return _Path; }
            set { _Path = value; }
        }
    }
}
