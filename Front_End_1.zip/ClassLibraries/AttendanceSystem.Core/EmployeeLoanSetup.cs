﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class EmployeeLoanSetup
    {
        public int ELID { get; set; }
        public string EmpId { get; set; }
        public int LoanAmount { get; set; }
        public int Duration  { get; set; }
        public int Instalment { get; set; }
        public DateTime ELoanSrtDate { get; set; }
        public DateTime ELoanEndDate { get; set; }
        public string Action { get; set; }
        public int ELLog { get; set; }
    }
}
