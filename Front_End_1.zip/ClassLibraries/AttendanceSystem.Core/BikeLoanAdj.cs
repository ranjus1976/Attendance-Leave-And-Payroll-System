﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class BikeLoanAdj
    {
        public string EmpId { get; set; }
        public int AdjAmount { get; set; }
        public string Month { get; set; }
        public string year { get; set; }
        public DateTime Date { get; set; }
        public string Action { get; set; }
    }
}
