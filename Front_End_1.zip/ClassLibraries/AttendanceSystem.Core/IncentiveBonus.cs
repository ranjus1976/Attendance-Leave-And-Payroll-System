﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
   public class IncentiveBonus
    {
       public int MonthNumber { get; set; }
       public string Action { get; set; }
       public string Option { get; set; }
       public int OptionId { get; set; }
       public int Gross { get; set; }
       public int Bonus { get; set; }
       public DateTime Date { get; set; }
       public string Month { get; set; }
       public string Year { get; set; }
       public string Machine { get; set; }
       public int Log { get; set; }
    }
}
