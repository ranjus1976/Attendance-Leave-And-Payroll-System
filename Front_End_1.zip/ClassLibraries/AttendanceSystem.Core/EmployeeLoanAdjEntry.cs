﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class EmployeeLoanAdjEntry
    {
        public string EmpId { get; set; }
        public int ELID { get; set; }
        public DateTime PayDate { get; set; }
        public int Adjustment { get; set; }
        public string Action { get; set; }
    }
}
