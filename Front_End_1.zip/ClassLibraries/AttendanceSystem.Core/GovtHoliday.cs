﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class GovtHoliday
    {
        public GovtHoliday()
        { 
        
        }
        private int _GHNumber;

        public int GHNumber
        {
            get { return _GHNumber; }
            set { _GHNumber = value; }
        }
        private string _GHName;

        public string GHName
        {
            get { return _GHName; }
            set { _GHName = value; }
        }
        private DateTime _FromDate;

        public DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }
        private DateTime _ToDate;

        public DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }
        private string _FinYearNo;

        public string FinYearNo
        {
            get { return _FinYearNo; }
            set { _FinYearNo = value; }
        }
        private int _EntryBy;

        public int EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }
        private DateTime _EntryDate;

        public DateTime EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }
        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
    }
}
