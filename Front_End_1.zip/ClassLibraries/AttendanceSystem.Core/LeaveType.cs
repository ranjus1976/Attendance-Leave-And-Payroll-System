﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class LeaveType
    {
        public LeaveType()
        {
        }

        private Int32 _LeaveTypeNumber;

        public Int32 LeaveTypeNumber
        {
            get { return _LeaveTypeNumber; }
            set { _LeaveTypeNumber = value; }
        }
        private String _LeaveName;

        public String LeaveName
        {
            get { return _LeaveName; }
            set { _LeaveName = value; }
        }
        private Int32 _LeaveBalance;

        public Int32 LeaveBalance
        {
            get { return _LeaveBalance; }
            set { _LeaveBalance = value; }
        }
        private Boolean _IsRequired;

        public Boolean IsRequired
        {
            get { return _IsRequired; }
            set { _IsRequired = value; }
        }
        
        private Boolean _IsFSpecific;
        public Boolean IsFSpecific
        {
            get { return _IsFSpecific; }
            set { _IsFSpecific = value; }
        }

        private Boolean _IsPaid;

        public Boolean IsPaid
        {
            get { return _IsPaid; }
            set { _IsPaid = value; }
        }

        private String _EntryBy;
        public String EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }
        private String _PC;

        public String PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
        private DateTime _EntryDate;

        public DateTime EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }
    }
}
