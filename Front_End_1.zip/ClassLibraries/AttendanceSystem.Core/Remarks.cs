﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Remarks
    {
        public Remarks()
        {
        }
        private Int32 _RemarksId = 0;

        public Int32 RemarksId
        {
            get { return _RemarksId; }
            set { _RemarksId = value; }
        }
        private Int32 _EmpId = 0;

        public Int32 EmpId
        {
            get { return _EmpId; }
            set { _EmpId = value; }
        }
        private DateTime _RemarksDate = DateTime.Now.Date;

        public DateTime RemarksDate
        {
            get { return _RemarksDate; }
            set { _RemarksDate = value; }
        }
        private String _Remarks = "";

        public String Remarks1
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }

        private int _EntryBy;

        public int EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }

        private DateTime _EntryDate = DateTime.Now.Date;

        public DateTime EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }

        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
    }
}
