﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class BikeLoanSetup
    {
        public int BLSID { get; set; }
        public string CompId { get; set; }
        public string EmpId { get; set; }
        public string BRegNo { get; set; }
        public int BTotalValue { get; set; }
        public string BLoanType { get; set; }
        public int Duration { get; set; }
        public int Interest { get; set; }
        public int EmpParticipation { get; set; }
        public int LoanAmount { get; set; }
        public int EmpInstAmt { get; set; }
        public int TotalAmtInst { get; set; }
        public int BLoanAmtDue { get; set; }
        public string AdjSatrtDate { get; set; }
        public string AdjEndDate { get; set; }
        public int ValidLog { get; set; }
        public string Action { get; set; }
    }
}
