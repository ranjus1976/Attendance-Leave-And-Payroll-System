﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Documentory
    {
        public Documentory()
        { 
        
        }
        private int _DocNo;

        public int DocNo
        {
            get { return _DocNo; }
            set { _DocNo = value; }
        }
        private string _EmpCode;

        public string EmpCode
        {
            get { return _EmpCode; }
            set { _EmpCode = value; }
        }
        private string _EmpDocumentoryList;

        public string EmpDocumentoryList
        {
            get { return _EmpDocumentoryList; }
            set { _EmpDocumentoryList = value; }
        }
    }
}
