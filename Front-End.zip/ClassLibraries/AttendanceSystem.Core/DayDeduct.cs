﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class DayDeduct
    {
        public DayDeduct()
        {
        }
        private Int32 _DayDeductId;

        public Int32 DayDeductId
        {
            get { return _DayDeductId; }
            set { _DayDeductId = value; }
        }
        private Int32 _Emp_Number;

        public Int32 Emp_Number
        {
            get { return _Emp_Number; }
            set { _Emp_Number = value; }
        }
        private DateTime _FromDate;

        public DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }
        private DateTime _ToDate;

        public DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }
        private float _TotalDyas;

        public float TotalDyas
        {
            get { return _TotalDyas; }
            set { _TotalDyas = value; }
        }
        private String _Remarks;

        public String Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
    }
}
