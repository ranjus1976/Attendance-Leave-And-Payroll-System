﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class WeeklyHoliDay1
    {
        public WeeklyHoliDay1()
        {

        }
        private int _empNumber;

        public int EmpNumber
        {
            get { return _empNumber; }
            set { _empNumber = value; }
        }
        private string _wHName;

        public string WHName
        {
            get { return _wHName; }
            set { _wHName = value; }
        }

        private Boolean _CheckHoliDay;

        public Boolean CheckHoliDay
        {
            get { return _CheckHoliDay; }
            set { _CheckHoliDay = value; }
        }
        private DateTime _HolidayDate;

        public DateTime HolidayDate
        {
            get { return _HolidayDate; }
            set { _HolidayDate = value; }
        }
        private int _entryBy;

        public int EntryBy
        {
            get { return _entryBy; }
            set { _entryBy = value; }
        }
        private DateTime _entryDate;

        public DateTime EntryDate
        {
            get { return _entryDate; }
            set { _entryDate = value; }
        }
        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
        private string _DeptID;

        public string DeptID
        {
            get { return _DeptID; }
            set { _DeptID = value; }
        }
        private string _deptNumber;

        public string DeptNumber
        {
            get { return _deptNumber; }
            set { _deptNumber = value; }
        }
        private string _compNumber;

        public string CompNumber
        {
            get { return _compNumber; }
            set { _compNumber = value; }
        }
    }

}
