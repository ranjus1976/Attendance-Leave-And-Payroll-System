﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class ProjectBAmount
    {
        public string ProjectName { get; set; }
        public string DesigName { get; set; }
        public int Amount { get; set; }
        public string Action { get; set; }
    }
}
