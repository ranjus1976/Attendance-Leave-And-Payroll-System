using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
  public  class TextDataCollect
    {
      public TextDataCollect()
      {

      }

      private string _CardId;

      public string CardId
      {
          get { return _CardId; }
          set { _CardId = value; }
      }
      private DateTime _PunchDate;

      public DateTime PunchDate
      {
          get { return _PunchDate; }
          set { _PunchDate = value; }
      }

      private String _PunchTime;

      public String PunchTime
      {
          get { return _PunchTime; }
          set { _PunchTime = value; }
      }
      private string _stNo;

      public string StNo
      {
          get { return _stNo; }
          set { _stNo = value; }
      }

      private string _InOut;

      public string InOut
      {
          get { return _InOut; }
          set { _InOut = value; }
      }

      private string _OvNMark;

      public string OvNMark
      {
          get { return _OvNMark; }
          set { _OvNMark = value; }
      }

      private int _Entryby;

      public int Entryby
      {
          get { return _Entryby; }
          set { _Entryby = value; }
      }

      private string _PC;

      public string PC
      {
          get { return _PC; }
          set { _PC = value; }
      }

    }
}
