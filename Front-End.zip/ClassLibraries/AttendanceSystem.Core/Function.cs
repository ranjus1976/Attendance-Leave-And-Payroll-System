﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Function
    {
        private Int32 _FunctionNumber;

        public Int32 FunctionNumber
        {
            get { return _FunctionNumber; }
            set { _FunctionNumber = value; }
        }
        private Int32 _RoleNumber;

        public Int32 RoleNumber
        {
            get { return _RoleNumber; }
            set { _RoleNumber = value; }
        }
        private String _FunctioName;

        public String FunctioName
        {
            get { return _FunctioName; }
            set { _FunctioName = value; }
        }
        private String _FormConstantName;

        public String FormConstantName
        {
            get { return _FormConstantName; }
            set { _FormConstantName = value; }
        }
        private String _FunctionDescription;

        public String FunctionDescription
        {
            get { return _FunctionDescription; }
            set { _FunctionDescription = value; }
        }
        private String _EntryBy;

        public String EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }
        private String _EntryDate;

        public String EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }
        private String _PC;

        public String PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
    }
}
