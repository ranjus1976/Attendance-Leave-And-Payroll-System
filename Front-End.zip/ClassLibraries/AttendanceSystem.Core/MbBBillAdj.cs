﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class MbBBillAdj
    {
        public MbBBillAdj() { }
        public string EmpId { get; set; }
        public string MonthName { get; set; }
        public string Year { get; set; }
        public float MobileDeduct { get; set; }
        public string MonthId { get; set; }
        public string Action { get; set; }
        public float MCelling { get; set; }
    }
}
