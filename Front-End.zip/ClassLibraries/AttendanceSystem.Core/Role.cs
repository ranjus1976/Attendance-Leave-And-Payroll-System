﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Role
    {
        private Int32 _RoleNumber;

        public Int32 RoleNumber
        {
            get { return _RoleNumber; }
            set { _RoleNumber = value; }
        }
        private String _RoleName;

        public String RoleName
        {
            get { return _RoleName; }
            set { _RoleName = value; }
        }
        private String _AspRole;

        public String AspRole
        {
            get { return _AspRole; }
            set { _AspRole = value; }
        }
        private String _User;

        public String User
        {
            get { return _User; }
            set { _User = value; }
        }
        private String _Mode;

        public String Mode
        {
            get { return _Mode; }
            set { _Mode = value; }
        }
        private String _EntryBy;

        public String EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }
        private DateTime _EntryDate;

        public DateTime EntryDate
        {
            get { return _EntryDate; }
            set { _EntryDate = value; }
        }
        private String _PC;

        public String PC
        {
            get { return _PC; }
            set { _PC = value; }
        }
    }
}
