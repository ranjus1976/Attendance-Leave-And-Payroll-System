using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Company
    {
        public Company()
        {

        }

        private int _CompNo;

        public int CompNo
        {
            get { return _CompNo; }
            set { _CompNo = value; }
        }

        private string _CompId;

        public string CompId
        {
            get { return _CompId; }
            set { _CompId = value; }
        }

        private string _CompName;

        public string CompName
        {
            get { return _CompName; }
            set { _CompName = value; }
        }

        private string _CompAddress;

        public string CompAddress
        {
            get { return _CompAddress; }
            set { _CompAddress = value; }
        }
        private string _CompPhone;

        public string CompPhone
        {
            get { return _CompPhone; }
            set { _CompPhone = value; }
        }

        private string _CompEmail;

        public string CompEmail
        {
            get { return _CompEmail; }
            set { _CompEmail = value; }
        }

        private string _CompFax;

        public string CompFax
        {
            get { return _CompFax; }
            set { _CompFax = value; }
        }
        private string _CompWeb;

        public string CompWeb
        {
            get { return _CompWeb; }
            set { _CompWeb = value; }
        }

        private String _CompCell;

        public String CompCell
        {
            get { return _CompCell; }
            set { _CompCell = value; }
        }
        private int _Entryby;

        public int Entryby
        {
            get { return _Entryby; }
            set { _Entryby = value; }
        }

        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

        private string _CompanyLogo;

        public string CompanyLogo
        {
            get { return _CompanyLogo; }
            set { _CompanyLogo = value; }
        }
    }
}
