using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public static class ReturningValue
    {
        public static Int32 rtnValue = 0;//string for login user id assigning. 
        public static String rtnErrorMessage = "";//string for login user id assigning. 
    }
}
