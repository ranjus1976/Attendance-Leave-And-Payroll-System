﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class User
    {
        string _uName;
        string _uPassword;
        string _uType;
        string _uAccept;
        int _userNo;
        public User() { }

        public int UserNo
        {
            get { return _userNo; }
            set { _userNo = value; }
        }
        public string UName
        {
            get { return _uName; }
            set { _uName = value; }
        }
        public string UPassword
        {
            get { return _uPassword; }
            set { _uPassword = value; }
        }
        public string UType
        {
            get { return _uType; }
            set { _uType = value; }
        }
        public string UAccept
        {
            get { return _uAccept; }
            set { _uAccept = value; }
        }

        private string _Email;

        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        private DateTime _ValidDate = System.DateTime.Now;

        public DateTime ValidDate
        {
            get { return _ValidDate; }
            set { _ValidDate = value; }
        }
    }
}
