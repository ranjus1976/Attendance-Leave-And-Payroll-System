using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class LeaveBalance
    {

        public LeaveBalance()
        {

            _All = string.Empty;
            _Leave_Balance_Numb = int.MinValue;
            _Employee_Number = int.MinValue;
         
            _PC = "";
            _MAX_Balance = int.MinValue;
            _Avail = int.MinValue;
            _EntryBy = int.MinValue;
            _All = "";
            _Dept = -1;
            _Sec = -1;
            _Emp = -1;


        }

        private int _Leave_Balance_Numb;

        public int Leave_Balance_Numb
        {
            get { return _Leave_Balance_Numb; }
            set { _Leave_Balance_Numb = value; }
        }


        private int _Employee_Number;

        public int Employee_Number
        {
            get { return _Employee_Number; }
            set { _Employee_Number = value; }
        }

        private int _Leave_Type_Number;

        public int Leave_Type_Number
        {
            get { return _Leave_Type_Number; }
            set { _Leave_Type_Number = value; }
        }

        private int _MAX_Balance;

        public int MAX_Balance
        {
            get { return _MAX_Balance; }
            set { _MAX_Balance = value; }
        }

        private double _Avail;

        public double Avail
        {
            get { return _Avail; }
            set { _Avail = value; }
        }

        private int _EntryBy;

        public int EntryBy
        {
            get { return _EntryBy; }
            set { _EntryBy = value; }
        }

        

        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

        private string _tempyear1;

        public string tempyear1
        {
            get { return _tempyear1; }
            set { _tempyear1 = value; }
        }

        private string _tempyear2;

        public string tempyear2
        {
            get { return _tempyear2; }
            set { _tempyear2 = value; }
        }

        private string _PreviousYear;

        public string PreviousYear
        {
            get { return _PreviousYear; }
            set { _PreviousYear = value; }
        }


        private string _Leave_Year;
        public string Leave_Year
        {
            get { return _Leave_Year; }
            set { _Leave_Year = value; }

        }


        private string _All;
        public string All
        {
            get { return _All; }
            set { _All = value; }

        }

        private Int32 _Dept;
        public Int32 Dept
        {
            get { return _Dept; }
            set { _Dept = value; }

        }

        private Int32 _Sec;
        public Int32 Sec
        {
            get { return _Sec; }
            set { _Sec = value; }
        }

        private int _Emp;
        public int Emp
        {
            get { return _Emp; }
            set { _Emp = value; }
        }

        private Int32 _Comp_Name;
        public Int32 Comp_Name
        {
            get { return _Comp_Name; }
            set { _Comp_Name = value; }
        }

        /// <summary>
        ///  will help to identify 
        /// </summary>

        private int _Entry_CL_Iden;
        public int Entry_CL_Iden
        {
            get { return _Entry_CL_Iden; }
            set { _Entry_CL_Iden = value; }
        }


        private int _Entry_EL_Iden;
        public int Entry_EL_Iden
        {
            get { return _Entry_EL_Iden; }
            set { _Entry_EL_Iden = value; }
        }

        private int _Entry_ML_Iden;
        public int Entry_ML_Iden
        {
            get { return _Entry_ML_Iden; }
            set { _Entry_ML_Iden = value; }
        }

        private int _Entry_LWP_Iden;
        public int Entry_LWP_Iden
        {
            get { return _Entry_LWP_Iden; }
            set { _Entry_LWP_Iden = value; }
        }

        private int _Entry_SL_Iden;
        public int Entry_SL_Iden
        {
            get { return _Entry_SL_Iden; }
            set { _Entry_SL_Iden = value; }
        }


        /// <summary>
        /// will contain  data.
        /// </summary>
        private int _Entry_CL_Type;
        public int Entry_CL_Type
        {
            get { return _Entry_CL_Type; }
            set { _Entry_CL_Type = value; }
        }

        private int _Entry_EL_Type;
        public int Entry_EL_Type
        {
            get { return _Entry_EL_Type; }
            set { _Entry_EL_Type = value; }
        }

        private int _Entry_SL_Type;
        public int Entry_SL_Type
        {
            get { return _Entry_SL_Type; }
            set { _Entry_SL_Type = value; }
        }

    }
}
