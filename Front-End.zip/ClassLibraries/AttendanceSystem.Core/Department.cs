using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class Department
    {
        public Department()
        {

        }

        private string _CompNo;

        public string CompNo
        {
            get { return _CompNo; }
            set { _CompNo = value; }
        }

        private int _DeptNo;

        public int DeptNo
        {
            get { return _DeptNo; }
            set { _DeptNo = value; }
        }

        private string _DeptId;

        public string DeptId
        {
            get { return _DeptId; }
            set { _DeptId = value; }
        }

        private string _DeptName;

        public string DeptName
        {
            get   { return _DeptName; }
            set { _DeptName = value; }
        }

        private int _Entryby;

        public int Entryby
        {
            get { return _Entryby; }
            set { _Entryby = value; }
        }

        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

      

    }
}
