using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
   public class Process
    {
       public Process()
       {

       }
    }
}
