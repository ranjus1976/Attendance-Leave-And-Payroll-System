﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class SalaryAdj
    {
        public string EmpId { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
        public int AdjAmount { get; set; }
        public int Log { get; set; }
        public string Remark { get; set; }
        public string Action { get; set; }
    }
}
