﻿using System;
using System.Collections.Generic;
using System.Text;


namespace AttendanceSystem.Core
{
    public class Designation
    {
        public Designation()
        { 
        
        }
        private int _desigNumber;

        public int DesigNumber
        {
            get { return _desigNumber; }
            set { _desigNumber = value; }
        }
        private int _Company;

        public int Company
        {
            get { return _Company; }
            set { _Company = value; }
        }

        private string _desigId;

        public string DesigId
        {
            get { return _desigId; }
            set { _desigId = value; }
        }

        private string _desigName;

        public string DesigName
        {
            get { return _desigName; }
            set { _desigName = value; }
        }

        private string _grade;

        public string Grade
        {
            get { return _grade; }
            set { _grade = value; }
        }

        private int _priority;

        public int Priority
        {
            get { return _priority; }
            set { _priority = value; }
        }

        private int _entryby;

        public int Entryby
        {
            get { return _entryby; }
            set { _entryby = value; }
        }

        private string _PC;

        public string PC
        {
            get { return _PC; }
            set { _PC = value; }
        }

        private DateTime _entrydate;

        public DateTime Entrydate
        {
            get { return _entrydate; }
            set { _entrydate = value; }
        }
    }
}
