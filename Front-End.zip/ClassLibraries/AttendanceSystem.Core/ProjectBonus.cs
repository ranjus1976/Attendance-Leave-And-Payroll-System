﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Core
{
    public class ProjectBonus
    {
        public string EmpNumber { get; set; }
        public DateTime EffectiveDate { get; set; }
        public int Duration { get; set; }
        public string ProjectName { get; set; }
        public int BAmount { get; set; }
        public int Gross { get; set; }
        public string EntryBy { get; set; }
        public string Action { get; set; }
    }
}
