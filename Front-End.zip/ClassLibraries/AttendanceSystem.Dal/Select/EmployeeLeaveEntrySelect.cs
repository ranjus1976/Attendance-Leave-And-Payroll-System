﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Select
{
    public class EmployeeLeaveEntrySelect : DataAccessBase
    {

       public EmployeeLeaveEntrySelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_ReadLeaveForSearch.ToString();
       }

       private SqlParameter[] _LeaveParams;

       public SqlParameter[] LeaveParams
       {
           get { return _LeaveParams; }
           set { _LeaveParams = value; }
       }

       public DataSet GetLeaveDataForView()
       {
           DataSet ds = new DataSet();
           try
           {
               
               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               dbh.Parameters = this.LeaveParams;

               ds = dbh.Run(base.ConnectionString, this.LeaveParams);
               return ds;
           }
           catch (Exception ex)
           {

              
           }
           return ds;
       }
       public void MakeParameter(Object[] pamameters)
       {
           SqlParameter[] param = {
                                      DataBaseHelper.MakeParam("@LeaveReadSql",SqlDbType.VarChar,300,ParameterDirection.Input,pamameters[0])
                                  };
           this.LeaveParams = param;
       }

    }
}
