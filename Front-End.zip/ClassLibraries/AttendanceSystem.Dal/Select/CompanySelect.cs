using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class CompanySelect:DataAccessBase
    {
       public CompanySelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Company_Select.ToString();
       }

        public DataSet SelectCompany()
        {
            try 
	        {
                DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
                return dbh.Run(base.ConnectionString);
	        }
	        catch (Exception)
	        {
        		
		        throw;
	        }
               
        }

    }
}
