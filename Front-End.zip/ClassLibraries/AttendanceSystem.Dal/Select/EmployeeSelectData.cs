﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class EmployeeSelectData:DataAccessBase
    {
        public EmployeeSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Employee_Select_Manual.ToString();

        }
        public DataSet EmpoyeeList()
        {
            try
            {
                DataBaseHelper dbh3 = new DataBaseHelper(StoredProcedureName);
                return dbh3.Run(base.ConnectionString);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
