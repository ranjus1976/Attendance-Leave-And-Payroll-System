﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace AttendanceSystem.Dal.Select
{
    public class UserSelectData:DataAccessBase
    {
        public UserSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_User_Select.ToString();
        }

         public DataSet SelectUserList()
         {
             try
             {
                 DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
                 return db.Run(base.ConnectionString);
              }
             catch(Exception)
             {
                 throw;

             }
                       
         }
    }
}
