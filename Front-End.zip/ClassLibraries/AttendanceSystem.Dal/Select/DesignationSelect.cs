using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class DesignationSelect: DataAccessBase
    {
        public DesignationSelect()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Designation_SelectAll.ToString();
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public DataSet SelectAllDesignation()
        {
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                return dbh.Run(base.ConnectionString);
                   
            }
            catch(Exception e)
            {
                throw;                
            }
        }

    }
    class DesignationSelectParameter
    {
        DesignationSelectParameter(Designation designation)
        {
            this.Desig = designation;
        }
        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        private SqlParameter[] param;

        public SqlParameter[] Param
        {
            get { return param; }
            set { param = value; }
        }

    }
}
