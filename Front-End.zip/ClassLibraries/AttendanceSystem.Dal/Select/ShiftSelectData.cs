﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace AttendanceSystem.Dal.Select
{
    public class ShiftSelectData : DataAccessBase
    {
        public ShiftSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Shift_Select.ToString();
        }
        public DataSet SelectShift()
        {
            try
            {
                DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
                return dbh.Run(base.ConnectionString);
            }
            catch(Exception)
            {
                throw;    
            }
        }
       
    }

}

