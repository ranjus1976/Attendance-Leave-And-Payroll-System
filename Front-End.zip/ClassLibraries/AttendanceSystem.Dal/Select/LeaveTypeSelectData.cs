﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
    public class LeaveTypeSelectData : DataAccessBase
    {
        public LeaveTypeSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Type_Select.ToString();
        }

        public DataSet SelectLeaveType()
        {
            try
            {
                DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
                return dbh.Run(base.ConnectionString);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
