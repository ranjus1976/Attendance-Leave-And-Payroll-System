﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Data;


namespace AttendanceSystem.Dal.Select
{
    public class SectionSelectData:DataAccessBase
    {
        public SectionSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Section_Select.ToString();
        }
        public DataSet SectionList()
        {
            try
            {
                DataBaseHelper dbh2 = new DataBaseHelper(StoredProcedureName);
                return dbh2.Run(base.ConnectionString);
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}
