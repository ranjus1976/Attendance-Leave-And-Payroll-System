﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;



namespace AttendanceSystem.Dal.Select
{
     public class UserLoginSelectData:DataAccessBase
     {
         public UserLoginSelectData()
         {
             StoredProcedureName = StoredProcedure.Name.sp_User_Login.ToString();
         }

         public string userName, userPassword;
   
         public void LoginCheck( string loginName, string loginPass)
         {
             DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
             SqlDataReader dr = null;
             try
             {
                 SqlParameter[] _para = {
                        DataBaseHelper.MakeParam("@UserId",SqlDbType.VarChar,20,ParameterDirection.Input,loginName),
                        DataBaseHelper.MakeParam("@UserPassword",SqlDbType.VarChar,20,ParameterDirection.Input,loginPass)
                                        };
                 db.Parameters = _para;
                 dr = db.ExecuteReader(base.ConnectionString);

                 if (dr.Read())
                 {
                     userName = dr["UserId"].ToString();
                     userPassword=dr["UserPassword"].ToString();
                 }
                     
             }
             catch (Exception e)
             {
                 e.Message.ToString();
             }
         }
     }
}
