﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Select
{
    public class OSDSelectData:DataAccessBase
    {
        public OSDSelectData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_OSD_SelectAll.ToString();
        }
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        private DataSet _OSDDataSet;

        public DataSet OSDDataSet
        {
            get { return _OSDDataSet; }
            set { _OSDDataSet = value; }
        }
        public void SelectOSDData()
        {
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                this.OSDDataSet = dbh.Run(base.ConnectionString);
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
            
        }
    }
    class OSDSelectDataParameter
    {
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        public OSDSelectDataParameter(OSD osdData)
        {
            this.OsdData = OsdData;    
        }
        public void BuildSelectAllParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@OSD_Number",SqlDbType.Int,4,ParameterDirection.Input,OsdData.OSDNumber)
                                   };
        }
    }
}
