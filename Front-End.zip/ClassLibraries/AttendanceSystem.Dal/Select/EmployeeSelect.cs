﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
   public class EmployeeSelect:DataAccessBase 
    {
       public EmployeeSelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Employee_Select.ToString();
       }

       public DataSet SelectEmployee()
       {
           try
           {
               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               return dbh.Run(base.ConnectionString);
           }
           catch (Exception)
           {
               throw;
           }
       }
    }
}
