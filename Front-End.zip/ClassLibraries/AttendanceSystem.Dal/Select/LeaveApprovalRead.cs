﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;


namespace AttendanceSystem.Dal.Select
{
    public class LeaveApprovalRead : DataAccessBase
    {

       public LeaveApprovalRead()
       {
           StoredProcedureName = StoredProcedure.Name.sp_LeaveReadForApprovePhase.ToString();
       }

       private LeaveApplied _LeaveApplied;

       public LeaveApplied LeaveApplied
       {
           get { return _LeaveApplied; }
           set { _LeaveApplied = value; }
       }
        
       public DataSet SelectLeaveDataForApproval()
       {
           try
           {
               LeaveApprovalReadParameters oParam = new LeaveApprovalReadParameters(this.LeaveApplied);

               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);

               //dbh.Parameters = oParam.Param;
               return dbh.Run(base.ConnectionString, oParam.Param);
           }
           catch (Exception)
           {

               throw;
           }
       }

       public class LeaveApprovalReadParameters
       {

           public LeaveApprovalReadParameters(LeaveApplied oLeaveApplied)
           {
               this.LeaveAppliedobj = oLeaveApplied;
               Build();
           }

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }

           private LeaveApplied _LeaveAppliedobj;

           public LeaveApplied LeaveAppliedobj
           {
               get { return _LeaveAppliedobj; }
               set { _LeaveAppliedobj = value; }
           }

           void Build()
           {
               try
               {
                   SqlParameter[] param = {
                                              DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,LeaveAppliedobj.Employee_Number),
                                              DataBaseHelper.MakeParam("@Year",SqlDbType.SmallDateTime,8,ParameterDirection.Input,LeaveAppliedobj.From_Date),
                                              DataBaseHelper.MakeParam("@LeaveType_Number",SqlDbType.Int,4,ParameterDirection.Input,LeaveAppliedobj.Leave_Type_Number)
                                          };

                   this.Param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }

       }

    }
}
