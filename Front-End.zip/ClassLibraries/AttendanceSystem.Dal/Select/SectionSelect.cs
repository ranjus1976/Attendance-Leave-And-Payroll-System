using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace AttendanceSystem.Dal.Select
{
   public  class SectionSelect :DataAccessBase 
    {
       public SectionSelect()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Section_Select.ToString();  
       }

       public DataSet SelectSection()
       {
           try
           {
               DataBaseHelper dbh = new DataBaseHelper(this.StoredProcedureName);
               return dbh.Run(base.ConnectionString);
           }
           catch (Exception)
           {

               throw;
           }

       }
    }
}
