﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class LeaveApplyUpdate : DataAccessBase
    {
       public LeaveApplyUpdate()
       {
           StoredProcedureName = StoredProcedure.Name.sp_LeaveApplied_Update.ToString();

       }

       private LeaveApplied _Leave_Applied;

       public LeaveApplied Leave_Applied
       {
           get { return _Leave_Applied; }
           set { _Leave_Applied = value; }
       }

       public void AddLeaveApply()
       {
           LeaveApplyUpdateParameters oLeaveProParam = new LeaveApplyUpdateParameters(this.Leave_Applied);

           DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
           try
           {
               oDBhalper.Parameters = oLeaveProParam.Param;
               oDBhalper.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (oDBhalper != null)
                   oDBhalper = null;
           }
       }

       public class LeaveApplyUpdateParameters
       {
           public LeaveApplyUpdateParameters(LeaveApplied oLeaveApply)
           {
               this._LeaveApplyUpdate = oLeaveApply;
               Build();
           }
           private LeaveApplied _LeaveApplyUpdate;

           private SqlParameter[] _param;

           public SqlParameter[] Param
           {
               get { return _param; }
               set { _param = value; }
           }
           void Build()
           {
               try
               {
                  
                   SqlParameter[] param = {
                                              
                                         DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,_LeaveApplyUpdate.Employee_Number),
                                         DataBaseHelper.MakeParam("@From_Date",SqlDbType.DateTime,8,ParameterDirection.Input,_LeaveApplyUpdate.From_Date),
                                         DataBaseHelper.MakeParam("@To_Date",SqlDbType.DateTime,8,ParameterDirection.Input,_LeaveApplyUpdate.To_Date),
                                         DataBaseHelper.MakeParam("@Total_Days",SqlDbType.Float,8,ParameterDirection.Input,_LeaveApplyUpdate.Total_Days),
                                         DataBaseHelper.MakeParam("@Leave_Type_Number",SqlDbType.Int,4,ParameterDirection.Input,_LeaveApplyUpdate.Leave_Type_Number),
                                         DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveApplyUpdate.Remarks),
                                         DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,_LeaveApplyUpdate.EntryBy),
                                         DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,8,ParameterDirection.Input,_LeaveApplyUpdate.EntryDate),
                                         DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,_LeaveApplyUpdate.PC),

                                         DataBaseHelper.MakeParam("@Approval",SqlDbType.Int,4,ParameterDirection.Input,_LeaveApplyUpdate.Approval), 

                                          };
                   this._param = param;
               }
               catch (Exception e)
               {
                   e.ToString();
               }
           }
       }


    }
}
