﻿using System;
using System.Collections.Generic;
using System.Text;

using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;


namespace AttendanceSystem.Dal.Update
{
    public class LeaveEmployeeLeaveStatusData : DataAccessBase
    {

        public LeaveEmployeeLeaveStatusData()
        {

            StoredProcedureName = StoredProcedure.Name.sp_LeaveStatusUpdate.ToString();

        }


        private LeaveBalance _Leave_Balance;

        public LeaveBalance Leave_Balance
        {
            get { return _Leave_Balance; }
            set { _Leave_Balance = value; }
        }

        public void UpdateLeaveBalanceFromStatus()
        {
            LeaveEmployeeLeaveStatusDataPM oLeaveStatusPM = new LeaveEmployeeLeaveStatusDataPM(this.Leave_Balance);

            DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);

            try
            {
                oDBhalper.Parameters = oLeaveStatusPM.Param;
                oDBhalper.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (oDBhalper != null)
                    oDBhalper = null;
            }
        }

        public class LeaveEmployeeLeaveStatusDataPM
        {

            public LeaveEmployeeLeaveStatusDataPM(LeaveBalance oBalance)
            {
                this._LeaveBalance = oBalance;
                Build();
            }

            private LeaveBalance _LeaveBalance;

            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            void Build()
            {
                try
                {
                    SqlParameter[] param = {
                                              
                                         DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Employee_Number), 
                                         DataBaseHelper.MakeParam("@MAX_Balance",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.MAX_Balance),
                                         DataBaseHelper.MakeParam("@Leave_Type_Number",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Leave_Type_Number),
                                         DataBaseHelper.MakeParam("@Leave_Year",SqlDbType.VarChar,10,ParameterDirection.Input,_LeaveBalance.Leave_Year),
                                         DataBaseHelper.MakeParam("@Leave_Avail",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Avail)
                                          };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
