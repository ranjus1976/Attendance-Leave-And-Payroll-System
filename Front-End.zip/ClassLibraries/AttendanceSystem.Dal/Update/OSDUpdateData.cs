﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class OSDUpdateData:DataAccessBase
    {
        public OSDUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_OSD_Update.ToString();
        }
        private OSD _OsdData;

        public OSD OsdData
        {
            get { return _OsdData; }
            set { _OsdData = value; }
        }
        public void UpdateOSDData()
        {
            OSDUpdateDataParameter osdUpdateParam = new OSDUpdateDataParameter(this.OsdData);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = osdUpdateParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    
                }
            }
        }
    }
    class OSDUpdateDataParameter
    {
        private OSD _OsdData;

        public OSD OsdData
        {
            get { return _OsdData; }
            set { _OsdData = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public OSDUpdateDataParameter(OSD osdData)
        {
            this.OsdData = osdData;
            BuildUpdateParameter();
        }
        public void BuildUpdateParameter()
        { 
            SqlParameter[] param={
                          DataBaseHelper.MakeParam("@OSD_Number",SqlDbType.Int,4,ParameterDirection.Input,OsdData.OSDNumber),
                          //DataBaseHelper.MakeParam("@Emp_Number",SqlDbType.Int,4,ParameterDirection.Input,OsdData.EmpNumber),
                          DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,4,ParameterDirection.Input,OsdData.FromDate),
                          DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,4,ParameterDirection.Input,OsdData.ToDate),
                          DataBaseHelper.MakeParam("@Location",SqlDbType.VarChar,100,ParameterDirection.Input,OsdData.Location),
                                 };
            this.Param = param;
        }
    }
}
