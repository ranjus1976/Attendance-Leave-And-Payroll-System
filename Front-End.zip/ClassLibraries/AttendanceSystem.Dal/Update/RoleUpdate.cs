﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Update
{
    public class RoleUpdate : DataAccessBase
    {
        public RoleUpdate()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Role_Update.ToString();
        }

        private AttendanceSystem.Core.Role _Role;

        public AttendanceSystem.Core.Role Role
        {
            get { return _Role; }
            set { _Role = value; }
        }

        public void UpdateRole()
        {

            RoleUpdateDataParameter obj_RoleUpdateDataParameter = new RoleUpdateDataParameter(Role);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_RoleUpdateDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class RoleUpdateDataParameter
    {
        private AttendanceSystem.Core.Role _Role;

        public RoleUpdateDataParameter(AttendanceSystem.Core.Role Role)
        {
            this._Role = Role;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@RoleName",SqlDbType.VarChar,50,ParameterDirection.Input,_Role.RoleName),
                    DataBaseHelper.MakeParam("@AspRole",SqlDbType.VarChar,150,ParameterDirection.Input,_Role.AspRole),
                    DataBaseHelper.MakeParam("@User_Name",SqlDbType.VarChar,150,ParameterDirection.Input,_Role.User ),
                    DataBaseHelper.MakeParam("@Mode",SqlDbType.VarChar,50,ParameterDirection.Input,_Role.Mode),  
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,_Role.EntryBy),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,50,ParameterDirection.Input,_Role.EntryDate ),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@Role_Number",SqlDbType.Int,4,ParameterDirection.Input,_Role.RoleNumber)
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }
}
