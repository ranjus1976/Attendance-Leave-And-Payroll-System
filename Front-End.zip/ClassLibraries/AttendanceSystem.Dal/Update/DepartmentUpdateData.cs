using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class DepartmentUpdateData : DataAccessBase
    {
        public DepartmentUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Department_Update.ToString();
        }

        private Department _Dept;

        public Department Dept
        {
            get { return _Dept; }
            set { _Dept = value; }
        }

        public void UpdateDepartment()
        {
            DepartmentUpdateParameter d = new DepartmentUpdateParameter(Dept);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = d.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class DepartmentUpdateParameter
        {
            public DepartmentUpdateParameter(Department Dept)
            {
                this._Dept = Dept;
                Build();
            }


            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private Department _Dept;

            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,_Dept.DeptNo ),
                    DataBaseHelper.MakeParam("@DeptId",SqlDbType.VarChar,4,ParameterDirection.Input,_Dept.DeptId),
                    DataBaseHelper.MakeParam("@DeptName",SqlDbType.VarChar,150,ParameterDirection.Input,_Dept.DeptName),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,4,ParameterDirection.Input,_Dept.CompNo )
                };//collection
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }


    }



}
