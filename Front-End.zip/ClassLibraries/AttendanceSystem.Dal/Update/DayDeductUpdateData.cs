﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Update
{
    public class DayDeductUpdateData : DataAccessBase
    {
        public DayDeductUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_DayFineUpdate.ToString();
        }

        private DayDeduct _DayDeduct;

        public DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        public void UpdateDayDeduct()
        {
            DayDeductUpdateParameter d = new DayDeductUpdateParameter(DayDeduct);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = d.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }

        class DayDeductUpdateParameter
        {
            private DayDeduct _DayDeduct;
            public DayDeductUpdateParameter(DayDeduct DayDeduct)
            {
                this._DayDeduct = DayDeduct;
                Build();
            }

            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }
            void Build()
            {
                try
                {
                    SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@DeductId",SqlDbType.Int,4,ParameterDirection.Input,_DayDeduct.DayDeductId),
                    DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,_DayDeduct.Emp_Number),
                    DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,8,ParameterDirection.Input,_DayDeduct.FromDate),
                    DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,8,ParameterDirection.Input,_DayDeduct.ToDate ),
                    DataBaseHelper.MakeParam("@TotalDays",SqlDbType.Float,4,ParameterDirection.Input,_DayDeduct.TotalDyas),  
                    DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,100,ParameterDirection.Input,_DayDeduct.Remarks)
                };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }
        }
    }
}
