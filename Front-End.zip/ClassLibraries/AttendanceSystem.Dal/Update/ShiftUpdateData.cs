﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;


namespace AttendanceSystem.Dal.Update
{
    public class ShiftUpdateData:DataAccessBase
    {

        private Shift _sht;
        public ShiftUpdateData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Shift_Update.ToString();
            
        }

        public Shift ObShift
        {
            get { return _sht; }
            set { _sht = value; }
        }
        public void UpdateShift()
        {
            ShiftUpdateParameter sup = new ShiftUpdateParameter(ObShift);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                
               
                db.Parameters = sup.Param;
                db.Run();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
    public  class ShiftUpdateParameter
    {
     private  Shift _shift;
        public ShiftUpdateParameter(Shift s)
        {
            this._shift = s;
            BuildUpdate();
        }
        private  SqlParameter[] _uparam;
        public SqlParameter[] Param
        {
            get { return _uparam; }
            set { _uparam = value; }
        }
        public void BuildUpdate()
        {
            try
            {
                SqlParameter[] _param ={
                           DataBaseHelper.MakeParam("@ShiftId",SqlDbType.Int,4,ParameterDirection.Input,_shift.ShiftId),
                           DataBaseHelper.MakeParam("@SeasonId",SqlDbType.VarChar,50,ParameterDirection.Input,_shift.SeasonId),
                           DataBaseHelper.MakeParam("@Shift_Number",SqlDbType.VarChar,50,ParameterDirection.Input,_shift.Shift_Number),
                           DataBaseHelper.MakeParam("@ShiftIn",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftInTime),
                           DataBaseHelper.MakeParam("@ShiftOut",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftOutTime),
                           DataBaseHelper.MakeParam("@ShiftLate",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftLate),
                           DataBaseHelper.MakeParam("@R_In",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftRamInTime),
                           DataBaseHelper.MakeParam("@R_Out",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftRamTimeOut),
                           DataBaseHelper.MakeParam("@R_Late",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.ShiftRamLateTime),
                           DataBaseHelper.MakeParam("@BrTime",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shift.BreakTime),
                           DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())

                                      };
                this._uparam = _param;
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
 
        }
    }
}
