﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace AttendanceSystem.Dal.Report
{
    public class ReportMonthlyPresentDaysData : DataAccessBase
    {
        public ReportMonthlyPresentDaysData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Employee_Monthly_Present.ToString();    
       }

         public string ProcedureName()
         {
             return this.StoredProcedureName;  
         }

         public SqlConnection GetDBConn()
         {
             SqlConnection oConn = new SqlConnection(this.ConnectionString);
             return oConn;
         }
    }
}
