﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;


namespace AttendanceSystem.Dal.Report
{
   public class ReportBonus : DataAccessBase
    {
       public ReportBonus()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Bonus_Report.ToString();
        }

        public string ProcedureName()
        {
            return this.StoredProcedureName;
        }

        public SqlConnection GetDBConn()
        {
            SqlConnection oConn = new SqlConnection(this.ConnectionString);
            return oConn;
        }

    }
}
