﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace AttendanceSystem.Dal.Report
{
    public class ReportProjectBonus : DataAccessBase
    {
        public ReportProjectBonus()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Project_Bonus_Report.ToString();
        }

        public string ProcedureName()
        {
            return this.StoredProcedureName;
        }

        public SqlConnection GetDBConn()
        {
            SqlConnection oConn = new SqlConnection(this.ConnectionString);
            return oConn;
        }
    }
}
