﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace AttendanceSystem.Dal.Report
{
   public class ReportMonthlyLateDaysData:DataAccessBase
    {
       public ReportMonthlyLateDaysData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Employee_Monthly_Late.ToString();    
       }
       public string ProcedureName()
       {
           return this.StoredProcedureName;
       }

       public SqlConnection GetDBConn()
       {
           SqlConnection oConn = new SqlConnection(this.ConnectionString);
           return oConn;
       }
    }
}
