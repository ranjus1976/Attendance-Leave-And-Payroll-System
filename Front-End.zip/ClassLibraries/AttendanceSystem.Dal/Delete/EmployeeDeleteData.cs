﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
   public class EmployeeDeleteData:DataAccessBase 
    {
        public EmployeeDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Employee_Delete.ToString();  
        }

        private Employee _Emp;

        public Employee Emp
        {
            get { return _Emp; }
            set { _Emp = value; }
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }


        public void DeleteEmployee()
        {
            EmployeeDeleteDataParameter EmpD = new EmployeeDeleteDataParameter(Emp);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = EmpD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

   class EmployeeDeleteDataParameter
   {
       public EmployeeDeleteDataParameter(Employee Emp)
       {
           this._Emp = Emp;
           BuildParameter();
       }
       private Employee _Emp;

       public Employee Emp
       {
           get { return _Emp; }
           set { _Emp = value; }
       }
       private SqlParameter[] _param;

       public SqlParameter[] Param
       {
           get { return _param; }
           set { _param = value; }
       }
       public void BuildParameter()
       {
           SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Emp_Number",SqlDbType.Int,4,ParameterDirection.Input,Emp.EmpNumber)
                                   };
           this.Param = param;
       }

   }
}
