﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Delete
{
    public class RemarksDeleteData : DataAccessBase
    {

        public RemarksDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Remarks_Delete.ToString();

        }
        private Remarks _Remarks;

        public Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        public void RemarksDelete()
        {
            RemarksDeleteParameter oLeaveDeleteParam = new RemarksDeleteParameter(this.Remarks);

            DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
            try
            {
                oDBhalper.Parameters = oLeaveDeleteParam.Param;
                oDBhalper.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (oDBhalper != null)
                    oDBhalper = null;
            }
        }

        public class RemarksDeleteParameter
        {

            private Remarks _objRemarks;
            public RemarksDeleteParameter(Remarks objRemarks)
            {
                this._objRemarks = objRemarks;
                this.Build();
            }

            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }
            void Build()
            {
                try
                {
                    //@leaveDel  numeric (9)

                    SqlParameter[] param = {                                              
                                         DataBaseHelper.MakeParam("RemarksId",SqlDbType.Int,9,ParameterDirection.Input,_objRemarks.RemarksId)
                                          };
                    this._param = param;
                }
                catch (Exception e)
                {
                    e.ToString();
                }
            }

        }

    }
}
