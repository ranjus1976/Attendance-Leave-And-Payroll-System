﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
   public class DocumentoryDeleteData:DataAccessBase
    {
       public DocumentoryDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Documentory_Delect.ToString();  
        }

       private Documentory _Doc;

       public Documentory Doc
       {
           get { return _Doc; }
           set { _Doc = value; }
       }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }


        public void DeleteDocumentory()
        {
            DocumentoryDataParameter DocD = new DocumentoryDataParameter(Doc);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = DocD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }


   class DocumentoryDataParameter
   {
       public DocumentoryDataParameter(Documentory Doc)
       {
           this._Doc = Doc;
           BuildParameter();
       }
       private Documentory _Doc;

       public Documentory Doc
       {
           get { return _Doc; }
           set { _Doc = value; }
       }

      
       private SqlParameter[] _param;

       public SqlParameter[] Param
       {
           get { return _param; }
           set { _param = value; }
       }
       public void BuildParameter()
       {
           SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Doc_Number",SqlDbType.Int,4,ParameterDirection.Input,Doc.DocNo)
                                   };
           this.Param = param;
       }

   }


}
