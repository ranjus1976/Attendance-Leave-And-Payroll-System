using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Delete
{
 public class DepartmentDeleteData:DataAccessBase 
    {
     public DepartmentDeleteData()
     {
         StoredProcedureName = StoredProcedure.Name.sp_Department_Delete.ToString();
     }

     private Department _Dept;

     public Department Dept
     {
         get { return _Dept; }
         set { _Dept = value; }
     }

     private SqlParameter[] _param;

     public SqlParameter[] Param
     {
         get { return _param; }
         set { _param = value; }
     }

     public void DeleteDepartment()
     {
        
         DepartmentDeleteDataParameter DepD = new DepartmentDeleteDataParameter(Dept);
         DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
         dbh.Parameters = DepD.Param;
         try
         {
             dbh.Run();
         }
         catch (Exception e)
         {
             e.ToString();
         }
         finally
         {
             if (dbh != null)
             {
                 dbh = null;
             }
         }
     }
    }
 class DepartmentDeleteDataParameter
 {
     public DepartmentDeleteDataParameter(Department Dept)
     {
         this.Dept = Dept;
         BuildParameter();
     }
     private Department _Dept;

     public Department Dept
     {
         get { return _Dept; }
         set { _Dept = value; }
     }

     


     private SqlParameter[] _param;

     public SqlParameter[] Param
     {
         get { return _param; }
         set { _param = value; }
     }
     public void BuildParameter()
     {
         SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,Dept.DeptNo)
                                   };
         this.Param = param;
     }

 }
}
