﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Delete
{
    public class UserDeleteData:DataAccessBase
    {
        private User _usr;
        public UserDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_User_Delete.ToString();
        }
        public User Usr
        {
            get { return _usr;}
            set { _usr = value; }
        }
       public void DeleteUser()
        {
            UserDeleteDataParameter udap = new UserDeleteDataParameter(Usr);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = udap.PROMS;
                db.Run();
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
        }
    }

    public class UserDeleteDataParameter
    {
        private User userOb;
        private SqlParameter[] proms;
        public UserDeleteDataParameter(User ur)
        {
            this.userOb = ur;
            Build();
 
        }
        public SqlParameter[] PROMS
        {
            get { return proms; }
            set { proms = value; }
        }
        public void Build()
        {
            try
            {
                SqlParameter[] pra ={
                              DataBaseHelper.MakeParam("User_Number", SqlDbType.Int,4,ParameterDirection.Input, userOb.UserNo)
                               };
                this.proms = pra;
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
        }

    }
}
