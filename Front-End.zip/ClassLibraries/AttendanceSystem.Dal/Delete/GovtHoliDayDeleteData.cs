﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Delete
{
    public class GovtHoliDayDeleteData:DataAccessBase
    {
        public GovtHoliDayDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_GovtHoliDay_Delete.ToString();
        }
        private GovtHoliday _gdata;

        public GovtHoliday Gdata
        {
            get { return _gdata; }
            set { _gdata = value; }
        }
        public void DeleteGovtHoliDay()
        {
            GovtHoliDayDeleteDataParameter p = new GovtHoliDayDeleteDataParameter(this.Gdata);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = p.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class GovtHoliDayDeleteDataParameter
    {
        GovtHoliday _gHoliDay;

        public GovtHoliday GHoliDay
        {
            get { return _gHoliDay; }
            set { _gHoliDay = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public GovtHoliDayDeleteDataParameter(GovtHoliday gHoliDay)
        {
            this.GHoliDay = gHoliDay;
            BuildDeleteParameter();
        }
        public void BuildDeleteParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@GHNumber",SqlDbType.Int,4,ParameterDirection.Input,GHoliDay.GHNumber)
                                   };
            this.Param = param;
        }
    }
}
