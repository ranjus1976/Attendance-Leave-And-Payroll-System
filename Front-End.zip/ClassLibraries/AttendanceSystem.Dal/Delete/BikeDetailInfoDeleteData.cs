﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;
namespace AttendanceSystem.Dal.Delete
{
    public class BikeDetailInfoDeleteData : DataAccessBase
    {
        public BikeDetailInfoDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeDetailInfo_Delete.ToString();
        }

        public BikeDetailInfo BikeDetailInfoD { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteBikeDetailInfoD()
        {

            BikeDetailInfoDeleteDataParameter BikeDetailInfoDData = new BikeDetailInfoDeleteDataParameter(BikeDetailInfoD);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = BikeDetailInfoDData.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class BikeDetailInfoDeleteDataParameter
    {
        public BikeDetailInfoDeleteDataParameter(BikeDetailInfo bikeDetailInfo)
        {
            this.BikeDetailInfoD = bikeDetailInfo;
            BuildParameter();
        }


        public BikeDetailInfo BikeDetailInfoD { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                    DataBaseHelper.MakeParam("@EngineNo",SqlDbType.VarChar,20,ParameterDirection.Input,BikeDetailInfoD.EngineNo),
                                    DataBaseHelper.MakeParam("@ChesisNo",SqlDbType.VarChar,20,ParameterDirection.Input,BikeDetailInfoD.ChesisNo)
                                   
                                   };
            this.Param = param;
        }

    }
}
