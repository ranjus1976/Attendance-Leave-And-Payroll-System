﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class FinancialYearDeleteData : DataAccessBase
    {
        public FinancialYearDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Financial_Year_Delete.ToString();
        }

        private FinancialYear _FinancialYear;

        public FinancialYear FinancialYear
        {
            get { return _FinancialYear; }
            set { _FinancialYear = value; }
        }
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteFinancialYear()
        {
            FinancialYearDeleteDataParameter ComD = new FinancialYearDeleteDataParameter(FinancialYear);

            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = ComD.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    class FinancialYearDeleteDataParameter
    {
        FinancialYear _FinancialYear;
        public FinancialYearDeleteDataParameter(FinancialYear FinancialYear)
        {
            this._FinancialYear = FinancialYear;
            BuildParameter();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Financial_Number",SqlDbType.Int,4,ParameterDirection.Input,_FinancialYear.FinancialYearNumber)
                                   };
            this.Param = param;
        }

    }
}
