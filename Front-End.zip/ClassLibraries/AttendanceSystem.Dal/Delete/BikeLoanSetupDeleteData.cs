﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
using AttendanceSystem.Dal;

namespace AttendanceSystem.Dal.Delete
{
    public class BikeLoanSetupDeleteData: DataAccessBase
    {
        public BikeLoanSetupDeleteData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeLoanSetup_Delete.ToString();
        }

        public BikeLoanSetup BikeLoanSetupD { get; set; }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        public void DeleteBikeLoanSetupD()
        {

            BikeLoanSetupDeleteDataParameter BikeLoanSetupDData = new BikeLoanSetupDeleteDataParameter(BikeLoanSetupD);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            dbh.Parameters = BikeLoanSetupDData.Param;
            try
            {
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class BikeLoanSetupDeleteDataParameter
    {
        public BikeLoanSetupDeleteDataParameter(BikeLoanSetup BikeLoanSetupD)
        {
            this.BikeLoanSetupD = BikeLoanSetupD;
            BuildParameter();
        }


        public BikeLoanSetup BikeLoanSetupD { get; set; }



        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public void BuildParameter()
        {
            SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupD.EmpId )
                                   
                                   };
            this.Param = param;
        }

    }
}
