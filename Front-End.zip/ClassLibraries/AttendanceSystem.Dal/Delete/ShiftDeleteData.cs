﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;




namespace AttendanceSystem.Dal.Delete
{
   public class ShiftDeleteData:DataAccessBase
    {
       private Shift _sf;

       public ShiftDeleteData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Shift_Delete.ToString();
       }

       public Shift Shf
       {
           get { return _sf; }
           set { _sf = value; }
       }
       public void ShiftDelete()
       {
           ShiftDeleteParameter sdp = new ShiftDeleteParameter(Shf);
           DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
           try
           {
               dbh.Parameters = sdp.Proms;
               dbh.Run();

           }
           catch (Exception ex)
           {
               ex.Message.ToString();
 
           }
 
       }


    }

    public class ShiftDeleteParameter
    {
        private Shift _Obj;
        SqlParameter[] _proms;
        public ShiftDeleteParameter(Shift _shift)
        {
         this._Obj=_shift;
         ShiftDel();
        }
        public SqlParameter[] Proms
        {
            get{return _proms;}
            set{ _proms=value;}
        }

        void ShiftDel()
        {
            SqlParameter[] param = {
                        DataBaseHelper.MakeParam("@ShiftId",SqlDbType.Int,4,ParameterDirection.Input,_Obj.ShiftId)
                                   };
            this._proms = param;

        }


    }
}
