﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
    public class FunctionDelete : DataAccessBase
    {
        public FunctionDelete()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Function_Delete.ToString();
        }

        private Function _Funcion;

        public Function Funcion
        {
            get { return _Funcion; }
            set { _Funcion = value; }
        }
        public void DeleteFunction()
        {

            FunctionDeleteDataParameter obj_FunctionDeleteDataParameter = new FunctionDeleteDataParameter(Funcion);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = obj_FunctionDeleteDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class FunctionDeleteDataParameter
    {
        private Function _Function;

        public FunctionDeleteDataParameter(Function Function)
        {
            this._Function = Function;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Function_Number",SqlDbType.Int,4,ParameterDirection.Input,_Function.FunctionNumber),
                    DataBaseHelper.MakeParam("@Role_Number",SqlDbType.Int,4,ParameterDirection.Input,_Function.RoleNumber)
                };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }
}
