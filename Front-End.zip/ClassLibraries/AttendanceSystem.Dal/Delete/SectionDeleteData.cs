using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Delete
{
   public class SectionDeleteData:DataAccessBase 
    {
       public SectionDeleteData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Section_Delete.ToString();
       }

       private Section _Sect;


       public Section Sect
       {
           get { return _Sect; }
           set { _Sect = value; }
       }

       private SqlParameter[] _param;

       public SqlParameter[] Param
       {
           get { return _param; }
           set { _param = value; }
       }

       public void DeleteSection()
       {
           
           SectionDeleteDataParameter SectD = new SectionDeleteDataParameter(Sect);
           DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
           dbh.Parameters = SectD.Param;
           try
           {
               dbh.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (dbh != null)
               {
                   dbh = null;
               }
           }
       }
    }

   class SectionDeleteDataParameter
   {
       public SectionDeleteDataParameter(Section Sect)
       {
           this._Sect = Sect;
           BuildParameter();
       }
       private Section _Sect;


       public Section Sect
       {
           get { return _Sect; }
           set { _Sect = value; }
       }

       


       private SqlParameter[] _param;

       public SqlParameter[] Param
       {
           get { return _param; }
           set { _param = value; }
       }
       public void BuildParameter()
       {
           SqlParameter[] param = { 
                                   DataBaseHelper.MakeParam("@Sect_Number",SqlDbType.Int,4,ParameterDirection.Input,Sect.SectNo)
                                   };
           this.Param = param;
       }

   }
}
