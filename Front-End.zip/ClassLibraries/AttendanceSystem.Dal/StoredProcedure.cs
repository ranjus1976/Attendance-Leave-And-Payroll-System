using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.Dal
{
    public class StoredProcedure
    {
        public enum Name
        {
            sp_Department_Add,
            sp_Department_Update,
            sp_Department_Delete,
            sp_Department_Select,

            sp_Financial_Year_Select,
            sp_Financial_Year_Update,
            sp_Financial_Year_Delete,
            sp_Financial_Year,

            sp_DayFineAdd,
            sp_DayFineDelete,
            sp_DayFineUpdate,
            sp_DayFineSelect,
            sp_SelectDayDeductByCompany,
            sp_PasswordChange,

            sp_Company_Add,
            sp_Company_Update,
            sp_Company_Delete,
            sp_Company_Select,

            sp_Remarks,
            sp_Remarks_Delete,
            sp_Remarks_Update,
            
            sp_Company_NameSelect,

            sp_Employee_Add,
            sp_Employee_Update,
            sp_Employee_Delete,
            sp_Employee_Select,
            sp_Employee_EnableDisable_Update,

            sp_Documentory_Add,
            sp_Documentory_Select,
            sp_Documentory_Delect,

            sp_LeaveApplied_Add,
            sp_Leave_Type_Add,
            sp_Leave_Type_Update,
            sp_Leave_Type_Delete,
            sp_Leave_Type_Select,
            sp_LeaveApplied_Update,
            sp_LeaveUpdate,
            sp_LeaveApprove,
            sp_LeaveApprove_Add,
            sp_LeaveDelete,
            sp_LeaveStatus_Add,
            sp_LeaveStatusUpdate,
            sp_LeaveBalanceRead,
            sp_ReadLeaveForSearch,
            sp_LeaveReadForApprovePhase,
            sp_Leave_Balance,
            sp_LeaveProcess_Add,

            sp_User_Login,
            sp_Process,

            sp_Section_Add,
            sp_Section_Select,
            sp_Section_Update,
            sp_Section_Delete,

            sp_TextData_Add,

            sp_User_Add,
            sp_User_Update,
            sp_User_Delete,
            sp_User_Select,

            sp_Role_Add,
            sp_Role_Update,
            sp_Role_Delete,
            sp_Role_Select,
            sp_Role_SelectbyRoleId,

            sp_Function_Add,
            sp_Function_Delete,
            sp_Function_Select,
            sp_Function_Update,

            sp_Shift_Add,
            sp_Shift_Update,
            sp_ShiftParameter_Select,
            sp_Shift_Delete,
            sp_Shift_Select,

            sp_Manual_Insert,
            sp_Manual_InsertAll,
            sp_Manual_InsertDept,
            sp_Manual_All,
            sp_Employee_Select_Manual,

            sp_OSD_Add, 
            sp_OSD_SelectAll, 
            sp_OSD_Update, 
            sp_OSD_Delete,

            sp_GovtHoliDay_Delete, 
            sp_GovtHoliDay_Add, 
            sp_GovtHoliDay_SelectAll, 
            sp_GovtHoliDay_Update,

            sp_Designation_Delete, 
            sp_Designation_Add, 
            sp_Designation_SelectAll, 
            sp_Designation_Update,

            sp_delete_WeeklyHoliday, 
            sp_WeeklyHoliDay_Insert, 
            sp_insertWeeklyHolidayByCursor, 

            sp_CompanyWiseWHD,

            sp_UserPermission_Insert, 
            sp_UserPermission_Function_Insert, 

            sp_JobCard, 
            sp_Employee_Monthly_Present,
            sp_Employee_Monthly_Absent, 
            sp_Employee_Monthly_Late,
            sp_Employee_Monthly_OTHour,
            sp_Employee_Monthly_Attendence,
            sp_Employee_Monthly_Summary,
            sp_Employee_Special_Information,
            sp_WHD_CheckBox, 
            sp_Employee_New_Information, 
            sp_Employee_Resign_Information, 
            sp_Leave_Information,
            sp_Leave_Balance_Report,

            sp_ComboFillForEmployee,
            sp_ComboFillForCompany,
            sp_ComboFillForDepartment,

            sp_Unrest_Condition_Insert,
            sp_Unrest_Condition_Update,
            sp_Unrest_Condition_Delete,
            sp_Unrest_Condition_Select,

            sp_Databasebackup,

            sp_SalarySlab_Add,
            sp_SalarySlab_Delete,
            sp_SalaryBreakup_Add,
            sp_MobBillAdj_Delete,
            sp_MbBillAdj_Add,
            sp_EmpWiseCBF_Add,
            sp_EmpWiseCBF_Delete,
            sp_EmpWiseCBFStart_Add,
            sp_EmpWiseCBFStart_Delete,
            sp_BikeLoanIntRate_Add,
            sp_BikeLoanInts_Delete,
            sp_BikeDetail_Add,
            sp_BikeDetailInfo_Delete,
            sp_BikeLoanSetup_Add,
            sp_BikeLoanSetup_Delete,
            sp_BikeLoanAdjAdd_Add,
            sp_EmployeeLoan_Add,
            sp_Salary_Sheet,
            sp_EmployeeLoanAdjEntry_Add,
            sp_SalaryProcess,
            sp_SalaryADj_Add,
            sp_Mobile_Bill,
            sp_Bike_Loan,
            sp_BonusProcess,
            sp_ProjectBonus,
            sp_ProjectBonusSetup,
            sp_Contract_SalaryBreakup_Add,
            sp_Project_Bonus_Report,
            sp_Bonus_Report,
            sp_IncentiveBonus_Add,
            sp_Emp_Comp_Loan_Report
        }
    }
}
