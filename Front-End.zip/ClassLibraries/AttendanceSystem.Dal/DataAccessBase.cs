using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace AttendanceSystem.Dal
{
    public class DataAccessBase
    {
        private string _StoredProcedureName;
        private String connectionString = ConfigurationManager.ConnectionStrings["WebAttendanceConnectionString"].ConnectionString.ToString();

        protected string StoredProcedureName
        {
            get { return _StoredProcedureName; }
            set { _StoredProcedureName = value; }
        }
        protected string ConnectionString
        {
            get { return connectionString; }
        }
    }
}
