﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class ProjectBonusAddData : DataAccessBase
    {
        public ProjectBonusAddData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_ProjectBonus.ToString();
        }
        public ProjectBonus ProjectBonusdata { get; set; }
        public void InsertProjectBonus()
        {
            ProjectBonusInsertDataParameter ProjectBonusParam = new ProjectBonusInsertDataParameter(ProjectBonusdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = ProjectBonusParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class ProjectBonusInsertDataParameter
    {
        private ProjectBonus ProjectBonusData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public ProjectBonusInsertDataParameter(ProjectBonus ProjectBonusDataData)
        {
            this.ProjectBonusData = ProjectBonusDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,ProjectBonusData.EmpNumber),
                            DataBaseHelper.MakeParam("@Duration",SqlDbType.Int,16,ParameterDirection.Input,ProjectBonusData.Duration),                            
                            DataBaseHelper.MakeParam("@ProjectName",SqlDbType.VarChar,50,ParameterDirection.Input,ProjectBonusData.ProjectName),
                            DataBaseHelper.MakeParam("@EffectiveDate",SqlDbType.DateTime,8,ParameterDirection.Input,ProjectBonusData.EffectiveDate),                            
                            DataBaseHelper.MakeParam("@EntryBy",SqlDbType.VarChar,50,ParameterDirection.Input,ProjectBonusData.EntryBy),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,ProjectBonusData.Action)
                                   };
            this.Param = param;
        }
    }
}
