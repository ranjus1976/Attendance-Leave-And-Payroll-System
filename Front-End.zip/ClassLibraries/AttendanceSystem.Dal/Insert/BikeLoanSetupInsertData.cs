﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class BikeLoanSetupInsertData: DataAccessBase
    {
        public BikeLoanSetupInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_BikeLoanSetup_Add.ToString();
        }
        public BikeLoanSetup BikeLoanSetupdata { get; set; }
        public void InsertBikeLoanSetup()
        {
            BikeLoanSetupInsertDataParameter BikeLoanSetupParam = new BikeLoanSetupInsertDataParameter(BikeLoanSetupdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = BikeLoanSetupParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class BikeLoanSetupInsertDataParameter
    {
        private BikeLoanSetup BikeLoanSetupData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public BikeLoanSetupInsertDataParameter(BikeLoanSetup BikeLoanSetupDataData)
        {
            this.BikeLoanSetupData = BikeLoanSetupDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@CompId",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.CompId),
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.EmpId),
                            DataBaseHelper.MakeParam("@BRegNo",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.BRegNo),
                            DataBaseHelper.MakeParam("@BTotalValue",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.BTotalValue),
                            DataBaseHelper.MakeParam("@BLoanType",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.BLoanType),
                            DataBaseHelper.MakeParam("@Duration",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.Duration),
                            DataBaseHelper.MakeParam("@Interest",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.Interest),
                            DataBaseHelper.MakeParam("@EmpParticipation",SqlDbType.Int,16,ParameterDirection.Input,BikeLoanSetupData.EmpParticipation),
                            DataBaseHelper.MakeParam("@LoanAmount",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.LoanAmount),
                            DataBaseHelper.MakeParam("@EmpInstAmt",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.EmpInstAmt),
                            DataBaseHelper.MakeParam("@TotalAmtInst",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.TotalAmtInst),
                            DataBaseHelper.MakeParam("@BLoanAmtDue",SqlDbType.Int,8,ParameterDirection.Input,BikeLoanSetupData.BLoanAmtDue),
                            DataBaseHelper.MakeParam("@AdjSatrtDate",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.AdjSatrtDate),
                            DataBaseHelper.MakeParam("@AdjEndDate",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.AdjEndDate),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,BikeLoanSetupData.Action)
                                   };
            this.Param = param;
        }
    }
}
