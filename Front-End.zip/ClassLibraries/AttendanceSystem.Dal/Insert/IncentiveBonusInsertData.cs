﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class IncentiveBonusInsertData : DataAccessBase
    {

        public IncentiveBonusInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_IncentiveBonus_Add.ToString();
        }
        public IncentiveBonus IncentiveBonusdata { get; set; }
        public void InsertIncentiveBonus()
        {
            IncentiveBonusInsertDataParameter IncentiveBonusParam = new IncentiveBonusInsertDataParameter(IncentiveBonusdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = IncentiveBonusParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class IncentiveBonusInsertDataParameter
    {
        private IncentiveBonus IncentiveBonusData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public IncentiveBonusInsertDataParameter(IncentiveBonus IncentiveBonusData)
        {
            this.IncentiveBonusData = IncentiveBonusData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@Option",SqlDbType.VarChar,10,ParameterDirection.Input,IncentiveBonusData.Option),
                            DataBaseHelper.MakeParam("@OptionId",SqlDbType.Int,16,ParameterDirection.Input,IncentiveBonusData.OptionId),
                            DataBaseHelper.MakeParam("@Log",SqlDbType.VarChar,10,ParameterDirection.Input,IncentiveBonusData.Log),
                            DataBaseHelper.MakeParam("@BonusRule",SqlDbType.Int,32,ParameterDirection.Input,IncentiveBonusData.Bonus),
                            DataBaseHelper.MakeParam("@MName",SqlDbType.VarChar,10,ParameterDirection.Input,IncentiveBonusData.Month),
                            DataBaseHelper.MakeParam("@MNumber",SqlDbType.Int,32,ParameterDirection.Input,IncentiveBonusData.MonthNumber),                            
                            DataBaseHelper.MakeParam("@Y",SqlDbType.VarChar,10,ParameterDirection.Input,IncentiveBonusData.Year),
                            DataBaseHelper.MakeParam("@Date",SqlDbType.DateTime,8,ParameterDirection.Input,IncentiveBonusData.Date),
                            DataBaseHelper.MakeParam("@Machine",SqlDbType.VarChar,20,ParameterDirection.Input,IncentiveBonusData.Machine),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,IncentiveBonusData.Action)
                                   };
            this.Param = param;
        }
    }
}
