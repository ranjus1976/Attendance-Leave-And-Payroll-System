﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class ProjectBAmountInsertData : DataAccessBase
    {
        public ProjectBAmountInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_ProjectBonusSetup.ToString();
        }
        public ProjectBAmount ProjectBAmountdata { get; set; }
        public void InsertProjectBAmount()
        {
            ProjectBAmountInsertDataParameter ProjectBonusParam = new ProjectBAmountInsertDataParameter(ProjectBAmountdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = ProjectBonusParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
     public class ProjectBAmountInsertDataParameter
    {
        private ProjectBAmount ProjectBAmountData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public ProjectBAmountInsertDataParameter(ProjectBAmount ProjectBAmountDataData)
        {
            this.ProjectBAmountData = ProjectBAmountDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@ProjectName",SqlDbType.VarChar,50,ParameterDirection.Input,ProjectBAmountData.ProjectName),
                            DataBaseHelper.MakeParam("@DesigName",SqlDbType.VarChar,50,ParameterDirection.Input,ProjectBAmountData.DesigName),
                            DataBaseHelper.MakeParam("@Amount",SqlDbType.Int,16,ParameterDirection.Input,ProjectBAmountData.Amount),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,50,ParameterDirection.Input,ProjectBAmountData.Action)
                                   };
            this.Param = param;
        }
    }
}
