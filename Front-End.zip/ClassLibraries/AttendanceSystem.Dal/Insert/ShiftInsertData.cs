﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.Dal.Insert
{
    public  class ShiftInsertData : DataAccessBase
    {
        public ShiftInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Shift_Add.ToString();
        }

        private Shift _shft;
        public Shift Shft
        {
            get { return _shft; }
            set { _shft = value; }
        }

       public void AddShift()
        {
            ShiftInsertDataParameter sip = new ShiftInsertDataParameter(Shft);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = sip.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
 
 
        }
    }


    #region DataParameter
    public class ShiftInsertDataParameter
    {
        private Shift _shft;
        private SqlParameter[] _param;
        public ShiftInsertDataParameter(Shift Shft)
        {
            this._shft = Shft;
            Build();
        }
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
    //@Shift_Number	int,
    //@ShiftId	int,
    //@ShiftName	varchar(	50),
    //@ShifIn	smalldatetime,
    //@ShifOut	datetime,
    //@ShifLate	smalldatetime,
    //@R_In		smalldatetime,
    //@R_Out	smalldatetime,
    //@R_Late	smalldatetime,
    //@BrTime	smalldatetime,
    //@Entryby	int,
    //@PC	varchar(50)
        public void Build()
        {
            try
            {
                SqlParameter[] param ={
                            DataBaseHelper.MakeParam("@SeasonId",SqlDbType.VarChar,50,ParameterDirection.Input,_shft.SeasonId),
                            DataBaseHelper.MakeParam("@Shift_Number",SqlDbType.VarChar,50,ParameterDirection.Input,_shft.Shift_Number),
                            DataBaseHelper.MakeParam("@ShiftIn",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftInTime),
                            DataBaseHelper.MakeParam("@ShiftOut",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftOutTime),
                            DataBaseHelper.MakeParam("@ShiftLate",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftLate),
                           
                            DataBaseHelper.MakeParam("@R_In",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftRamInTime),
                            DataBaseHelper.MakeParam("@R_Out",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftRamTimeOut),
                            DataBaseHelper.MakeParam("@R_Late",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.ShiftRamLateTime),
                            DataBaseHelper.MakeParam("@BrTime",SqlDbType.SmallDateTime,4,ParameterDirection.Input,_shft.BreakTime), 
                            DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,7),
                            DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,5,ParameterDirection.Input,System.Net.Dns.GetHostName())
                            };
                this._param = param;
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }


        }
        #endregion 

    }

}
