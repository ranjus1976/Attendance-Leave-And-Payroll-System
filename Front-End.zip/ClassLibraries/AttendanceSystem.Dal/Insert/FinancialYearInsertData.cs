﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core; 
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class FinancialYearInsertData : DataAccessBase
    {
        public FinancialYearInsertData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_Financial_Year.ToString(); 
       }

        private FinantialYear _FinancialYear;

        public FinantialYear FinancialYear
        {
            get { return _FinancialYear; }
            set { _FinancialYear = value; }
        }

       public void AddFinancialYear()
       {

           FinancialYearInsertDataParameter c = new FinancialYearInsertDataParameter(FinancialYear);
           DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
           try
           {
               db.Parameters = c.Param;
               db.Run();
           }
           catch (Exception e)
           {
               e.ToString();
           }
           finally
           {
               if (db != null)
                   db = null;
           }
       }

    }

    class FinancialYearInsertDataParameter

    {
        private FinantialYear _FinancialYear;

        public FinancialYearInsertDataParameter(FinantialYear FinancialYear)
        {
            this._FinancialYear = FinancialYear;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param = 
                {
                    DataBaseHelper.MakeParam("@Financial_Year",SqlDbType.VarChar,150,ParameterDirection.Input,_FinancialYear.FinYear ),
                    DataBaseHelper.MakeParam("@StartDate",SqlDbType.DateTime,8,ParameterDirection.Input,_FinancialYear.OpeningDate),  
                    DataBaseHelper.MakeParam("@EndDate",SqlDbType.DateTime,8,ParameterDirection.Input,_FinancialYear.ClosingDate ),
                    DataBaseHelper.MakeParam("@Running_Flag",SqlDbType.Bit,1,ParameterDirection.Input,_FinancialYear.ActiveBit),
                    DataBaseHelper.MakeParam("@Financial_Year_Number",SqlDbType.Int,8,ParameterDirection.Input,_FinancialYear.FinYearId),
                    DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,150,ParameterDirection.Input,_FinancialYear.Action)
                };
                this._param = param;
            }
            catch(Exception e)
            {
                e.ToString();
            }
        }
    }
}
