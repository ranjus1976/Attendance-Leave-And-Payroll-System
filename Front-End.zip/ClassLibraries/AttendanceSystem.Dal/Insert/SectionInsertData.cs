using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient;


namespace AttendanceSystem.Dal.Insert
{
  public class SectionInsertData : DataAccessBase 
    {
      public SectionInsertData()
      {
          StoredProcedureName = StoredProcedure.Name.sp_Section_Add.ToString(); 
      }

      private Section _Sect;

      public Section Sect
      {
          get { return _Sect; }
          set { _Sect = value; }
      }

      public void AddSection()
      {
          SectionInsertParameter s = new SectionInsertParameter(Sect);
          DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
          try
          {
              db.Parameters = s.Param;
              db.Run();
          }
          catch (Exception e)
          {
              e.ToString();
          }
          finally
          {
              if (db != null)
                  db = null;
          }
      }

    }
    class SectionInsertParameter
    {
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        private Section _Sect;
        void Build()
        
        {
            try
            {
                SqlParameter[] param =
                  {
                    DataBaseHelper.MakeParam("@SectId",SqlDbType.VarChar,4,ParameterDirection.Input,_Sect.SectId),
                    DataBaseHelper.MakeParam("@SectName",SqlDbType.VarChar,150,ParameterDirection.Input,_Sect.SectName),
                    DataBaseHelper.MakeParam("Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,_Sect.DeptNo),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                  };
                this._param  = param;
            }
            catch(Exception e) 
            {
                e.ToString();
            }
        }

        public SectionInsertParameter(Section Sect)
        {
            this._Sect = Sect;
            Build();
        }
    }
}
