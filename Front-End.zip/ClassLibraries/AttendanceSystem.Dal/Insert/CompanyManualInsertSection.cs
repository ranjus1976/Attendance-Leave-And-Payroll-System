﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
    public class CompanyManualInsertSection : DataAccessBase
    {
        public CompanyManualInsertSection()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Manual_InsertAll.ToString();
        }
        public void ManualInsertSection(string radioString, DateTime punchFromDate, DateTime punchToDate, DateTime punchTime, DateTime punchTimeOut, String Username)
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@strName",SqlDbType.VarChar,50,ParameterDirection.Input,radioString),
                    DataBaseHelper.MakeParam("@PunchFromDate",SqlDbType.SmallDateTime,4,ParameterDirection.Input,punchFromDate),
                    DataBaseHelper.MakeParam("@PunchToDate",SqlDbType.SmallDateTime,4,ParameterDirection.Input,punchToDate),
                    DataBaseHelper.MakeParam("@PunchTime",SqlDbType.SmallDateTime,4,ParameterDirection.Input,punchTime),
                    DataBaseHelper.MakeParam("@PunchTimeOut",SqlDbType.SmallDateTime,4,ParameterDirection.Input,punchTimeOut),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,50,ParameterDirection.Input,Username),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName())
                };
                DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
                dbh.Parameters = param;
                dbh.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
    }
}

