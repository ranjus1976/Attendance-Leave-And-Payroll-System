using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
    public class ProcessInsertData : DataAccessBase
    {
        public ProcessInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Process.ToString();
        }
        public void ProcessData(DateTime fromDate, DateTime toDate, int ID, string strID, string SeasonName, Boolean Ramadan, Boolean Unrest, Int32 CompId)
        {
            DataBaseHelper dbhelp = new DataBaseHelper(StoredProcedureName);
            try
            {
                SqlParameter[] Para = 
                {
                        DataBaseHelper.MakeParam("@dDate1",SqlDbType.DateTime,8,ParameterDirection.Input,fromDate),
                        DataBaseHelper.MakeParam("@dDate2",SqlDbType.DateTime,8,ParameterDirection.Input,toDate),
                        DataBaseHelper.MakeParam("@Criteria",SqlDbType.Int, 4, ParameterDirection.Input,ID),
                        DataBaseHelper.MakeParam("@Criteria_Name",SqlDbType.VarChar,25,ParameterDirection.Input,strID),
                        DataBaseHelper.MakeParam("@SeasonSelectedValue",SqlDbType.VarChar,25,ParameterDirection.Input,SeasonName),
                        DataBaseHelper.MakeParam("@Ramadan",SqlDbType.Bit,1,ParameterDirection.Input,Ramadan),
                        DataBaseHelper.MakeParam("@AnyUnrest",SqlDbType.Bit,1,ParameterDirection.Input,Unrest),
                        DataBaseHelper.MakeParam("@CompId",SqlDbType.Int,4,ParameterDirection.Input,CompId)
                        
                };
               
                dbhelp.Parameters = Para;
                dbhelp.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbhelp != null)
                    dbhelp = null;
            }
        }
    }
}
