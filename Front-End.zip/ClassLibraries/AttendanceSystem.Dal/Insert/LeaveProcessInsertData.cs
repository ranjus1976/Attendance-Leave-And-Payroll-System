using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using System.Data.SqlClient; 


namespace AttendanceSystem.Dal.Insert
{
  public  class LeaveProcessInsertData : DataAccessBase 
    {
      public LeaveProcessInsertData()
      {
          StoredProcedureName = StoredProcedure.Name.sp_LeaveProcess_Add.ToString(); 
      }

      private LeaveBalance _LeaveProcess;

      public LeaveBalance LeaveProcess
      {
          get { return _LeaveProcess; }
          set { _LeaveProcess = value; }
      }

      public void AddLeaveProcess()
      {
          LeaveProcessParameters oLeaveProParam = new LeaveProcessParameters(this.LeaveProcess);

          DataBaseHelper oDBhalper = new DataBaseHelper(StoredProcedureName);
          try
          {
              oDBhalper.Parameters = oLeaveProParam.Param;
              oDBhalper.Run();
          }
          catch (Exception e)
          {
              e.ToString();
          }
          finally
          {
              if (oDBhalper != null)
                  oDBhalper = null;
          }
      }

      public class LeaveProcessParameters
      {
          public LeaveProcessParameters(LeaveBalance oLeaveBalance)
          {
              this._LeaveBalance = oLeaveBalance;
              Build();
          }
          private LeaveBalance _LeaveBalance;

          private SqlParameter[] _param;

          public SqlParameter[] Param
          {
              get { return _param; }
              set { _param = value; }
          }
          void Build()
          {
              try
              {
                  //@Filter_All	varchar(10),
                  //@Filter_Dept 	varchar(10),
                  //@Filter_Sec 	varchar(10),
                  //@Filter_Emp 	int,
                  //@Comp_Name  varchar(10),
                  //@Entry_CL_Iden      int,
                  //@Entry_EL_Iden     int,
                  //@Entry_SL_Iden  int,
                  //@Leave_Year varchar(10),
                  //@Entry_CL_Type int,
                  //@Entry_EL_Type int,
                  //@Entry_SL_Type int

                  SqlParameter[] param = {
                                         DataBaseHelper.MakeParam("@Filter_Dept",SqlDbType.VarChar,10,ParameterDirection.Input,_LeaveBalance.Dept), 
                                         DataBaseHelper.MakeParam("@Filter_Sec",SqlDbType.VarChar,10,ParameterDirection.Input,_LeaveBalance.Sec),
                                         DataBaseHelper.MakeParam("@Filter_Emp",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Emp),
                                         DataBaseHelper.MakeParam("@Comp_Name",SqlDbType.VarChar,10,ParameterDirection.Input,_LeaveBalance.Comp_Name),
                                         DataBaseHelper.MakeParam("@Entry_CL_Iden",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Entry_CL_Iden),
                                         DataBaseHelper.MakeParam("@Entry_EL_Iden",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Entry_EL_Iden),
                                         DataBaseHelper.MakeParam("@Entry_SL_Iden",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Entry_SL_Iden),
                                         DataBaseHelper.MakeParam("@Leave_Year",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Leave_Year),
                                         DataBaseHelper.MakeParam("@Entry_CL_Type",SqlDbType.Int,4,ParameterDirection.Input,_LeaveBalance.Entry_CL_Type)
                                         };
                  this._param = param;
              }
              catch (Exception e)
              {
                  e.ToString();
              }
          }
      }
    }
}
