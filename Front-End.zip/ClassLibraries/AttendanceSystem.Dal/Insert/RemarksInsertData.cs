﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class RemarksInsertData:DataAccessBase
    {
        public RemarksInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Remarks.ToString();
        }
        private Remarks _Remarks;

        public Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }

        public void InsertRemarksData()
        {
            RemarksInsertDataParameter osdParam = new RemarksInsertDataParameter(Remarks);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = osdParam.Param;
                dbh.Run();
            }
            catch(Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class RemarksInsertDataParameter
    {
        private Remarks _Remarks;

        public Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public RemarksInsertDataParameter(Remarks Remarks)
        {
            this.Remarks = Remarks;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.Int,4,ParameterDirection.Input,_Remarks.EmpId),
                            DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,200,ParameterDirection.Input,_Remarks.Remarks1),
                            DataBaseHelper.MakeParam("@CurrDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Remarks.RemarksDate),
                            DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,_Remarks.PC),
                            DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,_Remarks.EntryBy),
                            DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,8,ParameterDirection.Input,_Remarks.EntryDate)
                                   };
            this.Param = param;
        }
    }
}
