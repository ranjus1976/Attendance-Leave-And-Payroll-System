﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class DesignationInsertData : DataAccessBase
    {
        public DesignationInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Designation_Add.ToString();
        }

        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }
        public void AddDesignation()
        {
            DesignationInsertDataParameter desigParam = new DesignationInsertDataParameter(Desig);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                dbh.Parameters = desigParam.Param;
                dbh.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbh != null)
                    dbh = null;
            }
        }
    }
    class DesignationInsertDataParameter
    {

        public DesignationInsertDataParameter(Designation desig)
        {
            this.Desig = desig;
            Build();
        }

        private Designation _desig;

        public Designation Desig
        {
            get { return _desig; }
            set { _desig = value; }
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@CompId",SqlDbType.Int,4,ParameterDirection.Input,Desig.Company),
                    DataBaseHelper.MakeParam("@DesigId",SqlDbType.Char,6,ParameterDirection.Input,Desig.DesigId),
                    DataBaseHelper.MakeParam("@DesigName",SqlDbType.VarChar,50,ParameterDirection.Input,Desig.DesigName),                    
                    DataBaseHelper.MakeParam("@Grade",SqlDbType.VarChar,20,ParameterDirection.Input,Desig.Grade),                    
                    DataBaseHelper.MakeParam("@Priority",SqlDbType.Int,4,ParameterDirection.Input,Desig.Priority),                                        
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,Desig.Entryby),                                        
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,Desig.PC),                                        
                    DataBaseHelper.MakeParam("@Entrydate",SqlDbType.DateTime,4,ParameterDirection.Input,Desig.Entrydate)                                        
                    
                };
                this._param = param;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
    }
}
