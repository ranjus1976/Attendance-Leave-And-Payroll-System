﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class EmpCBFStartInsertInsertInsertData: DataAccessBase
    {
        public EmpCBFStartInsertInsertInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_EmpWiseCBFStart_Add.ToString();
        }
        public EmpWiseCBFStart empwisecbfStart { get; set; }
        public void InsertEmpWiseCBFStart()
        {
            EmpWiseCBFStarttInsertDataParameter empwisecbfParam = new EmpWiseCBFStarttInsertDataParameter(empwisecbfStart);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = empwisecbfParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    class EmpWiseCBFStarttInsertDataParameter
    {
        private EmpWiseCBFStart empwisewbfStart { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public EmpWiseCBFStarttInsertDataParameter(EmpWiseCBFStart empwisewbfStartDataData)
        {
            this.empwisewbfStart = empwisewbfStartDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbfStart.EmpId),
                            DataBaseHelper.MakeParam("@EmpName",SqlDbType.VarChar,50,ParameterDirection.Input,empwisewbfStart.EmpName),
                            DataBaseHelper.MakeParam("@MonthName",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbfStart.MonthName),
                            DataBaseHelper.MakeParam("@YearName",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbfStart.YearName),
                            DataBaseHelper.MakeParam("@CbfLog",SqlDbType.Int,4,ParameterDirection.Input,empwisewbfStart.CbfLog),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,empwisewbfStart.Action)
                           
                                   };
            this.Param = param;
        }
    }
}
