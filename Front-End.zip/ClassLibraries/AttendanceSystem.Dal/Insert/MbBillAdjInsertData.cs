using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class MbBillAdjInsertData:DataAccessBase
    {
        public MbBillAdjInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_MbBillAdj_Add.ToString();
        }
        public MbBBillAdj MbBillAdjdata{get; set; }
        public void InsertMbBillAdj()
        {
            MbBillAdjInsertDataParameter mbbilladjParam = new MbBillAdjInsertDataParameter(MbBillAdjdata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = mbbilladjParam.Param;
                dbh.Run();
            }
            catch(Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class MbBillAdjInsertDataParameter
    {
        private MbBBillAdj MbBillAdjData{ get; set; }

        
        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public MbBillAdjInsertDataParameter(MbBBillAdj mbbilladjDataData)
        {
            this.MbBillAdjData = mbbilladjDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            //DataBaseHelper.MakeParam("",SqlDbType.Int,4,ParameterDirection.Input,OsdData.OSDNumber),
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,MbBillAdjData.EmpId),
                            DataBaseHelper.MakeParam("@MonthName",SqlDbType.VarChar,20,ParameterDirection.Input,MbBillAdjData.MonthName),
                            DataBaseHelper.MakeParam("@Year",SqlDbType.VarChar,20,ParameterDirection.Input,MbBillAdjData.Year),
                            DataBaseHelper.MakeParam("@MobileDeduct",SqlDbType.Float,4,ParameterDirection.Input,MbBillAdjData.MobileDeduct),
                            DataBaseHelper.MakeParam("@MonthId",SqlDbType.VarChar,20,ParameterDirection.Input,MbBillAdjData.MonthId),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,MbBillAdjData.Action),
                            DataBaseHelper.MakeParam("@MCelling",SqlDbType.Float,4,ParameterDirection.Input,MbBillAdjData.MCelling)
                                   };
            this.Param = param;
        }
    }
}
