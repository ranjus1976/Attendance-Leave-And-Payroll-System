using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class DepartmentInsertData : DataAccessBase
    {
        public DepartmentInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Department_Add.ToString();
        }
        private Department _Dept;

        public Department Dept
        {
            get { return _Dept; }
            set { _Dept = value; }
        }
        public void AddDepartment()
        {
            DepartmentInsertDataParameter d = new DepartmentInsertDataParameter(Dept);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);

            try
            {
                db.Parameters = d.Param;
                db.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }
    class DepartmentInsertDataParameter
    {
        public DepartmentInsertDataParameter(Department Dept)
        {
            this._Dept = Dept;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        private Department _Dept;

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {     
                    DataBaseHelper.MakeParam("@DeptId",SqlDbType.VarChar,4,ParameterDirection.Input,_Dept.DeptId),
                    DataBaseHelper.MakeParam("@DeptName",SqlDbType.VarChar,150,ParameterDirection.Input,_Dept.DeptName),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.Int,4,ParameterDirection.Input,1),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,4,ParameterDirection.Input,_Dept.CompNo)
                };//collection
                this._param = param;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
    }
}
