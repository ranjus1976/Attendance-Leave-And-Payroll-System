using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
   public class LeaveStatusInsertData : DataAccessBase 
    {
       public LeaveStatusInsertData ()
       {
           StoredProcedureName = StoredProcedure.Name.sp_LeaveStatus_Add.ToString();
       }

       private LeaveStatus _LeavStatus;

       public LeaveStatus LeavStatus
       {
           get { return _LeavStatus; }
           set { _LeavStatus = value; }
       }

       public void AddLeaveStatus()
       {

       }
    }
}
