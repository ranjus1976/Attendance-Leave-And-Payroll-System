﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class WeeklyHoliDayInsertData1 : DataAccessBase
    {
        public WeeklyHoliDayInsertData1()
        {
            StoredProcedureName = StoredProcedure.Name.sp_WeeklyHoliDay_Insert.ToString();
        }
        private WeeklyHoliDay1 _holiDay;

        public WeeklyHoliDay1 HoliDay
        {
            get { return _holiDay; }
            set { _holiDay = value; }
        }

        public void InsertWeeklyHoliDayData()
        {
            if (HoliDay.DeptNumber.Equals("0"))
            {
                HoliDay.DeptNumber = "-1";
            }
            HolidayInsertParameter holidayIP = new HolidayInsertParameter(this.HoliDay);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                dbh.Parameters = holidayIP.Param;
                    dbh.Run();
            }
            catch (Exception e)
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }

    public class HolidayInsertParameter
    {
        public HolidayInsertParameter(WeeklyHoliDay1 holiday)
        {
            this.Holiday = holiday;
            BuildParameter();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        private WeeklyHoliDay1 _holiday;

        public WeeklyHoliDay1 Holiday
        {
            get { return _holiday; }
            set { _holiday = value; }
        }
        public void BuildParameter()
        {
            try
            {
                SqlParameter[] param ={
                                 DataBaseHelper.MakeParam("@Comp_Number",SqlDbType.Int,4,ParameterDirection.Input,Convert.ToInt32(Holiday.CompNumber) ),
                                 DataBaseHelper.MakeParam("@Dept_Number",SqlDbType.Int,4,ParameterDirection.Input,Convert.ToInt32(Holiday.DeptNumber) ),
                                 DataBaseHelper.MakeParam("@Emp_Number",SqlDbType.Int,4,ParameterDirection.Input,Convert.ToInt32(Holiday.EmpNumber) ),
                                 DataBaseHelper.MakeParam("@WHName",SqlDbType.VarChar,50,ParameterDirection.Input,Holiday.WHName),
                                 DataBaseHelper.MakeParam("@CheckHoliDay",SqlDbType.Bit,2,ParameterDirection.Input,Holiday.CheckHoliDay),
                                 DataBaseHelper.MakeParam("@EntryBy",SqlDbType.Int,4,ParameterDirection.Input,Holiday.EntryBy),
                                 DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,4,ParameterDirection.Input,Holiday.EntryDate),
                                 DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,50,ParameterDirection.Input,Holiday.PC),
                                 };
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
    }
}