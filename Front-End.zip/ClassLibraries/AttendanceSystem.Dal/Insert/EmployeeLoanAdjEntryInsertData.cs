﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;
namespace AttendanceSystem.Dal.Insert
{
    public class EmployeeLoanAdjEntryInsertData : DataAccessBase
    {
        public EmployeeLoanAdjEntryInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_EmployeeLoanAdjEntry_Add.ToString();
        }
        public EmployeeLoanAdjEntry EmployeeLoanAdjEntrydata { get; set; }
        public void InsertEmployeeLoanAdjEntry()
        {
            EmployeeLoanAdjEntryInsertDataParameter EmployeeLoanAdjEntryParam = new EmployeeLoanAdjEntryInsertDataParameter(EmployeeLoanAdjEntrydata);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);

            try
            {
                dbh.Parameters = EmployeeLoanAdjEntryParam.Param;
                dbh.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (dbh != null)
                {
                    dbh = null;
                }
            }
        }
    }
    public class EmployeeLoanAdjEntryInsertDataParameter
    {
        private EmployeeLoanAdjEntry EmployeeLoanAdjEntryData { get; set; }


        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        public EmployeeLoanAdjEntryInsertDataParameter(EmployeeLoanAdjEntry EmployeeLoanAdjEntryDataData)
        {
            this.EmployeeLoanAdjEntryData = EmployeeLoanAdjEntryDataData;
            BuildParameters();
        }
        public void BuildParameters()
        {
            SqlParameter[] param = { 
                            DataBaseHelper.MakeParam("@EmpId",SqlDbType.VarChar,20,ParameterDirection.Input,EmployeeLoanAdjEntryData.EmpId),
                            DataBaseHelper.MakeParam("@Adjustment",SqlDbType.Int,16,ParameterDirection.Input,EmployeeLoanAdjEntryData.Adjustment),
                            DataBaseHelper.MakeParam("@PayDate",SqlDbType.DateTime,8,ParameterDirection.Input,EmployeeLoanAdjEntryData.PayDate),
                            DataBaseHelper.MakeParam("@Action",SqlDbType.VarChar,20,ParameterDirection.Input,EmployeeLoanAdjEntryData.Action)
                                   };
            this.Param = param;
        }

    }
}
