using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;

namespace AttendanceSystem.Dal.Insert
{
  public class LeaveApproveInsertData : DataAccessBase 
    {
      public LeaveApproveInsertData()
      {
          //StoredProcedureName = StoredProcedure.Name.sp_LeaveApprove_Add.ToString();
      }

      //private LeaveApprove _LeavApp;

      //public LeaveApprove LeavApp
      //{
      //    get { return _LeavApp; }
      //    set { _LeavApp = value; }
      //}

      public void AddLeaveApprove()
      {

      }
    }
}
