﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;


namespace AttendanceSystem.Dal.Insert
{
    public class EmployeeLoanInsertData : DataAccessBase
    {
        public EmployeeLoanInsertData()
       {
           StoredProcedureName = StoredProcedure.Name.sp_EmployeeLoan_Add.ToString(); 
       }
        public EmployeeLoanSetup EmployeeLoanSetupInsert { get; set; }

        public void AddEmployeeLoanSetup()
        {
            EmployeeLoanSetupInsertDataParameter EmployeeLoanSetupParam = new EmployeeLoanSetupInsertDataParameter(EmployeeLoanSetupInsert);
            DataBaseHelper dbh = new DataBaseHelper(StoredProcedureName);
            try
            {
                dbh.Parameters = EmployeeLoanSetupParam.Param;
                dbh.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (dbh != null)
                    dbh = null;
            }
        }
     private class EmployeeLoanSetupInsertDataParameter
        {

         public EmployeeLoanSetupInsertDataParameter(EmployeeLoanSetup EmployeeLoanSetupInsert)
            {
                this.EmployeeLoanSetupInsert = EmployeeLoanSetupInsert;
                Build();
            }

         public EmployeeLoanSetup EmployeeLoanSetupInsert { get; set; }
            private SqlParameter[] _param;

            public SqlParameter[] Param
            {
                get { return _param; }
                set { _param = value; }
            }

            private void Build()
            {
                try
                {
                    SqlParameter[] param =
                        {
                            DataBaseHelper.MakeParam("@EmpId", SqlDbType.VarChar, 20, ParameterDirection.Input,EmployeeLoanSetupInsert.EmpId),
                            DataBaseHelper.MakeParam("@LoanAmount", SqlDbType.Int, 16, ParameterDirection.Input,EmployeeLoanSetupInsert.LoanAmount),
                            DataBaseHelper.MakeParam("@Duration", SqlDbType.Int, 16, ParameterDirection.Input,EmployeeLoanSetupInsert.Duration),
                            DataBaseHelper.MakeParam("@Instalment", SqlDbType.Int, 8, ParameterDirection.Input,EmployeeLoanSetupInsert.Instalment),
                            DataBaseHelper.MakeParam("@ELoanSrtDate", SqlDbType.DateTime, 8,ParameterDirection.Input, EmployeeLoanSetupInsert.ELoanSrtDate),
                            DataBaseHelper.MakeParam("@ELoanEndDate", SqlDbType.DateTime, 8, ParameterDirection.Input,EmployeeLoanSetupInsert.ELoanEndDate),
                            DataBaseHelper.MakeParam("@ELLog", SqlDbType.Int, 16, ParameterDirection.Input,EmployeeLoanSetupInsert.ELLog),
                            DataBaseHelper.MakeParam("@Action", SqlDbType.VarChar,20, ParameterDirection.Input,EmployeeLoanSetupInsert.Action)



                        };
                    this._param = param;
                }
                catch (Exception ex)
                {
                    ReturningValue.rtnValue = 0;
                    ReturningValue.rtnErrorMessage = ex.Message.ToString();
                }
            }
        }
    }
   
}
