﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class LeaveTypeInsertData : DataAccessBase
    {
        public LeaveTypeInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_Leave_Type_Add.ToString();

        }
        private LeaveType _ObjLeaveType;

        public LeaveType ObjLeaveType
        {
            get { return _ObjLeaveType; }
            set { _ObjLeaveType = value; }
        }

        public void AddLeaveType()
        {
            LeaveTypeInsertDataParameter objLeaveTypeInsertDataParameter = new LeaveTypeInsertDataParameter(ObjLeaveType);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);

            try
            {
                db.Parameters = objLeaveTypeInsertDataParameter.Param;
                db.Run();
            }
            catch (Exception e)
            {
                e.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }

        }
    }
    class LeaveTypeInsertDataParameter
    {

        public LeaveTypeInsertDataParameter(LeaveType objLeaveType)
        {
            this.objLeaveType = objLeaveType;
            Build();
        }

        private LeaveType objLeaveType;
        private SqlParameter[] _param;
        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }
        void Build()
        {
            try
            {
                SqlParameter[] param =
                {     
                    DataBaseHelper.MakeParam("@LeaveTypeName",SqlDbType.VarChar,150,ParameterDirection.Input,objLeaveType.LeaveName),
                    DataBaseHelper.MakeParam("@Balance",SqlDbType.Int,4,ParameterDirection.Input,objLeaveType.LeaveBalance),
                    DataBaseHelper.MakeParam("@IsRequired",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsRequired),
                    DataBaseHelper.MakeParam("@IsFSpecific",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsFSpecific),
                    DataBaseHelper.MakeParam("@IsPaid",SqlDbType.Bit,1,ParameterDirection.Input,objLeaveType.IsPaid),
                    DataBaseHelper.MakeParam("@Entryby",SqlDbType.VarChar,150,ParameterDirection.Input,objLeaveType.EntryBy),
                    DataBaseHelper.MakeParam("@PC",SqlDbType.VarChar,150,ParameterDirection.Input,System.Net.Dns.GetHostName()),
                    DataBaseHelper.MakeParam("@EntryDate",SqlDbType.DateTime,50,ParameterDirection.Input,objLeaveType.EntryDate)
                };//collection
                this._param = param;
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
    }
}
