﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data.SqlClient;
using System.Data;

namespace AttendanceSystem.Dal.Insert
{
    public class DayDeductInsertData : DataAccessBase
    {
        public DayDeductInsertData()
        {
            StoredProcedureName = StoredProcedure.Name.sp_DayFineAdd.ToString();
        }

        private DayDeduct _DayDeduct;

        public DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }

        public void AddDayDeduct()
        {
            DayDeductInsertDataParameter c = new DayDeductInsertDataParameter(DayDeduct);
            DataBaseHelper db = new DataBaseHelper(StoredProcedureName);
            try
            {
                db.Parameters = c.Param;
                db.Run();
                ReturningValue.rtnValue = 1;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
            finally
            {
                if (db != null)
                    db = null;
            }
        }
    }

    class DayDeductInsertDataParameter
    {
        private DayDeduct _DayDeduct;

        public DayDeductInsertDataParameter(DayDeduct DayDeduct)
        {
            this._DayDeduct = DayDeduct;
            Build();
        }

        private SqlParameter[] _param;

        public SqlParameter[] Param
        {
            get { return _param; }
            set { _param = value; }
        }

        void Build()
        {
            try
            {
                SqlParameter[] param =
                {
                    DataBaseHelper.MakeParam("@Employee_Number",SqlDbType.Int,4,ParameterDirection.Input,_DayDeduct.Emp_Number),
                    DataBaseHelper.MakeParam("@FromDate",SqlDbType.DateTime,8,ParameterDirection.Input,_DayDeduct.FromDate),
                    DataBaseHelper.MakeParam("@ToDate",SqlDbType.DateTime,8,ParameterDirection.Input,_DayDeduct.ToDate ),
                    DataBaseHelper.MakeParam("@TotalDays",SqlDbType.Float,4,ParameterDirection.Input,_DayDeduct.TotalDyas),  
                    DataBaseHelper.MakeParam("@Remarks",SqlDbType.VarChar,100,ParameterDirection.Input,_DayDeduct.Remarks)
                };
                this._param = param;
            }
            catch (Exception ex)
            {
                ReturningValue.rtnValue = 0;
                ReturningValue.rtnErrorMessage = ex.Message.ToString();
            }
        }
    }
}
