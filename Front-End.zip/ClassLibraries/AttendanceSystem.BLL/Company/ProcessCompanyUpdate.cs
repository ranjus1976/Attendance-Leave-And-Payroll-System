using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessCompanyUpdate : IProcessLogic 
    {

        private Company _comp;

        public Company Comp
        {
            get { return _comp; }
            set { _comp = value; }
        }

        

        public void invoke()
        {
            CompanyUpdateData udata = new CompanyUpdateData();
            udata.Company = this._comp;
            udata.UpdateCompany(); 
        }
    }
}
