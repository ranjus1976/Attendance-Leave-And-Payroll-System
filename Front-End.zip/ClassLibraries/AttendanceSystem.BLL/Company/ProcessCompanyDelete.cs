using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL
{
  public  class ProcessCompanyDelete:IProcessLogic 
    {
      public ProcessCompanyDelete()
      { 
      }

      private Company _Comp;

      public Company Comp
      {
          get { return _Comp; }
          set { _Comp = value; }
      }

      public void invoke()
      {
          CompanyDeleteData ComD = new CompanyDeleteData();
          ComD.Comp = this.Comp;
          ComD.DeleteCompany();
      }
    }
}
