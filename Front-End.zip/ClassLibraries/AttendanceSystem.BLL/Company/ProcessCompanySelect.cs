using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessCompanySelect : IProcessLogic
    {
        public ProcessCompanySelect()
        {
        }

        private DataSet _CompanyDS;

        public DataSet CompanyDS
        {
            get { return _CompanyDS; }
            set { _CompanyDS = value; }
        }

        public void invoke()
        {
            CompanySelect comps = new CompanySelect();
            this._CompanyDS = comps.SelectCompany();
        }
    }
}
