using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;   

namespace AttendanceSystem.BLL
{
   public class ProcessSectionUpdate :IProcessLogic 
    {
        private Section _Sect;

        public Section Sect
        {
            get { return _Sect; }
            set { _Sect = value; }
        }

       public void invoke()
       {
           SectionUpdateData sudata = new SectionUpdateData();
           sudata.Sect = this._Sect;
           sudata.UpdateSection();
       }
    }

}
