using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
   public  class ProcessSectionDelete:IProcessLogic 
    {
       public ProcessSectionDelete()
      { 
      }

       private Section _Sect;

       public Section Sect
       {
           get { return _Sect; }
           set { _Sect = value; }
       }

       public void invoke()
       {
           
           SectionDeleteData SectD = new SectionDeleteData();
           SectD.Sect = this.Sect;
           SectD.DeleteSection();
       }
    }
   
}
