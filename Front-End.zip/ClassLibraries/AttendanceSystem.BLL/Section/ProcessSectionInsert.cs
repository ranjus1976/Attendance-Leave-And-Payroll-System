using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
   
namespace AttendanceSystem.BLL
{
   public class ProcessSectionInsert :IProcessLogic 
    {
        private Section _Sect;

        public Section Sect
        {
            get { return _Sect; }
            set { _Sect = value; }
        }
       public void invoke()
       {
           SectionInsertData sdata = new SectionInsertData();
           sdata.Sect = _Sect;
           sdata.AddSection();
       }
    }
}
