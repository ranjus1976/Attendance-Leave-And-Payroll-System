﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;
namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeLoanSetupDelete : IProcessLogic
    {
        public ProcessBikeLoanSetupDelete()
      {

      }

      public BikeLoanSetup BikeLoanSetupD { get; set; }
      public void invoke()
      {

          BikeLoanSetupDeleteData BikeLoanSetupD = new BikeLoanSetupDeleteData();
          BikeLoanSetupD.BikeLoanSetupD = this.BikeLoanSetupD;
          BikeLoanSetupD.DeleteBikeLoanSetupD();

         
      }
    }
}
