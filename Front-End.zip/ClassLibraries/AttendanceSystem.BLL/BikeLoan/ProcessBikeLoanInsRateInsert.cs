﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeLoanInsRateInsert : IProcessLogic
    {
        public BikeLoanIntRate bikeloanIntrate { get; set; }
        public void invoke()
        {
            BikeLoanIntRateInsertData EmpCBFStartInstData = new BikeLoanIntRateInsertData();
            EmpCBFStartInstData.BikeLoanIntRatedata = this.bikeloanIntrate;
            EmpCBFStartInstData.InsertBikeLoanIntRate();
        }
    }
}
