﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeDetailinfoDelete : IProcessLogic 
    {
        public ProcessBikeDetailinfoDelete()
      {

      }

        public BikeDetailInfo BikeDetailInfoD { get; set; }
      public void invoke()
      {

          BikeDetailInfoDeleteData BikeDetailInfoD = new BikeDetailInfoDeleteData();
          BikeDetailInfoD.BikeDetailInfoD = this.BikeDetailInfoD;
          BikeDetailInfoD.DeleteBikeDetailInfoD();

         
      }
    }
}
