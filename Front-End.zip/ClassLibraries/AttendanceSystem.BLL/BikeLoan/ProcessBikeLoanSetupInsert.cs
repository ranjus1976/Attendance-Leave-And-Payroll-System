﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeLoanSetupInsert:IProcessLogic
    {
        public BikeLoanSetup BikeLoanSetupInsert { get; set; }
        public void invoke()
        {
            BikeLoanSetupInsertData BikeLoanSetupData = new BikeLoanSetupInsertData();
            BikeLoanSetupData.BikeLoanSetupdata = this.BikeLoanSetupInsert;
            BikeLoanSetupData.InsertBikeLoanSetup();
        }

    }
}
