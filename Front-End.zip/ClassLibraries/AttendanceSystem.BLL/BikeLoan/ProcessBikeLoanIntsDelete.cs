﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;
namespace AttendanceSystem.BLL.BikeLoan
{
    public class ProcessBikeLoanIntsDelete : IProcessLogic 
    {
      public ProcessBikeLoanIntsDelete()
      {

      }

        public BikeLoanIntRate BikeLoanIntD { get; set; }
      public void invoke()
      {

          BikeLoanIntsDeleteData BikeLoanIntsD = new BikeLoanIntsDeleteData();
          BikeLoanIntsD.BikeLoanIntD = this.BikeLoanIntD;
          BikeLoanIntsD.DeleteBikeLoanIntD();

         
      }
    }

}
