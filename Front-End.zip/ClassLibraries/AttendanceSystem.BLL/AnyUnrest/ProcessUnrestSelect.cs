using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessUnrestSelect : IProcessLogic
    {
        public ProcessUnrestSelect()
        {
        }

        private DataSet _UnrestDS;

        public DataSet UnrestDS
        {
            get { return _UnrestDS; }
            set { _UnrestDS = value; }
        }

        public void invoke()
        {
            UnrestSelect unrests = new UnrestSelect();
            this._UnrestDS = unrests.SelectUnrest();
        }
    }
}
