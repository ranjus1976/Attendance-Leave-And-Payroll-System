using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert; 

namespace AttendanceSystem.BLL
{
    public class ProcessUnrestDelete : IProcessLogic
    {
        private Shift _Shift;

        public Shift Shift
        {
            get { return _Shift; }
            set { _Shift = value; }
        }
       
        public void invoke()
        {
            AnyunrestConditionDeleteData data = new AnyunrestConditionDeleteData();
            data.Shft = this._Shift;
            data.DeleteUnrestShift();
            
        }

    }
}
