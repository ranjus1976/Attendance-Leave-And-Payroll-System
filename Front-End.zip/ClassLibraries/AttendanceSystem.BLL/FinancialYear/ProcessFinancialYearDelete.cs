﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.BLL.FinancialYear
{
    class ProcessFinancialYearDelete
    {
    }
}
