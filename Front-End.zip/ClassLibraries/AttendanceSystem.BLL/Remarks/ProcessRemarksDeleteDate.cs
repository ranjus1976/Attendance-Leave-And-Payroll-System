﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Delete;
using AttendanceSystem.Core;


namespace AttendanceSystem.BLL
{
    public class ProcessRemarksDeleteDate : IProcessLogic
    {
        private AttendanceSystem.Core.Remarks _Remarks;

        public AttendanceSystem.Core.Remarks Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        public void invoke()
        {
            RemarksDeleteData data = new RemarksDeleteData();
            data.Remarks = this._Remarks;
            data.RemarksDelete();
        }
    }
}
