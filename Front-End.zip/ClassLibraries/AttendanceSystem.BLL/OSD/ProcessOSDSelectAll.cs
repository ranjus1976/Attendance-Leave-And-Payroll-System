﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessOSDSelectAll:IProcessLogic
    {
        public ProcessOSDSelectAll()
        { 
        
        }
        private DataSet _OSDDataSet;

        public DataSet OSDDataSet
        {
            get { return _OSDDataSet; }
            set { _OSDDataSet = value; }
        }

        
        public void invoke()
        {
            OSDSelectData osdData = new OSDSelectData();
            osdData.SelectOSDData();
            OSDDataSet = osdData.OSDDataSet;
        }
    }
}
