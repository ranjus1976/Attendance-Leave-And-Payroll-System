﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessOSDDelete:IProcessLogic
    {
        public ProcessOSDDelete()
        { 
        
        }
        private OSD _osdData;

        public OSD OsdData
        {
            get { return _osdData; }
            set { _osdData = value; }
        }
        public void invoke()
        {
            OSDDeleteData osdDel = new OSDDeleteData();
            osdDel.OsdData = this.OsdData;
            osdDel.DeleteOSDData();
        }
    }
}
