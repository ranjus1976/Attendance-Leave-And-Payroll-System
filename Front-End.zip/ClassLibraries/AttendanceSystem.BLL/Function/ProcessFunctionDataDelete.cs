﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessFunctionDataDelete : IProcessLogic
    {
        public ProcessFunctionDataDelete()
        {  
        }
        private AttendanceSystem.Core.Function _Function;

        public AttendanceSystem.Core.Function Function
        {
            get { return _Function; }
            set { _Function = value; }
        }
        public void invoke()
        {
            FunctionDelete obj_FunctionDelete = new FunctionDelete();
            obj_FunctionDelete.Funcion = this._Function;
            obj_FunctionDelete.DeleteFunction();
        }
    }
}
