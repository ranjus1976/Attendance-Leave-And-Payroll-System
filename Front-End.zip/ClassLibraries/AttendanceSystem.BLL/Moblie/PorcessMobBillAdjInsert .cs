using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL.Moblie
{
    public class PorcessMobBillAdjInsert : IProcessLogic
    {
        public PorcessMobBillAdjInsert()
        { 
        
        }
        public MbBBillAdj MbBillAdjBLL { get; set; }

        
        public void invoke()
        {
            MbBillAdjInsertData MbBillAdjInsert = new MbBillAdjInsertData();
            MbBillAdjInsert.MbBillAdjdata = this.MbBillAdjBLL;
            MbBillAdjInsert.InsertMbBillAdj();

         
        }
    }
}
