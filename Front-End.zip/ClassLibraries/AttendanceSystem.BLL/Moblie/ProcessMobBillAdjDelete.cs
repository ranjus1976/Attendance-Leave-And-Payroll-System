using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL.Moblie
{
    public class ProcessMobBillAdjDelete : IProcessLogic 
    {
        public ProcessMobBillAdjDelete()
      {

      }

        public MbBBillAdj MobD { get; set; }
      public void invoke()
      {

          MobBillAdjDeleteData MobBliiD = new MobBillAdjDeleteData();
          MobBliiD.Mob = this.MobD;
          MobBliiD.DeleteMob();

         
      }
    }
}
