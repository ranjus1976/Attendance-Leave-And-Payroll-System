﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
   public class ProcessLeaveApproveInsert
    {
       public ProcessLeaveApproveInsert()
       {
       }
       private LeaveApplied _LeaveApplied;


       public LeaveApplied LeaveApplied
       {
           get { return _LeaveApplied; }
           set { _LeaveApplied = value; }
       }

       public void invoke()
       {
           LeaveApproveUpdate oUpdate = new LeaveApproveUpdate();
           oUpdate.Leave_Applied = _LeaveApplied;
           oUpdate.ApproveLeaveApply();
       }

    }
}
