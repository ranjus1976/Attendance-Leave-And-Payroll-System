﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessEmployeeLEaveUpdate
    {

        public ProcessEmployeeLEaveUpdate()
        {

        }



        private LeaveApplied _LeaveApplly;

        public LeaveApplied LeaveApplly
        {
            get { return _LeaveApplly; }
            set { _LeaveApplly = value; }
        }


        public void invoke()
        {


            LeaveApplyUpdate oLeaveUpdate = new LeaveApplyUpdate();
            oLeaveUpdate.Leave_Applied = this.LeaveApplly;
            oLeaveUpdate.AddLeaveApply();

        }

    }


}
