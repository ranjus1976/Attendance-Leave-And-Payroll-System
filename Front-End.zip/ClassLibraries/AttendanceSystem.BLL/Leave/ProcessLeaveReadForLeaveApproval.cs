﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;
using System.Data;
using System.Data.SqlClient;

namespace AttendanceSystem.BLL
{
   public class ProcessLeaveReadForLeaveApproval
    {
       public ProcessLeaveReadForLeaveApproval()
       {
       }

       private DataSet _LeaveApproveDS;

       public DataSet LeaveApproveDS
       {
           get { return _LeaveApproveDS; }
           set { _LeaveApproveDS = value; }
       }

       private LeaveApplied _LeaveApplied;

       public LeaveApplied LeaveApplied
       {
           get { return _LeaveApplied; }
           set { _LeaveApplied = value; }
       }
       public void invoke()
       {
           //LeaveStatusRead oRead = new LeaveStatusRead();
           //oRead.LeaveBalance = this.LeaveBalance;
           //this.LeaveBalanceDS = oRead.GetBalanceStatus();
           LeaveApprovalRead oApprovalRead = new LeaveApprovalRead();
           oApprovalRead.LeaveApplied = this.LeaveApplied;
           this.LeaveApproveDS = oApprovalRead.SelectLeaveDataForApproval();

       }

    }
}
