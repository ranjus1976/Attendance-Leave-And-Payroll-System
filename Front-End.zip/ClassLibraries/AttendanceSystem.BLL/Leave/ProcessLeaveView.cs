﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessLeaveView
    {

        public ProcessLeaveView()
        {
        }


        //SqlParameter

        private Object[] _ProcedureParams;

        public Object[] ProcedureParams
        {
            get { return _ProcedureParams; }
            set { _ProcedureParams = value; }
        }


        private DataSet _LeaveDS;

        public DataSet LeaveDS
        {
            get { return _LeaveDS; }
            set { _LeaveDS = value; }
        }

        public void invoke()
        {
            EmployeeLeaveEntrySelect oLeaves = new EmployeeLeaveEntrySelect();
            oLeaves.MakeParameter(this.ProcedureParams);
            this._LeaveDS = oLeaves.GetLeaveDataForView();

        }

    }


}
