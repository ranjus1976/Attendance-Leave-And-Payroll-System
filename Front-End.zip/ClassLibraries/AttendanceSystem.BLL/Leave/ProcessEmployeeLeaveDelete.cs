﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessEmployeeLeaveDelete
    {

        public ProcessEmployeeLeaveDelete()
        {
        }
        private LeaveApplied _LeaveApplly;

        public LeaveApplied LeaveApplly
        {
            get { return _LeaveApplly; }
            set { _LeaveApplly = value; }
        }


        public void invoke()
        {

            //LeavAppliedInsertData oLeaveAppliedInsertData = new LeavAppliedInsertData();
            //oLeaveAppliedInsertData.LeavApp = this._LeaveApplly;
            //oLeaveAppliedInsertData.AddLeavApplied();

            LeaveDeleteData oLeaveDeleteData = new LeaveDeleteData();
            oLeaveDeleteData.Leave_Applied = this.LeaveApplly;
            oLeaveDeleteData.AddLeaveAppliedDeleteParameter();


        }


    }
}
