﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessRoleDataDelete : IProcessLogic
    {
       public ProcessRoleDataDelete()
        {  
        }

       private AttendanceSystem.Core.Role _Role;

       public AttendanceSystem.Core.Role Role
       {
           get { return _Role; }
           set { _Role = value; }
       }

      public void invoke()
      {
          RoleDelete obj_RoleDelete = new RoleDelete();
          obj_RoleDelete.Role = this.Role;
          obj_RoleDelete.DeleteRole();
      }
    }
}
