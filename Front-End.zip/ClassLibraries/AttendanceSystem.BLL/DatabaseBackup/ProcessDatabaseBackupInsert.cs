using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert; 

namespace AttendanceSystem.BLL
{
    public class ProcessDatabaseBackupInsert : IProcessLogic
    {
        private DatabaseBackup _DatabaseBackup;

        public DatabaseBackup DatabaseBackup
        {
            get { return _DatabaseBackup; }
            set { _DatabaseBackup = value; }
        }
        public void invoke()
        {
            DatabaseBackupInsertData data = new DatabaseBackupInsertData();
            data.DatabaseBackup = this._DatabaseBackup;
            data.AddDatabaseBack();
            
        }

    }
}
