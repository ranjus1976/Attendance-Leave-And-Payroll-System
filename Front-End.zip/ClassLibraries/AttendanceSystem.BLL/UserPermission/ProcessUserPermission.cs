﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert; 

namespace AttendanceSystem.BLL
{
    public class ProcessUserPermission : IProcessLogic
    {
        private AttendanceSystem.Core.UserPermission _UserPermission;

        public AttendanceSystem.Core.UserPermission UserPermission
        {
            get { return _UserPermission; }
            set { _UserPermission = value; }
        }

        public void invoke()
        {
            UserPermissionInsert obj_UserPermissionInsert = new UserPermissionInsert();
            obj_UserPermissionInsert.UserPermission = this._UserPermission;
            obj_UserPermissionInsert.AddUserPermission();

        }
    }
}
