﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessUserPermissionFunction : IProcessLogic
    {
        private AttendanceSystem.Core.UserPermission _UserPermission;

        public AttendanceSystem.Core.UserPermission UserPermission
        {
            get { return _UserPermission; }
            set { _UserPermission = value; }
        }

        public void invoke()
        {
            UserPermissionFunctionInsert obj_UserPermissionFunctionInsert = new UserPermissionFunctionInsert();
            obj_UserPermissionFunctionInsert.UserPermission = this._UserPermission;
            obj_UserPermissionFunctionInsert.AddUserPermissionFunction();

        }
    }
}
