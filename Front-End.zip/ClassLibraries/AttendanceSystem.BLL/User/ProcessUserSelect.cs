﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using System.Data;
using AttendanceSystem.Dal.Select;
    

namespace AttendanceSystem.BLL
{
    public class ProcessUserSelect:IProcessLogic
    {
        private DataSet _selUsr;
        public ProcessUserSelect()
        {
 
        }
        public DataSet SelUsr
        {
            get {return  _selUsr; }
            set { _selUsr = value; }
        }
        public void invoke()
        {
            UserSelectData usd = new UserSelectData();
            this.SelUsr = usd.SelectUserList();
            
        }

    }
}
