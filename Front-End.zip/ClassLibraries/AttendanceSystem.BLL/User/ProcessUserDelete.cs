﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL
{
    public class ProcessUserDelete:IProcessLogic
    {
        private User _ur;
        public User Ur
        {
            get { return _ur; }
            set { _ur = value; }
        }
        public void invoke()
        {
            UserDeleteData udd=new UserDeleteData();
            udd.Usr = this.Ur;
            udd.DeleteUser();
        }
    }
}
