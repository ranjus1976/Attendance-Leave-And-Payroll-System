﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
   public class ProcessUserUpdate:IProcessLogic
    {
       private User _userUp;

       public User userUp
       {
           get { return _userUp; }
           set { _userUp = value; }
       }
       public void invoke()
       {
           UserUpdateData uup = new UserUpdateData();
           uup.UsrUp =this._userUp;
           uup.UserUpdate();
 
       }

    }
}
