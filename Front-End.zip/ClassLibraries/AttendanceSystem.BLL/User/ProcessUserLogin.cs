﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
   public  class ProcessUserLogin
   {
       public ProcessUserLogin()
       { 
       }
       public void invoke( string userLogin, string userPass)
       {
           
           //UserLoginSelectData ulsd = new UserLoginSelectData();
           //ulsd.LoginCheck(userLogin, userPass);          
          
       }

       public bool ValidUser(string userLogin, string userPass)
       {
           UserLoginSelectData ulsd = new UserLoginSelectData();
           ulsd.LoginCheck(userLogin, userPass);

           if (ulsd.userName.Length > 0)
           {
               if (ulsd.userName == userLogin && ulsd.userPassword == userPass)
               {
                   return true;
               }
               else
                   return false;
           }
           else
               return false;
       }

   }
}
