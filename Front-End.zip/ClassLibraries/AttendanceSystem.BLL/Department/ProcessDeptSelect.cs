﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;


namespace AttendanceSystem.BLL
{
    public class ProcessDeptSelect:IProcessLogic
    {
        
        public ProcessDeptSelect()
        {

        }
        private DataSet _dept;
       
        public DataSet Dept
        {
            get { return _dept; }
            set { _dept = value; }
        }
        public void invoke()
        {
            DeptSelectData dsd = new DeptSelectData();
            this.Dept = dsd.DeptSelect();
         }
    }
}
