using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;


namespace AttendanceSystem.BLL
{
  public  class ProcessDepartmentDelete:IProcessLogic 
    {
      public ProcessDepartmentDelete()
      {

      }

      private Department _Dept;


      public Department Dept
      {
          get { return _Dept; }
          set { _Dept = value; }
      }

      public void invoke()
      {
          
          DepartmentDeleteData DeptD = new DepartmentDeleteData();
          DeptD.Dept = this.Dept;
          DeptD.DeleteDepartment();

         
      }
    }
}
