﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessDayDeductInsertData : IProcessLogic
    {
        private AttendanceSystem.Core.DayDeduct _DayDeduct;

        public AttendanceSystem.Core.DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        public void invoke()
        {
            DayDeductInsertData data = new DayDeductInsertData();
            data.DayDeduct = this._DayDeduct;
            data.AddDayDeduct();
        }
    }
}
