﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessDayDeductDeleteData : IProcessLogic
    {
        public ProcessDayDeductDeleteData()
        {
        }

        private AttendanceSystem.Core.DayDeduct _DayDeduct;

        public AttendanceSystem.Core.DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        public void invoke()
        {
            DayDeductDeleteData DayD = new DayDeductDeleteData();
            DayD.DayDeduct = this._DayDeduct;
            DayD.DeleteDayDeduct();
        }
    }
}
