﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessDayDeductUpdateData : IProcessLogic
    {
        private AttendanceSystem.Core.DayDeduct _DayDeduct;

        public AttendanceSystem.Core.DayDeduct DayDeduct
        {
            get { return _DayDeduct; }
            set { _DayDeduct = value; }
        }
        public void invoke()
        {
            DayDeductUpdateData udata = new DayDeductUpdateData();
            udata.DayDeduct = this._DayDeduct;
            udata.UpdateDayDeduct();
        }
    }
}
