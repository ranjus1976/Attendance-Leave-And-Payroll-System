﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Select;

namespace AttendanceSystem.BLL
{
    public class ProcessDayDeductSelectData : IProcessLogic
    {
        public ProcessDayDeductSelectData()
        {
        }

        private DataSet _DayDeductDS;

        public DataSet DayDeductDS
        {
            get { return _DayDeductDS; }
            set { _DayDeductDS = value; }
        }
        public void invoke()
        {
            DayDeductSelectData objDayDeductSelectData = new DayDeductSelectData();
            this._DayDeductDS = objDayDeductSelectData.SelectDayDeduct();
        }
    }
}
