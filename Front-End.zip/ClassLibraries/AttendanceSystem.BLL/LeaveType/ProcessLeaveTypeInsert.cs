﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Dal.Insert;
using AttendanceSystem.Core;

namespace AttendanceSystem.BLL
{
    public class ProcessLeaveTypeInsert : IProcessLogic
    {
        private AttendanceSystem.Core.LeaveType _LeaveType;
        public AttendanceSystem.Core.LeaveType LeaveType
        {
            get { return _LeaveType; }
            set { _LeaveType = value; }
        }
        public void invoke()
        {
            LeaveTypeInsertData objLeaveTypeInsertData = new LeaveTypeInsertData();
            objLeaveTypeInsertData.ObjLeaveType = this._LeaveType;
            objLeaveTypeInsertData.AddLeaveType();
        }
    }
}
