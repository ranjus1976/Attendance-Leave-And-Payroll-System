﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Update;

namespace AttendanceSystem.BLL
{
    public class ProcessEmployeeEnableDisableUpdate : IProcessLogic
    {
        private Employee _empUp;
        public ProcessEmployeeEnableDisableUpdate()
       { }
       public Employee EmpUp
       {
           get { return _empUp; }
           set { _empUp = value; }
       }
       public void invoke()
       {
           EmployeeEnableDisableUpdate empdata = new EmployeeEnableDisableUpdate();
           empdata.Emp = this._empUp;
           empdata.UpdateEnableDisableEmployee();
           
       }
    }
}
