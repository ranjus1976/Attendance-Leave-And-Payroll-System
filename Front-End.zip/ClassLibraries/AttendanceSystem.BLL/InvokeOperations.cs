using System;
using System.Collections.Generic;
using System.Text;

namespace AttendanceSystem.BLL
{
   public class InvokeOperations
    {
       public enum Name
       {
           insert,
           update,
           select,
           delete,
           transaction
       }
    }
}
