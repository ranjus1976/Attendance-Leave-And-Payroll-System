﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL.CBF
{
   public  class ProcessEmpWiseCBF : IProcessLogic
    {
        public EmpWiseCBF EmpCBF { get; set; }
        public void invoke()
        {
            EmpWiseCBFInsertData empwisecbfInstData = new EmpWiseCBFInsertData();
            empwisecbfInstData.empwisecbf = this.EmpCBF;
            empwisecbfInstData.InsertEmpWiseCBF();
        }
    }
}
