﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;
namespace AttendanceSystem.BLL
{
    public class ProcessSalarySlabInsert :IProcessLogic
    {
        public SalarySlab salarySlab { get; set; }
        public void invoke()
        {
            SalarySlabInsertData desigInstData = new SalarySlabInsertData();
            desigInstData.Slab = this.salarySlab;
            desigInstData.AddAddSalarySlab();
        }
    }
}
