﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessSalarySlabDelete :IProcessLogic 
    {
        public ProcessSalarySlabDelete()
        {
        }

        public SalarySlab slab { get; set; }
        public void invoke()
        {

            SalarySlabDeleteData SlabD = new SalarySlabDeleteData();
            SlabD.slab = this.slab;
            SlabD.DeleteSalarySlab();


        }
    }

   
}
