﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL.CBF
{
   public class ProcessEmpWiseCBFStartDelete : IProcessLogic 
    {
       public ProcessEmpWiseCBFStartDelete()
      {

      }

        public EmpWiseCBFStart EMPCBFDStart { get; set; }
      public void invoke()
      {

          EmpWiseCBFStartDeleteData EmpCbfStartD = new EmpWiseCBFStartDeleteData();
          EmpCbfStartD.EmpCbfStart = this.EMPCBFDStart;
          EmpCbfStartD.DeleteEmpCbf();

         
      }
    }
}
