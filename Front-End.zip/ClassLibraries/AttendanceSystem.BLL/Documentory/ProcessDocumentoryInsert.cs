﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
   public class ProcessDocumentoryInsert:IProcessLogic
    {
        private Documentory _Doc;

        public Documentory Doc
        {
            get { return _Doc; }
            set { _Doc = value; }
        }

        public void invoke()
        {
            DocumentoryInsertData dData = new DocumentoryInsertData();
            dData.Doc = this._Doc;
            dData.AddDocumentory();
        }
    }
}
