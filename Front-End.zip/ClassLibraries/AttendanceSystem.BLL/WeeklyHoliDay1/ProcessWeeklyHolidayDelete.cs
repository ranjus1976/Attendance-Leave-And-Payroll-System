﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.BLL;
using AttendanceSystem.Dal.Delete;

namespace AttendanceSystem.BLL
{
    public class ProcessWeeklyHolidayDelete:IProcessLogic
    {
        private WeeklyHoliDay1 _holiday;

        public WeeklyHoliDay1 Holiday
        {
            get { return _holiday; }
            set { _holiday = value; }
        }
        public void invoke()
        {
            //ProcessWeeklyHolidayDelete processDelete = new ProcessWeeklyHolidayDelete();
            WeeklyHolidayDeleteData delData = new WeeklyHolidayDeleteData();
            delData.HoliDay = this.Holiday;
            //delData.Holiday = this.Holiday;
            delData.DeleteWeeklyHoliday();
        }
    }
}
