﻿using System;
using System.Collections.Generic;
using System.Text;
using AttendanceSystem.Core;
using AttendanceSystem.Dal.Insert;

namespace AttendanceSystem.BLL
{
    public class ProcessWeeklyHoliDayInsert1:IProcessLogic
    {
        public ProcessWeeklyHoliDayInsert1()
        { 
        
        }
        private WeeklyHoliDay1 _holiDay;

        public WeeklyHoliDay1 HoliDay
        {
            get { return _holiDay; }
            set { _holiDay = value; }
        }
        public void invoke()
        {
            WeeklyHoliDayInsertData1 holiDayInsertData = new WeeklyHoliDayInsertData1();
            holiDayInsertData.HoliDay = this.HoliDay;
            holiDayInsertData.InsertWeeklyHoliDayData();
        }
        
    }
}
